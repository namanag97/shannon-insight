//! Operation contracts owned by `SAN-COMPILER-PACK-EXPANSION`.

pub trait PackExpansionContracts {
    /// `pack-expansion.pack-release.verify`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_pack_releases(
        &self,
        arg0: &crate::catalog_types::pack_expansion::SelectedPackReleaseSet,
        arg1: &crate::catalog_types::pack_expansion::PackTrustPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::pack_expansion::VerifiedPackReleaseSet, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.invocation.collect`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn collect_bound_pack_invocations(
        &self,
        arg0: &crate::vertical::BoundDeclarationGraph,
        arg1: &crate::catalog_types::pack_expansion::VerifiedPackReleaseSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::pack_expansion::BoundPackInvocationSet, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.dependency.plan`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_pack_expansion(
        &self,
        arg0: &crate::catalog_types::pack_expansion::VerifiedPackReleaseSet,
        arg1: &crate::catalog_types::pack_expansion::BoundPackInvocationSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::pack_expansion::PackExpansionPlan, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.invocation.expand`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn expand_pack_invocation(
        &self,
        arg0: &crate::catalog_types::pack_expansion::BoundPackInvocation,
        arg1: &crate::catalog_types::pack_expansion::PackExpansionPlan,
        arg2: crate::catalog_types::decision_resolution::PackDecisionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::pack_expansion::ExpandedPackInvocation, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.expansion.expand-all`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn expand_all_packs(
        &self,
        arg0: &crate::catalog_types::pack_expansion::BoundPackInvocationSet,
        arg1: &crate::catalog_types::pack_expansion::PackExpansionPlan,
        arg2: crate::catalog_types::decision_resolution::PackDecisionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::pack_expansion::PackExpansionOutcome, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.symbols.derive`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_hygienic_symbols(
        &self,
        arg0: &crate::catalog_types::pack_expansion::BoundPackInvocation,
        arg1: &crate::catalog_types::pack_expansion::GeneratedSymbolTemplateSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::pack_expansion::GeneratedSymbolPlan, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.expansion.verify`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_expanded_contributions(
        &self,
        arg0: &crate::vertical::ExpandedContributionSet,
        arg1: &crate::catalog_types::pack_expansion::PackExpansionPlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::pack_expansion::PackExpansionProof, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.checkpoint.create`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_pack_decision_checkpoint(
        &self,
        arg0: &crate::catalog_types::decision_resolution::PackDecisionState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionCheckpoint, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.checkpoint.resume`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_pack_decision(
        &self,
        arg0: &crate::catalog_types::decision_resolution::PackDecisionCheckpoint,
        arg1: &crate::catalog_types::decision_resolution::PackDecisionInput,
        arg2: crate::catalog_types::decision_resolution::PackDecisionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionOutcome, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.delta.classify`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_pack_decision_delta(
        &self,
        arg0: &crate::catalog_types::decision_resolution::PackDecisionClosure,
        arg1: &crate::catalog_types::decision_resolution::PackDecisionClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionDelta, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

    /// `pack-expansion.explain`. Owner: `SAN-COMPILER-PACK-EXPANSION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_pack_decision(
        &self,
        arg0: crate::catalog_types::decision_resolution::PackDecisionExplainTarget,
        arg1: &crate::catalog_types::decision_resolution::PackDecisionOutcome,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionExplanation, crate::vertical::PackExpansionRefusal, crate::waist::CompilerNeedsInput>;

}
