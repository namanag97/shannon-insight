
//! Facet- and contract-driven reference compiler.
//! Generic operations never dispatch on registry-family names or physical-provider names.
#![allow(clippy::result_large_err)]

use crate::canonical::{commit_parts, CanonicalCommitment};
use crate::model::*;
use crate::proof::*;
use std::collections::{BTreeMap, BTreeSet, VecDeque};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Refusal {
    InvalidContribution,
    PackageLockMismatch,
    SourceAuthorityMissing,
    FacetOwnerMismatch,
    DuplicateReleaseOccurrence,
    SupplierInventoryIncomplete {
        missing_release: OccurrenceId,
        missing_role: String,
    },
    DuplicateSupplierRole {
        release: OccurrenceId,
        role: String,
    },
    SupplierReleaseNotSelected {
        release: OccurrenceId,
    },
    MissingOffer {
        requirement: RequirementId,
    },
    AmbiguousOffer {
        requirement: RequirementId,
        candidate_count: usize,
    },
    UnresolvedDecision {
        requirement: RequirementId,
    },
    CardinalityMismatch {
        requirement: RequirementId,
        selected: usize,
        minimum: usize,
        maximum: usize,
    },
    SelfSatisfiedExternalRequirement {
        requirement: RequirementId,
    },
    UnclosedObligation {
        obligation: ObligationId,
    },
    UnknownObligationDependency {
        obligation: ObligationId,
        dependency: ObligationId,
    },
    CyclicObligationWithoutProgress,
    EmptySemanticGraph,
    DuplicateGraphOccurrence {
        occurrence: OccurrenceId,
    },
    UnknownGraphEndpoint {
        edge: OccurrenceId,
        endpoint: OccurrenceId,
    },
    InvalidHyperedgeCardinality {
        edge: OccurrenceId,
    },
    AuthorityCycle,
    EmptyPortableIntermediateRepresentationPortfolio,
    DuplicatePortableIntermediateRepresentationOccurrence {
        occurrence: OccurrenceId,
    },
    UnsupportedIrFeature {
        module: OccurrenceId,
        capability: CapabilityId,
    },
    IncapableTarget {
        capability: CapabilityId,
    },
    TranslationValidatorNotIndependent,
    TranslationArtifactCoverageMismatch,
    MissingRuntimeImplementation {
        requirement: RuntimeRequirementId,
    },
    DuplicateRuntimeImplementation {
        requirement: RuntimeRequirementId,
    },
    NonPortableRuntimeImplementation {
        implementation: ImplementationId,
    },
    EnvironmentLeakageIntoExecutionBinding {
        implementation: ImplementationId,
        fields: Vec<String>,
    },
    BlockingGap {
        gap: GapId,
    },
    GapDispositionIncomplete,
    MissingReplayDependency {
        occurrence: OccurrenceId,
    },
    DifferentPackageLockReplay,
    IncrementalCleanBuildMismatch,
    ReleaseOccurrenceSubstitution,
    EmptyDeploymentPlan,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Exhaustion {
    SupplierInventoryBudgetExhausted,
    ContributionAdmissionBudgetExhausted,
    OfferMatchingBudgetExhausted,
    ObligationClosureBudgetExhausted,
    GraphAdmissionBudgetExhausted,
    TargetNegotiationBudgetExhausted,
    TargetLoweringBudgetExhausted,
    TranslationValidationBudgetExhausted,
    RuntimeBindingBudgetExhausted,
    ReplayVerificationBudgetExhausted,
    IncrementalEquivalenceBudgetExhausted,
    DeploymentPlanningBudgetExhausted,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CompileFailure {
    Refused(Refusal),
    Exhausted(Exhaustion),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct WorkBudget {
    limit: u64,
    consumed: u64,
}

impl WorkBudget {
    pub fn new(limit: u64) -> Self {
        Self { limit, consumed: 0 }
    }

    pub fn limit(&self) -> u64 {
        self.limit
    }

    pub fn consumed(&self) -> u64 {
        self.consumed
    }

    fn consume(&mut self, units: u64, exhaustion: Exhaustion) -> Result<(), CompileFailure> {
        let next = self
            .consumed
            .checked_add(units)
            .ok_or_else(|| CompileFailure::Exhausted(exhaustion.clone()))?;
        if next > self.limit {
            return Err(CompileFailure::Exhausted(exhaustion));
        }
        self.consumed = next;
        Ok(())
    }
}

#[derive(Clone, Debug)]
pub struct CompilerVerifier {
    verifier: VerifierId,
}

impl CompilerVerifier {
    pub fn new(verifier: VerifierId) -> Self {
        Self { verifier }
    }

    pub fn verifier_id(&self) -> &VerifierId {
        &self.verifier
    }

    fn nonce(&self, label: &str, commitment: CanonicalCommitment) -> CanonicalCommitment {
        commit_owned(vec![
            label.as_bytes().to_vec(),
            self.verifier.as_str().as_bytes().to_vec(),
            commitment.as_bytes().to_vec(),
        ])
    }

    pub fn issue_authority(
        &self,
        owner: SovereignOwner,
        contract: ContractId,
        source_occurrence: OccurrenceId,
        package_lock: &PackageLock,
    ) -> AuthorityWitness {
        let nonce = commit_owned(vec![
            owner.as_str().as_bytes().to_vec(),
            contract.as_str().as_bytes().to_vec(),
            source_occurrence.as_str().as_bytes().to_vec(),
            package_lock.commitment.as_bytes().to_vec(),
        ]);
        AuthorityWitness::issue(
            owner,
            contract,
            source_occurrence,
            package_lock.commitment,
            self.verifier.clone(),
            nonce,
        )
    }

    pub fn admit_contribution(
        &self,
        envelope: &ContributionEnvelope,
        _projection: &ClassProjection,
        package_lock: &PackageLock,
        mut budget: WorkBudget,
    ) -> Result<AdmissionProof, CompileFailure> {
        if envelope.package_lock_commitment != package_lock.commitment {
            return Err(CompileFailure::Refused(Refusal::PackageLockMismatch));
        }
        if envelope.source_authority.as_str().is_empty() {
            return Err(CompileFailure::Refused(Refusal::SourceAuthorityMissing));
        }
        if envelope.declared_budget_ceiling == 0 || envelope.facet_kinds.is_empty() {
            return Err(CompileFailure::Refused(Refusal::InvalidContribution));
        }
        let units = 16u64
            .checked_add(envelope.declared_operations.len() as u64)
            .and_then(|value| value.checked_add(envelope.declared_decisions.len() as u64))
            .and_then(|value| value.checked_add(envelope.facet_kinds.len() as u64))
            .ok_or(CompileFailure::Exhausted(
                Exhaustion::ContributionAdmissionBudgetExhausted,
            ))?;
        budget.consume(units, Exhaustion::ContributionAdmissionBudgetExhausted)?;

        let result = commit_owned(vec![
            envelope.occurrence.as_str().as_bytes().to_vec(),
            envelope.canonical_commitment.as_bytes().to_vec(),
            package_lock.commitment.as_bytes().to_vec(),
        ]);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.contribution-admission"),
            budget.limit(),
            budget.consumed(),
            envelope.canonical_commitment,
            result,
        );
        Ok(AdmissionProof::issue(
            envelope.occurrence.clone(),
            envelope.canonical_commitment,
            package_lock.commitment,
            envelope.facet_kinds.iter().copied().collect(),
            receipt,
            self.verifier.clone(),
            self.nonce("admission", result),
        ))
    }

    pub fn close_supplier_inventory(
        &self,
        package_lock: &PackageLock,
        dispositions: &[SupplierDisposition],
        mut budget: WorkBudget,
    ) -> Result<Stage0SupplierInventoryClosure, CompileFailure> {
        let selected_release_count = package_lock.selected_releases.len();
        let expected = selected_release_count
            .checked_mul(ALL_SUPPLIER_ROLE_NAMES.len())
            .ok_or(CompileFailure::Exhausted(
                Exhaustion::SupplierInventoryBudgetExhausted,
            ))?;
        budget.consume(
            expected as u64,
            Exhaustion::SupplierInventoryBudgetExhausted,
        )?;

        let mut selected = BTreeSet::new();
        for release in &package_lock.selected_releases {
            if !selected.insert(release.occurrence.clone()) {
                return Err(CompileFailure::Refused(Refusal::DuplicateReleaseOccurrence));
            }
        }

        let mut actual = BTreeSet::new();
        for disposition in dispositions {
            if !selected.contains(&disposition.release_occurrence) {
                return Err(CompileFailure::Refused(
                    Refusal::SupplierReleaseNotSelected {
                        release: disposition.release_occurrence.clone(),
                    },
                ));
            }
            let pair = (
                disposition.release_occurrence.clone(),
                disposition.role.name().to_owned(),
            );
            if !actual.insert(pair.clone()) {
                return Err(CompileFailure::Refused(Refusal::DuplicateSupplierRole {
                    release: pair.0,
                    role: pair.1,
                }));
            }
        }

        for release in &package_lock.selected_releases {
            for role in ALL_SUPPLIER_ROLE_NAMES {
                if !actual.contains(&(release.occurrence.clone(), role.to_owned())) {
                    return Err(CompileFailure::Refused(
                        Refusal::SupplierInventoryIncomplete {
                            missing_release: release.occurrence.clone(),
                            missing_role: role.to_owned(),
                        },
                    ));
                }
            }
        }
        if actual.len() != expected {
            return Err(CompileFailure::Refused(Refusal::SupplierInventoryIncomplete {
                missing_release: package_lock.selected_releases[0].occurrence.clone(),
                missing_role: "unknown-extra-or-missing-pair".to_owned(),
            }));
        }

        let mut parts = vec![package_lock.commitment.as_bytes().to_vec()];
        for (release, role) in &actual {
            parts.push(release.as_str().as_bytes().to_vec());
            parts.push(role.as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.stage0-supplier-closure"),
            budget.limit(),
            budget.consumed(),
            package_lock.commitment,
            commitment,
        );
        Ok(Stage0SupplierInventoryClosure::issue(
            package_lock.occurrence.clone(),
            package_lock.commitment,
            package_lock
                .selected_releases
                .iter()
                .map(|release| release.occurrence.clone())
                .collect(),
            actual.len(),
            ALL_SUPPLIER_ROLE_NAMES.len(),
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("supplier-closure", commitment),
        ))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn bind_application(
        &self,
        package_lock: &PackageLock,
        supplier_closure: &Stage0SupplierInventoryClosure,
        requirements: &[RequirementContribution],
        offers: &[OfferContribution],
        decisions: &[SelectionDecision],
        mut budget: WorkBudget,
    ) -> Result<ApplicationBinding, CompileFailure> {
        let comparisons = requirements
            .len()
            .checked_mul(offers.len())
            .ok_or(CompileFailure::Exhausted(
                Exhaustion::OfferMatchingBudgetExhausted,
            ))?;
        budget.consume(comparisons as u64, Exhaustion::OfferMatchingBudgetExhausted)?;

        let requirement_ids: BTreeSet<_> = requirements
            .iter()
            .map(|requirement| requirement.requirement_id.clone())
            .collect();
        if requirement_ids.len() != requirements.len() {
            return Err(CompileFailure::Refused(Refusal::UnresolvedDecision {
                requirement: requirements[0].requirement_id.clone(),
            }));
        }
        let offer_ids: BTreeSet<_> = offers.iter().map(|offer| offer.offer_id.clone()).collect();
        if offer_ids.len() != offers.len() {
            return Err(CompileFailure::Refused(Refusal::AmbiguousOffer {
                requirement: requirements[0].requirement_id.clone(),
                candidate_count: offers.len(),
            }));
        }

        let decision_map: BTreeMap<_, _> = decisions
            .iter()
            .map(|decision| (decision.requirement.clone(), decision))
            .collect();
        if decision_map.len() != decisions.len() {
            return Err(CompileFailure::Refused(Refusal::UnresolvedDecision {
                requirement: decisions[0].requirement.clone(),
            }));
        }

        for requirement in requirements {
            let all_matching: Vec<_> = offers
                .iter()
                .filter(|offer| {
                    offer.offered_for == requirement.requirement_id
                        && offer.contract == requirement.contract
                })
                .collect();
            if all_matching
                .iter()
                .any(|offer| offer.owner == requirement.owner)
            {
                return Err(CompileFailure::Refused(
                    Refusal::SelfSatisfiedExternalRequirement {
                        requirement: requirement.requirement_id.clone(),
                    },
                ));
            }
            if all_matching.is_empty() {
                return Err(CompileFailure::Refused(Refusal::MissingOffer {
                    requirement: requirement.requirement_id.clone(),
                }));
            }
            let decision = decision_map.get(&requirement.requirement_id).ok_or_else(|| {
                CompileFailure::Refused(Refusal::UnresolvedDecision {
                    requirement: requirement.requirement_id.clone(),
                })
            })?;
            if decision.selected_offers.len() < requirement.cardinality.minimum
                || decision.selected_offers.len() > requirement.cardinality.maximum
            {
                return Err(CompileFailure::Refused(Refusal::CardinalityMismatch {
                    requirement: requirement.requirement_id.clone(),
                    selected: decision.selected_offers.len(),
                    minimum: requirement.cardinality.minimum,
                    maximum: requirement.cardinality.maximum,
                }));
            }
            if all_matching.len() > requirement.cardinality.maximum
                && decision.considered_offers.len() != all_matching.len()
            {
                return Err(CompileFailure::Refused(Refusal::AmbiguousOffer {
                    requirement: requirement.requirement_id.clone(),
                    candidate_count: all_matching.len(),
                }));
            }
            let candidates: BTreeSet<_> = all_matching
                .iter()
                .map(|offer| offer.offer_id.clone())
                .collect();
            if decision
                .selected_offers
                .iter()
                .any(|offer| !candidates.contains(offer))
            {
                return Err(CompileFailure::Refused(Refusal::UnresolvedDecision {
                    requirement: requirement.requirement_id.clone(),
                }));
            }
        }

        let mut parts = vec![
            package_lock.commitment.as_bytes().to_vec(),
            supplier_closure.commitment().as_bytes().to_vec(),
        ];
        for decision in decisions {
            parts.push(decision.occurrence.as_str().as_bytes().to_vec());
            parts.push(decision.basis_commitment.as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.application-binding"),
            budget.limit(),
            budget.consumed(),
            package_lock.commitment,
            commitment,
        );
        Ok(ApplicationBinding::issue(
            package_lock.commitment,
            supplier_closure.commitment(),
            requirements
                .iter()
                .map(|requirement| requirement.occurrence.clone())
                .collect(),
            offers.iter().map(|offer| offer.occurrence.clone()).collect(),
            decisions.to_vec(),
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("application-binding", commitment),
        ))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn close_obligations(
        &self,
        package_lock: &PackageLock,
        application_binding: &ApplicationBinding,
        obligations: &[ObligationContribution],
        rule_edition: RuleEdition,
        schema_edition: SchemaEdition,
        mut budget: WorkBudget,
    ) -> Result<ObligationClosure, CompileFailure> {
        if obligations.is_empty() {
            return Err(CompileFailure::Refused(Refusal::UnclosedObligation {
                obligation: fixed_obligation("obligation.missing.non-empty-fixed-point"),
            }));
        }
        let edge_count: usize = obligations.iter().map(|item| item.depends_on.len()).sum();
        let work = obligations
            .len()
            .checked_add(edge_count)
            .ok_or(CompileFailure::Exhausted(
                Exhaustion::ObligationClosureBudgetExhausted,
            ))?;
        budget.consume(work as u64, Exhaustion::ObligationClosureBudgetExhausted)?;

        let mut by_id = BTreeMap::new();
        for obligation in obligations {
            if obligation.discharge_evidence.is_none() {
                return Err(CompileFailure::Refused(Refusal::UnclosedObligation {
                    obligation: obligation.obligation_id.clone(),
                }));
            }
            by_id.insert(obligation.obligation_id.clone(), obligation);
        }
        let mut indegree: BTreeMap<ObligationId, usize> = obligations
            .iter()
            .map(|item| (item.obligation_id.clone(), 0))
            .collect();
        let mut outgoing: BTreeMap<ObligationId, Vec<ObligationId>> = BTreeMap::new();
        for obligation in obligations {
            for dependency in &obligation.depends_on {
                if !by_id.contains_key(dependency) {
                    return Err(CompileFailure::Refused(
                        Refusal::UnknownObligationDependency {
                            obligation: obligation.obligation_id.clone(),
                            dependency: dependency.clone(),
                        },
                    ));
                }
                *indegree
                    .get_mut(&obligation.obligation_id)
                    .expect("obligation inserted") += 1;
                outgoing
                    .entry(dependency.clone())
                    .or_default()
                    .push(obligation.obligation_id.clone());
            }
        }
        let mut queue: VecDeque<_> = indegree
            .iter()
            .filter_map(|(id, degree)| (*degree == 0).then_some(id.clone()))
            .collect();
        let mut visited = 0usize;
        while let Some(id) = queue.pop_front() {
            visited += 1;
            if let Some(targets) = outgoing.get(&id) {
                for target in targets {
                    let degree = indegree.get_mut(target).expect("target inserted");
                    *degree -= 1;
                    if *degree == 0 {
                        queue.push_back(target.clone());
                    }
                }
            }
        }
        if visited != obligations.len() {
            return Err(CompileFailure::Refused(
                Refusal::CyclicObligationWithoutProgress,
            ));
        }

        let mut parts = vec![
            package_lock.commitment.as_bytes().to_vec(),
            application_binding.commitment().as_bytes().to_vec(),
            rule_edition.as_str().as_bytes().to_vec(),
            schema_edition.as_str().as_bytes().to_vec(),
        ];
        for obligation in obligations {
            parts.push(obligation.occurrence.as_str().as_bytes().to_vec());
            parts.push(
                obligation
                    .discharge_evidence
                    .as_ref()
                    .expect("checked")
                    .as_str()
                    .as_bytes()
                    .to_vec(),
            );
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.obligation-closure"),
            budget.limit(),
            budget.consumed(),
            application_binding.commitment(),
            commitment,
        );
        Ok(ObligationClosure::issue(
            package_lock.commitment,
            application_binding.commitment(),
            obligations.to_vec(),
            obligations.len() as u64,
            rule_edition,
            schema_edition,
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("obligation-closure", commitment),
        ))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn admit_csag(
        &self,
        package_lock: &PackageLock,
        application_binding: &ApplicationBinding,
        obligation_closure: &ObligationClosure,
        nodes: &[HostileGraphNode],
        edges: &[HostileHyperedge],
        mut budget: WorkBudget,
    ) -> Result<Csag, CompileFailure> {
        if nodes.is_empty() || edges.is_empty() {
            return Err(CompileFailure::Refused(Refusal::EmptySemanticGraph));
        }
        let endpoint_count: usize = edges.iter().map(|edge| edge.endpoints.len()).sum();
        let units = nodes
            .len()
            .checked_add(edges.len())
            .and_then(|value| value.checked_add(endpoint_count))
            .ok_or(CompileFailure::Exhausted(
                Exhaustion::GraphAdmissionBudgetExhausted,
            ))?;
        budget.consume(units as u64, Exhaustion::GraphAdmissionBudgetExhausted)?;

        let mut occurrences = BTreeSet::new();
        for node in nodes {
            if !occurrences.insert(node.occurrence.clone()) {
                return Err(CompileFailure::Refused(
                    Refusal::DuplicateGraphOccurrence {
                        occurrence: node.occurrence.clone(),
                    },
                ));
            }
        }
        let node_occurrences = occurrences.clone();
        for edge in edges {
            if !occurrences.insert(edge.occurrence.clone()) {
                return Err(CompileFailure::Refused(
                    Refusal::DuplicateGraphOccurrence {
                        occurrence: edge.occurrence.clone(),
                    },
                ));
            }
            if edge.endpoints.len() < 2 {
                return Err(CompileFailure::Refused(
                    Refusal::InvalidHyperedgeCardinality {
                        edge: edge.occurrence.clone(),
                    },
                ));
            }
            for endpoint in &edge.endpoints {
                if !node_occurrences.contains(endpoint) {
                    return Err(CompileFailure::Refused(Refusal::UnknownGraphEndpoint {
                        edge: edge.occurrence.clone(),
                        endpoint: endpoint.clone(),
                    }));
                }
            }
        }
        if authority_cycle(nodes, edges) {
            return Err(CompileFailure::Refused(Refusal::AuthorityCycle));
        }

        let mut parts = vec![
            package_lock.commitment.as_bytes().to_vec(),
            application_binding.commitment().as_bytes().to_vec(),
            obligation_closure.commitment().as_bytes().to_vec(),
        ];
        let mut ordered_nodes = nodes.to_vec();
        ordered_nodes.sort_by(|left, right| left.occurrence.cmp(&right.occurrence));
        let mut ordered_edges = edges.to_vec();
        ordered_edges.sort_by(|left, right| left.occurrence.cmp(&right.occurrence));
        for node in &ordered_nodes {
            parts.push(node.occurrence.as_str().as_bytes().to_vec());
            parts.push(node.semantic_commitment.as_bytes().to_vec());
        }
        for edge in &ordered_edges {
            parts.push(edge.occurrence.as_str().as_bytes().to_vec());
            parts.push(edge.semantic_commitment.as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.csag-admission"),
            budget.limit(),
            budget.consumed(),
            application_binding.commitment(),
            commitment,
        );
        Ok(Csag::issue(
            package_lock.commitment,
            application_binding.commitment(),
            obligation_closure.commitment(),
            ordered_nodes,
            ordered_edges,
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("csag", commitment),
        ))
    }

    pub fn seal_ir_portfolio(
        &self,
        csag: &Csag,
        modules: &[PortableIrContribution],
    ) -> Result<PortableIrPortfolio, CompileFailure> {
        if modules.is_empty() {
            return Err(CompileFailure::Refused(
                Refusal::EmptyPortableIntermediateRepresentationPortfolio,
            ));
        }
        let mut occurrences = BTreeSet::new();
        for module in modules {
            if !occurrences.insert(module.occurrence.clone()) {
                return Err(CompileFailure::Refused(
                    Refusal::DuplicatePortableIntermediateRepresentationOccurrence {
                        occurrence: module.occurrence.clone(),
                    },
                ));
            }
        }
        let mut ordered = modules.to_vec();
        ordered.sort_by(|left, right| left.occurrence.cmp(&right.occurrence));
        let mut parts = vec![csag.commitment().as_bytes().to_vec()];
        for module in &ordered {
            parts.push(module.occurrence.as_str().as_bytes().to_vec());
            parts.push(module.canonical_commitment.as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        Ok(PortableIrPortfolio::issue(
            csag.commitment(),
            ordered,
            commitment,
            self.verifier.clone(),
            self.nonce("ir-portfolio", commitment),
        ))
    }

    pub fn negotiate_target(
        &self,
        portfolio: &PortableIrPortfolio,
        target: &TargetDescriptor,
        mut budget: WorkBudget,
    ) -> Result<TargetCapabilityNegotiation, CompileFailure> {
        let required: BTreeSet<_> = portfolio
            .modules()
            .iter()
            .flat_map(|module| module.required_capabilities.iter().cloned())
            .collect();
        budget.consume(
            required.len() as u64,
            Exhaustion::TargetNegotiationBudgetExhausted,
        )?;
        for module in portfolio.modules() {
            for capability in &module.required_capabilities {
                if !target.supported_capabilities.contains(capability) {
                    return Err(CompileFailure::Refused(Refusal::UnsupportedIrFeature {
                        module: module.occurrence.clone(),
                        capability: capability.clone(),
                    }));
                }
            }
        }
        let required_vec: Vec<_> = required.into_iter().collect();
        let supported_vec: Vec<_> = target.supported_capabilities.iter().cloned().collect();
        let mut parts = vec![
            portfolio.commitment().as_bytes().to_vec(),
            target.occurrence.as_str().as_bytes().to_vec(),
        ];
        for capability in &required_vec {
            parts.push(capability.as_str().as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.target-negotiation"),
            budget.limit(),
            budget.consumed(),
            portfolio.commitment(),
            commitment,
        );
        Ok(TargetCapabilityNegotiation::issue(
            target.occurrence.clone(),
            portfolio.commitment(),
            required_vec,
            supported_vec,
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("target-negotiation", commitment),
        ))
    }

    pub fn determine_target_legality(
        &self,
        negotiation: &TargetCapabilityNegotiation,
        portfolio: &PortableIrPortfolio,
    ) -> TargetLegalityReport {
        let module_occurrences: Vec<_> = portfolio
            .modules()
            .iter()
            .map(|module| module.occurrence.clone())
            .collect();
        let mut parts = vec![negotiation.commitment().as_bytes().to_vec()];
        for occurrence in &module_occurrences {
            parts.push(occurrence.as_str().as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        TargetLegalityReport::issue(
            negotiation.commitment(),
            module_occurrences,
            commitment,
            self.verifier.clone(),
            self.nonce("target-legality", commitment),
        )
    }

    pub fn lower_target(
        &self,
        legality: &TargetLegalityReport,
        portfolio: &PortableIrPortfolio,
        target: &TargetDescriptor,
        mut budget: WorkBudget,
    ) -> Result<LoweredTargetArtifactSet, CompileFailure> {
        budget.consume(
            portfolio.modules().len() as u64,
            Exhaustion::TargetLoweringBudgetExhausted,
        )?;
        let artifacts: Vec<_> = portfolio
            .modules()
            .iter()
            .map(|module| {
                let occurrence = OccurrenceId::parse(format!(
                    "lowered:{}:{}",
                    target.occurrence.as_str(),
                    module.occurrence.as_str()
                ))
                .expect("generated occurrence is valid");
                let content_commitment = commit_owned(vec![
                    legality.commitment().as_bytes().to_vec(),
                    target.occurrence.as_str().as_bytes().to_vec(),
                    module.occurrence.as_str().as_bytes().to_vec(),
                    module.canonical_commitment.as_bytes().to_vec(),
                ]);
                LoweredTargetArtifact {
                    occurrence,
                    target_occurrence: target.occurrence.clone(),
                    source_ir_occurrence: module.occurrence.clone(),
                    content_commitment,
                }
            })
            .collect();
        let mut parts = vec![legality.commitment().as_bytes().to_vec()];
        for artifact in &artifacts {
            parts.push(artifact.occurrence.as_str().as_bytes().to_vec());
            parts.push(artifact.content_commitment.as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.target-lowering"),
            budget.limit(),
            budget.consumed(),
            legality.commitment(),
            commitment,
        );
        Ok(LoweredTargetArtifactSet::issue(
            legality.commitment(),
            target.occurrence.clone(),
            artifacts,
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("target-lowering", commitment),
        ))
    }

    pub fn validate_translation(
        &self,
        lowered: &LoweredTargetArtifactSet,
        target: &TargetDescriptor,
        independent_validator: &VerifierId,
        mut budget: WorkBudget,
    ) -> Result<TranslationValidationSet, CompileFailure> {
        if independent_validator != &target.translation_validator
            || independent_validator.as_str() == target.lowering_implementation.as_str()
        {
            return Err(CompileFailure::Refused(
                Refusal::TranslationValidatorNotIndependent,
            ));
        }
        budget.consume(
            lowered.artifacts().len() as u64,
            Exhaustion::TranslationValidationBudgetExhausted,
        )?;
        let occurrences: Vec<_> = lowered
            .artifacts()
            .iter()
            .map(|artifact| artifact.occurrence.clone())
            .collect();
        if occurrences.len() != lowered.artifacts().len() {
            return Err(CompileFailure::Refused(
                Refusal::TranslationArtifactCoverageMismatch,
            ));
        }
        let mut parts = vec![
            lowered.commitment().as_bytes().to_vec(),
            independent_validator.as_str().as_bytes().to_vec(),
        ];
        for occurrence in &occurrences {
            parts.push(occurrence.as_str().as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.translation-validation"),
            budget.limit(),
            budget.consumed(),
            lowered.commitment(),
            commitment,
        );
        Ok(TranslationValidationSet::issue(
            lowered.commitment(),
            independent_validator.clone(),
            occurrences,
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("translation-validation", commitment),
        ))
    }

    pub fn close_target_compilation(
        &self,
        target: &TargetDescriptor,
        negotiation: &TargetCapabilityNegotiation,
        legality: &TargetLegalityReport,
        lowered: &LoweredTargetArtifactSet,
        validation: &TranslationValidationSet,
    ) -> TargetCompilationSet {
        let commitment = commit_owned(vec![
            target.occurrence.as_str().as_bytes().to_vec(),
            negotiation.commitment().as_bytes().to_vec(),
            legality.commitment().as_bytes().to_vec(),
            lowered.commitment().as_bytes().to_vec(),
            validation.commitment().as_bytes().to_vec(),
        ]);
        TargetCompilationSet::issue(
            target.occurrence.clone(),
            negotiation.commitment(),
            legality.commitment(),
            lowered.commitment(),
            validation.commitment(),
            commitment,
            self.verifier.clone(),
            self.nonce("target-compilation", commitment),
        )
    }

    pub fn bind_execution(
        &self,
        target_compilation: &TargetCompilationSet,
        portfolio: &PortableIrPortfolio,
        implementations: &[RuntimeImplementation],
        mut budget: WorkBudget,
    ) -> Result<ExecutionBinding, CompileFailure> {
        let required: BTreeSet<_> = portfolio
            .modules()
            .iter()
            .flat_map(|module| module.runtime_obligations.iter().cloned())
            .collect();
        let work = required
            .len()
            .checked_mul(implementations.len())
            .ok_or(CompileFailure::Exhausted(
                Exhaustion::RuntimeBindingBudgetExhausted,
            ))?;
        budget.consume(work as u64, Exhaustion::RuntimeBindingBudgetExhausted)?;

        for requirement in &required {
            let matches: Vec<_> = implementations
                .iter()
                .filter(|implementation| &implementation.requirement == requirement)
                .collect();
            if matches.is_empty() {
                return Err(CompileFailure::Refused(
                    Refusal::MissingRuntimeImplementation {
                        requirement: requirement.clone(),
                    },
                ));
            }
            if matches.len() != 1 {
                return Err(CompileFailure::Refused(
                    Refusal::DuplicateRuntimeImplementation {
                        requirement: requirement.clone(),
                    },
                ));
            }
            let implementation = matches[0];
            if !implementation.portable {
                return Err(CompileFailure::Refused(
                    Refusal::NonPortableRuntimeImplementation {
                        implementation: implementation.implementation.clone(),
                    },
                ));
            }
            if !implementation.declared_environment_fields.is_empty() {
                return Err(CompileFailure::Refused(
                    Refusal::EnvironmentLeakageIntoExecutionBinding {
                        implementation: implementation.implementation.clone(),
                        fields: implementation
                            .declared_environment_fields
                            .iter()
                            .cloned()
                            .collect(),
                    },
                ));
            }
        }

        let mut ordered = implementations.to_vec();
        ordered.sort_by(|left, right| left.requirement.cmp(&right.requirement));
        let mut parts = vec![target_compilation.commitment().as_bytes().to_vec()];
        for implementation in &ordered {
            parts.push(implementation.requirement.as_str().as_bytes().to_vec());
            parts.push(implementation.occurrence.as_str().as_bytes().to_vec());
            parts.push(
                implementation
                    .conformance_evidence
                    .as_str()
                    .as_bytes()
                    .to_vec(),
            );
        }
        let commitment = commit_owned(parts);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.execution-binding"),
            budget.limit(),
            budget.consumed(),
            target_compilation.commitment(),
            commitment,
        );
        Ok(ExecutionBinding::issue(
            target_compilation.commitment(),
            ordered,
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("execution-binding", commitment),
        ))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn close_application(
        &self,
        package_lock: &PackageLock,
        supplier_closure: &Stage0SupplierInventoryClosure,
        application_binding: &ApplicationBinding,
        obligation_closure: &ObligationClosure,
        csag: &Csag,
        portfolio: &PortableIrPortfolio,
        target_compilation: &TargetCompilationSet,
        execution_binding: &ExecutionBinding,
        gaps: &[GapDisposition],
        toolchain: ToolchainId,
    ) -> Result<ApplicationClosure, CompileFailure> {
        for gap in gaps {
            if gap.blocking {
                return Err(CompileFailure::Refused(Refusal::BlockingGap {
                    gap: gap.gap_id.clone(),
                }));
            }
        }
        let mut parts = vec![
            package_lock.occurrence.as_str().as_bytes().to_vec(),
            package_lock.commitment.as_bytes().to_vec(),
            supplier_closure.commitment().as_bytes().to_vec(),
            application_binding.commitment().as_bytes().to_vec(),
            obligation_closure.commitment().as_bytes().to_vec(),
            csag.commitment().as_bytes().to_vec(),
            portfolio.commitment().as_bytes().to_vec(),
            target_compilation.commitment().as_bytes().to_vec(),
            execution_binding.commitment().as_bytes().to_vec(),
            toolchain.as_str().as_bytes().to_vec(),
        ];
        for gap in gaps {
            parts.push(gap.gap_id.as_str().as_bytes().to_vec());
            parts.push(gap.evidence_commitment.as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        Ok(ApplicationClosure::issue(
            package_lock.occurrence.clone(),
            package_lock.commitment,
            supplier_closure.commitment(),
            application_binding.commitment(),
            obligation_closure.commitment(),
            csag.commitment(),
            portfolio.commitment(),
            target_compilation.commitment(),
            execution_binding.commitment(),
            gaps.to_vec(),
            toolchain,
            commitment,
            self.verifier.clone(),
            self.nonce("application-closure", commitment),
        ))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn package_release(
        &self,
        occurrence: OccurrenceId,
        package_lock: &PackageLock,
        closure: &ApplicationClosure,
        replay_dependencies: Vec<(ArtifactKindId, OccurrenceId, CanonicalCommitment)>,
        verifier_inventory: Vec<VerifierId>,
        toolchain: ToolchainId,
    ) -> Result<AppRelease, CompileFailure> {
        if closure.package_lock_commitment() != package_lock.commitment {
            return Err(CompileFailure::Refused(Refusal::PackageLockMismatch));
        }
        if replay_dependencies.is_empty() {
            return Err(CompileFailure::Refused(Refusal::MissingReplayDependency {
                occurrence: package_lock.occurrence.clone(),
            }));
        }
        let mut dependency_occurrences = BTreeSet::new();
        for (_, dependency_occurrence, _) in &replay_dependencies {
            if !dependency_occurrences.insert(dependency_occurrence.clone()) {
                return Err(CompileFailure::Refused(Refusal::MissingReplayDependency {
                    occurrence: dependency_occurrence.clone(),
                }));
            }
        }
        let mut parts = vec![
            occurrence.as_str().as_bytes().to_vec(),
            closure.commitment().as_bytes().to_vec(),
            package_lock.commitment.as_bytes().to_vec(),
            toolchain.as_str().as_bytes().to_vec(),
        ];
        for (_, dependency_occurrence, commitment) in &replay_dependencies {
            parts.push(dependency_occurrence.as_str().as_bytes().to_vec());
            parts.push(commitment.as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        Ok(AppRelease::issue(
            occurrence,
            closure.commitment(),
            package_lock.commitment,
            package_lock
                .selected_releases
                .iter()
                .map(|release| release.occurrence.clone())
                .collect(),
            replay_dependencies,
            verifier_inventory,
            toolchain,
            commitment,
            self.verifier.clone(),
            self.nonce("app-release", commitment),
        ))
    }

    #[allow(clippy::too_many_arguments)]
    pub fn reverify_offline(
        &self,
        release: &AppRelease,
        supplied_package_lock_commitment: CanonicalCommitment,
        available_dependency_occurrences: &BTreeSet<OccurrenceId>,
        clean_build_commitment: CanonicalCommitment,
        incremental_commitment: CanonicalCommitment,
        mut budget: WorkBudget,
    ) -> Result<OfflineReplayClosure, CompileFailure> {
        if release.package_lock_commitment() != supplied_package_lock_commitment {
            return Err(CompileFailure::Refused(
                Refusal::DifferentPackageLockReplay,
            ));
        }
        budget.consume(
            release.replay_dependencies().len() as u64,
            Exhaustion::ReplayVerificationBudgetExhausted,
        )?;
        let mut verified = Vec::new();
        for (_, occurrence, _) in release.replay_dependencies() {
            if !available_dependency_occurrences.contains(occurrence) {
                return Err(CompileFailure::Refused(Refusal::MissingReplayDependency {
                    occurrence: occurrence.clone(),
                }));
            }
            verified.push(occurrence.clone());
        }
        if clean_build_commitment != incremental_commitment {
            return Err(CompileFailure::Refused(
                Refusal::IncrementalCleanBuildMismatch,
            ));
        }
        let commitment = commit_owned(vec![
            release.occurrence().as_str().as_bytes().to_vec(),
            release.commitment().as_bytes().to_vec(),
            supplied_package_lock_commitment.as_bytes().to_vec(),
            clean_build_commitment.as_bytes().to_vec(),
        ]);
        let receipt = WorkReceipt::issue(
            fixed_coordinate("compiler.algorithm.offline-replay"),
            budget.limit(),
            budget.consumed(),
            release.commitment(),
            commitment,
        );
        Ok(OfflineReplayClosure::issue(
            release.occurrence().clone(),
            release.commitment(),
            supplied_package_lock_commitment,
            verified,
            clean_build_commitment,
            incremental_commitment,
            commitment,
            receipt,
            self.verifier.clone(),
            self.nonce("offline-replay", commitment),
        ))
    }

    pub fn bind_environment(
        &self,
        release: &AppRelease,
        input: &EnvironmentBindingInput,
    ) -> Result<EnvironmentBinding, CompileFailure> {
        if input.release_occurrence != *release.occurrence() {
            return Err(CompileFailure::Refused(
                Refusal::ReleaseOccurrenceSubstitution,
            ));
        }
        let commitment = commit_owned(vec![
            release.occurrence().as_str().as_bytes().to_vec(),
            release.commitment().as_bytes().to_vec(),
            input.occurrence.as_str().as_bytes().to_vec(),
            input.environment.as_str().as_bytes().to_vec(),
            input.region.as_bytes().to_vec(),
            input.placement.as_bytes().to_vec(),
            input.capacity_evidence.as_str().as_bytes().to_vec(),
        ]);
        Ok(EnvironmentBinding::issue(
            release.occurrence().clone(),
            release.commitment(),
            input.occurrence.clone(),
            commitment,
            self.verifier.clone(),
            self.nonce("environment-binding", commitment),
        ))
    }

    pub fn plan_deployment(
        &self,
        occurrence: OccurrenceId,
        environment_binding: &EnvironmentBinding,
        step_contracts: Vec<ContractId>,
        mut budget: WorkBudget,
    ) -> Result<DeploymentPlan, CompileFailure> {
        if step_contracts.is_empty() {
            return Err(CompileFailure::Refused(Refusal::EmptyDeploymentPlan));
        }
        budget.consume(
            step_contracts.len() as u64,
            Exhaustion::DeploymentPlanningBudgetExhausted,
        )?;
        let mut parts = vec![
            occurrence.as_str().as_bytes().to_vec(),
            environment_binding.commitment().as_bytes().to_vec(),
        ];
        for step in &step_contracts {
            parts.push(step.as_str().as_bytes().to_vec());
        }
        let commitment = commit_owned(parts);
        Ok(DeploymentPlan::issue(
            occurrence,
            environment_binding.commitment(),
            step_contracts,
            commitment,
            self.verifier.clone(),
            self.nonce("deployment-plan", commitment),
        ))
    }

    pub fn prepare_boot(
        &self,
        occurrence: OccurrenceId,
        deployment_plan: &DeploymentPlan,
        release: &AppRelease,
    ) -> BootInput {
        let commitment = commit_owned(vec![
            occurrence.as_str().as_bytes().to_vec(),
            deployment_plan.commitment().as_bytes().to_vec(),
            release.occurrence().as_str().as_bytes().to_vec(),
            release.commitment().as_bytes().to_vec(),
        ]);
        BootInput::issue(
            occurrence,
            deployment_plan.commitment(),
            release.occurrence().clone(),
            release.commitment(),
            commitment,
            self.verifier.clone(),
            self.nonce("boot-input", commitment),
        )
    }

    pub fn record_boot(
        &self,
        occurrence: OccurrenceId,
        boot_input: &BootInput,
        runtime_evidence: OccurrenceId,
        outcome: BootOutcome,
    ) -> BootReport {
        let outcome_label = match &outcome {
            BootOutcome::Booted => "booted".as_bytes().to_vec(),
            BootOutcome::Refused { reason } => reason.as_str().as_bytes().to_vec(),
        };
        let commitment = commit_owned(vec![
            occurrence.as_str().as_bytes().to_vec(),
            boot_input.commitment().as_bytes().to_vec(),
            runtime_evidence.as_str().as_bytes().to_vec(),
            outcome_label,
        ]);
        BootReport::issue(
            occurrence,
            boot_input.commitment(),
            runtime_evidence,
            outcome,
            commitment,
            self.verifier.clone(),
            self.nonce("boot-report", commitment),
        )
    }
}

fn authority_cycle(nodes: &[HostileGraphNode], edges: &[HostileHyperedge]) -> bool {
    let authority_nodes: BTreeSet<_> = nodes
        .iter()
        .filter(|node| node.kind == GraphNodeKind::Authority)
        .map(|node| node.occurrence.clone())
        .collect();
    let mut adjacency: BTreeMap<OccurrenceId, Vec<OccurrenceId>> = BTreeMap::new();
    for edge in edges {
        if edge.kind == HyperedgeKind::DelegatesAuthority && edge.endpoints.len() == 2 {
            let source = edge.endpoints[0].clone();
            let target = edge.endpoints[1].clone();
            if authority_nodes.contains(&source) && authority_nodes.contains(&target) {
                adjacency.entry(source).or_default().push(target);
            }
        }
    }
    let mut visiting = BTreeSet::new();
    let mut visited = BTreeSet::new();
    for node in &authority_nodes {
        if detect_cycle(node, &adjacency, &mut visiting, &mut visited) {
            return true;
        }
    }
    false
}

fn detect_cycle(
    node: &OccurrenceId,
    adjacency: &BTreeMap<OccurrenceId, Vec<OccurrenceId>>,
    visiting: &mut BTreeSet<OccurrenceId>,
    visited: &mut BTreeSet<OccurrenceId>,
) -> bool {
    if visited.contains(node) {
        return false;
    }
    if !visiting.insert(node.clone()) {
        return true;
    }
    if let Some(targets) = adjacency.get(node) {
        for target in targets {
            if detect_cycle(target, adjacency, visiting, visited) {
                return true;
            }
        }
    }
    visiting.remove(node);
    visited.insert(node.clone());
    false
}

fn commit_owned(parts: Vec<Vec<u8>>) -> CanonicalCommitment {
    let references: Vec<&[u8]> = parts.iter().map(Vec::as_slice).collect();
    commit_parts(&references)
}

fn fixed_coordinate(value: &'static str) -> StableCoordinate {
    StableCoordinate::parse(value).expect("fixed coordinate is valid")
}

fn fixed_obligation(value: &'static str) -> ObligationId {
    ObligationId::parse(value).expect("fixed obligation is valid")
}
