# Foundational Semantics Domain Atlas

Generated navigation only. JSON and JSONL are canonical.

## Status

- Validation: **PASS**
- Records: **7729**
- Typed relations: **2154**
- Boundary hypotheses: **131**
- Candidate bounded contexts: **21**
- Split proposals: **13**
- Merge proposals: **4**

## Research posture

The atlas was derived from external authorities and adversarial cases first. The attached SAN registry was used only afterward for non-mutating crosswalk and intake proposals.

## Context dispositions

| Disposition | Count |
|---|---:|
| `CANDIDATE_BOUNDED_CONTEXT` | 21 |
| `COMPOSITION` | 12 |
| `FOUNDATION_ALGEBRA_CANDIDATE` | 21 |
| `IMPLEMENTATION_CONCERN` | 2 |
| `OWNER_LOCAL_MODULE` | 7 |
| `PROFILE` | 13 |
| `PROOF_VERTICAL` | 1 |
| `PROVIDER_IMPLEMENTATION` | 4 |
| `PUBLICATION` | 2 |
| `REJECT_FALSE_BOUNDARY` | 3 |
| `RESOURCE_CONTRACT` | 6 |
| `RUNTIME_MECHANISM` | 1 |
| `SEMANTIC_FAMILY_CANDIDATE` | 22 |
| `SPLIT_REQUIRED` | 13 |
| `VERTICAL_CONCEPT` | 3 |

## Collections

| Kind | Count | File |
|---|---:|---|
| `ambiguous_example` | 124 | `scenarios/ambiguous_examples.jsonl` |
| `artifact` | 152 | `corpus/artifacts.jsonl` |
| `boundary_example` | 127 | `scenarios/boundary_examples.jsonl` |
| `capability` | 115 | `corpus/capabilities.jsonl` |
| `claim` | 556 | `corpus/claims.jsonl` |
| `command` | 84 | `corpus/commands.jsonl` |
| `competency_question` | 1128 | `scenarios/competency_questions.jsonl` |
| `composition` | 12 | `corpus/compositions.jsonl` |
| `concept` | 401 | `corpus/concepts.jsonl` |
| `conflict` | 19 | `issues/conflicts.jsonl` |
| `conflicting_example` | 126 | `scenarios/conflicting_examples.jsonl` |
| `context` | 131 | `corpus/contexts.jsonl` |
| `context_relationship` | 345 | `corpus/context_relationships.jsonl` |
| `contextual_meaning` | 414 | `corpus/contextual_meanings.jsonl` |
| `coverage_area` | 33 | `corpus/coverage_areas.jsonl` |
| `cross_domain_example` | 128 | `scenarios/cross_domain_examples.jsonl` |
| `disposition_entry` | 131 | `registry_intake/disposition_ledger.jsonl` |
| `entity` | 21 | `corpus/entities.jsonl` |
| `event` | 84 | `corpus/events.jsonl` |
| `evidence_source` | 86 | `corpus/evidence_sources.jsonl` |
| `gap` | 19 | `issues/gaps.jsonl` |
| `law` | 262 | `corpus/laws.jsonl` |
| `mapping` | 84 | `corpus/mappings.jsonl` |
| `merge_split_proposal` | 17 | `registry_intake/merge_split_proposals.jsonl` |
| `negative_example` | 127 | `scenarios/negative_examples.jsonl` |
| `policy` | 28 | `corpus/policies.jsonl` |
| `positive_example` | 124 | `scenarios/positive_examples.jsonl` |
| `profile` | 33 | `corpus/profiles.jsonl` |
| `query` | 42 | `corpus/queries.jsonl` |
| `refusal` | 188 | `corpus/refusals.jsonl` |
| `registry_candidate_unit` | 128 | `registry_intake/candidate_units.jsonl` |
| `registry_change_request` | 12 | `registry_intake/registry_change_requests.jsonl` |
| `registry_crosswalk` | 131 | `registry_intake/existing_record_crosswalk.jsonl` |
| `relation` | 2154 | `corpus/relations.jsonl` |
| `state` | 86 | `corpus/states.jsonl` |
| `unresolved_boundary` | 21 | `issues/unresolved_boundaries.jsonl` |
| `unresolved_reference` | 6 | `issues/unresolved_references.jsonl` |
| `value_object` | 50 | `corpus/value_objects.jsonl` |

## Highest-impact unresolved boundaries

- **Compatibility criterion owner** (`CRITICAL`): Compatibility is only meaningful for a consumer, operation set, and criterion edition.
- **Conformance versus admission** (`CRITICAL`): Validation engines assess contracts; accountable owners decide admission.
- **Identity criteria placement** (`CRITICAL`): Determine which identity assertion structure is horizontal while every subject-kind criterion remains owner-local.
- **Partial order versus causal assertion** (`CRITICAL`): Distributed happened-before and domain causation require different evidence and laws.
- **Place, boundary, and jurisdiction seam** (`CRITICAL`): Disputed places require authority-plural names, geometries, legal bases, and time.
- **Provenance versus verification** (`CRITICAL`): Origin and derivation do not own property assessment.
- **Rate, ratio, exchange, and money placement** (`CRITICAL`): Reusable mathematical operators must not absorb legal, accounting, market, or settlement semantics.
- **Time-scale, calendar, and zone composition** (`CRITICAL`): Timestamp interpretation must compose three distinct authorities and expose ambiguity.
- **Verification versus sufficiency** (`CRITICAL`): A successful assessment can remain insufficient for a particular decision.
- **Bitemporality versus correction lifecycle** (`HIGH`): Temporal axes and revision intent are related but not the same owner.
- **Claim versus observation** (`HIGH`): An observation event can generate a claim or result, but the assertion and activity remain distinct.
- **Terminology versus formal ontology profiles** (`HIGH`): ISO terminology, SKOS, OWL, foundational ontologies, and domain ontologies have overlapping but non-identical commitments.

## Navigation

- `manifest.json`: package identity, method, counts, and registry posture.
- `coverage/coverage_matrix.json`: modeled coverage and adversarial checks.
- `coverage/boundary_evaluation.json`: all twelve boundary tests.
- `coverage/registry_audit.json`: mechanical and semantic audit of the attached registry.
- `issues/`: conflicts, gaps, unresolved boundaries, and unresolved references.
- `VALIDATION.json`: validation results.
