
# SAN Cross-Registry Composition Reference Workspace

This standalone workspace models the selected contribution protocol, artifact finality and mixed-registry closure flow without modifying SAN production code.

It deliberately has no external Rust dependencies. Positive proof and authority values have private fields and verifier-only issuance paths. The generic compiler module consumes contracts, facets, capabilities and exact occurrences; it does not select behavior by registry-family or physical-provider name.

## Required gates

```bash
cargo fmt --all -- --check
cargo check --workspace --all-targets
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
RUSTDOCFLAGS="-D warnings" cargo doc --workspace --no-deps
```

The caller-proof construction fixture must fail to compile:

```bash
rustc \
  --edition=2021 \
  --extern san_composition_reference=target/debug/libsan_composition_reference.rlib \
  compile-fail/caller_constructs_proof.rs
```

`VERIFY/run.sh` performs the supported checks and records `BLOCKED_TOOLCHAIN_UNAVAILABLE` when the Rust toolchain is absent. An absent compiler is not a successful compiler test, despite the long and noble human tradition of relabeling missing evidence.
