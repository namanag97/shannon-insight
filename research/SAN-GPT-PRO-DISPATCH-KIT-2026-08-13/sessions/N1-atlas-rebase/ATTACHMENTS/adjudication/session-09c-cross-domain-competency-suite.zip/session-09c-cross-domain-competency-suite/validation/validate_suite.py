
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import pathlib
import re
import sys
from typing import Any

try:
    from jsonschema import Draft202012Validator, FormatChecker
except ImportError as exc:
    raise SystemExit("jsonschema is required: python -m pip install jsonschema") from exc

STATUS_ENUM = {"PASS", "PARTIAL", "FAIL", "NOT_APPLICABLE", "UNTESTABLE_MISSING_ARTIFACT"}
GENERIC_ESCAPE_KEYS = {
    "custom_fields", "extensions", "freeform", "generic_metadata", "generic_prose",
    "notes_blob", "opaque_payload", "payload", "properties",
}
SCHEMA_MAP = {
    "competency/questions.jsonl": "schemas/competency-question.schema.json",
    "competency/relation_requirements.jsonl": "schemas/relation-requirement.schema.json",
    "competency/ownership_expectations.jsonl": "schemas/ownership-expectation.schema.json",
    "scenarios/scenarios.jsonl": "schemas/scenario.schema.json",
    "scenarios/expected_context_maps.jsonl": "schemas/expected-context-map.schema.json",
    "scenarios/invalid_shortcuts.jsonl": "schemas/invalid-shortcut.schema.json",
    "evaluation/corpus_results.jsonl": "schemas/corpus-result.schema.json",
    "evaluation/context_results.jsonl": "schemas/context-result.schema.json",
    "evaluation/coverage_summary.json": "schemas/coverage-summary.schema.json",
    "evaluation/failure_clusters.jsonl": "schemas/failure-cluster.schema.json",
    "evaluation/uncovered_requirements.jsonl": "schemas/uncovered-requirement.schema.json",
    "manifest.json": "schemas/manifest.schema.json",
    "VALIDATION.json": "schemas/validation.schema.json",
}

def digest(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def read_json(path: pathlib.Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def read_jsonl(path: pathlib.Path) -> list[dict[str, Any]]:
    output = []
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        value = json.loads(line)
        if not isinstance(value, dict):
            raise ValueError(f"{path}:{line_number}: JSONL record is not an object")
        output.append(value)
    return output

def deep_keys(value: Any):
    if isinstance(value, dict):
        for key, nested in value.items():
            yield str(key)
            yield from deep_keys(nested)
    elif isinstance(value, list):
        for nested in value:
            yield from deep_keys(nested)

def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the Session 09C cross-domain competency suite")
    parser.add_argument("root", nargs="?", default=str(pathlib.Path(__file__).resolve().parents[1]))
    args = parser.parse_args()
    root = pathlib.Path(args.root).resolve()
    errors: list[str] = []
    checked_records = 0

    for rel, schema_rel in SCHEMA_MAP.items():
        data_path, schema_path = root / rel, root / schema_rel
        if not data_path.is_file():
            errors.append(f"missing required data file: {rel}")
            continue
        if not schema_path.is_file():
            errors.append(f"missing schema: {schema_rel}")
            continue
        schema = read_json(schema_path)
        try:
            Draft202012Validator.check_schema(schema)
        except Exception as exc:
            errors.append(f"invalid schema {schema_rel}: {exc}")
            continue
        validator = Draft202012Validator(schema, format_checker=FormatChecker())
        rows = read_jsonl(data_path) if data_path.suffix == ".jsonl" else [read_json(data_path)]
        checked_records += len(rows)
        for row_number, row in enumerate(rows, 1):
            for error in validator.iter_errors(row):
                path = "/".join(map(str, error.absolute_path))
                errors.append(f"{rel}:{row_number}:{path}: {error.message}")

    questions = read_jsonl(root / "competency/questions.jsonl")
    relations = read_jsonl(root / "competency/relation_requirements.jsonl")
    ownership = read_jsonl(root / "competency/ownership_expectations.jsonl")
    scenarios = read_jsonl(root / "scenarios/scenarios.jsonl")
    context_maps = read_jsonl(root / "scenarios/expected_context_maps.jsonl")
    shortcuts = read_jsonl(root / "scenarios/invalid_shortcuts.jsonl")
    corpus_results = read_jsonl(root / "evaluation/corpus_results.jsonl")
    context_results = read_jsonl(root / "evaluation/context_results.jsonl")
    failure_clusters = read_jsonl(root / "evaluation/failure_clusters.jsonl")
    uncovered = read_jsonl(root / "evaluation/uncovered_requirements.jsonl")
    coverage = read_json(root / "evaluation/coverage_summary.json")
    manifest = read_json(root / "manifest.json")

    qids, sids, shortcut_ids = ({q["id"] for q in questions}, {s["id"] for s in scenarios}, {s["id"] for s in shortcuts})
    if len(questions) < 150 or len(qids) != len(questions):
        errors.append(f"competency question count/uniqueness failed: {len(questions)} rows, {len(qids)} IDs")
    families = collections.Counter(q["family"] for q in questions)
    if len(families) != 35:
        errors.append(f"expected 35 question families, found {len(families)}")
    if len(scenarios) < 30 or sorted(s["scenario_number"] for s in scenarios) != list(range(1, 31)):
        errors.append("scenario sequence must contain exactly numbers 1 through 30")
    if len(shortcuts) != sum(len(s["invalid_shortcuts"]) for s in scenarios):
        errors.append("invalid shortcut record count does not match scenario inline shortcuts")
    if {r["question_id"] for r in relations} != qids:
        errors.append("relation requirements do not cover exactly the competency questions")
    if {r["question_id"] for r in ownership} != qids:
        errors.append("ownership expectations do not cover exactly the competency questions")
    if {r["scenario_id"] for r in context_maps} != sids:
        errors.append("context maps do not cover exactly the scenarios")
    for scenario in scenarios:
        if any(ref not in sids for ref in scenario["related_scenario_ids"]):
            errors.append(f"{scenario['id']}: unknown related scenario")
        if any(ref not in shortcut_ids for ref in scenario["invalid_shortcut_refs"]):
            errors.append(f"{scenario['id']}: unknown shortcut reference")
    for row in uncovered:
        if any(ref not in qids for ref in row["related_question_ids"]):
            errors.append(f"{row['id']}: unknown related question")
        if any(ref not in sids for ref in row["related_scenario_ids"]):
            errors.append(f"{row['id']}: unknown related scenario")

    corpus_ids = {s["corpus_id"] for s in manifest["source_corpora"]}
    expected_results = len(corpus_ids) * (len(questions) + len(scenarios))
    result_pairs = {(r["corpus_id"], r["test_id"]) for r in corpus_results}
    if len(corpus_results) != expected_results or len(result_pairs) != expected_results:
        errors.append(f"expected {expected_results} unique corpus-test results, found {len(corpus_results)} rows/{len(result_pairs)} pairs")
    if len(context_results) != manifest["counts"]["candidate_contexts"]:
        errors.append("context result count differs from manifest candidate context count")
    for row in corpus_results + context_results:
        if row["status"] not in STATUS_ENUM:
            errors.append(f"{row['id']}: invalid status {row['status']}")
    for row in corpus_results:
        if row["status"] == "PASS":
            if row["score"] is None or not row["hard_gates"] or not all(row["hard_gates"].values()):
                errors.append(f"{row['id']}: PASS without every hard gate")
            if row["prose_only_evidence_counted"] is not False:
                errors.append(f"{row['id']}: PASS counted prose-only evidence")

    for rel in [
        "competency/questions.jsonl", "competency/relation_requirements.jsonl",
        "competency/ownership_expectations.jsonl", "scenarios/scenarios.jsonl",
        "scenarios/expected_context_maps.jsonl", "scenarios/invalid_shortcuts.jsonl",
        "evaluation/corpus_results.jsonl", "evaluation/context_results.jsonl",
        "evaluation/failure_clusters.jsonl", "evaluation/uncovered_requirements.jsonl",
    ]:
        for row_number, row in enumerate(read_jsonl(root / rel), 1):
            hits = set(deep_keys(row)) & GENERIC_ESCAPE_KEYS
            if hits:
                errors.append(f"{rel}:{row_number}: generic escape keys {sorted(hits)}")

    # Manifest inventory intentionally excludes manifest.json and CHECKSUMS.txt to avoid self-hash cycles.
    actual_manifest_files = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.relative_to(root).as_posix() not in {"manifest.json", "CHECKSUMS.txt"}
    }
    listed_manifest_files = {row["path"] for row in manifest["files"]}
    if actual_manifest_files != listed_manifest_files:
        errors.append(f"manifest inventory mismatch: missing={sorted(actual_manifest_files-listed_manifest_files)}, extra={sorted(listed_manifest_files-actual_manifest_files)}")
    for row in manifest["files"]:
        path = root / row["path"]
        if not path.is_file():
            errors.append(f"manifest-listed file absent: {row['path']}")
        else:
            if path.stat().st_size != row["size_bytes"]:
                errors.append(f"manifest size mismatch: {row['path']}")
            if digest(path) != row["sha256"]:
                errors.append(f"manifest digest mismatch: {row['path']}")

    checksum_path = root / "CHECKSUMS.txt"
    checksum_entries = {}
    for line_number, line in enumerate(checksum_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        match = re.match(r"^([0-9a-f]{64})  (.+)$", line)
        if not match:
            errors.append(f"CHECKSUMS.txt:{line_number}: malformed line")
            continue
        checksum_entries[match.group(2)] = match.group(1)
    expected_checksum_files = {
        path.relative_to(root).as_posix()
        for path in root.rglob("*")
        if path.is_file() and path.relative_to(root).as_posix() != "CHECKSUMS.txt"
    }
    if set(checksum_entries) != expected_checksum_files:
        errors.append("CHECKSUMS.txt file coverage mismatch")
    for rel, expected in checksum_entries.items():
        if digest(root / rel) != expected:
            errors.append(f"CHECKSUMS digest mismatch: {rel}")

    expected_status_counts = collections.Counter(r["status"] for r in corpus_results)
    if dict(manifest["evaluation_status_counts"]) != {s: expected_status_counts.get(s, 0) for s in sorted(STATUS_ENUM)}:
        errors.append("manifest evaluation status counts do not match corpus results")
    if coverage["corpus_test_result_count"] != len(corpus_results):
        errors.append("coverage summary result count mismatch")

    output = {
        "status": "PASS" if not errors else "FAIL",
        "validator_version": "VAL-09C-1.0.0",
        "root": str(root),
        "schema_validated_record_count": checked_records,
        "counts": {
            "competency_questions": len(questions),
            "question_families": len(families),
            "adversarial_scenarios": len(scenarios),
            "invalid_shortcuts": len(shortcuts),
            "corpus_results": len(corpus_results),
            "context_results": len(context_results),
            "failure_clusters": len(failure_clusters),
            "uncovered_requirements": len(uncovered),
        },
        "errors": errors,
    }
    print(json.dumps(output, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if not errors else 1

if __name__ == "__main__":
    raise SystemExit(main())
