//! Types owned by `application_binding`.

use std::collections::{BTreeMap};

/// Field-complete contract model for `ApplicationBindingBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `ApplicationBindingCanonicalProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingCanonicalProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl ApplicationBindingCanonicalProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `ApplicationBindingCheckpoint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingCheckpoint {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: Vec<crate::waist::ArtifactRef>,
    work_spent: u64,
    remaining_budget: crate::waist::WorkBudget,
}

impl ApplicationBindingCheckpoint {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.completed
    }
    #[must_use]
    pub fn work_spent(&self) -> u64 {
        self.work_spent
    }
    #[must_use]
    pub fn remaining_budget(&self) -> &crate::waist::WorkBudget {
        &self.remaining_budget
    }
}

/// Field-complete contract model for `ApplicationBindingDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl ApplicationBindingDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `ApplicationBindingDispatchTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingDispatchTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl ApplicationBindingDispatchTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ApplicationBindingEvolutionRefusal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationBindingEvolutionRefusal {
    InvalidCarrier {
        field: crate::waist::FieldPath,
        reason: crate::waist::RefusalReason,
    },
    AuthorityMismatch {
        expected: crate::waist::StableId,
        actual: crate::waist::StableId,
    },
    EditionOrOccurrenceMismatch {
        subject: crate::waist::StableId,
    },
    SemanticConflict {
        subject: crate::waist::StableId,
        law: crate::waist::StableId,
    },
    Incomplete {
        missing: Vec<crate::waist::StableId>,
    },
    DescriptorDrift {
        expected: crate::waist::DigestClaim,
        actual: crate::waist::DigestClaim,
    },
}

/// Field-complete contract model for `ApplicationBindingExecutionContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingExecutionContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `ApplicationBindingExplainTarget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationBindingExplainTarget {
    Artifact {
        artifact: crate::waist::ArtifactRef,
    },
    Subject {
        subject: crate::waist::SubjectKey,
    },
    Refusal {
        refusal_id: crate::waist::StableId,
    },
}

/// Field-complete contract model for `ApplicationBindingExplanation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingExplanation {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl ApplicationBindingExplanation {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ApplicationBindingFingerprint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingFingerprint {
    subject: crate::waist::SubjectKey,
    claim: crate::waist::DigestClaim,
    source: crate::waist::ArtifactRef,
    domain: crate::waist::SeparationDomain,
}

impl ApplicationBindingFingerprint {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn claim(&self) -> &crate::waist::DigestClaim {
        &self.claim
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
}

/// Field-complete contract model for `ApplicationBindingInput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingInput {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `ApplicationBindingInputMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingInputMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `ApplicationBindingOrRefusal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationBindingOrRefusal {
    InvalidCarrier {
        field: crate::waist::FieldPath,
        reason: crate::waist::RefusalReason,
    },
    AuthorityMismatch {
        expected: crate::waist::StableId,
        actual: crate::waist::StableId,
    },
    EditionOrOccurrenceMismatch {
        subject: crate::waist::StableId,
    },
    SemanticConflict {
        subject: crate::waist::StableId,
        law: crate::waist::StableId,
    },
    Incomplete {
        missing: Vec<crate::waist::StableId>,
    },
    DescriptorDrift {
        expected: crate::waist::DigestClaim,
        actual: crate::waist::DigestClaim,
    },
}

/// Field-complete contract model for `ApplicationBindingOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationBindingOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::ApplicationBindingRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `ApplicationBindingPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `ApplicationBindingStageArtifacts`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingStageArtifacts {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ApplicationBindingTrustPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingTrustPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `ApplicationBindingVerificationContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingVerificationContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `BindingResolution`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BindingResolution {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl BindingResolution {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `CandidateOfferAssessment`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CandidateOfferAssessment {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl CandidateOfferAssessment {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `CandidateOfferSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CandidateOfferSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CandidateOfferSetMap`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CandidateOfferSetMap {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl CandidateOfferSetMap {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CanonicalContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CanonicalContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CardinalityResolution`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CardinalityResolution {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl CardinalityResolution {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `ContractHeader`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractHeader {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub owner: crate::waist::AuthorityRef,
    pub kind: crate::waist::RegistryKind,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub source: crate::waist::ArtifactRef,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ContractHeaderRegistry`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractHeaderRegistry {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl ContractHeaderRegistry {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `DeferredBindingRequirement`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeferredBindingRequirement {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub contract: crate::waist::ContractRef,
    pub cardinality: crate::waist::Cardinality,
    pub constraints: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
}

/// Field-complete contract model for `ExtensionBindingSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExtensionBindingSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ExtensionDeclarationSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExtensionDeclarationSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `GapAcceptanceDirectiveSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GapAcceptanceDirectiveSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `GapLedgerSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GapLedgerSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `GeneratedDispatchMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeneratedDispatchMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `JoinedRequirement`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JoinedRequirement {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub contract: crate::waist::ContractRef,
    pub cardinality: crate::waist::Cardinality,
    pub constraints: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
}

/// Field-complete contract model for `JoinedRequirementSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JoinedRequirementSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `RequirementCluster`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequirementCluster {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `RequirementClusterSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequirementClusterSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SelectionDirective`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionDirective {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SelectionDirectiveMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionDirectiveMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `SelectionDirectiveSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionDirectiveSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SelectionInvalidation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SelectionInvalidation {
    Declared,
    Applicable,
    Inapplicable {
        reason: crate::waist::StableId,
    },
    Blocked {
        gap: crate::waist::ArtifactRef,
    },
}

/// Field-complete contract model for `SelectionProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl SelectionProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `SelectionRequest`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionRequest {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SemanticOfferIndex`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticOfferIndex {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl SemanticOfferIndex {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `StructuralCandidateSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StructuralCandidateSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `VerifiedLinkSources`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VerifiedLinkSources {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl VerifiedLinkSources {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}
