//! Types owned by `name_binding`.

use std::collections::{BTreeMap, BTreeSet};

/// Field-complete contract model for `AliasBindingSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AliasBindingSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `AliasDeclarationSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AliasDeclarationSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CandidateSymbolSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CandidateSymbolSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CompatibilityPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompatibilityPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CompilerNamePolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompilerNamePolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CompilerNamePolicyMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompilerNamePolicyMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `ExportRegistry`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExportRegistry {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl ExportRegistry {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ImportBindingSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ImportBindingSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ImportDeclarationSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ImportDeclarationSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `NameBindingBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NameBindingBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `NameBindingCheckpoint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NameBindingCheckpoint {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: Vec<crate::waist::ArtifactRef>,
    work_spent: u64,
    remaining_budget: crate::waist::WorkBudget,
}

impl NameBindingCheckpoint {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.completed
    }
    #[must_use]
    pub fn work_spent(&self) -> u64 {
        self.work_spent
    }
    #[must_use]
    pub fn remaining_budget(&self) -> &crate::waist::WorkBudget {
        &self.remaining_budget
    }
}

/// Field-complete contract model for `NameBindingContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NameBindingContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `NameBindingDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NameBindingDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl NameBindingDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `NameBindingOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NameBindingOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::NameBindingRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `NameBindingState`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NameBindingState {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl NameBindingState {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `NameExplainTarget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NameExplainTarget {
    Artifact {
        artifact: crate::waist::ArtifactRef,
    },
    Subject {
        subject: crate::waist::SubjectKey,
    },
    Refusal {
        refusal_id: crate::waist::StableId,
    },
}

/// Field-complete contract model for `NameExplanation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NameExplanation {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl NameExplanation {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `PoisonedReferenceBinding`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PoisonedReferenceBinding {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl PoisonedReferenceBinding {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `ReferenceBinding`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceBinding {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl ReferenceBinding {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `ReferenceResolutionProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceResolutionProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl ReferenceResolutionProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ReferenceSite`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceSite {
    pub source: crate::waist::ArtifactRef,
    pub span: crate::waist::SourceSpan,
    pub kind: crate::waist::StableId,
    pub lexeme: String,
}

/// Field-complete contract model for `RenameBindingSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RenameBindingSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `RenameDeclarationSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RenameDeclarationSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ScopeGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScopeGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl ScopeGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `SelectedReleaseSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectedReleaseSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `StableSymbol`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StableSymbol {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SymbolCollisionSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SymbolCollisionSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SymbolTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SymbolTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl SymbolTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `UnresolvedNameRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UnresolvedNameRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `VisibilityProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VisibilityProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl VisibilityProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}
