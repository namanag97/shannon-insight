//! Types owned by `semantic_migration`.

use std::collections::{BTreeMap, BTreeSet};

/// Field-complete contract model for `CoexistencePlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CoexistencePlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl CoexistencePlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CompatibilityMatrix`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompatibilityMatrix {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl CompatibilityMatrix {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CompatibilityQuestion`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompatibilityQuestion {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CompatibilityRuling`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompatibilityRuling {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl CompatibilityRuling {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `ConversionPlanSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConversionPlanSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CorrespondenceDirectiveMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CorrespondenceDirectiveMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `CorrespondenceHeuristicPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CorrespondenceHeuristicPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CorrespondenceProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CorrespondenceProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl CorrespondenceProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `CorrespondenceProposalSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CorrespondenceProposalSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CorrespondenceSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CorrespondenceSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CsagPair`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagPair {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `DiffDispatchTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiffDispatchTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl DiffDispatchTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyReleasePair`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyReleasePair {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilySemanticDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilySemanticDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl FamilySemanticDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `HistoricalInterpretationPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HistoricalInterpretationPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl HistoricalInterpretationPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ImpactGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ImpactGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl ImpactGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `InFlightPortableMigrationPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InFlightPortableMigrationPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl InFlightPortableMigrationPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `InventoryConditionPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InventoryConditionPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `InventoryConditionedCompatibility`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InventoryConditionedCompatibility {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `InventoryProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct InventoryProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl InventoryProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ManualAdjudicationQueue`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ManualAdjudicationQueue {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `MigrationBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `MigrationCanonicalProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationCanonicalProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl MigrationCanonicalProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `MigrationCapabilityRequirementSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationCapabilityRequirementSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `MigrationCheckpoint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationCheckpoint {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: Vec<crate::waist::ArtifactRef>,
    work_spent: u64,
    remaining_budget: crate::waist::WorkBudget,
}

impl MigrationCheckpoint {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.completed
    }
    #[must_use]
    pub fn work_spent(&self) -> u64 {
        self.work_spent
    }
    #[must_use]
    pub fn remaining_budget(&self) -> &crate::waist::WorkBudget {
        &self.remaining_budget
    }
}

/// Field-complete contract model for `MigrationExecutionContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationExecutionContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `MigrationExplainTarget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum MigrationExplainTarget {
    Artifact {
        artifact: crate::waist::ArtifactRef,
    },
    Subject {
        subject: crate::waist::SubjectKey,
    },
    Refusal {
        refusal_id: crate::waist::StableId,
    },
}

/// Field-complete contract model for `MigrationExplanation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationExplanation {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl MigrationExplanation {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `MigrationExplanationGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationExplanationGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl MigrationExplanationGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `MigrationGateSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationGateSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `MigrationImpactGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationImpactGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl MigrationImpactGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `MigrationInput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationInput {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `MigrationInputMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationInputMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `MigrationPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `MigrationProofManifest`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationProofManifest {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `MigrationRecipeCatalog`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationRecipeCatalog {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl MigrationRecipeCatalog {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `MigrationRecipeDirectiveSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationRecipeDirectiveSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `MigrationSeal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationSeal {
    identity: crate::waist::StableId,
    owner: crate::waist::AuthorityRef,
    edition: crate::waist::Edition,
    kind: crate::waist::StableId,
    members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl MigrationSeal {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn edition(&self) -> &crate::waist::Edition {
        &self.edition
    }
    #[must_use]
    pub fn kind(&self) -> &crate::waist::StableId {
        &self.kind
    }
    #[must_use]
    pub fn members(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::ScalarValue> {
        &self.members
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `MigrationStageArtifacts`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationStageArtifacts {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `MigrationStepGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationStepGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl MigrationStepGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `MigrationVerificationContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MigrationVerificationContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `OwnerDiffSurfaceSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OwnerDiffSurfaceSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `PortableMigrationPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PortableMigrationPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl PortableMigrationPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `PortableMigrationPlanDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PortableMigrationPlanDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl PortableMigrationPlanDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `PortableMigrationPlanOrRefusal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PortableMigrationPlanOrRefusal {
    InvalidCarrier {
        field: crate::waist::FieldPath,
        reason: crate::waist::RefusalReason,
    },
    AuthorityMismatch {
        expected: crate::waist::StableId,
        actual: crate::waist::StableId,
    },
    EditionOrOccurrenceMismatch {
        subject: crate::waist::StableId,
    },
    SemanticConflict {
        subject: crate::waist::StableId,
        law: crate::waist::StableId,
    },
    Incomplete {
        missing: Vec<crate::waist::StableId>,
    },
    DescriptorDrift {
        expected: crate::waist::DigestClaim,
        actual: crate::waist::DigestClaim,
    },
}

/// Field-complete contract model for `PortableMigrationPlanProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PortableMigrationPlanProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl PortableMigrationPlanProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `PortableMigrationPlanningOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PortableMigrationPlanningOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::catalog_types::semantic_migration::SemanticMigrationRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `PortableMigrationPlanningProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PortableMigrationPlanningProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl PortableMigrationPlanningProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ProcessMigrationPolicySet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProcessMigrationPolicySet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `RecipeCandidateSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RecipeCandidateSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `RollbackEnvelope`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RollbackEnvelope {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SelectedRecipeSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectedRecipeSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SemanticCorrespondence`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticCorrespondence {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SemanticCorrespondenceSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticCorrespondenceSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SemanticDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl SemanticDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `SemanticDeltaSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticDeltaSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SemanticMigrationRefusal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SemanticMigrationRefusal {
    InvalidCarrier {
        field: crate::waist::FieldPath,
        reason: crate::waist::RefusalReason,
    },
    AuthorityMismatch {
        expected: crate::waist::StableId,
        actual: crate::waist::StableId,
    },
    EditionOrOccurrenceMismatch {
        subject: crate::waist::StableId,
    },
    SemanticConflict {
        subject: crate::waist::StableId,
        law: crate::waist::StableId,
    },
    Incomplete {
        missing: Vec<crate::waist::StableId>,
    },
    DescriptorDrift {
        expected: crate::waist::DigestClaim,
        actual: crate::waist::DigestClaim,
    },
}

/// Field-complete contract model for `SourceTargetMapPair`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceTargetMapPair {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `StateInventoryMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StateInventoryMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `StateInventorySnapshot`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StateInventorySnapshot {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl StateInventorySnapshot {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `TargetArtifactDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetArtifactDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl TargetArtifactDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `TargetCompilationPair`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetCompilationPair {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `VerifiedReleasePair`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VerifiedReleasePair {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl VerifiedReleasePair {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}
