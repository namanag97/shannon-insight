# DAT-SOURCE-CHANGE-STREAM · Source Change Stream Semantics

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

What source mutations were observed after a continuation, including transaction visibility, order scope, before and after images, deletes, duplicates, and structural-change visibility?

## Boundary

Owns:
- source change record semantics
- source transaction-visibility posture
- delete/before/after qualification
- source order scope
- duplicate/conflict distinction
- change-stream continuity claim

Explicitly excludes:
- application event
- Journal fact
- message broker implementation
- connector loop
- checkpoint implementation
- generic Causality
- Schema
- business identity resolution

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- DAT-SOURCE-OBSERVATION
- DAT-SOURCE-CONTINUATION

## Reciprocal semantic seams

- None in this edition.

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
