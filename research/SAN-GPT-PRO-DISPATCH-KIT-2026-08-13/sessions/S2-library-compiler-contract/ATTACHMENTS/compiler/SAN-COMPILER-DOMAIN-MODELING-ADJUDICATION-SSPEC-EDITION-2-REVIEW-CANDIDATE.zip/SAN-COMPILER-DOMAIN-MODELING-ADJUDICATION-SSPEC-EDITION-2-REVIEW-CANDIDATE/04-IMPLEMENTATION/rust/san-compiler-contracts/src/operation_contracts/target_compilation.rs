//! Operation contracts owned by `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`.

pub trait TargetCompilationContracts {
    /// `target-lowering.input.admit`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_target_lowering_input(
        &self,
        arg0: crate::catalog_types::target_compilation::TargetLoweringInputMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetLoweringInput, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.source.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_target_sources(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetLoweringInput,
        arg1: &crate::catalog_types::target_compilation::TargetLoweringTrustPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::VerifiedTargetSources, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.compiler.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_target_compiler(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetCompilerDescriptor,
        arg1: &crate::catalog_types::target_compilation::TargetCompilerSurface,
        arg2: &crate::catalog_types::target_compilation::TargetCompilerVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::VerifiedTargetCompiler, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.compiler.index`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn index_target_compilers(
        &self,
        arg0: &[crate::catalog_types::target_compilation::VerifiedTargetCompiler],
        arg1: crate::catalog_types::target_compilation::TargetLoweringBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetCompilerRegistry, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.portfolio.close`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_target_portfolio(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetCompilerRegistry,
        arg1: &crate::catalog_types::target_compilation::TargetRequestSet,
        arg2: &crate::catalog_types::target_compilation::TargetArtifactContractRegistry,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetCompilerPortfolio, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.slice.bind`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_target_slice(
        &self,
        arg0: &crate::catalog_types::target_compilation::VerifiedTargetCompiler,
        arg1: &crate::catalog_types::target_compilation::CsagSliceSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetSliceBinding, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.dialect.close`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_target_dialect(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetDialectSchema,
        arg1: &crate::catalog_types::target_compilation::TargetCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetDialectClosure, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.plan.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_lowering_plan(
        &self,
        arg0: &crate::catalog_types::target_compilation::LoweringPlan,
        arg1: &crate::catalog_types::target_compilation::TargetDialectClosure,
        arg2: &crate::catalog_types::target_compilation::PatternRegistry,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::LoweringPlanProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.type-converter.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_type_converter(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetTypeConverter,
        arg1: &crate::catalog_types::target_compilation::TargetDialectClosure,
        arg2: &crate::catalog_types::target_compilation::PreservationRelation,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TypeConverterProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.pattern.admit`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_lowering_pattern(
        &self,
        arg0: crate::catalog_types::target_compilation::LoweringPatternMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::LoweringPattern, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.pattern.index`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn index_lowering_patterns(
        &self,
        arg0: &[crate::catalog_types::target_compilation::LoweringPattern],
        arg1: &crate::catalog_types::target_compilation::TargetDialectClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::PatternIndex, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.candidate.discover`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn discover_pattern_candidates(
        &self,
        arg0: &crate::catalog_types::target_compilation::LoweringWorkState,
        arg1: &crate::catalog_types::target_compilation::LoweringPass,
        arg2: &crate::catalog_types::target_compilation::PatternIndex,
        arg3: crate::catalog_types::target_compilation::TargetPassBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::PatternCandidateSet, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.candidate.analyze`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn analyze_pattern_ambiguity(
        &self,
        arg0: &crate::catalog_types::target_compilation::PatternCandidateSet,
        arg1: &crate::catalog_types::target_compilation::LoweringPass,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::PatternChoicePlan, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.pattern.evaluate`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn evaluate_lowering_pattern(
        &self,
        arg0: &crate::catalog_types::target_compilation::LoweringPattern,
        arg1: &crate::catalog_types::target_compilation::PatternMatch,
        arg2: &crate::catalog_types::target_compilation::LoweringReadView,
        arg3: crate::catalog_types::target_compilation::TargetPassBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::LoweringProposal, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.proposal.canonicalize`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn canonicalize_lowering_proposals(
        &self,
        arg0: crate::waist::NonEmpty<crate::catalog_types::target_compilation::LoweringProposal>,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::CanonicalProposalBatch, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.proposal.commit`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_lowering_proposals(
        &self,
        arg0: &crate::catalog_types::target_compilation::LoweringWorkState,
        arg1: &crate::catalog_types::target_compilation::CanonicalProposalBatch,
        arg2: &crate::catalog_types::target_compilation::TargetDialectClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::LoweringCommit, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.progress.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_lowering_progress(
        &self,
        arg0: &crate::catalog_types::target_compilation::LoweringWorkState,
        arg1: &crate::catalog_types::target_compilation::LoweringCommit,
        arg2: &crate::catalog_types::target_compilation::LoweringProgressMeasure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::ProgressWitness, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.pass.execute`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn execute_lowering_pass(
        &self,
        arg0: &crate::catalog_types::target_compilation::LoweringWorkState,
        arg1: &crate::catalog_types::target_compilation::LoweringPass,
        arg2: &crate::catalog_types::target_compilation::TargetCompilerExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetPassOutcome, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.pass.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_lowering_pass_result(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetPassResult,
        arg1: &crate::catalog_types::target_compilation::LoweringPass,
        arg2: &crate::catalog_types::target_compilation::TargetDialectClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::PassPreservationWitness, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.plan.execute`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn execute_lowering_plan(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::catalog_types::target_compilation::VerifiedTargetCompiler,
        arg2: &crate::catalog_types::target_compilation::TargetCompilationPlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetCompilationOutcome, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.legality.assess`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn assess_target_legality(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetArtifactGraph,
        arg1: &crate::catalog_types::target_compilation::ConversionTarget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetLegalityReport, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.type.convert`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn convert_target_type(
        &self,
        arg0: &crate::catalog_types::target_compilation::SourceTypeView,
        arg1: &crate::catalog_types::target_compilation::TypeConversionPlan,
        arg2: &crate::catalog_types::target_compilation::TargetCompilerExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetTypeProjection, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.source-map.build`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_source_target_map(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::catalog_types::target_compilation::TargetArtifactGraph,
        arg2: &[crate::catalog_types::target_compilation::LoweringCommit],
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::SourceTargetMap, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.source-map.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_source_target_map(
        &self,
        arg0: &crate::catalog_types::target_compilation::SourceTargetMap,
        arg1: &crate::catalog_types::csag::CsagSlice,
        arg2: &crate::catalog_types::target_compilation::TargetArtifactGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::SourceTargetMapProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.preservation.compose-pass`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn compose_pass_witness(
        &self,
        arg0: &[crate::catalog_types::target_compilation::LocalPreservationWitness],
        arg1: &crate::catalog_types::target_compilation::PassCoverageProof,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::PassPreservationWitness, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.preservation.compose-target`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn compose_target_witness(
        &self,
        arg0: &[crate::catalog_types::target_compilation::PassPreservationWitness],
        arg1: &crate::catalog_types::target_compilation::SourceTargetMapProof,
        arg2: &crate::catalog_types::target_compilation::BoundaryPreservationProof,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetPreservationWitness, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.validation.plan`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_translation_validation_plan(
        &self,
        arg0: &crate::catalog_types::target_compilation::VerifiedTargetCompiler,
        arg1: &crate::catalog_types::target_compilation::TargetCompilationPlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::ValidationPlan, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.validation.run`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn validate_target_translation(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::vertical::TargetCompilation,
        arg2: &crate::catalog_types::target_compilation::ValidationPlan,
        arg3: &crate::catalog_types::target_compilation::TranslationValidatorContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TranslationValidationOutcome, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.validation.replay`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn replay_preservation_witness(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetPreservationWitness,
        arg1: &crate::catalog_types::target_compilation::TranslationValidatorContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::WitnessReplayProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.validation.differential`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn run_differential_conformance(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::vertical::TargetCompilation,
        arg2: &crate::catalog_types::target_compilation::DifferentialCorpus,
        arg3: &crate::catalog_types::target_compilation::ValidationBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::DifferentialConformanceReport, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.artifact-contract.index`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn index_target_artifact_contracts(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetCompilerRegistry,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetArtifactContractRegistry, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.target-requirement.join`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn join_target_artifact_requirements(
        &self,
        arg0: &[crate::catalog_types::target_compilation::TargetArtifactRequirement],
        arg1: &crate::catalog_types::target_compilation::TargetArtifactContractHeader,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::JoinedTargetArtifactRequirement, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.target-binding.resolve`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_target_artifact_binding(
        &self,
        arg0: &crate::catalog_types::target_compilation::JoinedTargetArtifactRequirement,
        arg1: &crate::catalog_types::target_compilation::TargetCompilationSetDraft,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetArtifactBinding, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.dependency.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_target_dependency_graph(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetCompilerPortfolio,
        arg1: &crate::catalog_types::target_compilation::TargetArtifactBindingSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetDependencyProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.boundary.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_target_boundaries(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::catalog_types::target_compilation::TargetCompilationDraft,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::BoundaryPreservationProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.obligation.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_target_obligations(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::catalog_types::target_compilation::TargetCompilationDraft,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetObligationPreservationProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.epistemic.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_target_epistemics(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::catalog_types::target_compilation::TargetCompilationDraft,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetEpistemicPreservationProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.provider-leak.scan`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn scan_target_provider_leakage(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetArtifactGraph,
        arg1: &crate::catalog_types::target_compilation::TargetBoundarySet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::ProviderFreeTargetProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.explanation.build`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_lowering_explanation(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetCompilationDraft,
        arg1: &crate::catalog_types::target_compilation::LoweringTraceSet,
        arg2: crate::waist::DisclosurePolicyRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::LoweringExplanationGraph, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.canonical.project`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_target_compilation(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetCompilationDraft,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetCompilationCanonicalProjection, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.compilation.build`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_target_compilation(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetCompilationDraft,
        arg1: &crate::catalog_types::target_compilation::TranslationValidationProof,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::TargetCompilation, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.portfolio.build`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_target_compilation_set(
        &self,
        arg0: &[crate::vertical::TargetCompilation],
        arg1: &crate::catalog_types::target_compilation::TargetArtifactBindingSet,
        arg2: &crate::catalog_types::target_compilation::TargetDependencyProof,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::TargetCompilationSet, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.portfolio.verify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_target_compilation_set(
        &self,
        arg0: &crate::vertical::TargetCompilationSet,
        arg1: &crate::catalog_types::target_compilation::TargetPortfolioVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetCompilationSetProof, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.checkpoint.resume`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_target_lowering(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetLoweringCheckpoint,
        arg1: &crate::catalog_types::target_compilation::TargetLoweringInput,
        arg2: &crate::catalog_types::target_compilation::TargetLoweringExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetLoweringOutcome, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.delta.classify`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_target_lowering_delta(
        &self,
        arg0: &crate::vertical::TargetCompilationSet,
        arg1: &crate::vertical::TargetCompilationSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetLoweringDelta, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.incremental.plan`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_incremental_lowering(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetLoweringDelta,
        arg1: &crate::catalog_types::target_compilation::IncrementalDependencyMap,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::IncrementalLoweringPlan, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.incremental.execute`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn execute_incremental_lowering(
        &self,
        arg0: &crate::catalog_types::target_compilation::IncrementalLoweringPlan,
        arg1: &crate::catalog_types::target_compilation::TargetLoweringExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetLoweringOutcome, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.explain`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_target_lowering(
        &self,
        arg0: crate::catalog_types::target_compilation::TargetLoweringExplainTarget,
        arg1: &crate::catalog_types::target_compilation::TargetCompilationOrRefusal,
        arg2: crate::waist::DisclosurePolicyRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetLoweringExplanation, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `target-lowering.lower`. Owner: `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn lower_targets(
        &self,
        arg0: &crate::catalog_types::target_compilation::TargetLoweringInput,
        arg1: &crate::catalog_types::target_compilation::TargetLoweringExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::TargetLoweringOutcome, crate::vertical::TargetCompilationRefusal, crate::waist::CompilerNeedsInput>;

}
