# CODEX start here

## Purpose

This archive is the deterministic **SAN Global Program Registry Architecture, Edition 1**. It corrects the registry metamodel before any further broad specification or crate generation. It is an architecture and evidence package, not a claim that SAN compiles, deploys or boots a governed application.

## Authority and trust

1. `SOURCE-AUTHORITY-LEDGER.json` is the complete inventory of the authorized private handoff and every nested candidate archive.
2. Attached principles and explicit owner decisions outrank current owner-local evidence.
3. Selected review-candidate sources outrank externally generated candidate registries, but remain unratified.
4. Archive presence, schema success, Rust symbol presence and historical `COMPLETE` labels never establish semantic authority or execution.
5. No public SAN GitHub repository was searched or used.

## Read in this order

1. `EXECUTIVE-ARCHITECTURE-DECISION.md`
2. `REGISTRY-METAMODEL.json`
3. `NAMESPACE-REGISTRY.json` and `UNIT-KIND-REGISTRY.json`
4. `IDENTITY-AND-EDITION-RULES.json`
5. `GLOBAL-PROGRAM-REGISTRY.json`
6. `CONFLICT-ADJUDICATION-LEDGER.json`
7. The five separate graph views
8. `COMPLETENESS-EVIDENCE-MATRIX.json`, `RESEARCH-GAP-LEDGER.json` and `OPEN-DECISIONS.md`
9. `IMPLEMENTATION-ORDER.json`
10. `PACKAGE-VERIFY.json`, `MANIFEST.json` and `VERIFY/verify_package.py`

## Edition 1 facts

- Governed records: **269**
- Semantic-library projection: **143**
- Proof verticals, excluded from that projection: **11**
- Bounded-context hypotheses, retained only in the context map: **129**
- Hard dependency nodes and edges: **269 / 697**
- Conflict adjudication records: **830**
- Compiler A/B external decisions: **25**, all unresolved
- Explicit not-proven claims: **25**

## Implementation rules

- Treat `GLOBAL-PROGRAM-REGISTRY.json` as the canonical Edition 1 record set and the other JSON artifacts as deterministic projections or control registries.
- Never edit derived graph, coverage or completeness files directly. Apply an exact-base-digest patch under `REGISTRY-CHANGE-PROTOCOL.md`, then regenerate and verify every projection.
- Dispatch compiler behavior by governed-unit kind, declared capability and typed descriptor. A branch on a family coordinate or display name is a verification failure.
- Do not create a crate because a registry record exists. `implementation_mapping.packaging_cardinality` is deliberately independent.
- Do not promote a bounded context, provider, publication, target dialect or proof scenario into semantic ownership merely to make counts symmetrical.
- Stop implementation at the first unresolved owner, source, compiler-finality, lowering, runtime or provider-closure dependency. Record the gap rather than inventing a default.

## Verification

Run:

```bash
python VERIFY/verify_package.py .
python VERIFY/verify_package.py SAN-GLOBAL-PROGRAM-REGISTRY-ARCHITECTURE-EDITION-1.zip
```

The verifier checks schemas, canonical serialization, manifest integrity, identities, aliases, owners, capabilities, references, hard-dependency acyclicity, graph separation, source traceability, completion overclaim, counts and deterministic ZIP metadata. It also corrupts representative in-memory inputs and requires every corruption to be rejected.

## Stop rule

Do not generate another broad corpus batch until the metamodel is ratified, the compiler A/B decisions are closed, and the primary acceptance vertical has executable positive and negative evidence. A larger pile of candidate JSON would only make the uncertainty harder to alphabetize.
