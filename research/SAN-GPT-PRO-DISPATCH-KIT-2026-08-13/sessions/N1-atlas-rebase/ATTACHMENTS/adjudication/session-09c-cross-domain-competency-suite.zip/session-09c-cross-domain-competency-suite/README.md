# Session 09C: Cross-Domain Competency and Adversarial Scenario Suite

## Purpose

This package tests whether a candidate reconciled non-data SAN domain model preserves required semantic distinctions, ownership, refusals, lifecycles, context wiring, specialization boundaries, and semantic-to-implementation seams.

It **does not** select, merge, rename, or canonize any candidate model. Expected owner roles in the suite are test obligations, not final registry dispositions. Apparently even nouns need due process now.

## Package totals

- Competency questions: **180** across **35** required families
- Adversarial scenarios: **30**
- Standalone invalid-modelling shortcuts: **120**
- Supplied candidate corpora evaluated: **10**
- Candidate contexts evaluated: **809**
- Corpus-test results: **2100**
- Corpus-test statuses: PASS **196**, PARTIAL **1209**, FAIL **134**, NOT_APPLICABLE **561**, UNTESTABLE_MISSING_ARTIFACT **0**
- Context statuses: PASS **390**, PARTIAL **419**, FAIL **0**

## Required directories

- `competency/`: questions, typed relation requirements, and semantic-ownership expectations.
- `scenarios/`: connected scenarios, expected context maps, and invalid shortcuts.
- `evaluation/`: per-corpus and per-context results, aggregate coverage, failure clusters, and uncovered requirements.
- `schemas/`: JSON Schema Draft 2020-12 schemas for every required data collection and package metadata record.
- `validation/`: source inventory, evaluation method, applicability matrix, independent research basis, distinctness analysis, content-validation report, and the package self-validator.

Top-level `manifest.json`, `VALIDATION.json`, and `CHECKSUMS.txt` describe and protect the package. The manifest inventory excludes `manifest.json` and `CHECKSUMS.txt` to avoid self-hash cycles. `CHECKSUMS.txt` covers every file except itself.

## Evaluation semantics

A result passes only when the distinction is structurally representable. Candidate competency-question prose, candidate scenario prose, README/generated prose, and issue/gap records are excluded as positive evidence. Issue records may explain weakness but cannot repair it.

`PASS` requires all mandatory hard gates. `PARTIAL` means meaningful structured evidence exists but required ownership, relations, qualifiers, laws, refusals, lifecycles, answer fields, or implementation seams remain incomplete. `FAIL` means the applicable distinction cannot be structurally carried. `NOT_APPLICABLE` is assigned only through the explicit territory matrix. `UNTESTABLE_MISSING_ARTIFACT` is reserved for absent or unreadable structured artifacts.

The evaluator normalizes equivalent structured record kinds across the two source metamodel families without rewriting source identities or pretending the metamodels are identical. Corpus-local inverse-document-frequency weighting and owner-locality gates reduce accidental PASS results assembled from unrelated vocabulary scattered across a large archive.

## Validation

From the package root:

```bash
python validation/validate_suite.py .
```

The validator requires Python 3.11+ and `jsonschema`. It validates Draft 2020-12 schemas, every required JSON/JSONL record, identifier/reference integrity, counts, status rules, PASS hard gates, generic-escape-key absence, manifest hashes, and `CHECKSUMS.txt`.

## Highest-impact uncovered requirements

- `UR-001` (CRITICAL): Typed identity, role, account, organization, and mandate separation [ISOLATED_COVERAGE; pass rate 0.0753]
- `UR-002` (CRITICAL): Delegation chains with expiry, revocation, scope, jurisdiction, and quantitative limits [ISOLATED_COVERAGE; pass rate 0.0857]
- `UR-014` (CRITICAL): Controller desired state versus operator command authority [ISOLATED_COVERAGE; pass rate 0.0877]
- `UR-003` (CRITICAL): Purpose-limited consent with downstream propagation and withdrawal [ISOLATED_COVERAGE; pass rate 0.0947]
- `UR-005` (CRITICAL): Multiple temporal axes and historically preserved correction [ISOLATED_COVERAGE; pass rate 0.1020]
- `UR-004` (CRITICAL): Jurisdiction and policy conflict without silent precedence [ISOLATED_COVERAGE; pass rate 0.1032]
- `UR-009` (CRITICAL): Distributed event, message, attempt, delivery, and causal-order separation [ISOLATED_COVERAGE; pass rate 0.1288]
- `UR-010` (CRITICAL): Network partition as explicit uncertainty, not success or failure fiction [FRAGMENTED_COVERAGE; pass rate 0.1562]

## Important limitations

The scoring is a conservative structured-evidence audit, not a proof that a candidate corpus is ontologically correct. A corpus can receive PARTIAL because the required distinction is genuinely absent, because ownership is spread across unrelated records, or because its metamodel does not expose the semantics in typed fields. These results identify what a reconciled model must prove; they do not decree the final model.
