# Content, Knowledge and Experience Domain Atlas

JSON/JSONL is canonical. This file is generated navigation.

## Package summary

- Primary records: 2386
- Typed semantic relations: 451
- Context-map relationships: 117
- Candidate bounded contexts: 22
- All boundary hypotheses: 37
- Split proposals: 4
- Merge proposals: 3
- Mandatory adversarial scenarios tested: 12

## Navigation

- `corpus/contexts.jsonl`: proposed owners, scopes, laws, behaviors and twelve boundary tests.
- `corpus/relations.jsonl`: binary and n-ary semantic relations.
- `corpus/context_relationships.jsonl`: context-map seams and translations.
- `scenarios/`: competency questions and positive, negative, boundary, ambiguous and cross-domain examples.
- `registry_intake/`: non-mutating crosswalks and proposed dispositions.
- `issues/`: conflicts, gaps and unresolved boundaries or references.
- `coverage/`: coverage matrix, boundary evaluation and validation summary.
- `schemas/` and `vocabularies/`: Draft 2020-12 schemas and controlled values.
- `VALIDATION.json` and `CHECKSUMS.txt`: mechanical validation and integrity evidence.

## Highest-impact unresolved boundaries

- `candidate.content-knowledge-experience.gap.analytics-metric-owner`: Visualization composition lacks an identified external analytics/metric owner.
- `candidate.content-knowledge-experience.gap.jurisdictional-record-law`: Retention, hold, erasure and disposition require jurisdictional profiles.
- `candidate.content-knowledge-experience.unresolved_boundary.translation-versus-parallel-authorship`: Translation, parallel co-authorship and adaptation need identity-policy adjudication.
- `candidate.content-knowledge-experience.unresolved_boundary.live-view-versus-publication`: A continuously changing visualization may be a service, sequence of releases or live publication contract.
- `candidate.content-knowledge-experience.gap.conversation-inference`: Conversation identity cannot be universally inferred from transport threads.
- `candidate.content-knowledge-experience.gap.archival-authenticity-threshold`: Archival authenticity and significant-property thresholds require community profiles.
