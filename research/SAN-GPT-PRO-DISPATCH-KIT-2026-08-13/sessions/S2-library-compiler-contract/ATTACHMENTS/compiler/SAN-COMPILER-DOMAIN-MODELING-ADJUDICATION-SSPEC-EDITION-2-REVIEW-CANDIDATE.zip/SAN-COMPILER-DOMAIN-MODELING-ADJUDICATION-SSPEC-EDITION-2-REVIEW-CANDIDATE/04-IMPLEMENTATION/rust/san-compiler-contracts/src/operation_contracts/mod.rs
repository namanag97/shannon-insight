//! Total, budgeted operation contracts for all sixteen retained contexts.
//! These traits declare contracts; only the reference vertical functions claim source inclusion.

pub mod app_release;
pub mod application_binding;
pub mod application_closure;
pub mod application_source_parsing;
pub mod csag;
pub mod decision_resolution;
pub mod declaration_admission;
pub mod family_compilation;
pub mod compiler_host;
pub mod name_binding;
pub mod obligation_closure;
pub mod pack_expansion;
pub mod semantic_migration;
pub mod target_compilation;
pub mod domain_definition;
pub mod package_extension_composition;
