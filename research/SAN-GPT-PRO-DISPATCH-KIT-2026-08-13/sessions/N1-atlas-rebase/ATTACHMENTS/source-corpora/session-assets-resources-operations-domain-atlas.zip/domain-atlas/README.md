# SAN Domain Atlas: Assets, Resources, and Physical Operations

This package is a machine-readable research corpus and boundary hypothesis set for the assigned physical-domain coverage region. JSONL collections are the primary records. JSON files contain manifests, controlled vocabularies, coverage summaries, indexes, and validation results. Markdown is navigation only.

The supplied SAN Global Program Registry was audited and cross-referenced as candidate evidence. It was not modified, treated as complete, or presumed to have correct unit kinds or boundaries.

## Reading order

1. `manifest.json`
2. `coverage/boundary_evaluation.json`
3. `corpus/contexts.jsonl`
4. `corpus/concepts.jsonl` and `corpus/contextual_meanings.jsonl`
5. `corpus/relations.jsonl` and `corpus/context_relationships.jsonl`
6. `registry_intake/`
7. `issues/`
8. `VALIDATION.json`

## Canonicality

All important semantics are in typed fields. The package intentionally avoids generic `metadata`, `properties`, `attributes`, `payload`, `extensions`, `custom_fields`, and `notes` escape hatches. Candidate identifiers do not claim existing `san.*` authority. External registry identities appear only as references and crosswalk targets.

## Scope control

The package does not build software, a compiler, an application, a data platform, a provider, a runtime, or a deployment. Digital-twin records are representation profiles over physical semantics. Observations and analytical recommendations are connected through explicit seams to separate data and analytics authorities.
