# SAN Foundational Semantics Domain Atlas

This archive is a machine-readable, first-principles research corpus for `FOUNDATIONAL_SEMANTICS`. It preserves authority, scope, edition, temporality, uncertainty, conflict, profiles, and negative scope rather than forcing one global ontology.

The attached SAN Global Program Registry is **not** a source of domain truth. It is used only after independent boundary derivation for crosswalk and registry-intake proposals. No `san.*` identity is mutated or ratified.

## Canonical content

JSON and JSONL are the source of truth. `generated/SUMMARY.md` is navigation only.

- `corpus/`: concepts, contextual meanings, claims, value objects, behavior, laws, contracts, contexts, relations, profiles, compositions, and mappings.
- `scenarios/`: competency questions plus positive, negative, boundary, ambiguous, conflicting, and cross-domain examples.
- `registry_intake/`: non-mutating crosswalk, candidate units, split/merge proposals, dispositions, and change requests.
- `issues/`: explicit conflicts, gaps, unresolved boundaries, and unresolved references.
- `schemas/`: closed JSON Schema Draft 2020-12 schemas for every primary record kind.
- `coverage/`: coverage matrix, boundary evaluation, registry audit, and validation summary.

## Validation

From the extracted `domain-atlas/` directory:

```bash
python tools/validate_corpus.py .
```

The validator checks JSON/JSONL parsing, Draft 2020-12 schemas, unique identifiers, internal reference closure, controlled vocabularies, relation types and roles, deterministic ordering, and checksums.

## Interpretation limits

This package reaches at most `L4_ADVERSARIALLY_TESTED`. It does not claim global completeness, independent review, registry admission, certification, or universal philosophical consensus. A globally usable map is achieved here by preserving plural authorities and explicit conflicts, not by pretending disagreement disappeared because someone designed a tidy JSON shape.
