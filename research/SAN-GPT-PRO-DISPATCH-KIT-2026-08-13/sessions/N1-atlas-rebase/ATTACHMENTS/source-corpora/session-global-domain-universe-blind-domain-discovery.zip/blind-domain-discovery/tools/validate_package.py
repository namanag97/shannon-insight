#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, sys
from collections import defaultdict
from urllib.parse import urljoin
from jsonschema import Draft202012Validator, FormatChecker, RefResolver

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
errors = []
def fail(check, path, message): errors.append({"check": check, "path": path, "message": message})

def load_json(path): return json.loads(path.read_text(encoding="utf-8"))
try:
    manifest = load_json(root / "manifest.json")
except Exception as exc:
    print(json.dumps({"status":"FAIL","errors":[{"check":"manifest","path":"manifest.json","message":str(exc)}]}, indent=2)); sys.exit(1)

schemas = {}
for path in sorted(root.rglob("*.schema.json")):
    rel = path.relative_to(root).as_posix()
    try:
        schema = load_json(path); Draft202012Validator.check_schema(schema)
        if "$id" not in schema: fail("schema", rel, "missing $id")
        else: schemas[schema["$id"]] = schema
    except Exception as exc: fail("schema", rel, str(exc))
for schema_id, schema in schemas.items():
    def refs(value):
        if isinstance(value, dict):
            for key, nested in value.items():
                if key == "$ref" and isinstance(nested, str) and not nested.startswith("#"):
                    target = urljoin(schema_id, nested)
                    if target not in schemas and not target.startswith("https://json-schema.org/"): fail("schema_ref", schema_id, f"unresolved {nested}")
                refs(nested)
        elif isinstance(value, list):
            for nested in value: refs(nested)
    refs(schema)

record_rows = {}
ids = defaultdict(list)
for spec in manifest.get("record_files", []):
    data_rel, schema_rel = spec["path"], spec["schema"]
    path = root / data_rel
    rows = []
    try:
        for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip(): fail("parse", data_rel, f"blank line {line_no}"); continue
            row = json.loads(line); rows.append(row)
            if line != json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=False): fail("determinism", data_rel, f"noncanonical line {line_no}")
            if isinstance(row.get("id"), str): ids[row["id"]].append(f"{data_rel}:{line_no}")
            else: fail("id", data_rel, f"missing id at line {line_no}")
    except Exception as exc: fail("parse", data_rel, str(exc))
    record_rows[data_rel] = rows
    try:
        schema = load_json(root / schema_rel)
        validator = Draft202012Validator(schema, resolver=RefResolver.from_schema(schema, store=schemas), format_checker=FormatChecker())
        for i, row in enumerate(rows, 1):
            for err in validator.iter_errors(row): fail("record_schema", f"{data_rel}:{i}", err.message)
    except Exception as exc: fail("record_schema", schema_rel, str(exc))

for spec in manifest.get("json_files", []):
    data_rel, schema_rel = spec["path"], spec["schema"]
    try:
        value = load_json(root / data_rel); schema = load_json(root / schema_rel)
        validator = Draft202012Validator(schema, resolver=RefResolver.from_schema(schema, store=schemas), format_checker=FormatChecker())
        for err in validator.iter_errors(value): fail("json_schema", data_rel, err.message)
        if isinstance(value, dict) and isinstance(value.get("id"), str): ids[value["id"]].append(data_rel)
    except Exception as exc: fail("json_schema", data_rel, str(exc))

for record_id, locations in ids.items():
    if len(locations) > 1: fail("id", record_id, f"duplicate in {locations}")
all_ids = set(ids)
def strings(value):
    if isinstance(value, str): yield value
    elif isinstance(value, dict):
        for nested in value.values(): yield from strings(nested)
    elif isinstance(value, list):
        for nested in value: yield from strings(nested)
for data_rel, rows in record_rows.items():
    row_ids = [r.get("id", "") for r in rows]
    if row_ids != sorted(row_ids): fail("determinism", data_rel, "records not sorted by id")
    for row in rows:
        for text in strings(row):
            if text.startswith("candidate.global-domain-universe.") and text not in all_ids: fail("reference", data_rel, f"unresolved {text}")

checksum_path = root / "CHECKSUMS.txt"
try:
    for line_no, line in enumerate(checksum_path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip(): continue
        digest, rel = line.split("  ", 1); target = root / rel
        if not target.exists(): fail("checksum", rel, "missing")
        elif hashlib.sha256(target.read_bytes()).hexdigest() != digest: fail("checksum", rel, "mismatch")
except Exception as exc: fail("checksum", "CHECKSUMS.txt", str(exc))

result = {"status":"PASS" if not errors else "FAIL", "record_count":sum(len(x) for x in record_rows.values()), "unique_id_count":len(ids), "schema_count":len(schemas), "errors":errors}
print(json.dumps(result, indent=2, sort_keys=True))
sys.exit(0 if not errors else 1)
