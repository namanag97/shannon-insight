//! Types owned by `family_compilation`.

use std::collections::{BTreeMap, BTreeSet};

/// Field-complete contract model for `FamilyCardSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyCardSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyClosureBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyClosureBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `FamilyClosureCheckpoint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyClosureCheckpoint {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: Vec<crate::waist::ArtifactRef>,
    work_spent: u64,
    remaining_budget: crate::waist::WorkBudget,
}

impl FamilyClosureCheckpoint {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.completed
    }
    #[must_use]
    pub fn work_spent(&self) -> u64 {
        self.work_spent
    }
    #[must_use]
    pub fn remaining_budget(&self) -> &crate::waist::WorkBudget {
        &self.remaining_budget
    }
}

/// Field-complete contract model for `FamilyClosureInput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyClosureInput {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `FamilyClosurePolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyClosurePolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `FamilyClosureProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyClosureProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl FamilyClosureProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `FamilyClosureSchedule`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyClosureSchedule {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl FamilyClosureSchedule {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyClosureState`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyClosureState {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl FamilyClosureState {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `FamilyCompilationInput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyCompilationInput {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `FamilyCompileDependencyGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyCompileDependencyGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl FamilyCompileDependencyGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyCompilerDispatchTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyCompilerDispatchTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl FamilyCompilerDispatchTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyCompilerSurface`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyCompilerSurface {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub owner: crate::waist::AuthorityRef,
    pub kind: crate::waist::RegistryKind,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub source: crate::waist::ArtifactRef,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyEmissions`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyEmissions {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyExplainTarget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum FamilyExplainTarget {
    Artifact {
        artifact: crate::waist::ArtifactRef,
    },
    Subject {
        subject: crate::waist::SubjectKey,
    },
    Refusal {
        refusal_id: crate::waist::StableId,
    },
}

/// Field-complete contract model for `FamilyExtensionSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyExtensionSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyGapDispositionSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyGapDispositionSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyGapLedger`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyGapLedger {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl FamilyGapLedger {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `FamilyInputDispositionLedger`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyInputDispositionLedger {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl FamilyInputDispositionLedger {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `FamilyInputProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyInputProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl FamilyInputProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `FamilyObligationSeedSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyObligationSeedSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyPassClosure`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPassClosure {
    identity: crate::waist::StableId,
    owner: crate::waist::AuthorityRef,
    edition: crate::waist::Edition,
    kind: crate::waist::StableId,
    members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl FamilyPassClosure {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn edition(&self) -> &crate::waist::Edition {
        &self.edition
    }
    #[must_use]
    pub fn kind(&self) -> &crate::waist::StableId {
        &self.kind
    }
    #[must_use]
    pub fn members(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::ScalarValue> {
        &self.members
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyPassId`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPassId {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `FamilyPassInput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPassInput {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `FamilyPassOutput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPassOutput {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyPassPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPassPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl FamilyPassPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyPlanCanonicalProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPlanCanonicalProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl FamilyPlanCanonicalProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `FamilyPlanDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPlanDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl FamilyPlanDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `FamilyPlanExplanation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPlanExplanation {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl FamilyPlanExplanation {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyPlanSetOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum FamilyPlanSetOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::FamilyCompilationRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `FamilyPublicCompileSurface`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPublicCompileSurface {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub owner: crate::waist::AuthorityRef,
    pub kind: crate::waist::RegistryKind,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub source: crate::waist::ArtifactRef,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyReleaseRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyReleaseRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `FamilyRequirementSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyRequirementSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilySurfaceSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilySurfaceSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ImportedFamilyPublicSurfaceSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ImportedFamilyPublicSurfaceSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}
