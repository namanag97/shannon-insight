//! Stage-0 package authority with exact selected-release × 58-role completeness.

use std::collections::{BTreeMap, BTreeSet};

use ed25519_dalek::{Signature, Verifier, VerifyingKey};
use sha2::{Digest, Sha256};

use crate::waist::{
    admit_artifact_ref, ArtifactRef, ArtifactRefCarrier, AuthorityRef, BudgetDimension,
    CompilerNeedsInput, Edition, Exhaustion, IdentityRefusal, MissingInputKind, OccurrenceId,
    PackageLockRef, RegistryKind, StableId, StageId, TotalOutcome, WorkBudget,
    WorkReceipt,
};

const STAGE0_DOMAIN: &[u8] = b"san.stage0.package-authority.edition-2\0";

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
#[repr(u16)]
pub enum CompilerSupplierRole {
    SourceDigestVerification,
    ConstitutionVerification,
    OwnerAdmission,
    NameDeclarationProjection,
    PackageLockVerification,
    PackVerification,
    PackDecisionDeclarationProjection,
    CompilerFamilySurfaceVerification,
    DecisionAlgebra,
    ContractAlgebra,
    OpaqueOwnerValueReadmission,
    FamilyCompilation,
    FamilyGraphProjection,
    RequirementAuthorityVerification,
    SelectionBasisVerification,
    SelectionAuthorityVerification,
    CentralLinkerBindingVerification,
    SemanticSubjectBindingVerification,
    ApplicationClosureCommitmentVerification,
    ObligationLattice,
    ObligationValueCodec,
    ObligationRule,
    ObligationDischargeValidation,
    ObligationReferenceVerification,
    RequirementResolutionKernel,
    CsagFamilyProjection,
    CsagClosureProjection,
    CsagCommitment,
    AuthorityCycleVerification,
    SliceAuthorityVerification,
    TargetSeeding,
    TargetTypeConversion,
    ConversionTarget,
    TargetPatternRewrite,
    TargetArtifactContractAlgebra,
    TranslationValidation,
    TargetCompilation,
    ReleaseSourceVerification,
    ReleaseArtifactVerification,
    ReleaseSealVerification,
    ReleaseAdapterVerification,
    SignatureVerification,
    AttestationVerification,
    ReleaseParityVerification,
    ReleaseLifecycleVerification,
    ReleaseInventoryProjection,
    ReleasePackaging,
    DeploymentRequirementProjection,
    ResourceSatisfactionAlgebra,
    EnvironmentSnapshotVerification,
    ProviderPlanAdaptation,
    DeploymentSealVerification,
    DeploymentLeakageVerification,
    EnvironmentBindingParityVerification,
    MigrationInventoryVerification,
    OwnerSemanticDiff,
    MigrationSealVerification,
    MigrationParityVerification,
}

impl CompilerSupplierRole {
    pub const ALL: [Self; 58] = [
        Self::SourceDigestVerification,
        Self::ConstitutionVerification,
        Self::OwnerAdmission,
        Self::NameDeclarationProjection,
        Self::PackageLockVerification,
        Self::PackVerification,
        Self::PackDecisionDeclarationProjection,
        Self::CompilerFamilySurfaceVerification,
        Self::DecisionAlgebra,
        Self::ContractAlgebra,
        Self::OpaqueOwnerValueReadmission,
        Self::FamilyCompilation,
        Self::FamilyGraphProjection,
        Self::RequirementAuthorityVerification,
        Self::SelectionBasisVerification,
        Self::SelectionAuthorityVerification,
        Self::CentralLinkerBindingVerification,
        Self::SemanticSubjectBindingVerification,
        Self::ApplicationClosureCommitmentVerification,
        Self::ObligationLattice,
        Self::ObligationValueCodec,
        Self::ObligationRule,
        Self::ObligationDischargeValidation,
        Self::ObligationReferenceVerification,
        Self::RequirementResolutionKernel,
        Self::CsagFamilyProjection,
        Self::CsagClosureProjection,
        Self::CsagCommitment,
        Self::AuthorityCycleVerification,
        Self::SliceAuthorityVerification,
        Self::TargetSeeding,
        Self::TargetTypeConversion,
        Self::ConversionTarget,
        Self::TargetPatternRewrite,
        Self::TargetArtifactContractAlgebra,
        Self::TranslationValidation,
        Self::TargetCompilation,
        Self::ReleaseSourceVerification,
        Self::ReleaseArtifactVerification,
        Self::ReleaseSealVerification,
        Self::ReleaseAdapterVerification,
        Self::SignatureVerification,
        Self::AttestationVerification,
        Self::ReleaseParityVerification,
        Self::ReleaseLifecycleVerification,
        Self::ReleaseInventoryProjection,
        Self::ReleasePackaging,
        Self::DeploymentRequirementProjection,
        Self::ResourceSatisfactionAlgebra,
        Self::EnvironmentSnapshotVerification,
        Self::ProviderPlanAdaptation,
        Self::DeploymentSealVerification,
        Self::DeploymentLeakageVerification,
        Self::EnvironmentBindingParityVerification,
        Self::MigrationInventoryVerification,
        Self::OwnerSemanticDiff,
        Self::MigrationSealVerification,
        Self::MigrationParityVerification,
    ];
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReleaseCoordinateCarrier {
    pub kind: RegistryKind,
    pub identity: String,
    pub edition: u32,
    pub occurrence: String,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct ReleaseCoordinate {
    kind: RegistryKind,
    identity: StableId,
    edition: Edition,
    occurrence: OccurrenceId,
}

impl ReleaseCoordinate {
    fn admit(carrier: ReleaseCoordinateCarrier) -> Result<Self, IdentityRefusal> {
        Ok(Self {
            kind: carrier.kind,
            identity: StableId::admit(carrier.identity)?,
            edition: Edition::admit(carrier.edition)?,
            occurrence: OccurrenceId::admit(carrier.occurrence)?,
        })
    }

    #[must_use]
    pub const fn kind(&self) -> RegistryKind { self.kind }
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub const fn edition(&self) -> Edition { self.edition }
    #[must_use]
    pub fn occurrence(&self) -> &OccurrenceId { &self.occurrence }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectedReleaseCarrier {
    pub coordinate: ReleaseCoordinateCarrier,
    pub source: ArtifactRefCarrier,
    pub descriptor_digest: [u8; 32],
    pub surface_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PackageLockCarrier {
    pub releases: Vec<SelectedReleaseCarrier>,
    pub claimed_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SupplierDispositionStateCarrier {
    Available {
        supplier: ReleaseCoordinateCarrier,
        artifact: ArtifactRefCarrier,
    },
    Blocked {
        gap: ArtifactRefCarrier,
    },
    StructurallyInapplicable {
        proof: ArtifactRefCarrier,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SupplierDispositionCarrier {
    pub owner: ReleaseCoordinateCarrier,
    pub role: CompilerSupplierRole,
    pub state: SupplierDispositionStateCarrier,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum SupplierDispositionKind {
    Available,
    Blocked,
    StructurallyInapplicable,
}

#[derive(Clone, Debug, Eq, PartialEq)]
enum SupplierDispositionState {
    Available { supplier: ReleaseCoordinate, artifact: ArtifactRef },
    Blocked { gap: ArtifactRef },
    StructurallyInapplicable { proof: ArtifactRef },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SupplierDisposition {
    owner: ReleaseCoordinate,
    role: CompilerSupplierRole,
    state: SupplierDispositionState,
}

impl SupplierDisposition {
    #[must_use]
    pub fn owner(&self) -> &ReleaseCoordinate { &self.owner }
    #[must_use]
    pub const fn role(&self) -> CompilerSupplierRole { self.role }
    #[must_use]
    pub const fn kind(&self) -> SupplierDispositionKind {
        match self.state {
            SupplierDispositionState::Available { .. } => SupplierDispositionKind::Available,
            SupplierDispositionState::Blocked { .. } => SupplierDispositionKind::Blocked,
            SupplierDispositionState::StructurallyInapplicable { .. } => SupplierDispositionKind::StructurallyInapplicable,
        }
    }
    #[must_use]
    pub fn available_supplier(&self) -> Option<&ReleaseCoordinate> {
        match &self.state {
            SupplierDispositionState::Available { supplier, .. } => Some(supplier),
            _ => None,
        }
    }
    #[must_use]
    pub fn evidence(&self) -> &ArtifactRef {
        match &self.state {
            SupplierDispositionState::Available { artifact, .. } => artifact,
            SupplierDispositionState::Blocked { gap } => gap,
            SupplierDispositionState::StructurallyInapplicable { proof } => proof,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
struct SelectedRelease {
    coordinate: ReleaseCoordinate,
    source: ArtifactRef,
    descriptor_digest: [u8; 32],
    surface_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VerifiedPackageLock {
    reference: PackageLockRef,
    digest: [u8; 32],
    releases: Vec<SelectedRelease>,
}

impl VerifiedPackageLock {
    #[must_use]
    pub fn reference(&self) -> &PackageLockRef { &self.reference }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
    #[must_use]
    pub fn releases(&self) -> impl ExactSizeIterator<Item = &ReleaseCoordinate> {
        self.releases.iter().map(|release| &release.coordinate)
    }
    #[must_use]
    pub fn contains(&self, coordinate: &ReleaseCoordinate) -> bool {
        self.releases.iter().any(|release| release.coordinate == *coordinate)
    }
    #[must_use]
    pub fn selected(&self, identity: &StableId, kind: RegistryKind) -> Option<&ReleaseCoordinate> {
        self.releases.iter().find(|release| release.coordinate.identity == *identity && release.coordinate.kind == kind).map(|release| &release.coordinate)
    }
    #[must_use]
    pub fn descriptor_digest(&self, coordinate: &ReleaseCoordinate) -> Option<&[u8; 32]> {
        self.releases.iter().find(|release| release.coordinate == *coordinate).map(|release| &release.descriptor_digest)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Stage0PackageAuthorityCandidate {
    lock: VerifiedPackageLock,
    dispositions: Vec<SupplierDisposition>,
    canonical: Vec<u8>,
    work: WorkReceipt,
}

impl Stage0PackageAuthorityCandidate {
    #[must_use]
    pub fn package_lock(&self) -> &VerifiedPackageLock { &self.lock }
    #[must_use]
    pub fn canonical_bytes(&self) -> &[u8] { &self.canonical }
    #[must_use]
    pub fn dispositions(&self) -> &[SupplierDisposition] { &self.dispositions }
    #[must_use]
    pub fn work(&self) -> &WorkReceipt { &self.work }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PinnedStage0TrustAnchorCarrier {
    pub authority: String,
    pub key_id: String,
    pub verifying_key: [u8; 32],
    pub installation: ArtifactRefCarrier,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PinnedStage0TrustAnchor {
    authority: AuthorityRef,
    key_id: StableId,
    verifying_key: [u8; 32],
    installation: ArtifactRef,
}

impl PinnedStage0TrustAnchor {
    #[must_use]
    pub fn authority(&self) -> &AuthorityRef { &self.authority }
    #[must_use]
    pub fn key_id(&self) -> &StableId { &self.key_id }
    #[must_use]
    pub const fn verifying_key(&self) -> &[u8; 32] { &self.verifying_key }
    #[must_use]
    pub fn installation(&self) -> &ArtifactRef { &self.installation }
}

pub fn install_pinned_stage0_anchor(
    carrier: PinnedStage0TrustAnchorCarrier,
) -> Result<PinnedStage0TrustAnchor, Stage0PackageAuthorityRefusal> {
    let authority = AuthorityRef::admit(carrier.authority)
        .map_err(Stage0PackageAuthorityRefusal::InvalidIdentity)?;
    let key_id = StableId::admit(carrier.key_id)
        .map_err(Stage0PackageAuthorityRefusal::InvalidIdentity)?;
    let installation = admit_artifact_ref(carrier.installation)
        .map_err(Stage0PackageAuthorityRefusal::InvalidIdentity)?;
    VerifyingKey::from_bytes(&carrier.verifying_key)
        .map_err(|_| Stage0PackageAuthorityRefusal::InvalidSignature)?;
    Ok(PinnedStage0TrustAnchor { authority, key_id, verifying_key: carrier.verifying_key, installation })
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Stage0PackageAttestationCarrier {
    pub issuer: String,
    pub key_id: String,
    pub evidence: ArtifactRefCarrier,
    pub signature: [u8; 64],
    pub verification_work_units: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Stage0PackageAuthorityProof {
    subject: PackageLockRef,
    issuer: AuthorityRef,
    key_id: StableId,
    evidence: ArtifactRef,
    signature: [u8; 64],
    signed_subject: Vec<u8>,
    work: WorkReceipt,
}

impl Stage0PackageAuthorityProof {
    #[must_use]
    pub fn subject(&self) -> &PackageLockRef { &self.subject }
    #[must_use]
    pub fn issuer(&self) -> &AuthorityRef { &self.issuer }
    #[must_use]
    pub fn key_id(&self) -> &StableId { &self.key_id }
    #[must_use]
    pub fn evidence(&self) -> &ArtifactRef { &self.evidence }
    #[must_use]
    pub const fn signature(&self) -> &[u8; 64] { &self.signature }
    #[must_use]
    pub fn signed_subject(&self) -> &[u8] { &self.signed_subject }
    #[must_use]
    pub fn work(&self) -> &WorkReceipt { &self.work }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Stage0PackageAuthority {
    package_lock: VerifiedPackageLock,
    disposition_matrix: Vec<SupplierDisposition>,
    proof: Stage0PackageAuthorityProof,
}

impl Stage0PackageAuthority {
    #[must_use]
    pub fn package_lock(&self) -> &VerifiedPackageLock { &self.package_lock }
    #[must_use]
    pub fn dispositions(&self) -> &[SupplierDisposition] { &self.disposition_matrix }
    #[must_use]
    pub fn proof(&self) -> &Stage0PackageAuthorityProof { &self.proof }

    #[must_use]
    pub fn disposition(
        &self,
        owner: &ReleaseCoordinate,
        role: CompilerSupplierRole,
    ) -> Option<&SupplierDisposition> {
        self.disposition_matrix.iter().find(|entry| entry.owner == *owner && entry.role == role)
    }

    #[must_use]
    pub fn available_supplier(
        &self,
        owner: &ReleaseCoordinate,
        role: CompilerSupplierRole,
    ) -> Option<&ReleaseCoordinate> {
        self.disposition(owner, role).and_then(SupplierDisposition::available_supplier)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum Stage0PackageAuthorityRefusal {
    EmptyReleaseSet,
    DuplicateRelease,
    RoleMatrixCardinalityMismatch { expected: u64, actual: u64 },
    MissingRole { release: String, role: CompilerSupplierRole },
    DuplicateRole { release: String, role: CompilerSupplierRole },
    DispositionForUnselectedRelease { release: String },
    LockDigestMismatch,
    LockReferenceMismatch,
    SignedSubjectMismatch,
    WorkReceiptMismatch,
    InvalidIdentity(IdentityRefusal),
    InvalidSignature,
    IssuerMismatch,
    KeyMismatch,
    ChargeOverflow,
}

fn checked_add(total: u64, value: u64) -> Result<u64, Stage0PackageAuthorityRefusal> {
    total.checked_add(value).ok_or(Stage0PackageAuthorityRefusal::ChargeOverflow)
}

fn checked_mul(left: u64, right: u64) -> Result<u64, Stage0PackageAuthorityRefusal> {
    left.checked_mul(right).ok_or(Stage0PackageAuthorityRefusal::ChargeOverflow)
}

fn carrier_string_bytes(release: &ReleaseCoordinateCarrier) -> Result<u64, Stage0PackageAuthorityRefusal> {
    let identity = u64::try_from(release.identity.len()).map_err(|_| Stage0PackageAuthorityRefusal::ChargeOverflow)?;
    let occurrence = u64::try_from(release.occurrence.len()).map_err(|_| Stage0PackageAuthorityRefusal::ChargeOverflow)?;
    checked_add(identity, occurrence)
}

fn precharge(
    lock: &PackageLockCarrier,
    dispositions: &[SupplierDispositionCarrier],
    budget: WorkBudget,
) -> Result<WorkReceipt, Exhaustion> {
    let release_count = u64::try_from(lock.releases.len()).unwrap_or(u64::MAX);
    let disposition_count = u64::try_from(dispositions.len()).unwrap_or(u64::MAX);
    let mut input_bytes = 32_u64;
    for release in &lock.releases {
        input_bytes = input_bytes.saturating_add(carrier_string_bytes(&release.coordinate).unwrap_or(u64::MAX));
        let source_bytes = release.source.identity.len()
            .checked_add(release.source.occurrence.len())
            .and_then(|value| u64::try_from(value).ok())
            .unwrap_or(u64::MAX);
        input_bytes = input_bytes.saturating_add(source_bytes);
        input_bytes = input_bytes.saturating_add(64);
    }
    for disposition in dispositions {
        input_bytes = input_bytes.saturating_add(carrier_string_bytes(&disposition.owner).unwrap_or(u64::MAX));
        input_bytes = input_bytes.saturating_add(16);
    }
    let input_items = release_count.saturating_add(disposition_count);
    let work_units = disposition_count
        .saturating_mul(4)
        .saturating_add(release_count.saturating_mul(58));
    let allocation_bytes = release_count
        .saturating_mul(384)
        .saturating_add(disposition_count.saturating_mul(192));
    let output_bytes = allocation_bytes.saturating_add(input_bytes);
    let stage = StageId::admit("stage0.precharge").expect("static stage identity");
    for (dimension, required, allowed) in [
        (BudgetDimension::InputItems, input_items, budget.max_input_items),
        (BudgetDimension::InputBytes, input_bytes, budget.max_input_bytes),
        (BudgetDimension::WorkUnits, work_units, budget.max_work_units),
        (BudgetDimension::AllocationBytes, allocation_bytes, budget.max_allocation_bytes),
        (BudgetDimension::OutputBytes, output_bytes, budget.max_output_bytes),
    ] {
        if required > allowed {
            return Err(Exhaustion { stage, dimension, required, allowed });
        }
    }
    Ok(WorkReceipt {
        stage,
        input_items,
        input_bytes,
        work_units,
        allocation_bytes,
        output_bytes,
        diagnostics: 0,
    })
}

fn encode_u64(output: &mut Vec<u8>, value: u64) {
    output.extend_from_slice(&value.to_be_bytes());
}

fn encode_bytes(output: &mut Vec<u8>, value: &[u8]) {
    encode_u64(output, u64::try_from(value.len()).unwrap_or(u64::MAX));
    output.extend_from_slice(value);
}

fn encode_release_coordinate(output: &mut Vec<u8>, coordinate: &ReleaseCoordinate) {
    output.push(match coordinate.kind {
        RegistryKind::Semantic => 1,
        RegistryKind::Ontology => 2,
        RegistryKind::Data => 3,
        RegistryKind::Ui => 4,
        RegistryKind::Target => 5,
        RegistryKind::Runtime => 6,
    });
    encode_bytes(output, coordinate.identity.as_str().as_bytes());
    output.extend_from_slice(&coordinate.edition.get().to_be_bytes());
    encode_bytes(output, coordinate.occurrence.stable().as_str().as_bytes());
}

fn encode_artifact(output: &mut Vec<u8>, artifact: &ArtifactRef) {
    encode_bytes(output, artifact.identity().as_str().as_bytes());
    output.extend_from_slice(&artifact.edition().get().to_be_bytes());
    encode_bytes(output, artifact.occurrence().stable().as_str().as_bytes());
    output.extend_from_slice(artifact.digest());
}

fn package_lock_projection(releases: &[SelectedRelease]) -> Vec<u8> {
    let mut output = Vec::new();
    encode_u64(&mut output, u64::try_from(releases.len()).unwrap_or(u64::MAX));
    for release in releases {
        encode_release_coordinate(&mut output, &release.coordinate);
        encode_artifact(&mut output, &release.source);
        output.extend_from_slice(&release.descriptor_digest);
        output.extend_from_slice(&release.surface_digest);
    }
    output
}

fn hex_lower(value: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut result = String::with_capacity(value.len() * 2);
    for byte in value {
        result.push(char::from(HEX[usize::from(byte >> 4)]));
        result.push(char::from(HEX[usize::from(byte & 0x0f)]));
    }
    result
}

pub fn derive_package_lock_digest(
    carrier: &PackageLockCarrier,
) -> Result<[u8; 32], Stage0PackageAuthorityRefusal> {
    let mut releases = Vec::with_capacity(carrier.releases.len());
    for release in &carrier.releases {
        releases.push(SelectedRelease {
            coordinate: ReleaseCoordinate::admit(release.coordinate.clone())
                .map_err(Stage0PackageAuthorityRefusal::InvalidIdentity)?,
            source: admit_artifact_ref(release.source.clone())
                .map_err(Stage0PackageAuthorityRefusal::InvalidIdentity)?,
            descriptor_digest: release.descriptor_digest,
            surface_digest: release.surface_digest,
        });
    }
    releases.sort_by(|left, right| left.coordinate.cmp(&right.coordinate));
    Ok(Sha256::digest(package_lock_projection(&releases)).into())
}

pub fn prepare_stage0_package_authority(
    carrier: PackageLockCarrier,
    disposition_carriers: Vec<SupplierDispositionCarrier>,
    budget: WorkBudget,
) -> TotalOutcome<Stage0PackageAuthorityCandidate, Stage0PackageAuthorityRefusal> {
    if carrier.releases.is_empty() {
        return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::EmptyReleaseSet);
    }
    let release_count = match u64::try_from(carrier.releases.len()) {
        Ok(value) => value,
        Err(_) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::ChargeOverflow),
    };
    let expected = match checked_mul(release_count, 58) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(refusal),
    };
    let actual = match u64::try_from(disposition_carriers.len()) {
        Ok(value) => value,
        Err(_) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::ChargeOverflow),
    };
    if actual != expected {
        return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::RoleMatrixCardinalityMismatch { expected, actual });
    }
    let work = match precharge(&carrier, &disposition_carriers, budget) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };

    let mut releases = Vec::with_capacity(carrier.releases.len());
    for release in carrier.releases {
        let coordinate = match ReleaseCoordinate::admit(release.coordinate) {
            Ok(value) => value,
            Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
        };
        let source = match admit_artifact_ref(release.source) {
            Ok(value) => value,
            Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
        };
        releases.push(SelectedRelease { coordinate, source, descriptor_digest: release.descriptor_digest, surface_digest: release.surface_digest });
    }
    releases.sort_by(|left, right| left.coordinate.cmp(&right.coordinate));
    if releases.windows(2).any(|pair| pair[0].coordinate == pair[1].coordinate) {
        return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::DuplicateRelease);
    }
    let projection = package_lock_projection(&releases);
    let digest: [u8; 32] = Sha256::digest(&projection).into();
    if digest != carrier.claimed_digest {
        return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::LockDigestMismatch);
    }
    let lock_ref = match PackageLockRef::admit(format!("pkg-lock:{}", hex_lower(&digest))) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
    };
    let lock = VerifiedPackageLock { reference: lock_ref, digest, releases };

    let selected = lock.releases.iter().map(|release| release.coordinate.clone()).collect::<BTreeSet<_>>();
    let mut dispositions = Vec::with_capacity(disposition_carriers.len());
    for carrier in disposition_carriers {
        let owner = match ReleaseCoordinate::admit(carrier.owner) {
            Ok(value) => value,
            Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
        };
        if !selected.contains(&owner) {
            return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::DispositionForUnselectedRelease { release: owner.identity.to_string() });
        }
        let state = match carrier.state {
            SupplierDispositionStateCarrier::Available { supplier, artifact } => {
                let supplier = match ReleaseCoordinate::admit(supplier) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
                };
                if !selected.contains(&supplier) {
                    return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::DispositionForUnselectedRelease { release: supplier.identity.to_string() });
                }
                let artifact = match admit_artifact_ref(artifact) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
                };
                SupplierDispositionState::Available { supplier, artifact }
            }
            SupplierDispositionStateCarrier::Blocked { gap } => match admit_artifact_ref(gap) {
                Ok(gap) => SupplierDispositionState::Blocked { gap },
                Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
            },
            SupplierDispositionStateCarrier::StructurallyInapplicable { proof } => match admit_artifact_ref(proof) {
                Ok(proof) => SupplierDispositionState::StructurallyInapplicable { proof },
                Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
            },
        };
        dispositions.push(SupplierDisposition { owner, role: carrier.role, state });
    }
    dispositions.sort_by(|left, right| (left.owner.clone(), left.role).cmp(&(right.owner.clone(), right.role)));

    let mut observed = BTreeMap::<ReleaseCoordinate, BTreeSet<CompilerSupplierRole>>::new();
    for disposition in &dispositions {
        let roles = observed.entry(disposition.owner.clone()).or_default();
        if !roles.insert(disposition.role) {
            return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::DuplicateRole {
                release: disposition.owner.identity.to_string(), role: disposition.role,
            });
        }
    }
    for release in lock.releases() {
        let Some(roles) = observed.get(release) else {
            return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::MissingRole {
                release: release.identity.to_string(), role: CompilerSupplierRole::SourceDigestVerification,
            });
        };
        for role in CompilerSupplierRole::ALL {
            if !roles.contains(&role) {
                return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::MissingRole {
                    release: release.identity.to_string(), role,
                });
            }
        }
    }

    let mut canonical = Vec::new();
    canonical.extend_from_slice(STAGE0_DOMAIN);
    encode_bytes(&mut canonical, &projection);
    encode_u64(&mut canonical, expected);
    for disposition in &dispositions {
        encode_release_coordinate(&mut canonical, &disposition.owner);
        canonical.extend_from_slice(&(disposition.role as u16).to_be_bytes());
        canonical.push(match disposition.kind() {
            SupplierDispositionKind::Available => 1,
            SupplierDispositionKind::Blocked => 2,
            SupplierDispositionKind::StructurallyInapplicable => 3,
        });
        encode_artifact(&mut canonical, disposition.evidence());
        if let Some(supplier) = disposition.available_supplier() {
            encode_release_coordinate(&mut canonical, supplier);
        }
    }
    TotalOutcome::Produced(Stage0PackageAuthorityCandidate { lock, dispositions, canonical, work })
}

pub fn stage0_attestation_signing_bytes(
    candidate: &Stage0PackageAuthorityCandidate,
    anchor: &PinnedStage0TrustAnchor,
    evidence: &ArtifactRef,
) -> Vec<u8> {
    let mut bytes = candidate.canonical.clone();
    encode_bytes(&mut bytes, anchor.authority.stable().as_str().as_bytes());
    encode_bytes(&mut bytes, anchor.key_id.as_str().as_bytes());
    encode_artifact(&mut bytes, &anchor.installation);
    encode_artifact(&mut bytes, evidence);
    bytes
}

pub fn verify_stage0_package_authority(
    candidate: Stage0PackageAuthorityCandidate,
    anchor: &PinnedStage0TrustAnchor,
    attestation: Stage0PackageAttestationCarrier,
    budget: WorkBudget,
) -> TotalOutcome<Stage0PackageAuthority, Stage0PackageAuthorityRefusal> {
    let issuer = match AuthorityRef::admit(attestation.issuer) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
    };
    if issuer != anchor.authority {
        return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::IssuerMismatch);
    }
    let key_id = match StableId::admit(attestation.key_id) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
    };
    if key_id != anchor.key_id {
        return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::KeyMismatch);
    }
    if attestation.verification_work_units == 0 || attestation.verification_work_units > budget.max_work_units {
        return TotalOutcome::Exhausted(Exhaustion {
            stage: StageId::admit("stage0.signature-verification").expect("static stage"),
            dimension: BudgetDimension::WorkUnits,
            required: attestation.verification_work_units.max(1),
            allowed: budget.max_work_units,
        });
    }
    let evidence = match admit_artifact_ref(attestation.evidence) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidIdentity(refusal)),
    };
    let signing_bytes = stage0_attestation_signing_bytes(&candidate, anchor, &evidence);
    let signature = Signature::from_bytes(&attestation.signature);
    let key = match VerifyingKey::from_bytes(&anchor.verifying_key) {
        Ok(value) => value,
        Err(_) => return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidSignature),
    };
    if key.verify(&signing_bytes, &signature).is_err() {
        return TotalOutcome::Refused(Stage0PackageAuthorityRefusal::InvalidSignature);
    }
    let proof = Stage0PackageAuthorityProof {
        subject: candidate.lock.reference.clone(),
        issuer,
        key_id,
        evidence,
        signature: attestation.signature,
        signed_subject: signing_bytes.clone(),
        work: WorkReceipt {
            stage: StageId::admit("stage0.signature-verification").expect("static stage"),
            input_items: 1,
            input_bytes: u64::try_from(signing_bytes.len()).unwrap_or(u64::MAX),
            work_units: attestation.verification_work_units,
            allocation_bytes: 0,
            output_bytes: 64,
            diagnostics: 0,
        },
    };
    TotalOutcome::Produced(Stage0PackageAuthority {
        package_lock: candidate.lock,
        disposition_matrix: candidate.dispositions,
        proof,
    })
}



pub fn verify_stage0_offline(
    authority: &Stage0PackageAuthority,
    anchor: &PinnedStage0TrustAnchor,
) -> Result<(), Stage0PackageAuthorityRefusal> {
    if authority.proof.subject != authority.package_lock.reference {
        return Err(Stage0PackageAuthorityRefusal::SignedSubjectMismatch);
    }
    if authority.proof.issuer != anchor.authority {
        return Err(Stage0PackageAuthorityRefusal::IssuerMismatch);
    }
    if authority.proof.key_id != anchor.key_id {
        return Err(Stage0PackageAuthorityRefusal::KeyMismatch);
    }

    let projection = package_lock_projection(&authority.package_lock.releases);
    let digest: [u8; 32] = Sha256::digest(&projection).into();
    if digest != authority.package_lock.digest {
        return Err(Stage0PackageAuthorityRefusal::LockDigestMismatch);
    }
    let expected_reference = PackageLockRef::admit(format!("pkg-lock:{}", hex_lower(&digest)))
        .map_err(Stage0PackageAuthorityRefusal::InvalidIdentity)?;
    if expected_reference != authority.package_lock.reference {
        return Err(Stage0PackageAuthorityRefusal::LockReferenceMismatch);
    }

    let release_count = u64::try_from(authority.package_lock.releases.len())
        .map_err(|_| Stage0PackageAuthorityRefusal::ChargeOverflow)?;
    let expected = checked_mul(release_count, 58)?;
    let actual = u64::try_from(authority.disposition_matrix.len())
        .map_err(|_| Stage0PackageAuthorityRefusal::ChargeOverflow)?;
    if actual != expected {
        return Err(Stage0PackageAuthorityRefusal::RoleMatrixCardinalityMismatch { expected, actual });
    }

    let selected = authority.package_lock.releases.iter()
        .map(|release| release.coordinate.clone())
        .collect::<BTreeSet<_>>();
    let mut dispositions = authority.disposition_matrix.clone();
    dispositions.sort_by(|left, right| (left.owner.clone(), left.role).cmp(&(right.owner.clone(), right.role)));
    let mut observed = BTreeMap::<ReleaseCoordinate, BTreeSet<CompilerSupplierRole>>::new();
    for disposition in &dispositions {
        if !selected.contains(&disposition.owner) {
            return Err(Stage0PackageAuthorityRefusal::DispositionForUnselectedRelease {
                release: disposition.owner.identity.to_string(),
            });
        }
        if let Some(supplier) = disposition.available_supplier() {
            if !selected.contains(supplier) {
                return Err(Stage0PackageAuthorityRefusal::DispositionForUnselectedRelease {
                    release: supplier.identity.to_string(),
                });
            }
        }
        let roles = observed.entry(disposition.owner.clone()).or_default();
        if !roles.insert(disposition.role) {
            return Err(Stage0PackageAuthorityRefusal::DuplicateRole {
                release: disposition.owner.identity.to_string(),
                role: disposition.role,
            });
        }
    }
    for release in authority.package_lock.releases() {
        let roles = observed.get(release).ok_or_else(|| Stage0PackageAuthorityRefusal::MissingRole {
            release: release.identity.to_string(),
            role: CompilerSupplierRole::SourceDigestVerification,
        })?;
        for role in CompilerSupplierRole::ALL {
            if !roles.contains(&role) {
                return Err(Stage0PackageAuthorityRefusal::MissingRole {
                    release: release.identity.to_string(),
                    role,
                });
            }
        }
    }

    let mut canonical = Vec::new();
    canonical.extend_from_slice(STAGE0_DOMAIN);
    encode_bytes(&mut canonical, &projection);
    encode_u64(&mut canonical, expected);
    for disposition in &dispositions {
        encode_release_coordinate(&mut canonical, &disposition.owner);
        canonical.extend_from_slice(&(disposition.role as u16).to_be_bytes());
        canonical.push(match disposition.kind() {
            SupplierDispositionKind::Available => 1,
            SupplierDispositionKind::Blocked => 2,
            SupplierDispositionKind::StructurallyInapplicable => 3,
        });
        encode_artifact(&mut canonical, disposition.evidence());
        if let Some(supplier) = disposition.available_supplier() {
            encode_release_coordinate(&mut canonical, supplier);
        }
    }
    encode_bytes(&mut canonical, anchor.authority.stable().as_str().as_bytes());
    encode_bytes(&mut canonical, anchor.key_id.as_str().as_bytes());
    encode_artifact(&mut canonical, &anchor.installation);
    encode_artifact(&mut canonical, &authority.proof.evidence);
    if canonical != authority.proof.signed_subject {
        return Err(Stage0PackageAuthorityRefusal::SignedSubjectMismatch);
    }

    let expected_stage = StageId::admit("stage0.signature-verification")
        .expect("static stage identity");
    let expected_input_bytes = u64::try_from(canonical.len())
        .map_err(|_| Stage0PackageAuthorityRefusal::ChargeOverflow)?;
    if authority.proof.work.stage != expected_stage
        || authority.proof.work.input_items != 1
        || authority.proof.work.input_bytes != expected_input_bytes
        || authority.proof.work.work_units == 0
        || authority.proof.work.allocation_bytes != 0
        || authority.proof.work.output_bytes != 64
        || authority.proof.work.diagnostics != 0
    {
        return Err(Stage0PackageAuthorityRefusal::WorkReceiptMismatch);
    }

    let key = VerifyingKey::from_bytes(&anchor.verifying_key)
        .map_err(|_| Stage0PackageAuthorityRefusal::InvalidSignature)?;
    let signature = Signature::from_bytes(&authority.proof.signature);
    key.verify(&canonical, &signature)
        .map_err(|_| Stage0PackageAuthorityRefusal::InvalidSignature)
}

pub fn require_available_supplier<'a>(
    authority: &'a Stage0PackageAuthority,
    owner: &ReleaseCoordinate,
    role: CompilerSupplierRole,
    stage: &str,
) -> Result<&'a ReleaseCoordinate, CompilerNeedsInput> {
    authority.available_supplier(owner, role).ok_or_else(|| CompilerNeedsInput {
        stage: StageId::admit(stage).expect("static stage identity"),
        kind: MissingInputKind::Verifier,
        subjects: vec![owner.identity.clone()],
    })
}
