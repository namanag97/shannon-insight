//! Operation contracts owned by `SAN-COMPILER-NAME-BINDING`.

pub trait NameBindingContracts {
    /// `name-binding.policy.admit`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_compiler_name_policy(
        &self,
        arg0: crate::catalog_types::name_binding::CompilerNamePolicyMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::CompilerNamePolicy, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.exports.index`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn index_family_exports(
        &self,
        arg0: &crate::vertical::FamilyDescriptorSet,
        arg1: &crate::catalog_types::name_binding::SelectedReleaseSet,
        arg2: &crate::catalog_types::name_binding::CompilerNamePolicy,
        arg3: crate::catalog_types::name_binding::NameBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::ExportRegistry, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.symbols.declare`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn declare_symbols(
        &self,
        arg0: &crate::vertical::AdmittedDeclarationSet,
        arg1: &crate::catalog_types::name_binding::ExportRegistry,
        arg2: &crate::catalog_types::name_binding::CompilerNamePolicy,
        arg3: crate::catalog_types::name_binding::NameBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::SymbolTable, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.scopes.build`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_scope_graph(
        &self,
        arg0: &crate::vertical::AdmittedDeclarationSet,
        arg1: &crate::catalog_types::name_binding::SymbolTable,
        arg2: &crate::catalog_types::name_binding::ImportDeclarationSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::ScopeGraph, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.imports.admit`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_imports(
        &self,
        arg0: &crate::vertical::AdmittedDeclarationSet,
        arg1: &crate::catalog_types::name_binding::ExportRegistry,
        arg2: &crate::catalog_types::name_binding::ScopeGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::ImportBindingSet, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.aliases.admit`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_aliases(
        &self,
        arg0: &crate::catalog_types::name_binding::AliasDeclarationSet,
        arg1: &crate::catalog_types::name_binding::SymbolTable,
        arg2: &crate::catalog_types::name_binding::ScopeGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::AliasBindingSet, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.renames.admit`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_renames(
        &self,
        arg0: &crate::catalog_types::name_binding::RenameDeclarationSet,
        arg1: &crate::catalog_types::name_binding::ExportRegistry,
        arg2: &crate::catalog_types::name_binding::CompatibilityPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::RenameBindingSet, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.candidates.discover`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn discover_symbol_candidates(
        &self,
        arg0: &crate::catalog_types::name_binding::UnresolvedNameRef,
        arg1: &crate::catalog_types::name_binding::NameBindingContext,
        arg2: crate::catalog_types::name_binding::NameBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::CandidateSymbolSet, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.reference.bind`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_reference(
        &self,
        arg0: &crate::catalog_types::name_binding::UnresolvedNameRef,
        arg1: &crate::catalog_types::name_binding::CandidateSymbolSet,
        arg2: &crate::catalog_types::name_binding::NameBindingContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::ReferenceBinding, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.references.bind-all`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_all_references(
        &self,
        arg0: &crate::vertical::AdmittedDeclarationSet,
        arg1: &crate::catalog_types::name_binding::NameBindingContext,
        arg2: crate::catalog_types::name_binding::NameBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::NameBindingOutcome, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.poison.propagate`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn propagate_name_poison(
        &self,
        arg0: &crate::catalog_types::declaration_admission::PoisonRef,
        arg1: &crate::catalog_types::name_binding::UnresolvedNameRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::PoisonedReferenceBinding, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.collisions.detect`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn detect_symbol_collisions(
        &self,
        arg0: &crate::catalog_types::name_binding::SymbolTable,
        arg1: &crate::catalog_types::name_binding::CompilerNamePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::SymbolCollisionSet, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.visibility.verify`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_visibility(
        &self,
        arg0: crate::catalog_types::name_binding::ReferenceSite,
        arg1: crate::catalog_types::name_binding::StableSymbol,
        arg2: &crate::catalog_types::name_binding::ScopeGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::VisibilityProof, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.binding.verify`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_reference_binding(
        &self,
        arg0: &crate::catalog_types::name_binding::ReferenceBinding,
        arg1: &crate::catalog_types::name_binding::NameBindingContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::ReferenceResolutionProof, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.delta.classify`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_name_binding_delta(
        &self,
        arg0: &crate::vertical::BoundDeclarationGraph,
        arg1: &crate::vertical::BoundDeclarationGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::NameBindingDelta, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.checkpoint.create`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_name_binding_checkpoint(
        &self,
        arg0: &crate::catalog_types::name_binding::NameBindingState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::NameBindingCheckpoint, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `name-binding.explain`. Owner: `SAN-COMPILER-NAME-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_name_binding(
        &self,
        arg0: crate::catalog_types::name_binding::NameExplainTarget,
        arg1: &crate::catalog_types::name_binding::NameBindingOutcome,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::NameExplanation, crate::vertical::NameBindingRefusal, crate::waist::CompilerNeedsInput>;

}
