#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,sys,tempfile,zipfile
from collections import Counter
from pathlib import Path
import jsonschema
TEST_IDS={'COHERENT_SOVEREIGN_QUESTION','SINGLE_SEMANTIC_AUTHORITY','COHERENT_VOCABULARY','DISTINCTIVE_LAWS','MEANINGFUL_LIFECYCLE','DOMAIN_SPECIFIC_REFUSALS','NAMED_CONSUMERS','EXPLICIT_NEGATIVE_SCOPE','IMPLEMENTATION_INDEPENDENCE','CROSS_INDUSTRY_STABILITY','NON_DUPLICATION','ANTI_EXPLOSION'}

def jl(p):return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]
def load_root(arg):
 p=Path(arg).resolve();td=None
 if p.is_file() and p.suffix.lower()=='.zip':
  td=tempfile.TemporaryDirectory();z=zipfile.ZipFile(p);bad=z.testzip()
  if bad:raise RuntimeError(f'ZIP CRC failure: {bad}')
  for i in z.infolist():
   dest=(Path(td.name)/i.filename).resolve()
   if not str(dest).startswith(str(Path(td.name).resolve())):raise RuntimeError(f'unsafe ZIP member {i.filename}')
  z.extractall(td.name);dirs=[x for x in Path(td.name).iterdir() if x.is_dir()];root=dirs[0] if len(dirs)==1 else Path(td.name)
 else:root=p
 return root,td

def main():
 root,td=load_root(sys.argv[1] if len(sys.argv)>1 else '.')
 errors=[];parsed=validated=checks=refs=0
 sm=json.loads((root/'validation/SCHEMA-MAP.json').read_text())
 for rel,srel in sm.items():
  p=root/rel;s=json.loads((root/srel).read_text());jsonschema.Draft202012Validator.check_schema(s);parsed+=1
  vals=jl(p) if p.suffix=='.jsonl' else [json.loads(p.read_text())]
  for i,v in enumerate(vals):
   for e in jsonschema.Draft202012Validator(s).iter_errors(v):errors.append(f'{rel}[{i}]: {e.message}')
   validated+=1
 for p in root.glob('schemas/*.json'):
  try:jsonschema.Draft202012Validator.check_schema(json.loads(p.read_text()));parsed+=1
  except Exception as e:errors.append(f'{p.relative_to(root)} invalid schema: {e}')
 checksum=[]
 for line in (root/'CHECKSUMS.txt').read_text().splitlines():
  if not line.strip():continue
  h,rel=line.split('  ',1);checksum.append(rel);checks+=1
  q=root/rel
  if not q.is_file():errors.append(f'missing checksum target {rel}')
  elif hashlib.sha256(q.read_bytes()).hexdigest()!=h:errors.append(f'checksum mismatch {rel}')
 manifest=json.loads((root/'manifest.json').read_text());sev=json.loads((root/'coverage/severity_summary.json').read_text())
 context=jl(root/'audit/context_findings.jsonl');relationships=jl(root/'audit/context_relationship_findings.jsonl');patterns=jl(root/'audit/relationship_pattern_findings.jsonl')
 ownership=jl(root/'audit/ownership_conflicts.jsonl');falseb=jl(root/'audit/false_boundaries.jsonl');missing=jl(root/'audit/missing_domains.jsonl');cross=jl(root/'audit/cross_domain_question_results.jsonl');registry=jl(root/'audit/registry_findings.jsonl')
 split=jl(root/'proposals/split_proposals.jsonl');merge=jl(root/'proposals/merge_proposals.jsonl');reclass=jl(root/'proposals/reclassification_proposals.jsonl');new=jl(root/'proposals/new_candidate_proposals.jsonl');relprop=jl(root/'proposals/relationship_reclassification_proposals.jsonl');deferred=jl(root/'proposals/deferred_questions.jsonl')
 audited=json.loads((root/'coverage/audited_candidates.json').read_text());unaudited=json.loads((root/'coverage/unaudited_candidates.json').read_text());relcov=json.loads((root/'coverage/relationship_coverage.json').read_text())
 sources=jl(root/'research/primary_sources.jsonl');claims=jl(root/'research/source_claim_map.jsonl');scope=json.loads((root/'research/research_scope.json').read_text())
 if len(context)!=1078 or audited['total']!=1078 or unaudited['total']!=0:errors.append('candidate coverage must be 1078 audited / 0 unaudited')
 cids=[r['candidate_ref']['candidate_id'] for r in context]
 if len(cids)!=len(set(cids)):errors.append('duplicate candidate audit')
 for label,recs in [('context',context),('missing',missing),('new',new)]:
  for i,r in enumerate(recs):
   tests=r['domain_correctness_tests'];ids=[t['test_id'] for t in tests]
   if len(tests)!=12 or set(ids)!=TEST_IDS or len(ids)!=len(set(ids)):errors.append(f'{label}[{i}] must contain 12 unique correctness tests')
   expected_summary={k:Counter(t['result'] for t in tests).get(k,0) for k in ['FAIL','NOT_APPLICABLE','PARTIAL','PASS']}
   actual_summary={k:r['test_summary'].get(k,0) for k in ['FAIL','NOT_APPLICABLE','PARTIAL','PASS']}
   if expected_summary!=actual_summary:errors.append(f'{label}[{i}] test summary mismatch')
 if len(cross)!=12:errors.append('exactly 12 cross-domain questions required')
 if len(relationships)!=2160 or relcov['total']!=2160:errors.append('relationship coverage must be exactly 2160')
 if relcov['session_context_relationship_count']!=1530 or relcov['registry_context_map_edge_count']!=615 or relcov['registry_semantic_seam_count']!=15:errors.append('relationship partition must be 1530/615/15')
 rids=[r['relationship_audit_id'] for r in relationships]
 if len(rids)!=len(set(rids)):errors.append('duplicate relationship audit ID')
 if sum(relcov['by_source_corpus'].values())!=2160:errors.append('relationship source counts do not sum')
 pids={p['relationship_finding_id'] for p in patterns}
 if {p['relationship_finding_ref'] for p in relprop}!=pids:errors.append('relationship proposals must exactly cover pattern findings')
 source_ids={s['source_id'] for s in sources}
 if len(source_ids)!=len(sources):errors.append('duplicate primary source ID')
 if source_ids!=set(manifest['external_research_sources']):errors.append('manifest source ledger mismatch')
 proposal_ids={r['proposal_id'] for r in new};confirmed=[r for r in missing if r['status']=='CONFIRMED_MISSING']
 region_refs=set()
 for r in missing:
  for ref in r['external_source_refs']:
   refs+=1
   if ref not in source_ids:errors.append(f'{r["region_id"]}: unknown source {ref}')
  for ref in r['new_candidate_refs']:
   if ref not in proposal_ids:errors.append(f'{r["region_id"]}: unknown proposal {ref}')
   region_refs.add(ref)
 if len(confirmed)!=8:errors.append('confirmed missing-region count must be 8')
 if len(new)!=12:errors.append('new candidate hypothesis count must be 12')
 if region_refs!=proposal_ids:errors.append('confirmed/deferred region proposal links do not exactly cover all new proposals')
 targets={'OWNERSHIP_CONFLICT':{r['conflict_id'] for r in ownership},'CROSS_DOMAIN_QUESTION':{r['question_id'] for r in cross},'MISSING_REGION':{r['region_id'] for r in missing},'NEW_CANDIDATE_PROPOSAL':proposal_ids,'RELATIONSHIP_PATTERN_FINDING':pids}
 expected={(k,v) for k,vals in targets.items() for v in vals};seen=set()
 for i,r in enumerate(claims):
  key=(r['target_kind'],r['target_id'])
  if key in seen:errors.append(f'duplicate claim target {key}')
  seen.add(key)
  if key not in expected:errors.append(f'unknown claim target {key}')
  for ref in r['source_refs']:
   refs+=1
   if ref not in source_ids:errors.append(f'claim[{i}] unknown source {ref}')
 if seen!=expected:errors.append('source claim map must exactly cover required targets')
 if scope['source_count']!=len(sources) or scope['official_or_primary_source_count']!=len(sources):errors.append('research scope source count mismatch')
 # IDs unique in every record file.
 for label,recs,field in [('context',context,'audit_id'),('relationship',relationships,'relationship_audit_id'),('pattern',patterns,'relationship_finding_id'),('ownership',ownership,'conflict_id'),('false',falseb,'false_boundary_id'),('missing',missing,'region_id'),('cross',cross,'question_id'),('registry',registry,'registry_finding_id'),('split',split,'proposal_id'),('merge',merge,'proposal_id'),('reclass',reclass,'proposal_id'),('new',new,'proposal_id'),('relprop',relprop,'proposal_id'),('deferred',deferred,'deferred_question_id'),('sources',sources,'source_id'),('claims',claims,'claim_map_id')]:
  vals=[r[field] for r in recs]
  if len(vals)!=len(set(vals)):errors.append(f'{label}: duplicate {field}')
 actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()};inv=[r['path'] for r in manifest['file_inventory']]
 if len(inv)!=len(set(inv)) or set(inv)!=actual:errors.append('manifest inventory must exactly cover all package files')
 if len(checksum)!=len(set(checksum)) or set(checksum)!=(actual-{'CHECKSUMS.txt'}):errors.append('CHECKSUMS must exactly cover all files except itself')
 counts={'context_finding_count':len(context),'context_relationship_finding_count':len(relationships),'relationship_pattern_finding_count':len(patterns),'relationship_reclassification_proposal_count':len(relprop),'ownership_conflict_count':len(ownership),'duplicate_owner_count':len(ownership),'false_boundary_count':len(falseb),'missing_region_evaluation_count':len(missing),'confirmed_missing_domain_count':len(confirmed),'confirmed_missing_region_count':len(confirmed),'cross_domain_question_count':len(cross),'registry_finding_count':len(registry),'split_proposal_count':len(split),'merge_proposal_count':len(merge),'reclassification_proposal_count':len(reclass),'new_candidate_proposal_count':len(new),'missing_owner_hypothesis_count':len(new),'deferred_question_count':len(deferred),'external_primary_source_count':len(sources),'source_claim_map_count':len(claims)}
 for k,v in counts.items():
  if manifest['counts'].get(k)!=v:errors.append(f'manifest count mismatch {k}: {manifest["counts"].get(k)} != {v}')
 for s in ['P0','P1','P2','P3']:
  if manifest['counts'].get(s)!=sev['canonical_unique_findings_by_severity'].get(s):errors.append(f'severity mismatch {s}')
 if any('merged-atlas' in p.name.lower() for p in root.rglob('*') if p.is_file()):errors.append('forbidden merged atlas artifact present')
 result={'status':'PASS' if not errors else 'FAIL','parsed_and_schema_validated_files':parsed,'validated_records':validated,'checksum_entries_verified':checks,'audited_candidates':len(context),'audited_relationship_artifacts':len(relationships),'confirmed_missing_regions':len(confirmed),'new_owner_hypotheses':len(new),'external_primary_sources':len(sources),'source_claim_map_records':len(claims),'referential_checks_performed':refs,'package_file_count':len(actual),'errors':errors}
 print(json.dumps(result,indent=2,sort_keys=True))
 if td:td.cleanup()
 return 0 if not errors else 1
if __name__=='__main__':raise SystemExit(main())
