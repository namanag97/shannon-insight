//! Operation contracts owned by `SAN-COMPILER-FAMILY-COMPILATION`.

pub trait FamilyCompilationContracts {
    /// `family-closure.input.slice`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn slice_family_inputs(
        &self,
        arg0: crate::catalog_types::family_compilation::FamilyReleaseRef,
        arg1: &crate::vertical::BoundDeclarationGraph,
        arg2: &crate::vertical::ExpandedContributionSet,
        arg3: &crate::vertical::ResolvedDecisionSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyCompilationInput, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.dependency.build`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_family_compile_graph(
        &self,
        arg0: &crate::vertical::FamilyDescriptorSet,
        arg1: &crate::vertical::BoundDeclarationGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyCompileDependencyGraph, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.dispatch.bind`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_family_compiler_dispatch(
        &self,
        arg0: &crate::vertical::FamilyDescriptorSet,
        arg1: &crate::catalog_types::family_compilation::FamilySurfaceSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyCompilerDispatchTable, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.plan.schedule`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn schedule_family_closure(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyCompileDependencyGraph,
        arg1: crate::catalog_types::family_compilation::FamilyClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyClosureSchedule, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.family.validate-input`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn validate_family_input(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyCompilationInput,
        arg1: &crate::vertical::FamilyDescriptor,
        arg2: &crate::catalog_types::family_compilation::ImportedFamilyPublicSurfaceSet,
        arg3: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyInputProof, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.family.run-pass`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn run_family_compiler_pass(
        &self,
        arg0: crate::catalog_types::family_compilation::FamilyPassId,
        arg1: &crate::catalog_types::family_compilation::FamilyPassInput,
        arg2: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        arg3: crate::catalog_types::family_compilation::FamilyClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyPassOutput, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.family.run-plan`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn run_family_pass_plan(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyCompilationInput,
        arg1: &crate::catalog_types::family_compilation::FamilyPassPlan,
        arg2: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        arg3: crate::catalog_types::family_compilation::FamilyClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyPassClosure, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.requirements.emit`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn emit_family_requirements(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyPassClosure,
        arg1: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyRequirementSet, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.cards.emit`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn emit_family_cards(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyPassClosure,
        arg1: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyCardSet, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.obligations.emit`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn emit_family_obligation_seeds(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyPassClosure,
        arg1: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyObligationSeedSet, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.extensions.emit`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn emit_family_extensions(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyPassClosure,
        arg1: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyExtensionSet, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.public-surface.project`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_family_public_surface(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyPassClosure,
        arg1: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyPublicCompileSurface, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.inputs.account`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn account_family_inputs(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyCompilationInput,
        arg1: &crate::catalog_types::family_compilation::FamilyPassClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyInputDispositionLedger, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.gaps.resolve`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_family_plan_gaps(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyGapLedger,
        arg1: &crate::catalog_types::family_compilation::FamilyClosurePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyGapDispositionSet, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.canonical.project`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_family_plan(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyPassClosure,
        arg1: &crate::catalog_types::family_compilation::FamilyEmissions,
        arg2: &crate::catalog_types::family_compilation::FamilyInputDispositionLedger,
        arg3: &crate::catalog_types::family_compilation::FamilyGapDispositionSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyPlanCanonicalProjection, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.plan.build`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_family_plan(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyCompilationInput,
        arg1: &crate::catalog_types::family_compilation::FamilyPassClosure,
        arg2: &crate::catalog_types::family_compilation::FamilyEmissions,
        arg3: &crate::catalog_types::family_compilation::FamilyPlanCanonicalProjection,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::FamilyPlan, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.plan.verify`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_family_plan(
        &self,
        arg0: &crate::vertical::FamilyPlan,
        arg1: &crate::vertical::FamilyDescriptor,
        arg2: &crate::catalog_types::family_compilation::FamilyCompilerSurface,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyClosureProof, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.set.close`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_family_plan_set(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyClosureSchedule,
        arg1: &crate::catalog_types::family_compilation::FamilyClosureInput,
        arg2: crate::catalog_types::family_compilation::FamilyClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyPlanSetOutcome, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.checkpoint.create`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_family_closure_checkpoint(
        &self,
        arg0: &crate::catalog_types::family_compilation::FamilyClosureState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyClosureCheckpoint, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.delta.classify`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_family_plan_delta(
        &self,
        arg0: &crate::vertical::FamilyPlan,
        arg1: &crate::vertical::FamilyPlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyPlanDelta, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

    /// `family-closure.explain`. Owner: `SAN-COMPILER-FAMILY-COMPILATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_family_plan(
        &self,
        arg0: crate::catalog_types::family_compilation::FamilyExplainTarget,
        arg1: &crate::catalog_types::family_compilation::FamilyPlanSetOutcome,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::family_compilation::FamilyPlanExplanation, crate::vertical::FamilyCompilationRefusal, crate::waist::CompilerNeedsInput>;

}
