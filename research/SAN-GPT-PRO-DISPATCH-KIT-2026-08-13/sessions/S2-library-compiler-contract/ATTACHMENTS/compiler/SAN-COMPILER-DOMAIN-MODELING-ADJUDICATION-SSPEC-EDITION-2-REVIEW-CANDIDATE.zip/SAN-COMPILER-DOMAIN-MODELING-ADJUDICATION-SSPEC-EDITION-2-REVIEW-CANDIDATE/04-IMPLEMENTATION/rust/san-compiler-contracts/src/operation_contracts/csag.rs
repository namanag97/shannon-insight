//! Operation contracts owned by `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`.

pub trait CsagContracts {
    /// `csag-builder.input.admit`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_csag_build_input(
        &self,
        arg0: crate::catalog_types::csag::CsagBuildInputMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagBuildInput, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.input.verify`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_csag_inputs(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: &crate::catalog_types::csag::CsagBuildInput,
        arg2: &crate::catalog_types::csag::CsagTrustPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagInputs, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.dispatch.bind`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_graph_projection_dispatch(
        &self,
        arg0: &crate::catalog_types::csag::CsagInputs,
        arg1: &crate::catalog_types::csag::GeneratedGraphDispatchMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::GraphProjectionDispatchTable, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.schema.index`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn index_csag_schemas(
        &self,
        arg0: &crate::catalog_types::csag::CsagInputs,
        arg1: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagSchemaRegistry, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.family.project-one`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_family_fragment(
        &self,
        arg0: crate::catalog_types::csag::FamilyPlanRef,
        arg1: &crate::vertical::ApplicationBinding,
        arg2: &crate::catalog_types::csag::GraphProjectionDispatchTable,
        arg3: crate::catalog_types::csag::ProjectionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::FamilyGraphFragment, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.family.project-all`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_family_fragments(
        &self,
        arg0: &crate::catalog_types::csag::CsagInputs,
        arg1: &crate::catalog_types::csag::GraphProjectionDispatchTable,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::FamilyGraphFragmentSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.closure.project-linker`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_linker_closure_fragment(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: &crate::vertical::ApplicationBinding,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::LinkerGraphFragment, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.closure.project-obligations`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_obligation_fragment(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::ObligationGraphFragment, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.fragment.verify-local`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_graph_fragment(
        &self,
        arg0: &crate::catalog_types::csag::GraphFragment,
        arg1: &crate::catalog_types::csag::CsagSchemaRegistry,
        arg2: &crate::catalog_types::csag::CsagInputs,
        arg3: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::FragmentVerificationProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.fragments.verify-all`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_all_fragments(
        &self,
        arg0: &crate::catalog_types::csag::GraphFragmentSet,
        arg1: &crate::catalog_types::csag::CsagSchemaRegistry,
        arg2: &crate::catalog_types::csag::CsagInputs,
        arg3: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::FragmentVerificationSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.nodes.collect`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn collect_node_proposals(
        &self,
        arg0: &crate::catalog_types::csag::GraphFragmentSet,
        arg1: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::NodeProposalSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.nodes.commit`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_nodes(
        &self,
        arg0: &crate::catalog_types::csag::NodeProposalSet,
        arg1: &crate::catalog_types::csag::CsagSchemaRegistry,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::NodeCommitResult, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.references.resolve`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_node_references(
        &self,
        arg0: &crate::catalog_types::csag::GraphFragmentSet,
        arg1: &crate::catalog_types::csag::NodeCommitResult,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::ReferenceResolutionTable, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.edges.collect`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn collect_hyperedge_proposals(
        &self,
        arg0: &crate::catalog_types::csag::GraphFragmentSet,
        arg1: &crate::catalog_types::csag::ReferenceResolutionTable,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::HyperedgeProposalSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.edges.commit`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_hyperedges(
        &self,
        arg0: &crate::catalog_types::csag::HyperedgeProposalSet,
        arg1: &crate::catalog_types::csag::NodeCommitResult,
        arg2: &crate::catalog_types::csag::CsagSchemaRegistry,
        arg3: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::HyperedgeCommitResult, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.provenance.intern`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn intern_csag_provenance(
        &self,
        arg0: &crate::catalog_types::csag::GraphFragmentSet,
        arg1: &crate::catalog_types::csag::NodeCommitResult,
        arg2: &crate::catalog_types::csag::HyperedgeCommitResult,
        arg3: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::ProvenanceIndex, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.index.incidence`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_incidence_indexes(
        &self,
        arg0: &crate::catalog_types::csag::NodeCommitResult,
        arg1: &crate::catalog_types::csag::HyperedgeCommitResult,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::IncidenceIndexSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.index.semantic`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_semantic_indexes(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::SemanticIndexSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.ownership`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_owner_uniqueness(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::OwnerUniquenessProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.references`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_reference_closure(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ReferenceClosureProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.endpoint-schema`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_endpoint_schemas(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::EndpointSchemaProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.phase`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_phase_consistency(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::PhaseCompatibilityProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.epistemic`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_epistemic_transitions(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::catalog_types::csag::EpistemicPolicySet,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::EpistemicClosureProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.bindings`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_binding_coverage(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::vertical::ApplicationBinding,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::BindingCoverageProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.obligations`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_obligation_coverage(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::vertical::ObligationClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::ObligationCoverageProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.decisions`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_decision_coverage(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::vertical::ApplicationBinding,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::DecisionCoverageProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.gaps`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_gap_coverage(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: &crate::catalog_types::csag::CsagBuilderState,
        arg2: &crate::vertical::ApplicationBinding,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::GapCoverageProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.provider-free`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_provider_free(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::ProviderFreeProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.orphans`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_orphan_dispositions(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::catalog_types::csag::CsagSchemaRegistry,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::OrphanDispositionProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.projection.compile`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_compile_projection(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CompileProjection, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.projection.application`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_application_projection(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::ApplicationSemanticProjection, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.projection.authority`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_authority_projection(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::AuthorityProjection, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.projection.runtime`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_runtime_projection(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::RuntimeInteractionProjection, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.projection.evolution`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_evolution_projection(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::EvolutionProjection, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.projection.deployment`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_deployment_requirement_projection(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::DeploymentRequirementProjection, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.projection.verify-all`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_csag_projections(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: &crate::catalog_types::csag::CsagProjectionSet,
        arg2: &crate::vertical::ApplicationBinding,
        arg3: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::ProjectionProofSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify.global`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_csag_global(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::catalog_types::csag::CsagProjectionSet,
        arg2: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagClosureProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.explain.build`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_csag_explanation_graph(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::catalog_types::csag::CsagClosureProof,
        arg2: crate::waist::DisclosurePolicyRef,
        arg3: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagExplanationGraph, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.canonical.project`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_canonical_csag(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuilderState,
        arg1: &crate::catalog_types::csag::CsagProjectionSet,
        arg2: &crate::catalog_types::csag::CsagClosureProof,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagCanonicalProjection, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.seal.attach`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn attach_csag_seal(
        &self,
        arg0: &crate::catalog_types::csag::CsagCanonicalProjection,
        arg1: &crate::catalog_types::app_release::ExternalSealBundle,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagSeal, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.build`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_csag(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuildInput,
        arg1: &crate::catalog_types::csag::CsagExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagBuildOutcome, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.verify`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_csag(
        &self,
        arg0: &crate::vertical::Csag,
        arg1: &crate::catalog_types::csag::CsagVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagVerificationProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.slice.requirement-admit`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_slice_requirement(
        &self,
        arg0: crate::catalog_types::csag::SliceRequirementMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::SliceRequirement, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.slice.compute`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn slice_csag(
        &self,
        arg0: &crate::vertical::Csag,
        arg1: &crate::catalog_types::csag::SliceRequirement,
        arg2: &crate::catalog_types::csag::CsagSliceContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagSlice, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.slice.verify`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_csag_slice(
        &self,
        arg0: &crate::catalog_types::csag::CsagSlice,
        arg1: &crate::vertical::Csag,
        arg2: &crate::catalog_types::csag::SliceRequirement,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagSliceProof, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.slice.family`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn slice_family(
        &self,
        arg0: &crate::vertical::Csag,
        arg1: crate::catalog_types::family_compilation::FamilyReleaseRef,
        arg2: crate::catalog_types::csag::FamilySlicePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagSlice, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.slice.target`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn slice_target(
        &self,
        arg0: &crate::vertical::Csag,
        arg1: &crate::catalog_types::csag::TargetSliceRequirement,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagSlice, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.explain.node`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_csag_node(
        &self,
        arg0: &crate::vertical::Csag,
        arg1: crate::catalog_types::csag::CsagNodeId,
        arg2: crate::waist::DisclosurePolicyRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagExplanation, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.explain.path`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_csag_path(
        &self,
        arg0: &crate::vertical::Csag,
        arg1: crate::catalog_types::csag::CsagExplainQuery,
        arg2: crate::waist::DisclosurePolicyRef,
        arg3: crate::catalog_types::csag::CsagBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagExplanationPathSet, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.checkpoint.resume`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_csag_build(
        &self,
        arg0: &crate::catalog_types::csag::CsagBuildCheckpoint,
        arg1: &crate::catalog_types::csag::CsagBuildInput,
        arg2: &crate::catalog_types::csag::CsagExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagBuildOutcome, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.delta.classify`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_csag_delta(
        &self,
        arg0: &crate::vertical::Csag,
        arg1: &crate::vertical::Csag,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagDelta, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.incremental.plan`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_incremental_csag_rebuild(
        &self,
        arg0: &crate::catalog_types::csag::CsagDelta,
        arg1: &crate::vertical::Csag,
        arg2: &crate::catalog_types::csag::CsagBuildInput,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::IncrementalCsagBuildPlan, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

    /// `csag-builder.parity.verify`. Owner: `SAN-COMPILER-CSAG-CONSTRUCTION-AND-VERIFICATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_csag_parity(
        &self,
        arg0: crate::catalog_types::csag::CsagVectorCorpus,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::csag::CsagParityReport, crate::vertical::CsagRefusal, crate::waist::CompilerNeedsInput>;

}
