
# SAN Cross-Registry Composability, Intermediate Representation and Execution-Closure Package

This deterministic review-candidate package contains the selected architecture, attached-source claim ledger, Global Registry rebase, current Rust adjudication, executable Python reference validator, mutation suite and standalone Rust architectural model.

The package makes no claim that SAN production source was modified or that a production compiler, target, runtime, deployment or boot executed. The source-authorized User Interface contribution remains absent. The reference client fixture is deliberately marked as reference authority only.

Run the package verifier from the extracted root:

```bash
./VERIFY/run.sh
```

Require Rust execution rather than accepting the disclosed toolchain blocker:

```bash
./VERIFY/run.sh --require-rust
```

The package remains `REVIEW_CANDIDATE` with certification `NONE`.
