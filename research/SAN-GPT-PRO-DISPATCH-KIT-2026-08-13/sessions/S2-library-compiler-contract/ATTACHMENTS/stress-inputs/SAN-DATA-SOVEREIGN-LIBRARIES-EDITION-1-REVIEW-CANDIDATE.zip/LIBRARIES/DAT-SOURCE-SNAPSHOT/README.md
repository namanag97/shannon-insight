# DAT-SOURCE-SNAPSHOT · Source Snapshot Semantics

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

What coherent finite source read was observed at one source cut and isolation posture, with which coverage, segmentation, finalization, resume, and completeness claims?

## Boundary

Owns:
- source snapshot identity
- source cut/coherence posture
- snapshot segmentation semantics
- source finalization requirement
- snapshot completeness qualification
- snapshot resume invariants

Explicitly excludes:
- database transaction implementation
- provider snapshot mode
- source I/O
- table-format snapshot
- generic data cut
- checkpoint
- savepoint
- watermark

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- DAT-SOURCE-OBSERVATION
- DAT-DATA-CUT

## Reciprocal semantic seams

- None in this edition.

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
