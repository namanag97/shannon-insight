
#![forbid(unsafe_code)]
//! REVIEW_CANDIDATE SAN compiler contract crate.
//!
//! Certification is NONE. The source is field-complete and includes a non-vacuous
//! reference vertical, but this package records no Cargo evidence in the audit environment.

pub mod waist;
pub mod stage0;
pub mod catalog_types;
pub mod operation_contracts;
pub mod vertical;
