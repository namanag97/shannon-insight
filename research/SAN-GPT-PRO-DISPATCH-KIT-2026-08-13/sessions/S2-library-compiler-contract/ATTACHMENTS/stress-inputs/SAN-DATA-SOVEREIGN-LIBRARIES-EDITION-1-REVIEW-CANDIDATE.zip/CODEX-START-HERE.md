# Codex Start Here

1. Read `README.md`, `CATALOG.json`, `OWNERSHIP-MATRIX.json`, `BOUNDARY-ADJUDICATION.json`, `HARD-DEPENDENCY-DAG.json`, and `FIRST-BATCH-SELECTION.json`.
2. Treat all eight specifications as `REVIEW_CANDIDATE`, certification `NONE`.
3. Do not write a library until its external Sovereign Semantic imports and current compiler contracts are reconciled.
4. Use `IMPLEMENTATION-PACKET.json` as an implementation plan, not as evidence of implementation.
5. Implement carriers and budget precharge first; admitted values have private fields and no `Deserialize` constructor.
6. Keep semantic requirements separate from provider offers and runtime mechanisms.
7. Run `python VERIFY/verify.py .` after every generated or manual change.
8. No analytical result may mutate application state directly; mutation re-enters Host Role Composition → Kernel.
