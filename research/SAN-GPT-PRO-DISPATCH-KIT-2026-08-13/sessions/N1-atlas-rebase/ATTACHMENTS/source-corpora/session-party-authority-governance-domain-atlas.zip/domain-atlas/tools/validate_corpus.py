#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path
from typing import Any
from jsonschema import Draft202012Validator, FormatChecker

BANNED = {"metadata", "properties", "attributes", "payload", "extensions", "custom_fields", "notes"}

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def load_jsonl(path: Path) -> list[dict[str, Any]]:
    result = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            raise ValueError(f"blank JSONL line: {path}:{number}")
        result.append(json.loads(line))
    return result

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def walk(value: Any, record_id: str, ids: set[str], errors: list[dict[str, Any]], key: str | None = None, path: tuple[str, ...] = ()) -> None:
    if isinstance(value, dict):
        for k, v in value.items():
            if k in BANNED:
                errors.append({"check": "banned_field", "record_id": record_id, "path": "/".join((*path, k))})
            walk(v, record_id, ids, errors, k, (*path, k))
        if value.get("object_type") == "REFERENCE" and isinstance(value.get("value"), str):
            ref = value["value"]
            if ref.startswith("candidate.party-authority-governance.") and ref not in ids:
                errors.append({"check": "missing_claim_reference", "record_id": record_id, "missing_ref": ref})
    elif isinstance(value, list):
        for i, child in enumerate(value):
            walk(child, record_id, ids, errors, key, (*path, str(i)))
    elif isinstance(value, str):
        if key == "missing_ref":
            return
        if value.startswith("candidate.party-authority-governance.") and value not in ids:
            errors.append({"check": "missing_local_reference", "record_id": record_id, "path": "/".join(path), "missing_ref": value})

def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    manifest = load_json(root / "manifest.json")
    errors: list[dict[str, Any]] = []
    records: list[dict[str, Any]] = []
    by_kind: dict[str, list[dict[str, Any]]] = {}
    for collection, rel in manifest["data_files"].items():
        path = root / rel
        items = load_jsonl(path)
        if [r["id"] for r in items] != sorted(r["id"] for r in items):
            errors.append({"check": "deterministic_order", "file": rel})
        records.extend(items)
        for item in items:
            by_kind.setdefault(item["kind"], []).append(item)
    ids = {r["id"] for r in records}
    duplicates = [i for i, n in Counter(r["id"] for r in records).items() if n > 1]
    if duplicates:
        errors.append({"check": "duplicate_ids", "ids": sorted(duplicates)})
    for kind, items in by_kind.items():
        schema_path = root / manifest["schema_files_by_kind"][kind]
        schema = load_json(schema_path)
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(schema, format_checker=FormatChecker())
        for item in items:
            for err in validator.iter_errors(item):
                errors.append({"check": "schema", "record_id": item["id"], "path": "/".join(str(x) for x in err.path), "message": err.message})
            walk(item, item["id"], ids, errors)
    checksums = {}
    for line in (root / "CHECKSUMS.txt").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        digest, rel = line.split("  ", 1)
        checksums[rel] = digest
    for rel, expected in checksums.items():
        path = root / rel
        if not path.exists():
            errors.append({"check": "checksum_missing_file", "file": rel})
        elif sha256(path) != expected:
            errors.append({"check": "checksum_mismatch", "file": rel})
    status = "PASS" if not errors else "FAIL"
    print(json.dumps({"status": status, "record_count": len(records), "kind_count": len(by_kind), "error_count": len(errors), "errors": errors[:100]}, indent=2))
    return 0 if not errors else 1

if __name__ == "__main__":
    raise SystemExit(main())
