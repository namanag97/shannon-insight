#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parents[1]

def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    manifest = json.loads((ROOT / 'MANIFEST.json').read_text())
    errors = []
    for item in manifest['files']:
        path = ROOT / item['path']
        if not path.is_file():
            errors.append(f'missing:{item["path"]}')
        elif sha256(path) != item['sha256']:
            errors.append(f'hash:{item["path"]}')
    types = []
    for path in list((ROOT / '02-COMPILER').glob('*/TYPES.json')) + list((ROOT / '03-DOMAIN-MODELING').glob('*/TYPES.json')):
        types.extend(json.loads(path.read_text())['type_rows'])
    if len(types) != 751:
        errors.append(f'type-count:{len(types)}')
    for row in types:
        algebra = row['algebra']
        if algebra['kind'] == 'struct' and not algebra.get('fields'):
            errors.append(f'fieldless:{row["catalog_identity"]}')
        if algebra['kind'] == 'enum' and not algebra.get('variants'):
            errors.append(f'variantless:{row["catalog_identity"]}')
    rust = '\n'.join(path.read_text() for path in (ROOT / '04-IMPLEMENTATION/rust').rglob('*.rs'))
    for forbidden in ['san-spec-model', 'san_spec_model', 'CURRENT_RUST_CANDIDATE', 'VerifiedVerifiedApplicationClosure', 'BackendBackendAppRelease']:
        if forbidden in rust:
            errors.append(f'forbidden:{forbidden}')
    if re.search(r'pub struct\s+[A-Za-z0-9_]+\s*;', rust):
        errors.append('unit-struct')
    print(json.dumps({'passed': not errors, 'errors': errors}, indent=2))
    return 0 if not errors else 1

if __name__ == '__main__':
    raise SystemExit(main())
