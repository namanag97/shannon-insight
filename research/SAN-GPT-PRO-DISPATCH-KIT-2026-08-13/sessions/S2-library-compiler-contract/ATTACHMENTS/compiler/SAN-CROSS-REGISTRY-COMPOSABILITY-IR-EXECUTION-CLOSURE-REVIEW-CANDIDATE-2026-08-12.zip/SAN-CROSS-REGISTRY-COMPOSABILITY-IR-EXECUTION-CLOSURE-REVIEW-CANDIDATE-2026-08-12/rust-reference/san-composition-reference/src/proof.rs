
//! Verifier-issued positive authority and sealed artifact values.
//! Fields and issuance functions are intentionally not public to callers.
#![allow(dead_code)]

use crate::canonical::CanonicalCommitment;
use crate::model::*;

#[derive(Clone, Debug, Eq, PartialEq)]
struct ProofSeal {
    issuer: VerifierId,
    nonce_commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkReceipt {
    algorithm: StableCoordinate,
    limit: u64,
    consumed: u64,
    input_commitment: CanonicalCommitment,
    result_commitment: CanonicalCommitment,
}

impl WorkReceipt {
    pub fn algorithm(&self) -> &StableCoordinate {
        &self.algorithm
    }

    pub fn limit(&self) -> u64 {
        self.limit
    }

    pub fn consumed(&self) -> u64 {
        self.consumed
    }

    pub fn input_commitment(&self) -> CanonicalCommitment {
        self.input_commitment
    }

    pub fn result_commitment(&self) -> CanonicalCommitment {
        self.result_commitment
    }

    pub(crate) fn issue(
        algorithm: StableCoordinate,
        limit: u64,
        consumed: u64,
        input_commitment: CanonicalCommitment,
        result_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            algorithm,
            limit,
            consumed,
            input_commitment,
            result_commitment,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AuthorityWitness {
    authority_owner: SovereignOwner,
    authority_contract: ContractId,
    source_occurrence: OccurrenceId,
    package_lock_commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl AuthorityWitness {
    pub fn authority_owner(&self) -> &SovereignOwner {
        &self.authority_owner
    }

    pub fn authority_contract(&self) -> &ContractId {
        &self.authority_contract
    }

    pub fn source_occurrence(&self) -> &OccurrenceId {
        &self.source_occurrence
    }

    pub(crate) fn issue(
        authority_owner: SovereignOwner,
        authority_contract: ContractId,
        source_occurrence: OccurrenceId,
        package_lock_commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            authority_owner,
            authority_contract,
            source_occurrence,
            package_lock_commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionProof {
    contribution_occurrence: OccurrenceId,
    contribution_commitment: CanonicalCommitment,
    package_lock_commitment: CanonicalCommitment,
    admitted_facets: Vec<FacetKind>,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl AdmissionProof {
    pub fn contribution_occurrence(&self) -> &OccurrenceId {
        &self.contribution_occurrence
    }

    pub fn contribution_commitment(&self) -> CanonicalCommitment {
        self.contribution_commitment
    }

    pub fn admitted_facets(&self) -> &[FacetKind] {
        &self.admitted_facets
    }

    pub(crate) fn issue(
        contribution_occurrence: OccurrenceId,
        contribution_commitment: CanonicalCommitment,
        package_lock_commitment: CanonicalCommitment,
        admitted_facets: Vec<FacetKind>,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            contribution_occurrence,
            contribution_commitment,
            package_lock_commitment,
            admitted_facets,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Stage0SupplierInventoryClosure {
    package_lock_occurrence: OccurrenceId,
    package_lock_commitment: CanonicalCommitment,
    selected_release_occurrences: Vec<OccurrenceId>,
    disposition_count: usize,
    supplier_role_count: usize,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl Stage0SupplierInventoryClosure {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn disposition_count(&self) -> usize {
        self.disposition_count
    }

    pub fn expected_disposition_count(&self) -> usize {
        self.selected_release_occurrences.len() * self.supplier_role_count
    }

    pub(crate) fn issue(
        package_lock_occurrence: OccurrenceId,
        package_lock_commitment: CanonicalCommitment,
        selected_release_occurrences: Vec<OccurrenceId>,
        disposition_count: usize,
        supplier_role_count: usize,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            package_lock_occurrence,
            package_lock_commitment,
            selected_release_occurrences,
            disposition_count,
            supplier_role_count,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBinding {
    package_lock_commitment: CanonicalCommitment,
    supplier_closure_commitment: CanonicalCommitment,
    requirement_occurrences: Vec<OccurrenceId>,
    offer_occurrences: Vec<OccurrenceId>,
    decisions: Vec<SelectionDecision>,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl ApplicationBinding {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn decisions(&self) -> &[SelectionDecision] {
        &self.decisions
    }

    pub(crate) fn issue(
        package_lock_commitment: CanonicalCommitment,
        supplier_closure_commitment: CanonicalCommitment,
        requirement_occurrences: Vec<OccurrenceId>,
        offer_occurrences: Vec<OccurrenceId>,
        decisions: Vec<SelectionDecision>,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            package_lock_commitment,
            supplier_closure_commitment,
            requirement_occurrences,
            offer_occurrences,
            decisions,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosure {
    package_lock_commitment: CanonicalCommitment,
    application_binding_commitment: CanonicalCommitment,
    obligations: Vec<ObligationContribution>,
    fixed_point_rounds: u64,
    rule_edition: RuleEdition,
    schema_edition: SchemaEdition,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl ObligationClosure {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn obligations(&self) -> &[ObligationContribution] {
        &self.obligations
    }

    pub fn fixed_point_rounds(&self) -> u64 {
        self.fixed_point_rounds
    }

    pub(crate) fn issue(
        package_lock_commitment: CanonicalCommitment,
        application_binding_commitment: CanonicalCommitment,
        obligations: Vec<ObligationContribution>,
        fixed_point_rounds: u64,
        rule_edition: RuleEdition,
        schema_edition: SchemaEdition,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            package_lock_commitment,
            application_binding_commitment,
            obligations,
            fixed_point_rounds,
            rule_edition,
            schema_edition,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Csag {
    package_lock_commitment: CanonicalCommitment,
    application_binding_commitment: CanonicalCommitment,
    obligation_closure_commitment: CanonicalCommitment,
    nodes: Vec<HostileGraphNode>,
    hyperedges: Vec<HostileHyperedge>,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl Csag {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn nodes(&self) -> &[HostileGraphNode] {
        &self.nodes
    }

    pub fn hyperedges(&self) -> &[HostileHyperedge] {
        &self.hyperedges
    }

    pub(crate) fn issue(
        package_lock_commitment: CanonicalCommitment,
        application_binding_commitment: CanonicalCommitment,
        obligation_closure_commitment: CanonicalCommitment,
        nodes: Vec<HostileGraphNode>,
        hyperedges: Vec<HostileHyperedge>,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            package_lock_commitment,
            application_binding_commitment,
            obligation_closure_commitment,
            nodes,
            hyperedges,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PortableIrPortfolio {
    csag_commitment: CanonicalCommitment,
    modules: Vec<PortableIrContribution>,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl PortableIrPortfolio {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn modules(&self) -> &[PortableIrContribution] {
        &self.modules
    }

    pub(crate) fn issue(
        csag_commitment: CanonicalCommitment,
        modules: Vec<PortableIrContribution>,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            csag_commitment,
            modules,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetCapabilityNegotiation {
    target_occurrence: OccurrenceId,
    ir_portfolio_commitment: CanonicalCommitment,
    required: Vec<CapabilityId>,
    supported: Vec<CapabilityId>,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl TargetCapabilityNegotiation {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub(crate) fn issue(
        target_occurrence: OccurrenceId,
        ir_portfolio_commitment: CanonicalCommitment,
        required: Vec<CapabilityId>,
        supported: Vec<CapabilityId>,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            target_occurrence,
            ir_portfolio_commitment,
            required,
            supported,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetLegalityReport {
    negotiation_commitment: CanonicalCommitment,
    legal_module_occurrences: Vec<OccurrenceId>,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl TargetLegalityReport {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub(crate) fn issue(
        negotiation_commitment: CanonicalCommitment,
        legal_module_occurrences: Vec<OccurrenceId>,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            negotiation_commitment,
            legal_module_occurrences,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LoweredTargetArtifactSet {
    legality_commitment: CanonicalCommitment,
    target_occurrence: OccurrenceId,
    artifacts: Vec<LoweredTargetArtifact>,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl LoweredTargetArtifactSet {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn artifacts(&self) -> &[LoweredTargetArtifact] {
        &self.artifacts
    }

    pub(crate) fn issue(
        legality_commitment: CanonicalCommitment,
        target_occurrence: OccurrenceId,
        artifacts: Vec<LoweredTargetArtifact>,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            legality_commitment,
            target_occurrence,
            artifacts,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TranslationValidationSet {
    lowered_artifact_commitment: CanonicalCommitment,
    validator: VerifierId,
    validated_artifact_occurrences: Vec<OccurrenceId>,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl TranslationValidationSet {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub(crate) fn issue(
        lowered_artifact_commitment: CanonicalCommitment,
        validator: VerifierId,
        validated_artifact_occurrences: Vec<OccurrenceId>,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            lowered_artifact_commitment,
            validator,
            validated_artifact_occurrences,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetCompilationSet {
    target_occurrence: OccurrenceId,
    negotiation_commitment: CanonicalCommitment,
    legality_commitment: CanonicalCommitment,
    lowered_artifact_commitment: CanonicalCommitment,
    translation_validation_commitment: CanonicalCommitment,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl TargetCompilationSet {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn target_occurrence(&self) -> &OccurrenceId {
        &self.target_occurrence
    }

    pub(crate) fn issue(
        target_occurrence: OccurrenceId,
        negotiation_commitment: CanonicalCommitment,
        legality_commitment: CanonicalCommitment,
        lowered_artifact_commitment: CanonicalCommitment,
        translation_validation_commitment: CanonicalCommitment,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            target_occurrence,
            negotiation_commitment,
            legality_commitment,
            lowered_artifact_commitment,
            translation_validation_commitment,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExecutionBinding {
    target_compilation_commitment: CanonicalCommitment,
    implementations: Vec<RuntimeImplementation>,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl ExecutionBinding {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn implementations(&self) -> &[RuntimeImplementation] {
        &self.implementations
    }

    pub(crate) fn issue(
        target_compilation_commitment: CanonicalCommitment,
        implementations: Vec<RuntimeImplementation>,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            target_compilation_commitment,
            implementations,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationClosure {
    package_lock_occurrence: OccurrenceId,
    package_lock_commitment: CanonicalCommitment,
    supplier_closure_commitment: CanonicalCommitment,
    application_binding_commitment: CanonicalCommitment,
    obligation_closure_commitment: CanonicalCommitment,
    csag_commitment: CanonicalCommitment,
    ir_portfolio_commitment: CanonicalCommitment,
    target_compilation_commitment: CanonicalCommitment,
    execution_binding_commitment: CanonicalCommitment,
    gap_dispositions: Vec<GapDisposition>,
    toolchain: ToolchainId,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl ApplicationClosure {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn package_lock_commitment(&self) -> CanonicalCommitment {
        self.package_lock_commitment
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn issue(
        package_lock_occurrence: OccurrenceId,
        package_lock_commitment: CanonicalCommitment,
        supplier_closure_commitment: CanonicalCommitment,
        application_binding_commitment: CanonicalCommitment,
        obligation_closure_commitment: CanonicalCommitment,
        csag_commitment: CanonicalCommitment,
        ir_portfolio_commitment: CanonicalCommitment,
        target_compilation_commitment: CanonicalCommitment,
        execution_binding_commitment: CanonicalCommitment,
        gap_dispositions: Vec<GapDisposition>,
        toolchain: ToolchainId,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            package_lock_occurrence,
            package_lock_commitment,
            supplier_closure_commitment,
            application_binding_commitment,
            obligation_closure_commitment,
            csag_commitment,
            ir_portfolio_commitment,
            target_compilation_commitment,
            execution_binding_commitment,
            gap_dispositions,
            toolchain,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AppRelease {
    occurrence: OccurrenceId,
    application_closure_commitment: CanonicalCommitment,
    package_lock_commitment: CanonicalCommitment,
    selected_release_occurrences: Vec<OccurrenceId>,
    replay_dependencies: Vec<(ArtifactKindId, OccurrenceId, CanonicalCommitment)>,
    verifier_inventory: Vec<VerifierId>,
    toolchain: ToolchainId,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl AppRelease {
    pub fn occurrence(&self) -> &OccurrenceId {
        &self.occurrence
    }

    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub fn package_lock_commitment(&self) -> CanonicalCommitment {
        self.package_lock_commitment
    }

    pub fn replay_dependencies(&self) -> &[(ArtifactKindId, OccurrenceId, CanonicalCommitment)] {
        &self.replay_dependencies
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn issue(
        occurrence: OccurrenceId,
        application_closure_commitment: CanonicalCommitment,
        package_lock_commitment: CanonicalCommitment,
        selected_release_occurrences: Vec<OccurrenceId>,
        replay_dependencies: Vec<(ArtifactKindId, OccurrenceId, CanonicalCommitment)>,
        verifier_inventory: Vec<VerifierId>,
        toolchain: ToolchainId,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            occurrence,
            application_closure_commitment,
            package_lock_commitment,
            selected_release_occurrences,
            replay_dependencies,
            verifier_inventory,
            toolchain,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OfflineReplayClosure {
    release_occurrence: OccurrenceId,
    release_commitment: CanonicalCommitment,
    package_lock_commitment: CanonicalCommitment,
    verified_dependencies: Vec<OccurrenceId>,
    clean_build_commitment: CanonicalCommitment,
    incremental_commitment: CanonicalCommitment,
    commitment: CanonicalCommitment,
    work_receipt: WorkReceipt,
    seal: ProofSeal,
}

impl OfflineReplayClosure {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    #[allow(clippy::too_many_arguments)]
    pub(crate) fn issue(
        release_occurrence: OccurrenceId,
        release_commitment: CanonicalCommitment,
        package_lock_commitment: CanonicalCommitment,
        verified_dependencies: Vec<OccurrenceId>,
        clean_build_commitment: CanonicalCommitment,
        incremental_commitment: CanonicalCommitment,
        commitment: CanonicalCommitment,
        work_receipt: WorkReceipt,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            release_occurrence,
            release_commitment,
            package_lock_commitment,
            verified_dependencies,
            clean_build_commitment,
            incremental_commitment,
            commitment,
            work_receipt,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EnvironmentBinding {
    release_occurrence: OccurrenceId,
    release_commitment: CanonicalCommitment,
    environment_occurrence: OccurrenceId,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl EnvironmentBinding {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub(crate) fn issue(
        release_occurrence: OccurrenceId,
        release_commitment: CanonicalCommitment,
        environment_occurrence: OccurrenceId,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            release_occurrence,
            release_commitment,
            environment_occurrence,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeploymentPlan {
    occurrence: OccurrenceId,
    environment_binding_commitment: CanonicalCommitment,
    step_contracts: Vec<ContractId>,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl DeploymentPlan {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub(crate) fn issue(
        occurrence: OccurrenceId,
        environment_binding_commitment: CanonicalCommitment,
        step_contracts: Vec<ContractId>,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            occurrence,
            environment_binding_commitment,
            step_contracts,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BootInput {
    occurrence: OccurrenceId,
    deployment_plan_commitment: CanonicalCommitment,
    release_occurrence: OccurrenceId,
    release_commitment: CanonicalCommitment,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

impl BootInput {
    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub(crate) fn issue(
        occurrence: OccurrenceId,
        deployment_plan_commitment: CanonicalCommitment,
        release_occurrence: OccurrenceId,
        release_commitment: CanonicalCommitment,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            occurrence,
            deployment_plan_commitment,
            release_occurrence,
            release_commitment,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BootReport {
    occurrence: OccurrenceId,
    boot_input_commitment: CanonicalCommitment,
    runtime_evidence: OccurrenceId,
    outcome: BootOutcome,
    commitment: CanonicalCommitment,
    seal: ProofSeal,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum BootOutcome {
    Booted,
    Refused { reason: ContractId },
}

impl BootReport {
    pub fn outcome(&self) -> &BootOutcome {
        &self.outcome
    }

    pub fn commitment(&self) -> CanonicalCommitment {
        self.commitment
    }

    pub(crate) fn issue(
        occurrence: OccurrenceId,
        boot_input_commitment: CanonicalCommitment,
        runtime_evidence: OccurrenceId,
        outcome: BootOutcome,
        commitment: CanonicalCommitment,
        issuer: VerifierId,
        nonce_commitment: CanonicalCommitment,
    ) -> Self {
        Self {
            occurrence,
            boot_input_commitment,
            runtime_evidence,
            outcome,
            commitment,
            seal: ProofSeal {
                issuer,
                nonce_commitment,
            },
        }
    }
}
