#!/usr/bin/env python3
import json, pathlib, collections, sys
root=pathlib.Path(__file__).resolve().parents[2]
allowed=set(json.load(open(root/"vocabularies/statuses.json")))
errors=[]; ids=[]
for p in sorted(root.rglob("*.jsonl")):
 rows=[]
 for i,l in enumerate(open(p,encoding="utf-8"),1):
  if not l.strip(): continue
  try:r=json.loads(l)
  except Exception as e: errors.append(f"{p}:{i}: parse {e}"); continue
  rows.append(r); ids.append(r.get("id"))
  if r.get("status") not in allowed: errors.append(f"{p}:{i}: invalid status {r.get('status')}")
  if not r.get("id") or not r.get("record_kind"): errors.append(f"{p}:{i}: missing id/record_kind")
 if [str(r.get("id","")) for r in rows] != sorted(str(r.get("id","")) for r in rows): errors.append(f"{p}: nondeterministic ordering")
c=collections.Counter(ids); errors += [f"duplicate id {k}" for k,v in c.items() if k and v>1]
print(json.dumps({"status":"PASS" if not errors else "FAIL","errors":errors,"record_count":len(ids)},indent=2))
sys.exit(1 if errors else 0)
