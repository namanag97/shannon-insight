#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import textwrap
import zipfile
from collections import defaultdict, deque
from copy import deepcopy
from pathlib import Path
from typing import Any, Iterable

BUILD_DATE = "2026-08-12"
PACKAGE_ID = "SAN-DATA-SOVEREIGN-LIBRARIES"
PACKAGE_EDITION = 1
STATUS = "REVIEW_CANDIDATE"
CERTIFICATION = "NONE"
ARCHIVE_NAME = "SAN-DATA-SOVEREIGN-LIBRARIES-EDITION-1-REVIEW-CANDIDATE.zip"
ROOT = Path("/mnt/data/san_data_spec_build/data-libraries-spec-session")
DEFAULT_OUT = Path("/mnt/data/SAN-DATA-SOVEREIGN-LIBRARIES-EDITION-1-REVIEW-CANDIDATE")

IDENTITY_RE = re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$")
EDITION_SUFFIX_RE = re.compile(r"(?:/v\d+|@v\d+|[-_]v\d+)$", re.I)


def canon_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def pretty_bytes(obj: Any) -> bytes:
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, obj: Any, canonical: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(canon_bytes(obj) if canonical else pretty_bytes(obj))


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def slug(text: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "-", text.upper()).strip("-")


def camel(text: str) -> str:
    parts = re.findall(r"[A-Za-z0-9]+", text)
    return "".join(p[:1].upper() + p[1:] for p in parts)


def stable_hash_id(prefix: str, *parts: str) -> str:
    digest = hashlib.sha256("\x1f".join(parts).encode()).hexdigest()[:12].upper()
    return f"{prefix}-{digest}"


def inapplicable(reason: str, law: str) -> dict[str, Any]:
    return {"disposition": "INAPPLICABLE", "reason": reason, "law": law}


def external_contract(owner: str, requirement: str, gap: str | None = None) -> dict[str, Any]:
    result = {"disposition": "EXTERNAL_CONTRACT", "owner": owner, "requirement": requirement}
    if gap:
        result["gap"] = gap
    return result


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def source_lock() -> list[dict[str, Any]]:
    paths = [
        ROOT / "00-START/START-HERE.md",
        ROOT / "00-START/PROMPT-FOR-GPT-PRO.md",
        ROOT / "00-START/REVIEW-OF-CURRENT-PROPOSALS.md",
        *sorted((ROOT / "01-CONSTITUTION").glob("*")),
        ROOT / "02-CURRENT-REGISTRIES/CURRENT-SEM-CONVERGENCE.json",
        ROOT / "02-CURRENT-REGISTRIES/FAMILY-SPECS.md",
        *sorted((ROOT / "03-DATA-RESEARCH").glob("*")),
        *sorted((ROOT / "05-PREVIOUS-PROPOSALS").glob("*")),
    ]
    rows = []
    for path in paths:
        if path.is_file():
            rows.append({
                "path": str(path.relative_to(ROOT)),
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
                "authority_class": (
                    "START_AND_REVIEW" if "00-START" in str(path)
                    else "BINDING_CONSTITUTION" if "01-CONSTITUTION" in str(path)
                    else "CURRENT_REGISTRY" if "02-CURRENT" in str(path)
                    else "RESEARCH_INPUT" if "03-DATA" in str(path)
                    else "PREVIOUS_PROPOSAL_NON_AUTHORITY"
                ),
            })
    return rows


WEB_SOURCES: list[dict[str, Any]] = [
    {
        "identity": "SRC-W3C-DCAT-3",
        "title": "Data Catalog Vocabulary Version 3",
        "publisher": "W3C",
        "url": "https://www.w3.org/TR/vocab-dcat-3/",
        "edition_or_date": "2024-08-22",
        "source_type": "NORMATIVE_STANDARD",
        "authority": "PRIMARY",
        "supported_propositions": [
            "Dataset, Distribution, DataService, DatasetSeries, and CatalogRecord are distinct classes.",
            "A distribution is a specific accessible representation of a dataset.",
            "A catalog record describes registration metadata and is distinct from the described resource.",
        ],
        "limitations": ["DCAT is a catalog vocabulary and does not define SAN application authority or execution semantics."],
        "affected_libraries": ["DAT-COLLECTION", "DAT-DISTRIBUTION", "DAT-DATA-CUT", "DAT-DATA-PRODUCT"],
    },
    {
        "identity": "SRC-BITOL-ODCS-3-1",
        "title": "Open Data Contract Standard 3.1.0",
        "publisher": "Linux Foundation Bitol",
        "url": "https://bitol-io.github.io/open-data-contract-standard/v3.1.0/",
        "edition_or_date": "3.1.0",
        "source_type": "OFFICIAL_STANDARD",
        "authority": "PRIMARY",
        "supported_propositions": ["A data contract has independent schema, quality, SLA, infrastructure, role, support, and commercial sections."],
        "limitations": ["ODCS is a published contract format and does not become SAN Constitutional Contract Metamodel authority."],
        "affected_libraries": ["DAT-DATA-PRODUCT", "DAT-DISTRIBUTION"],
    },
    {
        "identity": "SRC-W3C-PROV-O",
        "title": "PROV-O: The PROV Ontology",
        "publisher": "W3C",
        "url": "https://www.w3.org/TR/prov-o/",
        "edition_or_date": "2013-04-30",
        "source_type": "NORMATIVE_STANDARD",
        "authority": "PRIMARY",
        "supported_propositions": ["Provenance distinguishes Entity, Activity, Agent, derivation, generation, use, attribution, and delegation."],
        "limitations": ["SAN Sovereign Semantics SEM-027 remains the local semantic owner."],
        "affected_libraries": ["ALL_FIRST_BATCH"],
    },
    {
        "identity": "SRC-W3C-DQV",
        "title": "Data on the Web Best Practices: Data Quality Vocabulary",
        "publisher": "W3C",
        "url": "https://www.w3.org/TR/vocab-dqv/",
        "edition_or_date": "2016-12-15",
        "source_type": "NORMATIVE_STANDARD",
        "authority": "PRIMARY",
        "supported_propositions": ["Quality Dimension, Quality Metric, and Quality Measurement are distinct concepts."],
        "limitations": ["SEM-089 and Independent Assurance own reusable quality meaning and appraisal in SAN."],
        "affected_libraries": ["DAT-DATA-CUT", "DAT-DISTRIBUTION"],
    },
    {
        "identity": "SRC-POSTGRES-18-LOGICAL-REPLICATION",
        "title": "PostgreSQL 18 Logical Replication",
        "publisher": "PostgreSQL Global Development Group",
        "url": "https://www.postgresql.org/docs/current/logical-replication.html",
        "edition_or_date": "PostgreSQL 18 current documentation",
        "source_type": "OFFICIAL_PRODUCT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Logical replication uses replication identity and typically begins with a snapshot followed by ongoing changes."],
        "limitations": ["One implementation profile cannot define provider-neutral DATA semantics."],
        "affected_libraries": ["DAT-SOURCE-SNAPSHOT", "DAT-SOURCE-CONTINUATION", "DAT-SOURCE-CHANGE-STREAM", "DAT-SNAPSHOT-CONTINUATION-STITCHING"],
    },
    {
        "identity": "SRC-POSTGRES-18-ISOLATION",
        "title": "PostgreSQL 18 Transaction Isolation",
        "publisher": "PostgreSQL Global Development Group",
        "url": "https://www.postgresql.org/docs/current/transaction-iso.html",
        "edition_or_date": "PostgreSQL 18 current documentation",
        "source_type": "OFFICIAL_PRODUCT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Repeatable Read gives a stable database view while serializability is a stronger and distinct property."],
        "limitations": ["Isolation names require source-profile interpretation; SAN must not generalize from product labels alone."],
        "affected_libraries": ["DAT-SOURCE-SNAPSHOT"],
    },
    {
        "identity": "SRC-DEBEZIUM-POSTGRES-STABLE",
        "title": "Debezium PostgreSQL Connector",
        "publisher": "Debezium Project",
        "url": "https://debezium.io/documentation/reference/stable/connectors/postgresql.html",
        "edition_or_date": "stable documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_PROJECT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": [
            "A consistent snapshot can be followed from the exact source position at which it was taken.",
            "WAL history is finite and loss of retained history constrains continuation and recovery.",
        ],
        "limitations": ["Connector behavior is configuration- and version-specific and requires Provider Implementation Evidence conformance."],
        "affected_libraries": ["DAT-SOURCE-SNAPSHOT", "DAT-SOURCE-CONTINUATION", "DAT-SOURCE-CHANGE-STREAM", "DAT-SNAPSHOT-CONTINUATION-STITCHING"],
    },
    {
        "identity": "SRC-MS-GRAPH-DELTA",
        "title": "Use delta query to track changes in Microsoft Graph data",
        "publisher": "Microsoft",
        "url": "https://learn.microsoft.com/en-us/graph/delta-query-overview",
        "edition_or_date": "2025-04-30",
        "source_type": "OFFICIAL_PRODUCT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Delta links are opaque, encode query parameters, may return an item in different pages, and do not imply a simple total sequence."],
        "limitations": ["Resource-specific delta semantics differ and are provider profiles."],
        "affected_libraries": ["DAT-SOURCE-CONTINUATION", "DAT-SOURCE-CHANGE-STREAM"],
    },
    {
        "identity": "SRC-MONGODB-CHANGE-STREAMS",
        "title": "MongoDB Change Streams",
        "publisher": "MongoDB",
        "url": "https://www.mongodb.com/docs/manual/changeStreams/",
        "edition_or_date": "current documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_PRODUCT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Resume tokens, invalidation, pipeline options, oplog horizon, and sharded ordering affect lawful continuation."],
        "limitations": ["Provider-specific token and ordering semantics remain Provider Implementation Evidence."],
        "affected_libraries": ["DAT-SOURCE-CONTINUATION", "DAT-SOURCE-CHANGE-STREAM"],
    },
    {
        "identity": "SRC-AWS-S3-EVENT-NOTIFICATIONS",
        "title": "Amazon S3 Event Notifications",
        "publisher": "Amazon Web Services",
        "url": "https://docs.aws.amazon.com/AmazonS3/latest/userguide/EventNotifications.html",
        "edition_or_date": "current documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_PRODUCT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Object notifications are delivered at least once and may be duplicated or reordered."],
        "limitations": ["Notifications do not prove object finalization, completeness, or a global source order."],
        "affected_libraries": ["DAT-SOURCE-OBSERVATION", "DAT-SOURCE-CHANGE-STREAM"],
    },
    {
        "identity": "SRC-BEAM-PROGRAMMING-GUIDE",
        "title": "Apache Beam Programming Guide",
        "publisher": "Apache Beam",
        "url": "https://beam.apache.org/documentation/programming-guide/",
        "edition_or_date": "current documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_PROJECT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Watermarks, event time, processing time, windows, triggers, panes, allowed lateness, and late firings are distinct."],
        "limitations": ["These concepts inform later DATA libraries and do not collapse into source continuation or cut semantics."],
        "affected_libraries": ["DAT-WATERMARK-FRONTIER", "DAT-WINDOW-TRIGGER-PANE", "DAT-ANALYTICAL-FINALITY"],
    },
    {
        "identity": "SRC-FLINK-CHECKPOINTING",
        "title": "Apache Flink Checkpointing and Stateful Stream Processing",
        "publisher": "Apache Flink",
        "url": "https://nightlies.apache.org/flink/flink-docs-stable/docs/dev/datastream/fault-tolerance/checkpointing/",
        "edition_or_date": "stable documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_PROJECT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Execution checkpoints coordinate operator state and input positions; checkpointing modes and unaligned checkpoints are runtime mechanisms."],
        "limitations": ["A checkpoint is not a source continuation, watermark, data cut, savepoint, or business finality certificate."],
        "affected_libraries": ["DAT-DATAFLOW-RECOVERY-EQUIVALENCE", "DAT-SOURCE-CONTINUATION"],
    },
    {
        "identity": "SRC-ICEBERG-SPEC",
        "title": "Apache Iceberg Table Specification",
        "publisher": "Apache Iceberg",
        "url": "https://iceberg.apache.org/spec/",
        "edition_or_date": "v1-v3 adopted; current documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_SPECIFICATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Logical table, snapshot, manifest list, manifest, data file, delete file, sequence number, and atomic commit are distinct."],
        "limitations": ["Iceberg does not own SAN generic Data Cut or analytical collection meaning."],
        "affected_libraries": ["DAT-ANALYTICAL-TABLE-SNAPSHOT", "DAT-DATA-CUT"],
    },
    {
        "identity": "SRC-OPENLINEAGE-OBJECT-MODEL",
        "title": "OpenLineage Object Model",
        "publisher": "OpenLineage",
        "url": "https://openlineage.io/docs/spec/object-model/",
        "edition_or_date": "current documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_SPECIFICATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Job, Run, Dataset, design-time facets, and run-time events are distinct."],
        "limitations": ["OpenLineage is a lineage publication profile; SEM-027 Provenance remains semantic owner."],
        "affected_libraries": ["DAT-COLLECTION", "DAT-DATA-CUT"],
    },
    {
        "identity": "SRC-SUBSTRAIT-SPEC",
        "title": "Substrait Specification",
        "publisher": "Apache Substrait",
        "url": "https://substrait.io/spec/specification/",
        "edition_or_date": "pre-1.0 current specification retrieved 2026-08-12",
        "source_type": "OFFICIAL_SPECIFICATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Portable relational plan vocabulary is distinct from semantic ownership and physical execution."],
        "limitations": ["Portable Target IR owns plan representation; DATA owns provider-neutral analytical meaning."],
        "affected_libraries": ["DAT-RELATIONAL-COLLECTION-ALGEBRA"],
    },
    {
        "identity": "SRC-DATAFUSION-OPTIMIZER",
        "title": "Apache DataFusion Query Optimizer and Plan Documentation",
        "publisher": "Apache DataFusion",
        "url": "https://datafusion.apache.org/library-user-guide/query-optimizer.html",
        "edition_or_date": "current documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_PROJECT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Logical and physical planning and optimization are distinct stages."],
        "limitations": ["Optimizer search and physical planning belong to Application Compilation and Closure and Portable Target IR, not to DATA ownership."],
        "affected_libraries": ["DAT-RELATIONAL-COLLECTION-ALGEBRA"],
    },
    {
        "identity": "SRC-MATERIALIZE-VIEWS",
        "title": "Materialize Views and Materialized Views",
        "publisher": "Materialize",
        "url": "https://materialize.com/docs/concepts/views/",
        "edition_or_date": "current documentation retrieved 2026-08-12",
        "source_type": "OFFICIAL_PRODUCT_DOCUMENTATION",
        "authority": "PRIMARY_IMPLEMENTATION_EVIDENCE",
        "supported_propositions": ["Logical view, indexed view, and durably materialized view have distinct persistence and serving behavior."],
        "limitations": ["One product does not own provider-neutral incremental or materialized-result semantics."],
        "affected_libraries": ["DAT-INCREMENTAL-COMPUTATION", "DAT-MATERIALIZED-RESULT"],
    },
]


SEM_NAMES = {
    1:"Canonical Form",2:"Digest",3:"Encoding",4:"Text Suite",5:"Exact Number",6:"Unit and Dimension",7:"Quantity",8:"Money",9:"Ratio",10:"Fixed Time Span",11:"Instant and Time-Scale Semantics",12:"Elapsed Measurement",13:"Path and Singular Traversal Algebra",14:"Identifier and Issuance Algebra",15:"Execution Context",16:"Negative Outcome",17:"Diagnostic",18:"Served Answer",19:"Causality",20:"Media Representation",21:"Namespace",22:"Calendar",23:"Recurrence",24:"Expiry",25:"Journal and Institutional Recording Algebra",26:"Bitemporality, Revision Intent and Double-Cut Semantics",27:"Provenance, Origin and Responsibility Lineage",28:"Evidence, Independent Verification and Sufficiency",29:"Vocabulary",30:"Schema",31:"Identity, Denotation and Continuity",32:"Reference",33:"Locator",34:"Designation",35:"Correspondence",36:"Recognition",37:"Place and Geography",38:"Party",39:"Relationship",40:"Structure",41:"Membership",42:"Tenancy",43:"Jurisdiction",44:"Rule",45:"Decision",46:"Adjudication",47:"Obligation",48:"Classification",49:"Purpose",50:"Consent",51:"Risk",52:"Control",53:"Credential",54:"Identity Proofing",55:"Authentication",56:"Session",57:"Federation",58:"Delegation",59:"Entitlement",60:"Authorization",61:"Secret Lifecycle",62:"Workload Identity",63:"Network Intent",64:"Topology Intent",65:"Commitment",66:"Work",67:"Process",68:"Case",69:"Communication",70:"Rate and Exchange",71:"Apportionment",72:"Holding",73:"Ledger",74:"Payment",75:"Tax",76:"Metering",77:"Offering and Catalog",78:"Pricing",79:"Offer and Proposal",80:"Content Record",81:"Retention",82:"Residency",83:"Erasure",84:"Integration",85:"Derivation",86:"Query Contract",87:"Measure",88:"Model and Inference",89:"Data Quality",90:"Reference Frame and Alignment",91:"Numerical Function and Approximation",92:"Artifact",93:"Release",94:"Telemetry Contract",95:"Health Contract",96:"Service Objective",97:"Alerting",98:"Incident",99:"Continuity"
}


def sem_id(n: int) -> str:
    return f"SEM-{n:03d}"


def sem_owner(n: int) -> dict[str, str]:
    return {"coordinate": sem_id(n), "name": SEM_NAMES[n], "track": "Sovereign Semantics"}


CANONICAL_LIBRARIES: list[dict[str, Any]] = [
    {"identity":"DAT-COLLECTION","title":"Data Collection Semantics","question":"What makes a provider-neutral collection of data members one collection, independent of one cut, representation, service, catalog entry, or storage realization?","group":"Data Product and Publication","phase":1,"status":"FIRST_BATCH"},
    {"identity":"DAT-DATA-CUT","title":"Data Cut Semantics","question":"What exact immutable occurrence of a collection is identified, with which membership, source or derivation scope, temporal scope, completeness posture, and evidence?","group":"Data Product and Publication","phase":2,"status":"FIRST_BATCH"},
    {"identity":"DAT-DISTRIBUTION","title":"Data Distribution Semantics","question":"What accessible representation of a collection or data cut is made available, and which representation, loss, access, rights, resolution, and validity claims attach to it?","group":"Data Product and Publication","phase":3,"status":"FIRST_BATCH"},
    {"identity":"DAT-SOURCE-OBSERVATION","title":"Source-Qualified Observation Semantics","question":"What did a foreign source expose under which authority, interface, principal, time, visibility, and uncertainty scope, without elevating the observation into application truth?","group":"Source Observation and Acquisition","phase":4,"status":"FIRST_BATCH"},
    {"identity":"DAT-SOURCE-SNAPSHOT","title":"Source Snapshot Semantics","question":"What coherent finite source read was observed at one source cut and isolation posture, with which coverage, segmentation, finalization, resume, and completeness claims?","group":"Source Observation and Acquisition","phase":5,"status":"FIRST_BATCH"},
    {"identity":"DAT-SOURCE-CONTINUATION","title":"Source Continuation Semantics","question":"What source-qualified coordinate and exact observation scope can resume source observation, and when is it eligible, expired, invalidated, incomparable, or unable to bridge a history gap?","group":"Source Observation and Acquisition","phase":6,"status":"FIRST_BATCH"},
    {"identity":"DAT-SOURCE-CHANGE-STREAM","title":"Source Change Stream Semantics","question":"What source mutations were observed after a continuation, including transaction visibility, order scope, before and after images, deletes, duplicates, and structural-change visibility?","group":"Source Observation and Acquisition","phase":7,"status":"FIRST_BATCH"},
    {"identity":"DAT-SNAPSHOT-CONTINUATION-STITCHING","title":"Snapshot–Continuation Stitching","question":"How are a finite source snapshot and subsequent source changes composed into one history without omission, double application, scope mismatch, or transaction incoherence?","group":"Source Observation and Acquisition","phase":8,"status":"FIRST_BATCH"},
    {"identity":"DAT-DATA-PRODUCT","title":"Data Product Semantics","question":"What consumer-facing analytical product exists, which collections and cuts it publishes, and what provider-neutral value, ownership, contract, and lifecycle posture define it?","group":"Data Product and Publication","phase":9,"status":"LATER_QUEUE"},
    {"identity":"DAT-RELATIONAL-COLLECTION-ALGEBRA","title":"Relational Collection Algebra","question":"What relation and result does a provider-neutral relational expression denote under explicit multiplicity, missingness, grain, key, type, ordering, and error semantics?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-DOCUMENT-VARIANT-ALGEBRA","title":"Document and Variant Algebra","question":"What do object, array, path, union, absent-value, duplicate-key, and normalization operations mean over document and variant data?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-TIME-SERIES-SIGNAL-ALGEBRA","title":"Time-Series and Signal Algebra","question":"What constitutes a series and sample, and what do resampling, interpolation, aggregation, reset, downsampling, frequency, and signal operations mean?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-GRAPH-PATH-ALGEBRA","title":"Graph and Path Algebra","question":"What do graph elements, paths, path identity, traversal modes, reachability, subgraph, and graph aggregation mean independent of a graph engine?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-SPATIAL-COVERAGE-ALGEBRA","title":"Spatial and Coverage Algebra","question":"What do geometry, geography, coordinate reference, topology, raster coverage, reprojection, interpolation, and spatial predicates mean?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-ARRAY-TENSOR-ALGEBRA","title":"Array and Tensor Algebra","question":"What do rank, shape, dimension, coordinate, slicing, broadcasting, sparse representation, chunking, and tensor operations mean?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-SEARCH-RANKING-ALGEBRA","title":"Search and Ranking Algebra","question":"What do tokenization, indexing, matching, scoring, ranking, top-k, tie, and result-explanation mean independent of a search engine?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-VECTOR-RETRIEVAL-ALGEBRA","title":"Vector Retrieval Algebra","question":"What vector space, model edition, metric, exact or approximate neighbor result, filter order, top-k, and recall contract define vector retrieval?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-EVENT-OBJECT-PROCESS-ALGEBRA","title":"Event–Object Process Algebra","question":"What do events, objects, event-object and object-object relations, cases, traces, variants, conformance, and process-derived results mean?","group":"Data Modality Algebras","phase":10,"status":"LATER_QUEUE"},
    {"identity":"DAT-ANALYTICAL-GRAIN-METRIC","title":"Analytical Grain, Dimension and Metric Semantics","question":"What analytical quantity is evaluated at which grain, across which dimensions, with which unit, time, join, fan-out, additivity, filter, and correction semantics?","group":"Analytics and Decision Products","phase":11,"status":"LATER_QUEUE"},
    {"identity":"DAT-STATISTICAL-STUDY-ESTIMATE","title":"Statistical Study and Estimate Semantics","question":"What target population, sampling design, estimator, uncertainty, assumptions, data cut, and inference scope justify a statistical result?","group":"Analytics and Decision Products","phase":11,"status":"LATER_QUEUE"},
    {"identity":"DAT-FORECAST-PRODUCT","title":"Forecast Product Semantics","question":"What target, issue time, horizon, scenario, probability or interval, revision, backtest, and validity posture define a forecast product?","group":"Analytics and Decision Products","phase":11,"status":"LATER_QUEUE"},
    {"identity":"DAT-EXPERIMENT-ANALYSIS","title":"Experiment Analysis Semantics","question":"What assignment, exposure, treatment, metric, estimand, analysis cut, stopping rule, and inference define an experiment result?","group":"Analytics and Decision Products","phase":11,"status":"LATER_QUEUE"},
    {"identity":"DAT-CAUSAL-ANALYSIS","title":"Causal Analysis Semantics","question":"What intervention, causal estimand, identification assumptions, confounding, interference, sensitivity, and evidence scope support a causal result?","group":"Analytics and Decision Products","phase":11,"status":"LATER_QUEUE"},
    {"identity":"DAT-OPTIMIZATION-SCENARIO","title":"Optimization and Scenario Product Semantics","question":"What decision variables, objectives, constraints, scenarios, feasibility, solution, sensitivity, uncertainty, and recommendation posture define an optimization result?","group":"Analytics and Decision Products","phase":11,"status":"LATER_QUEUE"},
    {"identity":"DAT-FEATURE-DATASET","title":"Feature Dataset Semantics","question":"What entity, feature, event-time, availability, derivation, point-in-time cut, materialization, and serving posture define a feature dataset?","group":"Machine Learning and Retrieval Data","phase":12,"status":"LATER_QUEUE"},
    {"identity":"DAT-TRAINING-EVALUATION-DATASET","title":"Training and Evaluation Dataset Semantics","question":"What examples, labels, splits, sampling, leakage controls, dependency closure, reproducibility, and evaluation use define a training or evaluation dataset?","group":"Machine Learning and Retrieval Data","phase":12,"status":"LATER_QUEUE"},
    {"identity":"DAT-RETRIEVAL-CONTEXT-DATASET","title":"Retrieval Context Dataset Semantics","question":"What corpus, document, chunk, embedding, index cut, retrieval result, context assembly, grounding, citation, and deletion posture define retrieval context data?","group":"Machine Learning and Retrieval Data","phase":12,"status":"LATER_QUEUE"},
    {"identity":"DAT-INCREMENTAL-COMPUTATION","title":"Incremental Computation Semantics","question":"Under which change modes, state representation, algebraic properties, and correction rules may input deltas maintain a result equivalent to full evaluation?","group":"Incremental and Corrective Computation","phase":13,"status":"LATER_QUEUE"},
    {"identity":"DAT-MATERIALIZED-RESULT","title":"Materialized Result Semantics","question":"What stored computed result exists, which derivation and input cut it represents, and when is it valid, stale, substitutable, superseded, or rebuildable?","group":"Incremental and Corrective Computation","phase":13,"status":"LATER_QUEUE"},
    {"identity":"DAT-HISTORICAL-RECALCULATION","title":"Backfill, Replay and Reproduction Semantics","question":"Which historical inputs, logic editions, dependency editions, boundaries, overlap rules, and output obligations distinguish backfill, replay, reprocess, and reproduction?","group":"Incremental and Corrective Computation","phase":13,"status":"LATER_QUEUE"},
    {"identity":"DAT-ANALYTICAL-RESTATEMENT","title":"Analytical Restatement Semantics","question":"Who may replace or correct a published analytical result, over which historical scope, with which disclosures, supersession, reconciliation, and non-authoritative posture?","group":"Incremental and Corrective Computation","phase":13,"status":"LATER_QUEUE"},
    {"identity":"DAT-ANALYTICAL-TABLE-SNAPSHOT","title":"Analytical Table and Snapshot Semantics","question":"What logical analytical table exists and what exact table snapshot represents its current or historical data independent of file, manifest, catalog, and engine realization?","group":"Persistence, Serving and Collaboration","phase":14,"status":"LATER_QUEUE"},
    {"identity":"DAT-ANALYTICAL-SERVING-CUT","title":"Analytical Serving Cut Semantics","question":"Which coherent analytical cut is consumer-visible across one or more requests, and how are partial results, cache reuse, shared snapshot tokens, revocation, and last-known-good behavior governed?","group":"Persistence, Serving and Collaboration","phase":14,"status":"LATER_QUEUE"},
    {"identity":"DAT-DATA-SHARING-COLLABORATION","title":"Data Sharing and Controlled Collaboration Semantics","question":"What data, cut, participant, entitlement, usage constraint, revocation, permitted computation, and output-control posture define sharing, federation, or clean-room collaboration?","group":"Persistence, Serving and Collaboration","phase":14,"status":"LATER_QUEUE"},
]

FIRST_BATCH_IDS = [row["identity"] for row in CANONICAL_LIBRARIES if row["status"] == "FIRST_BATCH"]
LIB_INDEX = {row["identity"]: row for row in CANONICAL_LIBRARIES}


def type_def(name: str, kind: str, meaning: str, owner: str, carrier: bool = False, admitted: bool = False, fields: list[dict[str, Any]] | None = None, equality: str = "STRUCTURAL", ordering: str = "NONE") -> dict[str, Any]:
    return {
        "identity": f"TYPE-{slug(owner)}-{slug(name)}",
        "rust_name": name,
        "kind": kind,
        "meaning": meaning,
        "semantic_owner": owner,
        "fields": fields or [],
        "carrier": carrier,
        "admitted": admitted,
        "deserializable": carrier and not admitted,
        "fields_private": admitted,
        "equality": equality,
        "ordering": ordering,
        "construction": (
            "BOUNDED_DESERIALIZATION_THEN_ADMISSION" if carrier
            else "PRIVATE_SMART_CONSTRUCTOR" if admitted
            else "OWNER_VALIDATED_VALUE"
        ),
        "forbidden_construction": ["public raw constructor", "blind Deserialize into admitted value"] if admitted else [],
    }


def term(name: str, definition: str, owner: str, kind: str = "TERM", synonyms: list[str] | None = None, false_twins: list[str] | None = None) -> dict[str, Any]:
    return {
        "identity": f"TERM-{slug(owner)}-{slug(name)}",
        "term": name,
        "definition": definition,
        "owner": owner,
        "kind": kind,
        "synonyms": synonyms or [],
        "prohibited_ambiguous_meanings": false_twins or [],
        "evolution": "Definition changes require a new semantic edition; labels may evolve under Vocabulary ownership.",
    }


def refusal(owner: str, variant: str, meaning: str, locus: list[str], precedence: int, disclosure: str = "SAFE_SUMMARY") -> dict[str, Any]:
    return {
        "identity": f"REFUSAL-{slug(owner)}-{slug(variant)}",
        "variant": variant,
        "meaning": meaning,
        "production_locus": locus,
        "validation_precedence": precedence,
        "disclosure": disclosure,
        "retryability": "NOT_RETRYABLE_WITHOUT_CHANGED_INPUT_OR_EVIDENCE",
    }


def decision(owner: str, name: str, value_type: str, phase: str, absence: str, compatibility: str, affected_ops: list[str], evidence: str, merge: str = "EXACT_OR_CONFLICT") -> dict[str, Any]:
    return {
        "identity": f"DECISION-{slug(owner)}-{slug(name)}",
        "title": name,
        "owner": owner,
        "value_type": value_type,
        "binding_phase": phase,
        "absence_semantics": absence,
        "merge_algebra": merge,
        "validation": "Value must be admitted by the owner and remain within the library's invariant envelope.",
        "provenance": "Retain author, authority, source occurrence, edition, and evidence references.",
        "compatibility_impact": compatibility,
        "evidence_requirement": evidence,
        "affected_operations": affected_ops,
        "default_authority": "NO_IMPLICIT_DEFAULT",
        "conflict_behavior": "REFUSE_WITH_TYPED_CONFLICT",
        "explanation_requirement": "Explain selected, absent, conflicting, and rejected values deterministically.",
    }


def law(owner: str, name: str, statement: str, operations: list[str], refusal_ids: list[str], preconditions: list[str] | None = None, postconditions: list[str] | None = None, scope: str = "ALL_ADMITTED_VALUES") -> dict[str, Any]:
    identity = f"LAW-{slug(owner)}-{slug(name)}"
    return {
        "identity": identity,
        "title": name,
        "statement": statement,
        "scope": scope,
        "preconditions": preconditions or ["Inputs have passed hostile-carrier and budget admission."],
        "postconditions": postconditions or ["Returned admitted values preserve the statement."],
        "enforcement_locus": ["admission", "pure operation", "compiler validation"],
        "operations_affected": operations,
        "refusal_on_violation": refusal_ids,
        "constructive_example": f"A bounded valid witness satisfies {name}.",
        "negative_counterexample": f"A minimally changed false twin violates {name} and is refused.",
        "proof_obligations": [f"PROP-{slug(owner)}-{slug(name)}", f"MUT-{slug(owner)}-{slug(name)}"],
        "evolution_consequence": "A change that weakens this law is breaking and requires a new edition plus migration or explicit refusal.",
    }


def operation(owner: str, name: str, input_carrier: str, admitted_inputs: list[str], output: str, refusal_family: str, law_coverage: list[str], decisions: list[str], authority: str, budget_id: str, work_formula: str, compiler_consumer: str, runtime_consequence: str, evolution: str, vectors: list[str] | None = None, allocation: str = "PRECHARGE_THEN_ALLOCATE_AT_MOST_DECLARED_OUTPUT") -> dict[str, Any]:
    opid = f"OP-{slug(owner)}-{slug(name)}"
    rust_symbol = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
    in_type = camel(name) + "Input"
    out_type = camel(name) + "Output"
    refusal_type = camel(owner.replace("DAT-", "")) + "Refusal"
    return {
        "identity": opid,
        "title": name,
        "owner": owner,
        "rust_symbol": rust_symbol,
        "candidate_signature": f"pub fn {rust_symbol}(input: {in_type}, budget: &mut {camel(owner.replace('DAT-',''))}Budget) -> Result<{out_type}, {refusal_type}>;",
        "input_carrier": input_carrier,
        "admitted_inputs": admitted_inputs,
        "output": output,
        "refusal_family": refusal_family,
        "law_coverage": law_coverage,
        "decision_dependencies": decisions,
        "authority_requirement": authority,
        "budget": budget_id,
        "budget_formula": work_formula,
        "determinism": "DETERMINISTIC_FOR_EQUAL_CANONICAL_INPUTS_DECISIONS_AND_EVIDENCE",
        "allocation_behavior": allocation,
        "evidence_retained": ["input source digest", "decision provenance", "authority evidence", "law results"],
        "compiler_consumer": compiler_consumer,
        "runtime_consequence": runtime_consequence,
        "evolution_impact": evolution,
        "conformance_vectors": vectors or [f"VECTOR-{slug(owner)}-{slug(name)}-POSITIVE", f"VECTOR-{slug(owner)}-{slug(name)}-NEGATIVE", f"VECTOR-{slug(owner)}-{slug(name)}-MAX", f"VECTOR-{slug(owner)}-{slug(name)}-MAX-PLUS-ONE"],
        "side_effect_posture": "PURE_NO_IO",
        "execution_reachability": "ADMITTED_INPUT_ONLY",
    }


def budget(owner: str, max_input_bytes: int, max_items: int, max_depth: int, max_output_bytes: int, max_state_items: int = 0, max_iterations: int = 1, max_graph_expansion: int = 0) -> dict[str, Any]:
    bid = f"BUDGET-{slug(owner)}-DEFAULT"
    return {
        "identity": bid,
        "owner": owner,
        "max_input_bytes": max_input_bytes,
        "max_items": max_items,
        "max_depth": max_depth,
        "max_graph_expansion": max_graph_expansion,
        "max_iterations": max_iterations,
        "max_state_items": max_state_items,
        "max_output_bytes": max_output_bytes,
        "max_diagnostics": min(1024, max_items + 32),
        "max_evidence_refs": min(4096, max_items * 2 + 32),
        "max_allocation_bytes": max_input_bytes + max_output_bytes + max_items * 256,
        "work_unit_formula": "input_bytes + 8*items + 16*depth + 32*graph_expansion + 64*iterations + 8*state_items",
        "precharge_order": ["validate scalar bounds", "checked aggregate arithmetic", "charge work units", "charge allocation", "allocate", "construct admitted output"],
        "overflow_behavior": "REFUSE_BUDGET_ARITHMETIC_OVERFLOW",
        "exhaustion_refusal": f"REFUSAL-{slug(owner)}-BUDGET-EXHAUSTED",
        "batch_accounting": "Precharge the full aggregate batch; per-item charging alone is forbidden.",
    }


def state_machine(owner: str, subject: str, states: list[str], commands: list[str], transitions: dict[tuple[str, str], tuple[str, str]], terminal_states: list[str]) -> dict[str, Any]:
    matrix = []
    for st in states:
        for cmd in commands:
            if (st, cmd) in transitions:
                nxt, event = transitions[(st, cmd)]
                matrix.append({"state":st,"command":cmd,"outcome":"TRANSITION","next_state":nxt,"event":event,"refusal":None})
            else:
                matrix.append({"state":st,"command":cmd,"outcome":"REFUSAL","next_state":st,"event":None,"refusal":f"REFUSAL-{slug(owner)}-TRANSITION-NOT-PERMITTED"})
    return {
        "identity": f"STATE-MACHINE-{slug(owner)}-{slug(subject)}",
        "owner": owner,
        "subject": subject,
        "states": states,
        "initial_state": states[0],
        "terminal_states": terminal_states,
        "commands": commands,
        "events": sorted({v[1] for v in transitions.values()}),
        "matrix": matrix,
        "totality_expected_cells": len(states) * len(commands),
        "idempotency": "Repeated commands are either explicitly idempotent or refused by the total matrix.",
        "concurrency": "Value-level expected edition and digest must be supplied where two admitted revisions compete.",
        "replay": "Fold events deterministically; unknown event editions require an explicit upcaster or refusal.",
        "history": "Retain transition evidence and prior admitted edition references.",
    }


def oid(owner: str, name: str) -> str:
    return f"OP-{slug(owner)}-{slug(name)}"

def lid(owner: str, name: str) -> str:
    return f"LAW-{slug(owner)}-{slug(name)}"

def did(owner: str, name: str) -> str:
    return f"DECISION-{slug(owner)}-{slug(name)}"

def rid(owner: str, name: str) -> str:
    return f"REFUSAL-{slug(owner)}-{slug(name)}"


def common_refusals(owner: str) -> list[dict[str, Any]]:
    return [
        refusal(owner, "INVALID-CARRIER", "The hostile carrier is malformed, exceeds structural bounds, or fails canonical admission.", ["carrier parser", "admission"], 10),
        refusal(owner, "MISSING-REQUIRED-IMPORT", "A required admitted value from another sovereign owner is absent or unavailable.", ["admission", "compiler closure"], 20),
        refusal(owner, "AUTHORITY-UNAVAILABLE", "The required authoring, verification, or binding authority is unavailable or not evidenced.", ["authority gate"], 30),
        refusal(owner, "CONFLICT", "Two admitted claims or decisions conflict without a lawful merge.", ["decision merge", "semantic closure"], 40),
        refusal(owner, "UNKNOWN-OR-INCOMPLETE", "The requested conclusion exceeds current observation, completeness, or evidence.", ["pure operation", "answer qualification"], 50),
        refusal(owner, "BUDGET-EXHAUSTED", "The aggregate hostile-input work, state, allocation, or output budget is exhausted.", ["budget precharge"], 5),
        refusal(owner, "BUDGET-ARITHMETIC-OVERFLOW", "Checked aggregate budget arithmetic overflowed before allocation.", ["budget precharge"], 1),
        refusal(owner, "RECALLED-USE", "A required edition, authority, evidence item, or provider claim has been recalled.", ["admission", "compiler closure"], 25),
        refusal(owner, "TRANSITION-NOT-PERMITTED", "The command is not lawful in the current state.", ["state machine"], 60),
    ]


def common_imports(*nums: int) -> list[dict[str, Any]]:
    return [sem_owner(n) for n in nums]


LIB_DEFS: dict[str, dict[str, Any]] = {}

# ---------------------------------------------------------------------------
# DAT-COLLECTION
# ---------------------------------------------------------------------------
owner = "DAT-COLLECTION"
refs = common_refusals(owner) + [
    refusal(owner, "MEMBERSHIP-UNDECIDABLE", "Membership cannot be decided within the declared rule, evidence, and work scope.", ["assess_membership"], 45),
    refusal(owner, "DUPLICATE-POLICY-VIOLATED", "The candidate collection violates its admitted duplicate-member posture.", ["admit_collection", "add_member_claim"], 35),
    refusal(owner, "COLLECTION-IDENTITY-CONFLICT", "Two definitions claim one collection identity but differ in identity-defining semantics.", ["compare_collections", "readmit_collection"], 40),
]
B = budget(owner, 4_194_304, 100_000, 64, 8_388_608, max_state_items=100_000, max_iterations=4)
decs = [
    decision(owner, "Membership Rule Form", "MembershipRuleForm", "AUTHORING", "ABSENT_IS_INVALID", "Changing rule form may change membership and is breaking.", [oid(owner,"Admit Collection"), oid(owner,"Assess Membership")], "Collection owner approval and rule evidence."),
    decision(owner, "Duplicate Posture", "DuplicatePosture", "AUTHORING", "ABSENT_MEANS_DUPLICATES_DISTINCT", "A change may change collection cardinality and is breaking.", [oid(owner,"Admit Collection"), oid(owner,"Compute Collection Fingerprint")], "Owner declaration and consumer-impact evidence."),
    decision(owner, "Ordering Posture", "OrderingPosture", "AUTHORING", "ABSENT_MEANS_ORDER_NOT_SEMANTIC", "Changing semantic ordering may be breaking.", [oid(owner,"Admit Collection"), oid(owner,"Compare Collections")], "Owner declaration and ordering-law evidence."),
    decision(owner, "Boundedness Posture", "BoundednessPosture", "AUTHORING", "ABSENT_MEANS_UNKNOWN", "Changing boundedness changes legal operations and runtime obligations.", [oid(owner,"Admit Collection")], "Declared source/product scope and closure authority."),
]
laws = [
    law(owner,"Collection Identity Is Not Cut", "A collection identity denotes a membership theory or collection subject; it does not denote one data cut, snapshot, distribution, table, service, or catalog record.", [oid(owner,"Admit Collection"), oid(owner,"Compare Collections")], [rid(owner,"COLLECTION-IDENTITY-CONFLICT")]),
    law(owner,"Membership Is Qualified", "A membership conclusion is valid only for the declared rule edition, subject, observation or evidence cut, and knowledge posture.", [oid(owner,"Assess Membership"), oid(owner,"Add Member Claim")], [rid(owner,"MEMBERSHIP-UNDECIDABLE")]),
    law(owner,"Unknown Is Not False", "Not observed, withheld, unavailable, conflicting, and not applicable membership are not equivalent to non-membership.", [oid(owner,"Assess Membership")], [rid(owner,"UNKNOWN-OR-INCOMPLETE")]),
    law(owner,"Representation Independence", "Changing an encoding, file, table layout, locator, or distribution without changing admitted membership semantics does not create a new collection identity.", [oid(owner,"Compare Collections"), oid(owner,"Compute Collection Fingerprint")], [rid(owner,"COLLECTION-IDENTITY-CONFLICT")]),
    law(owner,"Schema Is Imported", "Collection semantics may require an admitted Schema reference but never redefine field, type, or constraint meaning.", [oid(owner,"Admit Collection")], [rid(owner,"MISSING-REQUIRED-IMPORT")]),
    law(owner,"Duplicate Posture Is Explicit", "Collection cardinality and equality must be interpreted under an admitted duplicate posture rather than inferred from a storage representation.", [oid(owner,"Admit Collection"), oid(owner,"Compute Collection Fingerprint")], [rid(owner,"DUPLICATE-POLICY-VIOLATED")]),
    law(owner,"Aggregate Budget Precharge", "All carrier bytes, rules, member claims, evidence references, and output diagnostics are charged before allocation or canonical construction.", [oid(owner,"Admit Collection"), oid(owner,"Add Member Claim"), oid(owner,"Compute Collection Fingerprint")], [rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
ops = [
    operation(owner,"Admit Collection","CollectionCarrier",["CollectionId","VocabularyTermRef","SchemaRef","MembershipRule","CollectionDecisions"],"AdmittedCollection",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Collection Identity Is Not Cut"),lid(owner,"Schema Is Imported"),lid(owner,"Duplicate Posture Is Explicit"),lid(owner,"Aggregate Budget Precharge")],[d["identity"] for d in decs],"Collection author authority imported through Execution Context and Evidence",B["identity"],"bytes + 16*rules + 8*evidence_refs","Application Compilation and Closure: source admission and family closure","Publishes no effect; emits provider-neutral collection requirements only.","New membership semantics require a new edition."),
    operation(owner,"Assess Membership","MembershipAssessmentCarrier",["AdmittedCollection","MemberClaim","ObservationCut","EvidenceBundle"],"MembershipAssessment",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Membership Is Qualified"),lid(owner,"Unknown Is Not False")],[did(owner,"Membership Rule Form")],"No new authority; conclusion is bounded by supplied evidence",B["identity"],"rules * claim_predicates + evidence_refs","Application compiler explanation query and analytical admission","May generate a runtime validation obligation when membership is not statically decidable.","Rule evolution invalidates cached assessments."),
    operation(owner,"Add Member Claim","MemberClaimCarrier",["AdmittedCollection","MemberClaim","EvidenceBundle"],"CollectionWithMemberClaim",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Membership Is Qualified"),lid(owner,"Duplicate Posture Is Explicit"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"Duplicate Posture")],"Collection contributor authority",B["identity"],"existing_claims + 1 + evidence_refs","Family closure and data-product declaration admission","No I/O; records a claim requiring later runtime validation if source-dependent.","Member claim editions coexist; incompatible membership rules require migration."),
    operation(owner,"Compute Collection Fingerprint","CollectionFingerprintInput",["AdmittedCollection","CanonicalFormRequirement","DigestRequirement"],"CollectionFingerprintClaim",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Representation Independence"),lid(owner,"Duplicate Posture Is Explicit"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"Ordering Posture"),did(owner,"Duplicate Posture")],"No additional authority",B["identity"],"canonical_definition_bytes + identity_defining_claims","CSAG fingerprinting and application release sealing","Requires external Canonical Form and Digest implementations; no local hash algorithm.","Fingerprint algorithm changes are representation changes and retain old evidence."),
    operation(owner,"Compare Collections","CollectionComparisonInput",["AdmittedCollection","AdmittedCollection","ComparisonProfile"],"CollectionComparison",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Collection Identity Is Not Cut"),lid(owner,"Representation Independence")],[did(owner,"Membership Rule Form"),did(owner,"Duplicate Posture"),did(owner,"Ordering Posture")],"No additional authority",B["identity"],"definition_items_left + definition_items_right","Semantic diff and migration planning","No runtime effect.","Produces typed semantic delta and migration obligations."),
    operation(owner,"Readmit Collection","CollectionReadmissionInput",["CollectionCarrier","PriorAdmittedCollection","EvolutionEvidence"],"ReadmittedCollection",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Collection Identity Is Not Cut"),lid(owner,"Membership Is Qualified")],[d["identity"] for d in decs],"Collection owner authority and evolution evidence",B["identity"],"new_carrier + prior_definition + evidence","Semantic diff and migration planner","No runtime effect; emits rebuild/reassessment obligations.","Same-edition semantic mutation is refused."),
]
sm = state_machine(owner,"CollectionAdmission",["RAW","PARSED","ADMITTED","FROZEN","REFUSED"],["PARSE","ADMIT","FREEZE","REVISE"],{
    ("RAW","PARSE"):("PARSED","CollectionCarrierParsed"),
    ("PARSED","ADMIT"):("ADMITTED","CollectionAdmitted"),
    ("ADMITTED","FREEZE"):("FROZEN","CollectionFrozenForRelease"),
    ("ADMITTED","REVISE"):("PARSED","CollectionRevisionOpened"),
    ("FROZEN","REVISE"):("PARSED","NewCollectionEditionOpened"),
},["FROZEN","REFUSED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,14,15,16,17,20,21,27,28,29,30,32,39,40,41,44,45,47,48,49,50,60,81,82,83,85,89,92),
    "owned": ["provider-neutral collection identity","membership rule and qualification","duplicate and ordering posture","collection boundedness","membership assessment"],
    "exclusions": ["data cut","source snapshot","distribution","data service","table","file","catalog record","Schema meaning","Identity meaning","provider storage"],
    "terms": [
        term("Collection","A provider-neutral subject whose membership is determined by an admitted rule or explicit member claims.",owner,"ENTITY",["data collection"],["dataset file","table","cut"]),
        term("Membership Rule","An editioned predicate or closed declaration determining qualified membership.",owner,"RULE",[],["database filter","access policy"]),
        term("Member Claim","A revisable claim that a subject is a member under an exact rule and evidence cut.",owner,"CLAIM",[],["business fact"]),
        term("Membership Assessment","A qualified answer KnownMember, KnownNonMember, Unknown, Withheld, Unavailable, NotApplicable, or Conflicting.",owner,"ANSWER",[],["boolean contains"]),
        term("Duplicate Posture","Whether equal member occurrences remain distinct, collapse by key, or are prohibited.",owner,"DECISION",[],["storage deduplication"]),
        term("Ordering Posture","Whether order is semantic, merely observed, or irrelevant.",owner,"DECISION",[],["source arrival order"]),
        term("Boundedness Posture","Whether membership is finite and closed, finite but open to additions, unbounded, or unknown.",owner,"DECISION",[],["runtime memory bound"]),
        term("Collection Fingerprint","A claim over canonical identity-defining collection semantics produced through external Canonical Form and Digest owners.",owner,"CLAIM",[],["content identifier"]),
    ],
    "false_twins": ["Collection ≠ Data Cut","Collection ≠ Source Snapshot","Collection ≠ Distribution","Collection ≠ Data Product","Collection ≠ Table","Collection ≠ Catalog Record","Membership unknown ≠ non-membership"],
    "types": [
        type_def("CollectionCarrier","HOSTILE_CARRIER","Bounded untrusted declaration of collection semantics.",owner,carrier=True),
        type_def("MembershipAssessmentCarrier","HOSTILE_CARRIER","Bounded untrusted membership question.",owner,carrier=True),
        type_def("MemberClaimCarrier","HOSTILE_CARRIER","Bounded untrusted membership claim.",owner,carrier=True),
        type_def("AdmittedCollection","ADMITTED_ENTITY","Invariant-protected collection definition.",owner,admitted=True),
        type_def("MembershipRule","VALUE","Closed admitted membership-rule form and references.",owner),
        type_def("MemberClaim","CLAIM","Qualified member assertion with evidence and rule edition.",owner),
        type_def("MembershipAssessment","ANSWER","Qualified non-authoritative membership answer.",owner),
        type_def("CollectionFingerprintClaim","CLAIM","Canonical fingerprint claim retaining external proof references.",owner),
    ],
    "decisions": decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-W3C-DCAT-3","SRC-OPENLINEAGE-OBJECT-MODEL","SRC-W3C-PROV-O"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-COLLECTION-DEFINITION","title":"Collection Definition","classification":"CORE","question":"What one collection denotes and how its membership is defined?"},
        {"identity":"SUBDOMAIN-DAT-COLLECTION-MEMBERSHIP","title":"Membership Assessment","classification":"CORE","question":"How is qualified membership answered under incomplete knowledge?"},
        {"identity":"SUBDOMAIN-DAT-COLLECTION-FINGERPRINT","title":"Collection Fingerprinting","classification":"SUPPORTING","question":"How are identity-defining semantics projected for external canonicalization and digest?"},
    ],
}

# ---------------------------------------------------------------------------
# DAT-DATA-CUT
# ---------------------------------------------------------------------------
owner = "DAT-DATA-CUT"
refs = common_refusals(owner) + [
    refusal(owner,"CUT-MEMBERSHIP-NOT-FROZEN","The cut claims immutability but its membership remains open or unresolved.",["admit_data_cut","verify_data_cut"],35),
    refusal(owner,"COMPLETENESS-OVERCLAIM","The claimed completeness exceeds the named scope, frontier, authority, or evidence.",["qualify_completeness","verify_data_cut"],45),
    refusal(owner,"CUT-COLLECTION-MISMATCH","The cut does not bind to the declared collection identity and edition.",["admit_data_cut","compare_data_cuts"],30),
    refusal(owner,"CUT-CONFLICT","Two manifests or cut claims conflict for the same cut identity.",["merge_cut_evidence","compare_data_cuts"],40),
]
B = budget(owner, 16_777_216, 1_000_000, 64, 33_554_432, max_state_items=1_000_000, max_iterations=4)
decs = [
    decision(owner,"Membership Materialization","CutMembershipForm","AUTHORING","ABSENT_IS_INVALID","Changing manifest, predicate closure, or member digest is breaking.",[oid(owner,"Admit Data Cut"),oid(owner,"Verify Data Cut")],"Collection owner and cut publisher evidence."),
    decision(owner,"Completeness Vocabulary","CutCompletenessVocabulary","AUTHORING","ABSENT_MEANS_UNKNOWN","New completeness classes are forward-incompatible unless handled as unknown.",[oid(owner,"Qualify Completeness")],"Named completeness authority and evidence protocol."),
    decision(owner,"Temporal Scope","CutTemporalScope","AUTHORING","ABSENT_MEANS_NOT_TEMPORALLY_SCOPED","Changing valid, event, recording, or publication scope may be breaking.",[oid(owner,"Admit Data Cut"),oid(owner,"Compare Data Cuts")],"Imported time values and source/derivation evidence."),
    decision(owner,"Conflict Policy","CutConflictPolicy","AUTHORING","ABSENT_MEANS_REFUSE","A permissive policy can weaken correctness and requires a new edition.",[oid(owner,"Merge Cut Evidence")],"Cut owner authority and independent assurance evidence."),
]
laws = [
    law(owner,"Cut Is An Immutable Occurrence","An admitted data cut denotes one immutable occurrence of a collection under exact identity-defining membership and scope; later correction creates another cut or restatement relation.",[oid(owner,"Admit Data Cut"),oid(owner,"Verify Data Cut")],[rid(owner,"CUT-MEMBERSHIP-NOT-FROZEN")]),
    law(owner,"Cut Binds Collection","Every cut binds one admitted collection identity and relevant collection edition without redefining collection membership theory.",[oid(owner,"Admit Data Cut"),oid(owner,"Compare Data Cuts")],[rid(owner,"CUT-COLLECTION-MISMATCH")]),
    law(owner,"Completeness Is Qualified","Completeness is a scoped claim with authority, evidence, unknown posture, withheld posture, and frontier; it is never an unqualified boolean.",[oid(owner,"Qualify Completeness"),oid(owner,"Verify Data Cut")],[rid(owner,"COMPLETENESS-OVERCLAIM")]),
    law(owner,"Cut Is Not Snapshot Or Checkpoint","A data cut is distinct from a source snapshot, table-format snapshot, cursor, watermark, consumer offset, execution checkpoint, and savepoint even when one of those helps identify it.",[oid(owner,"Admit Data Cut"),oid(owner,"Compare Data Cuts")],[rid(owner,"CUT-CONFLICT")]),
    law(owner,"Cut Evidence Is Preserved","The cut retains references to collection, source or derivation cuts, membership proof, temporal scope, provenance, and completeness evidence without self-authoring them.",[oid(owner,"Admit Data Cut"),oid(owner,"Merge Cut Evidence")],[rid(owner,"MISSING-REQUIRED-IMPORT")]),
    law(owner,"Conflicting Manifests Refuse","Two incompatible identity-defining membership manifests cannot silently merge under one cut identity.",[oid(owner,"Merge Cut Evidence"),oid(owner,"Verify Data Cut")],[rid(owner,"CUT-CONFLICT")]),
    law(owner,"Cut Fingerprint Stability","Equal canonical cut semantics yield equal external digest claims; representation-only changes do not alter cut identity unless representation belongs to the identity charter.",[oid(owner,"Compute Cut Fingerprint"),oid(owner,"Compare Data Cuts")],[rid(owner,"CUT-CONFLICT")]),
    law(owner,"Aggregate Budget Precharge","Manifest members, segment digests, evidence, conflicts, and diagnostics are aggregate-precharged before allocation.",[oid(owner,"Admit Data Cut"),oid(owner,"Merge Cut Evidence"),oid(owner,"Verify Data Cut")],[rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
ops = [
    operation(owner,"Admit Data Cut","DataCutCarrier",["CollectionRef","CutIdentity","CutMembership","CutTemporalScope","CompletenessClaim","EvidenceBundle"],"AdmittedDataCut",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Cut Is An Immutable Occurrence"),lid(owner,"Cut Binds Collection"),lid(owner,"Cut Evidence Is Preserved"),lid(owner,"Aggregate Budget Precharge")],[d["identity"] for d in decs],"Cut publisher authority and admitted collection reference",B["identity"],"carrier_bytes + members + segments + evidence_refs","Family closure and data-product compilation","Emits storage/publication requirements; no storage commit.","Membership or scope change requires a new cut identity or edition-governed correction."),
    operation(owner,"Qualify Completeness","CompletenessCarrier",["AdmittedDataCut","CompletenessScope","CompletenessEvidence","UnknownPosture"],"QualifiedCompleteness",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Completeness Is Qualified"),lid(owner,"Cut Evidence Is Preserved")],[did(owner,"Completeness Vocabulary")],"Named completeness authority or qualified source evidence",B["identity"],"scope_items + evidence_refs + conflict_claims","Compiler guarantee closure and user explanation","May emit runtime completeness probes; cannot mark provider healthy itself.","New completeness vocabulary requires compatibility review."),
    operation(owner,"Verify Data Cut","DataCutVerificationInput",["AdmittedDataCut","EvidenceBundle","VerificationProfile"],"DataCutVerificationResult",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Cut Is An Immutable Occurrence"),lid(owner,"Completeness Is Qualified"),lid(owner,"Conflicting Manifests Refuse")],[did(owner,"Membership Materialization"),did(owner,"Completeness Vocabulary")],"Verifier authority imported from Evidence and Independent Assurance",B["identity"],"members + segments + evidence_refs","Application closure issuance and publication gate","Produces a non-authorizing verification result and obligations; no publication action.","Verification results are editioned and recallable."),
    operation(owner,"Merge Cut Evidence","CutEvidenceMergeInput",["AdmittedDataCut","EvidenceBundle","EvidenceBundle"],"CutWithMergedEvidence",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Cut Evidence Is Preserved"),lid(owner,"Conflicting Manifests Refuse")],[did(owner,"Conflict Policy")],"No new authority; retain each evidence authority",B["identity"],"left_evidence + right_evidence + conflict_checks","Evidence closure and explanation graph","No runtime effect.","Conflicts remain explicit across editions."),
    operation(owner,"Compute Cut Fingerprint","CutFingerprintInput",["AdmittedDataCut","CanonicalFormRequirement","DigestRequirement"],"CutFingerprintClaim",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Cut Fingerprint Stability"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"Membership Materialization"),did(owner,"Temporal Scope")],"No additional authority",B["identity"],"canonical_cut_bytes + manifest_items","CSAG fingerprinting and release sealing","External canonicalization/digest requirement only.","Digest mechanism changes preserve historical claims."),
    operation(owner,"Compare Data Cuts","DataCutComparisonInput",["AdmittedDataCut","AdmittedDataCut","ComparisonProfile"],"DataCutComparison",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Cut Binds Collection"),lid(owner,"Cut Is Not Snapshot Or Checkpoint"),lid(owner,"Cut Fingerprint Stability")],[did(owner,"Temporal Scope"),did(owner,"Membership Materialization")],"No additional authority",B["identity"],"left_members + right_members + evidence_refs","Semantic diff and migration planning","No runtime effect.","Emits supersession/rebuild/restatement consequences."),
    operation(owner,"Supersede Data Cut","CutSupersessionInput",["AdmittedDataCut","AdmittedDataCut","SupersessionEvidence"],"CutSupersessionRelation",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Cut Is An Immutable Occurrence"),lid(owner,"Cut Evidence Is Preserved")],[did(owner,"Conflict Policy")],"Cut owner or lawful restatement authority",B["identity"],"2*cut_size + evidence_refs","Analytical publication lifecycle and historical interpretation","No publication side effect; emits supersession fact requirement.","Historical cut remains interpretable and is never mutated."),
]
sm = state_machine(owner,"DataCutQualification",["CANDIDATE","COHERENCE_CHECKED","QUALIFIED","VERIFIED","REFUSED"],["CHECK_COHERENCE","QUALIFY","VERIFY","REJECT"],{
    ("CANDIDATE","CHECK_COHERENCE"):("COHERENCE_CHECKED","CutCoherenceChecked"),
    ("COHERENCE_CHECKED","QUALIFY"):("QUALIFIED","CutQualified"),
    ("QUALIFIED","VERIFY"):("VERIFIED","CutVerified"),
    ("CANDIDATE","REJECT"):("REFUSED","CutRefused"),
    ("COHERENCE_CHECKED","REJECT"):("REFUSED","CutRefused"),
    ("QUALIFIED","REJECT"):("REFUSED","CutRefused"),
},["VERIFIED","REFUSED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,11,14,15,16,17,19,20,24,25,26,27,28,29,30,32,44,45,47,48,49,50,60,81,82,83,85,89,92),
    "hard_data_dependencies":["DAT-COLLECTION"],
    "owned":["data cut identity","immutable cut occurrence","cut membership binding","qualified completeness","cut supersession relation"],
    "exclusions":["collection membership theory","source snapshot","table-format snapshot","cursor","watermark","checkpoint","savepoint","publication action","provenance meaning"],
    "terms":[
        term("Data Cut","An immutable occurrence of one collection under exact membership, scope, and evidence.",owner,"OCCURRENCE",["dataset version","data slice"],["source snapshot","checkpoint"]),
        term("Cut Membership","The exact member set or admitted identity-defining manifest for one cut.",owner,"VALUE",[],["collection membership rule"]),
        term("Completeness Claim","A scoped proposition about included, missing, withheld, unavailable, or unknown members.",owner,"CLAIM",[],["boolean complete"]),
        term("Cut Temporal Scope","Imported valid, event, recording, observation, or publication time references associated with a cut.",owner,"VALUE",[],["Rust lifetime"]),
        term("Cut Supersession","A relation that another cut replaces this cut for a declared use without mutating history.",owner,"RELATION",[],["in-place update"]),
        term("Cut Conflict","An incompatibility among identity-defining manifests, scope, evidence, or completeness claims.",owner,"FINDING",[],["provider error string"]),
        term("Cut Fingerprint Claim","An external canonical/digest result over cut identity-defining semantics.",owner,"CLAIM",[],["cut identity itself"]),
    ],
    "false_twins":["Data Cut ≠ Collection","Data Cut ≠ Source Snapshot","Data Cut ≠ Table Snapshot","Data Cut ≠ Cursor","Data Cut ≠ Watermark","Data Cut ≠ Checkpoint","Completeness ≠ boolean"],
    "types":[
        type_def("DataCutCarrier","HOSTILE_CARRIER","Bounded untrusted cut declaration.",owner,carrier=True),
        type_def("CompletenessCarrier","HOSTILE_CARRIER","Bounded untrusted completeness claim.",owner,carrier=True),
        type_def("AdmittedDataCut","ADMITTED_OCCURRENCE","Invariant-protected immutable data cut.",owner,admitted=True),
        type_def("CutMembership","VALUE","Identity-defining cut membership representation.",owner),
        type_def("QualifiedCompleteness","CLAIM","Scoped completeness posture with unknown and withheld semantics.",owner),
        type_def("DataCutVerificationResult","EVIDENCE_RESULT","Non-authorizing verification result retaining verifier evidence.",owner),
        type_def("CutSupersessionRelation","RELATION","Typed historical supersession relation.",owner),
        type_def("CutFingerprintClaim","CLAIM","External canonical digest claim.",owner),
    ],
    "decisions":decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-W3C-DCAT-3","SRC-W3C-PROV-O","SRC-W3C-DQV","SRC-ICEBERG-SPEC","SRC-OPENLINEAGE-OBJECT-MODEL"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-DATA-CUT-IDENTITY","title":"Cut Identity and Membership","classification":"CORE","question":"What exact immutable occurrence is this cut?"},
        {"identity":"SUBDOMAIN-DAT-DATA-CUT-COMPLETENESS","title":"Cut Completeness","classification":"CORE","question":"What is known, missing, withheld, unavailable, or conflicting within the declared scope?"},
        {"identity":"SUBDOMAIN-DAT-DATA-CUT-HISTORY","title":"Cut Supersession and Interpretation","classification":"SUPPORTING","question":"How do later cuts correct or supersede earlier cuts without rewriting history?"},
    ],
}

# ---------------------------------------------------------------------------
# DAT-DISTRIBUTION
# ---------------------------------------------------------------------------
owner = "DAT-DISTRIBUTION"
refs = common_refusals(owner) + [
    refusal(owner,"REPRESENTATION-PROFILE-INCOMPLETE","The distribution lacks a complete representation, media, encoding, resolution, or loss posture.",["admit_distribution"],35),
    refusal(owner,"EXACT-CUT-NOT-BOUND","The distribution claims immutable/exact content without binding a verified data cut.",["bind_distribution_cut","verify_distribution_claim"],40),
    refusal(owner,"LOSS-UNDISCLOSED","A transformation or representation weakening is not disclosed.",["admit_distribution","compare_distributions"],45),
    refusal(owner,"ACCESS-CLAIM-OVERREACH","An observed locator or successful access was elevated into an availability or rights guarantee.",["qualify_distribution_access"],50),
]
B = budget(owner, 8_388_608, 100_000, 64, 16_777_216, max_state_items=100_000, max_iterations=4)
decs = [
    decision(owner,"Binding Posture","DistributionBindingPosture","AUTHORING","ABSENT_MEANS_ROLLING_COLLECTION_REFERENCE","Changing exact/rolling/series binding affects reproducibility and is breaking.",[oid(owner,"Admit Distribution"),oid(owner,"Bind Distribution Cut")],"Publisher declaration and consumer contract evidence."),
    decision(owner,"Representation Loss Profile","RepresentationLossProfile","AUTHORING","ABSENT_MEANS_NO_LOSS_CLAIM_NOT_ALLOWED","Changing loss or resolution is breaking for consumers relying on fidelity.",[oid(owner,"Admit Distribution"),oid(owner,"Compare Distributions")],"Format/media evidence and owner declaration."),
    decision(owner,"Access Posture","DistributionAccessPosture","DEPLOYMENT_BINDING","ABSENT_MEANS_ACCESS_UNBOUND","Access method changes can be compatible if semantic representation and obligations remain.",[oid(owner,"Qualify Distribution Access")],"Provider-neutral requirement and later provider binding evidence."),
    decision(owner,"Rights Attachment Level","RightsAttachmentLevel","AUTHORING","ABSENT_MEANS_REQUIRE_DISTRIBUTION_LEVEL_RIGHTS","Rights conflicts block publication.",[oid(owner,"Admit Distribution")],"Imported agreement, purpose, authorization, and rights evidence."),
]
laws = [
    law(owner,"Distribution Is Representation","A distribution denotes a specific accessible representation or availability form; it is not the conceptual collection, product, service, catalog record, or provider endpoint.",[oid(owner,"Admit Distribution"),oid(owner,"Compare Distributions")],[rid(owner,"REPRESENTATION-PROFILE-INCOMPLETE")]),
    law(owner,"Physical Form Does Not Own Meaning","File format, media type, encoding, compression, packaging, and locator are imported representation concerns and cannot redefine collection or cut semantics.",[oid(owner,"Admit Distribution")],[rid(owner,"MISSING-REQUIRED-IMPORT")]),
    law(owner,"Exact Claim Requires Cut","A distribution claiming immutable exact content must bind one admitted and sufficiently verified data cut; a rolling distribution must disclose that it is not an immutable cut.",[oid(owner,"Bind Distribution Cut"),oid(owner,"Verify Distribution Claim")],[rid(owner,"EXACT-CUT-NOT-BOUND")]),
    law(owner,"Representation Loss Is Explicit","Changes in precision, projection, sampling, language, resolution, omitted fields, compression loss, or schema layout are disclosed as typed loss or preservation claims.",[oid(owner,"Admit Distribution"),oid(owner,"Compare Distributions")],[rid(owner,"LOSS-UNDISCLOSED")]),
    law(owner,"Locator Is Not Distribution Identity","A distribution may move, gain mirrors, or change access locators without changing identity when the admitted representation semantics remain the same.",[oid(owner,"Qualify Distribution Access"),oid(owner,"Compare Distributions")],[rid(owner,"ACCESS-CLAIM-OVERREACH")]),
    law(owner,"Availability Observation Is Not Guarantee","A successful read or health observation is evidence about an access occurrence, not a self-authored service objective, entitlement, or provider guarantee.",[oid(owner,"Qualify Distribution Access")],[rid(owner,"ACCESS-CLAIM-OVERREACH")]),
    law(owner,"Aggregate Budget Precharge","All representation fields, rights references, locators, mirror candidates, and diagnostics are aggregate-precharged before allocation.",[oid(owner,"Admit Distribution"),oid(owner,"Compare Distributions")],[rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
ops = [
    operation(owner,"Admit Distribution","DistributionCarrier",["CollectionRef","OptionalDataCutRef","MediaRepresentationRef","EncodingRef","LocatorRequirement","RightsEvidence","RepresentationLossProfile"],"AdmittedDistribution",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Distribution Is Representation"),lid(owner,"Physical Form Does Not Own Meaning"),lid(owner,"Representation Loss Is Explicit"),lid(owner,"Aggregate Budget Precharge")],[d["identity"] for d in decs],"Distribution publisher authority and imported rights evidence",B["identity"],"carrier_bytes + representation_fields + rights_refs + locators","Data product closure and client-facing contract projection","Emits access, media, resource, and provider requirements; no network access.","Representation changes classified by loss and binding posture."),
    operation(owner,"Bind Distribution Cut","DistributionCutBindingInput",["AdmittedDistribution","AdmittedDataCut","CutVerificationEvidence"],"CutBoundDistribution",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Exact Claim Requires Cut"),lid(owner,"Distribution Is Representation")],[did(owner,"Binding Posture")],"Distribution publisher authority and cut verification evidence",B["identity"],"distribution_fields + cut_evidence","Application closure and publication planning","No publication effect; creates exact-cut provider-neutral requirement.","Rebinding to another cut creates another distribution occurrence or editioned binding."),
    operation(owner,"Qualify Distribution Access","DistributionAccessInput",["AdmittedDistribution","AccessObservation","AuthorizationEvidence","ServiceObjectiveEvidence"],"QualifiedDistributionAccess",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Locator Is Not Distribution Identity"),lid(owner,"Availability Observation Is Not Guarantee")],[did(owner,"Access Posture")],"No authority elevation; retain external authorization/provider evidence",B["identity"],"locators + evidence_refs + health_claims","Client-facing answer qualification and provider binding explanation","May emit runtime access probe obligations; cannot access a locator.","Access observations expire independently of distribution identity."),
    operation(owner,"Compare Distributions","DistributionComparisonInput",["AdmittedDistribution","AdmittedDistribution","ComparisonProfile"],"DistributionComparison",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Distribution Is Representation"),lid(owner,"Representation Loss Is Explicit"),lid(owner,"Locator Is Not Distribution Identity")],[did(owner,"Representation Loss Profile"),did(owner,"Binding Posture")],"No additional authority",B["identity"],"left_representation + right_representation","Semantic diff and compatibility planning","No runtime effect.","Produces representation compatibility, re-download, and consumer impact obligations."),
    operation(owner,"Verify Distribution Claim","DistributionVerificationInput",["AdmittedDistribution","RepresentationEvidence","OptionalCutEvidence"],"DistributionVerificationResult",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Exact Claim Requires Cut"),lid(owner,"Representation Loss Is Explicit")],[did(owner,"Binding Posture"),did(owner,"Representation Loss Profile")],"Verifier authority imported from Evidence and Independent Assurance",B["identity"],"representation_fields + evidence_refs","Publication gate and assurance case","No access or publication effect.","Verification evidence expires and can be recalled."),
    operation(owner,"Project Distribution Contract","DistributionContractProjectionInput",["AdmittedDistribution","ContractHeaderRequirement"],"DistributionContractContribution",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Distribution Is Representation"),lid(owner,"Physical Form Does Not Own Meaning")],[d["identity"] for d in decs],"Distribution owner authority",B["identity"],"distribution_fields + guarantees","Constitutional contract projection and central application linker","No provider offer is authored.","Contract changes follow CON compatibility laws."),
]
sm = state_machine(owner,"DistributionAdmission",["CANDIDATE","REPRESENTATION_CHECKED","ADMITTED","CUT_BOUND","REFUSED"],["CHECK_REPRESENTATION","ADMIT","BIND_CUT","REJECT"],{
    ("CANDIDATE","CHECK_REPRESENTATION"):("REPRESENTATION_CHECKED","DistributionRepresentationChecked"),
    ("REPRESENTATION_CHECKED","ADMIT"):("ADMITTED","DistributionAdmitted"),
    ("ADMITTED","BIND_CUT"):("CUT_BOUND","DistributionBoundToCut"),
    ("CANDIDATE","REJECT"):("REFUSED","DistributionRefused"),
    ("REPRESENTATION_CHECKED","REJECT"):("REFUSED","DistributionRefused"),
    ("ADMITTED","REJECT"):("REFUSED","DistributionRefused"),
},["CUT_BOUND","REFUSED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,3,14,15,16,17,18,20,21,24,27,28,29,30,32,33,44,45,47,48,49,50,60,65,77,81,82,83,84,86,92,94,95,96),
    "hard_data_dependencies":["DAT-COLLECTION"],
    "semantic_seams":["DAT-DATA-CUT"],
    "owned":["distribution identity","representation profile","exact versus rolling binding posture","representation loss disclosure","qualified access claim"],
    "exclusions":["collection","data product","data service","catalog record","file format definition","encoding definition","locator meaning","authorization","provider endpoint","service runtime"],
    "terms":[
        term("Distribution","A specific accessible representation or availability form of a collection or cut.",owner,"ENTITY",["dataset distribution"],["dataset","service"]),
        term("Representation Profile","The imported media, encoding, packaging, layout, language, resolution, and profile claims of a distribution.",owner,"VALUE",[],["Schema"]),
        term("Cut Binding","An exact or rolling relation from a distribution to a collection or admitted data cut.",owner,"RELATION",[],["table snapshot"]),
        term("Representation Loss Profile","A typed declaration of preserved, weakened, omitted, aggregated, sampled, projected, or lossy semantics.",owner,"VALUE",[],["quality score"]),
        term("Distribution Access Observation","A source-qualified observation that one locator or access route responded under a principal and time.",owner,"OBSERVATION",[],["availability guarantee"]),
        term("Distribution Mirror","An alternative locator or realization believed to expose equivalent representation semantics.",owner,"ROLE",[],["duplicate collection"]),
    ],
    "false_twins":["Distribution ≠ Collection","Distribution ≠ Data Product","Distribution ≠ Data Service","Distribution ≠ Catalog Record","Locator ≠ Distribution identity","Successful access ≠ availability guarantee"],
    "types":[
        type_def("DistributionCarrier","HOSTILE_CARRIER","Bounded untrusted distribution declaration.",owner,carrier=True),
        type_def("AdmittedDistribution","ADMITTED_ENTITY","Invariant-protected distribution definition.",owner,admitted=True),
        type_def("RepresentationProfile","VALUE","Typed imported representation metadata and preservation posture.",owner),
        type_def("DistributionBindingPosture","CLOSED_ENUM","ExactCut, RollingCollection, SeriesMember, or Unbound.",owner),
        type_def("RepresentationLossProfile","VALUE","Typed preservation and loss vector.",owner),
        type_def("QualifiedDistributionAccess","ANSWER","Evidence-qualified access answer without provider guarantee laundering.",owner),
        type_def("DistributionContractContribution","CONTRACT_CONTRIBUTION","Provider-neutral distribution contribution using CON-owned header/algebra.",owner),
    ],
    "decisions":decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-W3C-DCAT-3","SRC-BITOL-ODCS-3-1","SRC-W3C-PROV-O"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-DISTRIBUTION-REPRESENTATION","title":"Distribution Representation","classification":"CORE","question":"What accessible representation exists and what does it preserve or lose?"},
        {"identity":"SUBDOMAIN-DAT-DISTRIBUTION-BINDING","title":"Collection and Cut Binding","classification":"CORE","question":"Does the distribution expose an immutable cut, a rolling collection, or another declared binding?"},
        {"identity":"SUBDOMAIN-DAT-DISTRIBUTION-ACCESS","title":"Access Qualification","classification":"SUPPORTING","question":"What may be claimed from observed access without self-authoring provider guarantees?"},
    ],
}

# ---------------------------------------------------------------------------
# DAT-SOURCE-OBSERVATION
# ---------------------------------------------------------------------------
owner = "DAT-SOURCE-OBSERVATION"
refs = common_refusals(owner) + [
    refusal(owner,"SOURCE-SCOPE-INCOMPLETE","Source, interface, principal, visibility, time, or query scope is absent.",["admit_source_observation"],35),
    refusal(owner,"SOURCE-CLAIM-ELEVATION","A source-qualified claim was promoted into application fact, universal schema, identity, authority, or provider guarantee.",["admit_source_observation","qualify_source_absence"],25),
    refusal(owner,"VISIBILITY-AMBIGUOUS","Absence cannot be distinguished from permission filtering, source omission, unsupported field, or empty result.",["qualify_source_absence"],45),
    refusal(owner,"SOURCE-OBSERVATION-CONFLICT","Source observations conflict within the same declared cut and scope without an admitted resolution.",["merge_source_observations"],40),
]
B = budget(owner, 8_388_608, 250_000, 96, 16_777_216, max_state_items=250_000, max_iterations=8)
decs = [
    decision(owner,"Observation Subject Granularity","SourceSubjectGranularity","AUTHORING","ABSENT_IS_INVALID","Changing subject granularity changes reference and completeness semantics.",[oid(owner,"Admit Source Observation")],"Source profile and observation requirement evidence."),
    decision(owner,"Visibility Posture","SourceVisibilityPosture","AUTHORING","ABSENT_MEANS_UNKNOWN","Changing visibility scope invalidates absence and completeness answers.",[oid(owner,"Admit Source Observation"),oid(owner,"Qualify Source Absence")],"Principal, authorization, source-interface and discovery evidence."),
    decision(owner,"Source Time Interpretation","SourceTimeInterpretation","AUTHORING","ABSENT_MEANS_OBSERVATION_TIME_ONLY","Promoting source time to event/valid/record time is breaking without evidence.",[oid(owner,"Admit Source Observation")],"Source profile and imported time semantics."),
    decision(owner,"Structural Observation Posture","StructuralObservationPosture","AUTHORING","ABSENT_MEANS_SOURCE_QUALIFIED_ONLY","Changing source-to-schema mapping requires explicit semantic mapping review.",[oid(owner,"Admit Structural Observation")],"Source metadata evidence and SEM-030 admission outcome."),
]
laws = [
    law(owner,"Observation Is Not Application Fact","A source observation is a qualified claim about what a foreign source exposed; it never becomes authoritative application truth without the owning application admission path.",[oid(owner,"Admit Source Observation"),oid(owner,"Project Committed Fact Intake Requirement")],[rid(owner,"SOURCE-CLAIM-ELEVATION")]),
    law(owner,"Observation Scope Is Complete","Every source observation names source identity, interface or operation, principal or workload identity, query or selection, visibility and authorization posture, observation time, and evidence cut.",[oid(owner,"Admit Source Observation")],[rid(owner,"SOURCE-SCOPE-INCOMPLETE")]),
    law(owner,"Absence Has Multiple Meanings","No row, no object, no field, null, withheld, redacted, permission-filtered, unsupported, unavailable, and not-observed remain distinct.",[oid(owner,"Qualify Source Absence")],[rid(owner,"VISIBILITY-AMBIGUOUS")]),
    law(owner,"Source Structure Is Not Schema","Provider metadata, inferred shape, ERD, API response, or connector destination shape is a source-qualified structural observation and cannot self-author SEM-030 Schema.",[oid(owner,"Admit Structural Observation")],[rid(owner,"SOURCE-CLAIM-ELEVATION")]),
    law(owner,"Source Time Is Qualified","A source timestamp is not event time, valid time, recording time, commit time, ingestion time, or processing time unless the exact interpretation is admitted from its owner.",[oid(owner,"Admit Source Observation")],[rid(owner,"SOURCE-CLAIM-ELEVATION")]),
    law(owner,"Evidence Ceiling","No observation conclusion may exceed its source, principal, interface, cut, transformation, uncertainty, or evidence basis.",[oid(owner,"Admit Source Observation"),oid(owner,"Merge Source Observations")],[rid(owner,"UNKNOWN-OR-INCOMPLETE")]),
    law(owner,"Conflicts Remain Visible","Conflicting source observations do not collapse by last writer, string equality, or provider precedence without an explicit imported decision.",[oid(owner,"Merge Source Observations")],[rid(owner,"SOURCE-OBSERVATION-CONFLICT")]),
    law(owner,"Aggregate Budget Precharge","Carrier bytes, selected fields, records, source metadata, evidence, conflicts, and diagnostics are aggregate-precharged before allocation.",[oid(owner,"Admit Source Observation"),oid(owner,"Merge Source Observations")],[rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
ops = [
    operation(owner,"Admit Source Observation","SourceObservationCarrier",["SourceRef","InterfaceRef","PrincipalScope","ObservationTime","VisibilityScope","SelectionScope","SourceClaim","EvidenceBundle"],"AdmittedSourceObservation",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Observation Is Not Application Fact"),lid(owner,"Observation Scope Is Complete"),lid(owner,"Source Time Is Qualified"),lid(owner,"Evidence Ceiling"),lid(owner,"Aggregate Budget Precharge")],[d["identity"] for d in decs],"Source-observation authoring authority; no source authority is inferred",B["identity"],"carrier_bytes + selected_fields + source_claim_items + evidence_refs","Source admission, source-profile closure and explanation","Emits source observation requirements; performs no I/O.","Source profile or scope change requires re-admission."),
    operation(owner,"Qualify Source Absence","SourceAbsenceInput",["AdmittedSourceObservation","AbsenceQuestion","VisibilityEvidence","SourceCapabilityEvidence"],"QualifiedSourceAbsence",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Absence Has Multiple Meanings"),lid(owner,"Evidence Ceiling")],[did(owner,"Visibility Posture")],"No authority elevation; retain external evidence",B["identity"],"visibility_claims + capability_claims + source_observations","Compiler explanation and downstream completeness reasoning","May generate runtime probes; cannot conclude source emptiness without evidence.","Visibility evidence expiry invalidates the answer."),
    operation(owner,"Admit Structural Observation","SourceStructureCarrier",["SourceRef","InterfaceRef","StructuralClaim","ObservationCut","EvidenceBundle"],"AdmittedSourceStructureObservation",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Source Structure Is Not Schema"),lid(owner,"Observation Scope Is Complete"),lid(owner,"Evidence Ceiling")],[did(owner,"Structural Observation Posture")],"Source metadata observation authority only",B["identity"],"carrier_bytes + fields + nested_depth + evidence_refs","Schema admission input and source mapping compiler","Emits an SEM-030 admission requirement; never creates Schema directly.","Structural deltas remain source-qualified and may trigger schema review."),
    operation(owner,"Merge Source Observations","SourceObservationMergeInput",["AdmittedSourceObservation","AdmittedSourceObservation","MergeDecisionEvidence"],"MergedSourceObservationSet",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Evidence Ceiling"),lid(owner,"Conflicts Remain Visible")],[did(owner,"Visibility Posture"),did(owner,"Observation Subject Granularity")],"Named reconciliation or observation authority",B["identity"],"left_items + right_items + conflict_pairs","Acquisition reconciliation and explanation graph","No source write or mutation.","Merge decisions are editioned and do not erase original observations."),
    operation(owner,"Compare Observation Scopes","ObservationScopeComparisonInput",["AdmittedSourceObservation","AdmittedSourceObservation"],"ObservationScopeComparison",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Observation Scope Is Complete"),lid(owner,"Source Time Is Qualified")],[d["identity"] for d in decs],"No additional authority",B["identity"],"scope_fields_left + scope_fields_right","Acquisition planner and semantic diff","No runtime effect.","Produces incompatibility and resnapshot/requery obligations."),
    operation(owner,"Project Source Requirement","SourceRequirementProjectionInput",["ObservationRequirement","ContractHeaderRequirement"],"ProviderNeutralSourceRequirement",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Observation Scope Is Complete"),lid(owner,"Evidence Ceiling")],[d["identity"] for d in decs],"Requirement author authority",B["identity"],"requirement_fields + guarantees","CON requirement projection and CMP provider linking","No provider offer is authored.","Requirement editions evolve under CON compatibility."),
    operation(owner,"Project Committed Fact Intake Requirement","CommittedFactIntakeProjectionInput",["AdmittedSourceObservation","ApplicationFactBoundaryRef"],"CommittedFactIntakeRequirement",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Observation Is Not Application Fact")],[],"Application ontology/kernel boundary authority",B["identity"],"observation_refs + boundary_refs","Application linker and Host Role Composition","Requires re-entry through application kernel for any mutation.","Boundary change is breaking and blocks direct-source authority."),
]
sm = state_machine(owner,"SourceObservationAdmission",["RAW","STRUCTURALLY_ADMITTED","SOURCE_QUALIFIED","ACCEPTED","REFUSED"],["ADMIT_STRUCTURE","QUALIFY_SOURCE","ACCEPT","REJECT"],{
    ("RAW","ADMIT_STRUCTURE"):("STRUCTURALLY_ADMITTED","SourceCarrierStructurallyAdmitted"),
    ("STRUCTURALLY_ADMITTED","QUALIFY_SOURCE"):("SOURCE_QUALIFIED","SourceObservationQualified"),
    ("SOURCE_QUALIFIED","ACCEPT"):("ACCEPTED","SourceObservationAccepted"),
    ("RAW","REJECT"):("REFUSED","SourceObservationRefused"),
    ("STRUCTURALLY_ADMITTED","REJECT"):("REFUSED","SourceObservationRefused"),
    ("SOURCE_QUALIFIED","REJECT"):("REFUSED","SourceObservationRefused"),
},["ACCEPTED","REFUSED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,3,11,14,15,16,17,19,20,21,24,27,28,29,30,31,32,33,35,36,42,43,45,47,48,49,50,53,56,57,58,60,62,63,64,69,81,82,83,84,85,89,90,92,94,95,96),
    "owned":["source-qualified observation","complete observation scope","source absence qualification","source structural observation","source claim conflict"],
    "exclusions":["application fact","Schema","Identity","Authorization","provider connector","source I/O","source truth elevation","business correspondence"],
    "terms":[
        term("Source Observation","A bounded claim about what a named foreign source exposed under an exact scope.",owner,"OBSERVATION",[],["application fact"]),
        term("Source Scope","The source, interface, operation, principal, selection, visibility, time, and evidence context of an observation.",owner,"VALUE",[],["connection string"]),
        term("Source Subject","The source-qualified object, record, field, file, message, table, endpoint, or resource being observed.",owner,"ROLE",[],["business entity"]),
        term("Visibility Scope","What the observing principal and interface were permitted and capable of seeing.",owner,"VALUE",[],["source completeness"]),
        term("Source Absence","A qualified non-observation with reasons such as not found, not visible, withheld, unsupported, unavailable, or unknown.",owner,"ANSWER",[],["null"]),
        term("Source Structure Observation","A source-qualified structural claim submitted to Schema admission without owning Schema.",owner,"OBSERVATION",[],["Schema"]),
        term("Source Claim Conflict","Two source observations that cannot jointly hold under the same declared scope.",owner,"FINDING",[],["last writer wins"]),
    ],
    "false_twins":["Source Observation ≠ Application Fact","Source Structure Observation ≠ Schema","Source ID ≠ enterprise Identity","Source timestamp ≠ Event Time","No result ≠ empty source","Connector capability ≠ source semantic guarantee"],
    "types":[
        type_def("SourceObservationCarrier","HOSTILE_CARRIER","Bounded untrusted source observation.",owner,carrier=True),
        type_def("SourceStructureCarrier","HOSTILE_CARRIER","Bounded source structural metadata carrier.",owner,carrier=True),
        type_def("AdmittedSourceObservation","ADMITTED_OBSERVATION","Invariant-protected source-qualified observation.",owner,admitted=True),
        type_def("AdmittedSourceStructureObservation","ADMITTED_OBSERVATION","Source-qualified structural observation without Schema authority.",owner,admitted=True),
        type_def("SourceObservationScope","VALUE","Complete source/interface/principal/selection/time/visibility scope.",owner),
        type_def("QualifiedSourceAbsence","ANSWER","Typed absence and uncertainty answer.",owner),
        type_def("SourceClaimConflict","FINDING","Conflict retaining both claims and evidence.",owner),
        type_def("ProviderNeutralSourceRequirement","CONTRACT_REQUIREMENT_CONTRIBUTION","Provider-neutral observation requirement using CON-owned algebra.",owner),
    ],
    "decisions":decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-W3C-PROV-O","SRC-OPENLINEAGE-OBJECT-MODEL","SRC-AWS-S3-EVENT-NOTIFICATIONS","SRC-MS-GRAPH-DELTA"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-SOURCE-OBSERVATION-SCOPE","title":"Observation Scope","classification":"CORE","question":"Under exactly what source, interface, principal, selection, time, and visibility was a claim observed?"},
        {"identity":"SUBDOMAIN-DAT-SOURCE-OBSERVATION-ABSENCE","title":"Absence and Visibility","classification":"CORE","question":"What does a missing result mean under incomplete source visibility?"},
        {"identity":"SUBDOMAIN-DAT-SOURCE-OBSERVATION-STRUCTURE","title":"Structural Observation","classification":"SUPPORTING","question":"How is source-native structure observed without annexing Schema meaning?"},
    ],
}

# ---------------------------------------------------------------------------
# DAT-SOURCE-SNAPSHOT
# ---------------------------------------------------------------------------
owner = "DAT-SOURCE-SNAPSHOT"
refs = common_refusals(owner) + [
    refusal(owner,"SNAPSHOT-CUT-INCOHERENT","Snapshot segments do not share one admitted source cut or an explicit weakening.",["admit_source_snapshot","verify_snapshot_coherence"],30),
    refusal(owner,"SNAPSHOT-PARTIAL","The snapshot does not cover the declared source assets or selection scope.",["qualify_snapshot_completeness","verify_snapshot_coherence"],40),
    refusal(owner,"SOURCE-NOT-FINALIZED","An object, file, export, or source batch exists but is not evidenced as complete and safe to admit.",["admit_snapshot_segment","close_source_snapshot"],25),
    refusal(owner,"SNAPSHOT-RESUME-SCOPE-CHANGED","A resumed snapshot changed source cut, selection, principal, structure, or chunk semantics without a new edition.",["resume_source_snapshot"],35),
    refusal(owner,"SNAPSHOT-SEGMENT-CONFLICT","Two segments claim the same logical scope with incompatible contents or source coordinates.",["merge_snapshot_segments"],45),
]
B = budget(owner, 67_108_864, 2_000_000, 128, 134_217_728, max_state_items=2_000_000, max_iterations=32)
decs = [
    decision(owner,"Snapshot Consistency Posture","SnapshotConsistencyPosture","AUTHORING","ABSENT_IS_INVALID","Weakening consistency is breaking and changes stitching guarantees.",[oid(owner,"Admit Source Snapshot"),oid(owner,"Verify Snapshot Coherence")],"Source profile, isolation evidence, and consumer correctness requirement."),
    decision(owner,"Segmentation Strategy","SnapshotSegmentationStrategy","PLANNING","ABSENT_MEANS_PROVIDER_DETERMINED_WITH_PROOF","May be compatible only if cut and membership semantics are preserved.",[oid(owner,"Admit Snapshot Segment"),oid(owner,"Merge Snapshot Segments")],"Finite bounds and provider-neutral segmentation evidence."),
    decision(owner,"Source Finalization Policy","SourceFinalizationPolicy","AUTHORING","ABSENT_MEANS_FINALIZATION_REQUIRED","Changing finalization may admit partial files/exports and is breaking.",[oid(owner,"Admit Snapshot Segment"),oid(owner,"Close Source Snapshot")],"Source family profile and provider conformance evidence."),
    decision(owner,"Snapshot Completeness Scope","SnapshotCompletenessScope","AUTHORING","ABSENT_MEANS_UNKNOWN","Changing scope invalidates completeness and stitching proof.",[oid(owner,"Qualify Snapshot Completeness")],"Observation requirement and source inventory cut."),
]
laws = [
    law(owner,"Snapshot Is Source-Qualified","A source snapshot is a finite set of source observations bound to one source, interface, selection, principal, and admitted source-cut posture; it is not a universal data cut or table snapshot.",[oid(owner,"Admit Source Snapshot")],[rid(owner,"SNAPSHOT-CUT-INCOHERENT")]),
    law(owner,"Segments Share One Cut","All segments of a coherent snapshot share one admitted source cut or a named, evidence-backed weakening that downstream consumers explicitly accept.",[oid(owner,"Admit Snapshot Segment"),oid(owner,"Merge Snapshot Segments"),oid(owner,"Verify Snapshot Coherence")],[rid(owner,"SNAPSHOT-CUT-INCOHERENT")]),
    law(owner,"Chunking Preserves Membership","Segmentation, pagination, partitioning, parallel reads, and retries may alter execution but not logical snapshot membership, duplicate posture, or source cut.",[oid(owner,"Admit Snapshot Segment"),oid(owner,"Merge Snapshot Segments")],[rid(owner,"SNAPSHOT-SEGMENT-CONFLICT")]),
    law(owner,"Partial Is Not Complete","A successful set of reads is not a complete snapshot unless every declared source asset, selection range, finalization condition, and withheld/unknown posture is discharged.",[oid(owner,"Qualify Snapshot Completeness"),oid(owner,"Verify Snapshot Coherence")],[rid(owner,"SNAPSHOT-PARTIAL")]),
    law(owner,"Existence Is Not Finalization","Object existence, file visibility, export job success, manifest closure, upload completion, and safe admission remain distinct source-profile claims.",[oid(owner,"Admit Snapshot Segment"),oid(owner,"Close Source Snapshot")],[rid(owner,"SOURCE-NOT-FINALIZED")]),
    law(owner,"Resume Preserves Scope","Resuming a snapshot preserves source cut, principal, interface, selection, structure interpretation, and segmentation identity or opens a new snapshot attempt.",[oid(owner,"Resume Source Snapshot")],[rid(owner,"SNAPSHOT-RESUME-SCOPE-CHANGED")]),
    law(owner,"Closed Snapshot Is Immutable","Closing a source snapshot freezes its admitted segments and evidence; correction creates a new attempt, new cut, or typed supersession.",[oid(owner,"Close Source Snapshot"),oid(owner,"Compare Source Snapshots")],[rid(owner,"SNAPSHOT-SEGMENT-CONFLICT")]),
    law(owner,"Aggregate Budget Precharge","All segments, records, source assets, evidence, conflict pairs, and diagnostics are aggregate-precharged before allocation or merge.",[oid(owner,"Admit Source Snapshot"),oid(owner,"Merge Snapshot Segments")],[rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
ops = [
    operation(owner,"Admit Source Snapshot","SourceSnapshotCarrier",["SourceObservationScope","SourceCutClaim","SnapshotSelection","ConsistencyPosture","SegmentationPlan","CompletenessScope","EvidenceBundle"],"AdmittedSourceSnapshot",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Snapshot Is Source-Qualified"),lid(owner,"Segments Share One Cut"),lid(owner,"Aggregate Budget Precharge")],[d["identity"] for d in decs],"Snapshot requirement author and source-observation authority",B["identity"],"carrier_bytes + segments + source_assets + evidence_refs","Acquisition planning and application closure","Emits snapshot runtime requirements; performs no read.","Consistency or selection change requires a new edition/attempt."),
    operation(owner,"Admit Snapshot Segment","SnapshotSegmentCarrier",["AdmittedSourceSnapshot","SegmentIdentity","SegmentRange","SourceObservations","FinalizationEvidence"],"AdmittedSnapshotSegment",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Segments Share One Cut"),lid(owner,"Chunking Preserves Membership"),lid(owner,"Existence Is Not Finalization")],[did(owner,"Segmentation Strategy"),did(owner,"Source Finalization Policy")],"Snapshot runtime receipt or independently admitted source evidence",B["identity"],"segment_bytes + records + evidence_refs","Runtime receipt admission and snapshot closure","Consumes receipts as values; no filesystem/network action.","Segment representation changes retain logical range/cut identity or are rejected."),
    operation(owner,"Merge Snapshot Segments","SnapshotSegmentMergeInput",["AdmittedSourceSnapshot","AdmittedSnapshotSegmentSet"],"MergedSnapshotBody",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Segments Share One Cut"),lid(owner,"Chunking Preserves Membership"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"Segmentation Strategy")],"No new authority; retain segment receipts",B["identity"],"segments + records + overlap_checks","Snapshot closure and stitching compiler","No runtime effect.","Merge is deterministic for equal admitted segments."),
    operation(owner,"Qualify Snapshot Completeness","SnapshotCompletenessInput",["AdmittedSourceSnapshot","MergedSnapshotBody","DiscoveryInventoryCut","CompletenessEvidence"],"QualifiedSnapshotCompleteness",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Partial Is Not Complete"),lid(owner,"Existence Is Not Finalization")],[did(owner,"Snapshot Completeness Scope"),did(owner,"Source Finalization Policy")],"Named completeness authority or qualified source evidence",B["identity"],"source_assets + segments + evidence_refs","Stitching precondition and assurance explanation","May emit runtime inventory/finalization probes.","Completeness expires or is invalidated when source scope changes."),
    operation(owner,"Verify Snapshot Coherence","SnapshotVerificationInput",["AdmittedSourceSnapshot","MergedSnapshotBody","QualifiedSnapshotCompleteness","IsolationEvidence"],"SnapshotCoherenceResult",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Segments Share One Cut"),lid(owner,"Partial Is Not Complete"),lid(owner,"Closed Snapshot Is Immutable")],[did(owner,"Snapshot Consistency Posture"),did(owner,"Snapshot Completeness Scope")],"Independent verifier or admitted provider conformance evidence",B["identity"],"segments + ranges + evidence_refs + conflict_checks","Stitching compiler and publication guarantee closure","No execution; produces proof requirement/result.","Verification is tied to snapshot edition and evidence validity."),
    operation(owner,"Resume Source Snapshot","SnapshotResumeInput",["AdmittedSourceSnapshot","ResumeReceipt","PriorSegmentSet"],"SnapshotResumePlan",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Resume Preserves Scope"),lid(owner,"Chunking Preserves Membership")],[did(owner,"Segmentation Strategy")],"Snapshot controller receipt and provider conformance evidence",B["identity"],"prior_segments + receipt_fields","Runtime/control plan validation","Emits provider-neutral resume obligations; does not resume I/O.","Provider configuration change may force restart/new attempt."),
    operation(owner,"Close Source Snapshot","SnapshotCloseInput",["AdmittedSourceSnapshot","MergedSnapshotBody","QualifiedSnapshotCompleteness","CloseEvidence"],"ClosedSourceSnapshot",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Existence Is Not Finalization"),lid(owner,"Closed Snapshot Is Immutable")],[did(owner,"Source Finalization Policy"),did(owner,"Snapshot Completeness Scope")],"Snapshot owner plus finalization evidence",B["identity"],"segments + evidence_refs","Stitching input closure and release explanation","No publication; emits immutable snapshot input.","Closed snapshot never mutates; correction creates a successor."),
    operation(owner,"Compare Source Snapshots","SourceSnapshotComparisonInput",["ClosedSourceSnapshot","ClosedSourceSnapshot"],"SourceSnapshotComparison",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Snapshot Is Source-Qualified"),lid(owner,"Closed Snapshot Is Immutable")],[d["identity"] for d in decs],"No additional authority",B["identity"],"left_segments + right_segments","Semantic diff/migration and re-snapshot planning","No runtime effect.","Produces scope, cut, completeness, and representation deltas."),
]
sm = state_machine(owner,"SourceSnapshotLifecycle",["OPEN","SEGMENTED","CLOSED","COHERENCE_CHECKED","QUALIFIED","REFUSED"],["ADD_SEGMENT","CLOSE","CHECK_COHERENCE","QUALIFY","REJECT"],{
    ("OPEN","ADD_SEGMENT"):("SEGMENTED","SnapshotSegmentAdded"),
    ("SEGMENTED","ADD_SEGMENT"):("SEGMENTED","SnapshotSegmentAdded"),
    ("SEGMENTED","CLOSE"):("CLOSED","SourceSnapshotClosed"),
    ("CLOSED","CHECK_COHERENCE"):("COHERENCE_CHECKED","SnapshotCoherenceChecked"),
    ("COHERENCE_CHECKED","QUALIFY"):("QUALIFIED","SourceSnapshotQualified"),
    ("OPEN","REJECT"):("REFUSED","SourceSnapshotRefused"),
    ("SEGMENTED","REJECT"):("REFUSED","SourceSnapshotRefused"),
    ("CLOSED","REJECT"):("REFUSED","SourceSnapshotRefused"),
    ("COHERENCE_CHECKED","REJECT"):("REFUSED","SourceSnapshotRefused"),
},["QUALIFIED","REFUSED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,11,14,15,16,17,19,20,24,25,26,27,28,29,30,32,33,43,44,45,47,48,49,50,60,81,82,83,85,89,92,94,95,96,99),
    "hard_data_dependencies":["DAT-SOURCE-OBSERVATION","DAT-DATA-CUT"],
    "owned":["source snapshot identity","source cut/coherence posture","snapshot segmentation semantics","source finalization requirement","snapshot completeness qualification","snapshot resume invariants"],
    "exclusions":["database transaction implementation","provider snapshot mode","source I/O","table-format snapshot","generic data cut","checkpoint","savepoint","watermark"],
    "terms":[
        term("Source Snapshot","A finite source-qualified body observed under one cut and consistency posture.",owner,"OCCURRENCE",[],["data cut","table snapshot"]),
        term("Source Cut","The source-qualified visibility boundary to which snapshot observations belong.",owner,"VALUE",[],["data cut identity"]),
        term("Snapshot Segment","A bounded part of a snapshot with explicit logical range and cut equality.",owner,"OCCURRENCE",["chunk"],["independent snapshot"]),
        term("Snapshot Consistency Posture","The declared source visibility/isolation guarantee or explicit weakening.",owner,"DECISION",[],["provider option name"]),
        term("Source Finalization","Evidence that a source object, file, export, or batch is complete enough for snapshot admission.",owner,"CLAIM",[],["object exists"]),
        term("Snapshot Completeness","Qualified coverage of source assets, selection, segments, withholding, unknowns, and finalization.",owner,"CLAIM",[],["job succeeded"]),
        term("Snapshot Resume","A continuation of the same snapshot attempt preserving identity-defining scope.",owner,"VALUE",[],["source change continuation"]),
    ],
    "false_twins":["Source Snapshot ≠ Data Cut","Source Snapshot ≠ Table Snapshot","Source Snapshot ≠ Checkpoint","Object exists ≠ upload complete","Export job succeeded ≠ artifact verified","Chunking ≠ independent cuts"],
    "types":[
        type_def("SourceSnapshotCarrier","HOSTILE_CARRIER","Bounded untrusted source-snapshot declaration.",owner,carrier=True),
        type_def("SnapshotSegmentCarrier","HOSTILE_CARRIER","Bounded untrusted snapshot segment and receipt.",owner,carrier=True),
        type_def("AdmittedSourceSnapshot","ADMITTED_OCCURRENCE","Invariant-protected source snapshot plan/claim.",owner,admitted=True),
        type_def("AdmittedSnapshotSegment","ADMITTED_OCCURRENCE","Invariant-protected source snapshot segment.",owner,admitted=True),
        type_def("ClosedSourceSnapshot","ADMITTED_OCCURRENCE","Immutable closed source snapshot.",owner,admitted=True),
        type_def("SnapshotConsistencyPosture","CLOSED_ENUM","Serializable, RepeatableStableView, TransactionConsistentExport, SourceAtomicObjectSet, ExplicitlyWeakened, or Unknown.",owner),
        type_def("QualifiedSnapshotCompleteness","CLAIM","Scoped completeness with withheld/unknown/finalization posture.",owner),
        type_def("SnapshotCoherenceResult","EVIDENCE_RESULT","Non-authorizing coherence result retaining source/provider evidence.",owner),
    ],
    "decisions":decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-POSTGRES-18-ISOLATION","SRC-POSTGRES-18-LOGICAL-REPLICATION","SRC-DEBEZIUM-POSTGRES-STABLE","SRC-AWS-S3-EVENT-NOTIFICATIONS"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-SOURCE-SNAPSHOT-CUT","title":"Source Cut and Consistency","classification":"CORE","question":"What one source view does the snapshot observe?"},
        {"identity":"SUBDOMAIN-DAT-SOURCE-SNAPSHOT-SEGMENTS","title":"Segmentation and Resume","classification":"CORE","question":"How may a finite snapshot be chunked and resumed without changing membership?"},
        {"identity":"SUBDOMAIN-DAT-SOURCE-SNAPSHOT-CLOSURE","title":"Finalization and Completeness","classification":"CORE","question":"When is a finite source read safe to close and qualify?"},
    ],
}

# ---------------------------------------------------------------------------
# DAT-SOURCE-CONTINUATION
# ---------------------------------------------------------------------------
owner = "DAT-SOURCE-CONTINUATION"
refs = common_refusals(owner) + [
    refusal(owner,"CONTINUATION-SCOPE-MISMATCH","The continuation token or coordinate is used with a different source, interface, principal, query shape, partition, or option set.",["admit_source_continuation","compare_continuations","evaluate_resume_eligibility"],30),
    refusal(owner,"CONTINUATION-EXPIRED","The continuation is outside the evidenced source history or token validity horizon.",["evaluate_resume_eligibility"],35),
    refusal(owner,"CONTINUATION-INVALIDATED","The source or protocol invalidated the continuation and requires a new observation procedure.",["evaluate_resume_eligibility"],35),
    refusal(owner,"COORDINATE-INCOMPARABLE","Coordinates do not belong to the same admitted coordinate space or no ordering law is available.",["compare_continuations"],40),
    refusal(owner,"HISTORY-GAP-UNBRIDGED","Required changes may have occurred after the prior cut but before the earliest resumable continuation.",["evaluate_resume_eligibility","bind_continuation_to_snapshot"],45),
    refusal(owner,"OPAQUE-TOKEN-MODIFIED","An opaque continuation token was parsed, edited, synthesized, or normalized outside its provider profile.",["admit_source_continuation"],25),
]
B = budget(owner, 4_194_304, 100_000, 64, 8_388_608, max_state_items=100_000, max_iterations=16)
decs = [
    decision(owner,"Coordinate Opacity","CoordinateOpacity","AUTHORING","ABSENT_MEANS_OPAQUE","Changing opacity/interpretation is breaking and may invalidate historical tokens.",[oid(owner,"Admit Source Continuation"),oid(owner,"Compare Continuations")],"Source protocol profile and provider conformance evidence."),
    decision(owner,"Scope Binding","ContinuationScopeBinding","AUTHORING","ABSENT_IS_INVALID","Changing any scope dimension invalidates continuation reuse.",[oid(owner,"Admit Source Continuation"),oid(owner,"Evaluate Resume Eligibility")],"Exact source/interface/query/principal/partition/options."),
    decision(owner,"Comparison Posture","ContinuationComparisonPosture","AUTHORING","ABSENT_MEANS_INCOMPARABLE","Adding a total/partial order changes planner options and requires evidence.",[oid(owner,"Compare Continuations")],"Source protocol ordering law and conformance vectors."),
    decision(owner,"Horizon Policy","ContinuationHorizonPolicy","DEPLOYMENT_BINDING","ABSENT_MEANS_HORIZON_UNKNOWN","A shorter horizon can make prior recovery guarantees unsatisfied.",[oid(owner,"Evaluate Resume Eligibility")],"Current source retention/token evidence and observation time."),
]
laws = [
    law(owner,"Continuation Is Scope Bound","A continuation is valid only within its exact source, interface, operation/query shape, options, principal, partition/subscription, and coordinate-space scope.",[oid(owner,"Admit Source Continuation"),oid(owner,"Evaluate Resume Eligibility")],[rid(owner,"CONTINUATION-SCOPE-MISMATCH")]),
    law(owner,"Opaque Means Opaque","An opaque token is retained and replayed byte-for-byte under its source profile; its internal fields are not parsed, edited, canonicalized, fabricated, or compared.",[oid(owner,"Admit Source Continuation")],[rid(owner,"OPAQUE-TOKEN-MODIFIED")]),
    law(owner,"Comparison Requires Coordinate Space","Ordering or equality is available only for continuations admitted to one coordinate space with an explicit comparison law; no cross-source order is inferred.",[oid(owner,"Compare Continuations")],[rid(owner,"COORDINATE-INCOMPARABLE")]),
    law(owner,"Continuation Is Not Runtime Checkpoint","A source continuation is distinct from consumer acknowledgement, broker offset, watermark, execution checkpoint, savepoint, data cut, and table snapshot even if one runtime stores it.",[oid(owner,"Admit Source Continuation"),oid(owner,"Compare Continuations")],[rid(owner,"CONTINUATION-SCOPE-MISMATCH")]),
    law(owner,"Eligibility Depends On Current Horizon","Historical possession of a token does not prove current resumability; eligibility requires current source-horizon and invalidation evidence.",[oid(owner,"Evaluate Resume Eligibility")],[rid(owner,"CONTINUATION-EXPIRED"),rid(owner,"CONTINUATION-INVALIDATED")]),
    law(owner,"Gap Is Distinct From Expiry","Expired, invalidated, malformed, unauthorized, incomparable, and history-gap outcomes remain separate because remediation differs.",[oid(owner,"Evaluate Resume Eligibility")],[rid(owner,"HISTORY-GAP-UNBRIDGED"),rid(owner,"CONTINUATION-EXPIRED"),rid(owner,"CONTINUATION-INVALIDATED")]),
    law(owner,"Snapshot Binding Preserves Frontier","A continuation bound to a source snapshot begins at or before the snapshot's source frontier under a declared overlap policy; an unobserved interval is refused.",[oid(owner,"Bind Continuation To Snapshot")],[rid(owner,"HISTORY-GAP-UNBRIDGED")]),
    law(owner,"Aggregate Budget Precharge","Token bytes, partitions, scope fields, horizon evidence, comparison candidates, and diagnostics are aggregate-precharged before allocation.",[oid(owner,"Admit Source Continuation"),oid(owner,"Compare Continuations")],[rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
ops = [
    operation(owner,"Admit Source Continuation","SourceContinuationCarrier",["SourceObservationScope","OpaqueOrStructuredCoordinate","ContinuationScope","IssueOrObservationTime","EvidenceBundle"],"AdmittedSourceContinuation",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Continuation Is Scope Bound"),lid(owner,"Opaque Means Opaque"),lid(owner,"Continuation Is Not Runtime Checkpoint"),lid(owner,"Aggregate Budget Precharge")],[d["identity"] for d in decs],"Continuation observation/authoring authority; provider semantics remain external",B["identity"],"carrier_bytes + scope_fields + partitions + evidence_refs","Acquisition closure and runtime requirement projection","Emits source continuation requirement; performs no resume.","Scope or token semantics changes require re-admission/new edition."),
    operation(owner,"Evaluate Resume Eligibility","ResumeEligibilityInput",["AdmittedSourceContinuation","CurrentSourceHorizonEvidence","InvalidationEvidence","CurrentAuthorizationEvidence"],"ResumeEligibility",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Eligibility Depends On Current Horizon"),lid(owner,"Gap Is Distinct From Expiry"),lid(owner,"Continuation Is Scope Bound")],[did(owner,"Horizon Policy"),did(owner,"Scope Binding")],"No self-authority; current provider/source and authorization evidence required",B["identity"],"horizon_claims + invalidation_claims + scope_fields","Runtime boot/admission and repair planning","May emit resnapshot or human-adjudication obligation; does not contact source.","Eligibility is time/evidence-scoped and expires."),
    operation(owner,"Compare Continuations","ContinuationComparisonInput",["AdmittedSourceContinuation","AdmittedSourceContinuation","ComparisonEvidence"],"ContinuationComparison",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Comparison Requires Coordinate Space"),lid(owner,"Opaque Means Opaque")],[did(owner,"Coordinate Opacity"),did(owner,"Comparison Posture")],"No additional authority",B["identity"],"coordinate_bytes + scope_fields","Acquisition planner and progress explanation","No runtime effect.","Comparison law version retained in result."),
    operation(owner,"Bind Continuation To Snapshot","SnapshotContinuationBindingInput",["ClosedSourceSnapshot","AdmittedSourceContinuation","FrontierCorrespondenceEvidence","OverlapDecision"],"SnapshotContinuationBinding",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Snapshot Binding Preserves Frontier"),lid(owner,"Continuation Is Scope Bound")],[did(owner,"Scope Binding"),did(owner,"Comparison Posture")],"Snapshot/continuation owner authority and source frontier evidence",B["identity"],"snapshot_frontiers + continuation_scope + evidence_refs","Snapshot-continuation stitching compiler","No runtime effect; emits exact start/overlap obligations.","Binding invalidated by scope, snapshot, or horizon change."),
    operation(owner,"Project Continuation Requirement","ContinuationRequirementProjectionInput",["ContinuationRequirement","ContractHeaderRequirement"],"ProviderNeutralContinuationRequirement",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Continuation Is Scope Bound"),lid(owner,"Eligibility Depends On Current Horizon")],[d["identity"] for d in decs],"Requirement author authority",B["identity"],"requirement_fields + guarantees","CON requirement projection and provider linker","No provider offer authored.","Requirement evolves under CON compatibility."),
    operation(owner,"Qualify Continuation Failure","ContinuationFailureInput",["AdmittedSourceContinuation","SourceFailureObservation","ProviderEvidence"],"QualifiedContinuationFailure",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Gap Is Distinct From Expiry"),lid(owner,"Eligibility Depends On Current Horizon")],[did(owner,"Horizon Policy")],"No self-verification; retain source/provider evidence",B["identity"],"failure_claims + evidence_refs","Diagnostics, repair planner, and operator explanation","No retry; emits typed remediation requirement.","Failure categories may expand only under new edition/unknown handling."),
    operation(owner,"Readmit Continuation","ContinuationReadmissionInput",["SourceContinuationCarrier","PriorAdmittedSourceContinuation","EvolutionEvidence"],"ReadmittedSourceContinuation",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Continuation Is Scope Bound"),lid(owner,"Opaque Means Opaque")],[d["identity"] for d in decs],"Continuation owner authority and evolution evidence",B["identity"],"new_carrier + prior_scope + evidence_refs","Semantic diff and migration planning","No runtime effect.","Same-edition token semantic mutation refused."),
]
sm = state_machine(owner,"ContinuationEligibility",["RAW","SCOPE_BOUND","ELIGIBLE","EXPIRED","INVALIDATED","REFUSED"],["BIND_SCOPE","EVALUATE","EXPIRE","INVALIDATE","REJECT"],{
    ("RAW","BIND_SCOPE"):("SCOPE_BOUND","ContinuationScopeBound"),
    ("SCOPE_BOUND","EVALUATE"):("ELIGIBLE","ContinuationEligible"),
    ("SCOPE_BOUND","EXPIRE"):("EXPIRED","ContinuationExpired"),
    ("ELIGIBLE","EXPIRE"):("EXPIRED","ContinuationExpired"),
    ("SCOPE_BOUND","INVALIDATE"):("INVALIDATED","ContinuationInvalidated"),
    ("ELIGIBLE","INVALIDATE"):("INVALIDATED","ContinuationInvalidated"),
    ("RAW","REJECT"):("REFUSED","ContinuationRefused"),
    ("SCOPE_BOUND","REJECT"):("REFUSED","ContinuationRefused"),
},["EXPIRED","INVALIDATED","REFUSED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,3,11,14,15,16,17,19,20,21,24,27,28,29,30,32,33,43,44,45,47,48,49,50,53,56,60,62,63,64,81,82,83,92,94,95,96,99),
    "hard_data_dependencies":["DAT-SOURCE-OBSERVATION"],
    "semantic_seams":["DAT-SOURCE-SNAPSHOT"],
    "owned":["source continuation identity","coordinate space and opacity","continuation scope binding","resume eligibility","history horizon relation","snapshot frontier binding"],
    "exclusions":["consumer acknowledgement","broker offset ownership","watermark","checkpoint","savepoint","data cut","provider token implementation","source I/O"],
    "terms":[
        term("Source Continuation","A source-qualified token or coordinate that may resume observation within an exact scope.",owner,"VALUE",["resume token","delta token"],["checkpoint","watermark"]),
        term("Continuation Scope","The source, interface, query/options, principal, partition/subscription, and coordinate-space binding.",owner,"VALUE",[],["connection config"]),
        term("Coordinate Space","The domain within which coordinates can be tested for equality or order under an admitted law.",owner,"VALUE",[],["global time"]),
        term("Opaque Token","A continuation whose bytes are replayed unchanged and whose internal semantics are provider-owned.",owner,"VALUE",[],["parseable cursor"]),
        term("Source Horizon","Evidence about the earliest or latest currently resumable source history.",owner,"CLAIM",[],["retention policy"]),
        term("Resume Eligibility","A qualified answer Eligible, Expired, Invalidated, Unauthorized, Incomparable, Gap, Unknown, or Refused.",owner,"ANSWER",[],["token exists"]),
        term("Snapshot Frontier Binding","A relation showing how a continuation overlaps or follows a source snapshot cut.",owner,"RELATION",[],["stitching itself"]),
    ],
    "false_twins":["Source Continuation ≠ Checkpoint","Source Continuation ≠ Savepoint","Source Continuation ≠ Watermark","Source Continuation ≠ Consumer Offset","Opaque token ≠ parseable coordinate","Expired ≠ history gap"],
    "types":[
        type_def("SourceContinuationCarrier","HOSTILE_CARRIER","Bounded untrusted continuation token/coordinate and scope.",owner,carrier=True),
        type_def("AdmittedSourceContinuation","ADMITTED_VALUE","Invariant-protected source continuation.",owner,admitted=True),
        type_def("ContinuationScope","VALUE","Exact source/interface/query/principal/partition/options scope.",owner),
        type_def("OpaqueContinuationToken","VALUE","Opaque bounded bytes retained without semantic parsing.",owner),
        type_def("StructuredSourceCoordinate","VALUE","Source-profile coordinate admitted under external comparison laws.",owner),
        type_def("ResumeEligibility","ANSWER","Qualified resume eligibility and remediation posture.",owner),
        type_def("SnapshotContinuationBinding","RELATION","Typed snapshot frontier and continuation overlap binding.",owner),
        type_def("QualifiedContinuationFailure","FINDING","Typed continuation failure preserving provider/source evidence.",owner),
    ],
    "decisions":decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-DEBEZIUM-POSTGRES-STABLE","SRC-MS-GRAPH-DELTA","SRC-MONGODB-CHANGE-STREAMS","SRC-POSTGRES-18-LOGICAL-REPLICATION","SRC-FLINK-CHECKPOINTING"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-CONTINUATION-SCOPE","title":"Continuation Scope and Coordinate","classification":"CORE","question":"What exact scope and coordinate space make this continuation meaningful?"},
        {"identity":"SUBDOMAIN-DAT-CONTINUATION-HORIZON","title":"Eligibility, Horizon and Invalidation","classification":"CORE","question":"Can observation resume now, and why not if it cannot?"},
        {"identity":"SUBDOMAIN-DAT-CONTINUATION-SNAPSHOT-BINDING","title":"Snapshot Frontier Binding","classification":"SUPPORTING","question":"How does continuation start relate to the source snapshot frontier?"},
    ],
}

# ---------------------------------------------------------------------------
# DAT-SOURCE-CHANGE-STREAM
# ---------------------------------------------------------------------------
owner = "DAT-SOURCE-CHANGE-STREAM"
refs = common_refusals(owner) + [
    refusal(owner,"CHANGE-KIND-UNSUPPORTED","The source change kind is unknown or unsupported under the admitted change profile.",["admit_change_record"],35),
    refusal(owner,"TRANSACTION-VISIBILITY-UNKNOWN","The source does not establish transaction grouping, commit visibility, or atomicity required by the consumer.",["admit_change_record","qualify_transaction_group"],40),
    refusal(owner,"DELETE-IDENTITY-INSUFFICIENT","A delete or tombstone cannot identify the affected source subject under the required key posture.",["admit_change_record"],30),
    refusal(owner,"ORDER-SCOPE-VIOLATED","A record order or predecessor relation violates the admitted source order scope.",["admit_change_record","validate_change_sequence"],35),
    refusal(owner,"CONFLICTING-DUPLICATE","Two records share one observation identity or coordinate but carry incompatible source-change content.",["deduplicate_change_records"],40),
    refusal(owner,"STRUCTURAL-CHANGE-INVISIBLE","A consumer requires source structural-change visibility that the source/profile cannot establish.",["qualify_structure_change_visibility"],45),
    refusal(owner,"CHANGE-HISTORY-GAP","The change stream cannot establish continuity over the required source interval.",["validate_change_sequence"],45),
]
B = budget(owner, 33_554_432, 1_000_000, 96, 67_108_864, max_state_items=1_000_000, max_iterations=64)
decs = [
    decision(owner,"Change Mode","SourceChangeMode","AUTHORING","ABSENT_IS_INVALID","Changing append/upsert/retract/replace semantics is breaking.",[oid(owner,"Admit Change Record"),oid(owner,"Normalize Change Batch")],"Source profile, connector conformance, and consumer requirement."),
    decision(owner,"Transaction Visibility","TransactionVisibilityPosture","AUTHORING","ABSENT_MEANS_UNKNOWN","Weakening visibility may invalidate batch atomicity and stitching.",[oid(owner,"Qualify Transaction Group"),oid(owner,"Validate Change Sequence")],"Source transaction/log evidence."),
    decision(owner,"Delete Representation","DeleteRepresentationPosture","AUTHORING","ABSENT_MEANS_DELETES_NOT_PROVEN","Changing key/tombstone posture affects reconstructibility.",[oid(owner,"Admit Change Record")],"Replication identity/key evidence."),
    decision(owner,"Order Scope","SourceOrderScope","AUTHORING","ABSENT_MEANS_UNORDERED","Claiming stronger order requires conformance evidence.",[oid(owner,"Validate Change Sequence")],"Source protocol order law and partition scope."),
    decision(owner,"Duplicate Identity","ChangeDuplicateIdentity","AUTHORING","ABSENT_IS_INVALID","Changing dedup identity may alter exactly-once reconstruction.",[oid(owner,"Deduplicate Change Records")],"Source record identity/coordinate evidence."),
    decision(owner,"Structure Change Visibility","StructureChangeVisibilityPosture","AUTHORING","ABSENT_MEANS_UNKNOWN","Changing visibility affects schema-evolution safety.",[oid(owner,"Qualify Structure Change Visibility")],"Source/connector documentation and observed conformance."),
]
laws = [
    law(owner,"Change Record Is Source Observation","A source change record describes a source mutation observation; it is not an application domain event, journal fact, authorized decision, or business command.",[oid(owner,"Admit Change Record")],[rid(owner,"SOURCE-CLAIM-ELEVATION") if owner=="DAT-SOURCE-OBSERVATION" else rid(owner,"CHANGE-KIND-UNSUPPORTED")]),
    law(owner,"Change Kind Is Explicit","Insert, update, replace, delete, truncate, patch, schema signal, heartbeat, unknown, and provider-specific kinds remain distinct or are explicitly mapped with loss.",[oid(owner,"Admit Change Record"),oid(owner,"Normalize Change Batch")],[rid(owner,"CHANGE-KIND-UNSUPPORTED")]),
    law(owner,"Transaction Visibility Is Qualified","Transaction identity, commit status, grouping, order, atomic delivery, and partial visibility are explicit; a message batch is not assumed to equal a source transaction.",[oid(owner,"Qualify Transaction Group"),oid(owner,"Validate Change Sequence")],[rid(owner,"TRANSACTION-VISIBILITY-UNKNOWN")]),
    law(owner,"Delete Must Identify Subject","A delete, tombstone, truncate, TTL removal, or soft-delete observation names the affected subject/key scope or explicitly refuses reconstructibility.",[oid(owner,"Admit Change Record")],[rid(owner,"DELETE-IDENTITY-INSUFFICIENT")]),
    law(owner,"Before And After Are Not Assumed","Before image, after image, changed-fields set, generated values, and unchanged values are independently qualified.",[oid(owner,"Admit Change Record")],[rid(owner,"UNKNOWN-OR-INCOMPLETE")]),
    law(owner,"Order Is Scoped","Ordering claims apply only to admitted transaction, partition, key, source coordinate, or global scopes; no stronger total order is invented.",[oid(owner,"Validate Change Sequence")],[rid(owner,"ORDER-SCOPE-VIOLATED")]),
    law(owner,"Duplicate And Conflict Differ","A byte/semantic duplicate may be suppressed under an admitted identity rule; incompatible records with the same identity are conflicts and must refuse.",[oid(owner,"Deduplicate Change Records")],[rid(owner,"CONFLICTING-DUPLICATE")]),
    law(owner,"Structural Visibility Is Not Guaranteed","Absence of a DDL or metadata event does not prove source structure stability; the stream publishes an exact visibility posture.",[oid(owner,"Qualify Structure Change Visibility")],[rid(owner,"STRUCTURAL-CHANGE-INVISIBLE")]),
    law(owner,"Continuity Is Evidenced","A valid continuation and accepted record sequence do not prove the absence of a source-history gap unless predecessor, horizon, and scope evidence discharge it.",[oid(owner,"Validate Change Sequence")],[rid(owner,"CHANGE-HISTORY-GAP")]),
    law(owner,"Aggregate Budget Precharge","Records, images, fields, transaction members, dedup candidates, conflict pairs, evidence, and diagnostics are aggregate-precharged before allocation.",[oid(owner,"Admit Change Record"),oid(owner,"Normalize Change Batch"),oid(owner,"Deduplicate Change Records")],[rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
# Add a dedicated generic elevation refusal for this owner.
refs.append(refusal(owner,"BUSINESS-EVENT-ELEVATION","A source mutation observation was presented as an authoritative application event or fact.",["admit_change_record","project_committed_fact_requirement"],20))
# Repair first law refusal to use correct ID.
laws[0]["refusal_on_violation"] = [rid(owner,"BUSINESS-EVENT-ELEVATION")]
ops = [
    operation(owner,"Admit Change Record","ChangeRecordCarrier",["AdmittedSourceContinuation","SourceObservationScope","ChangeIdentity","ChangeKind","SubjectKey","BeforeAfterPayload","SourceCoordinate","TransactionClaim","EvidenceBundle"],"AdmittedSourceChangeRecord",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Change Record Is Source Observation"),lid(owner,"Change Kind Is Explicit"),lid(owner,"Delete Must Identify Subject"),lid(owner,"Before And After Are Not Assumed"),lid(owner,"Aggregate Budget Precharge")],[d["identity"] for d in decs],"Source change-observation authority; business authority is explicitly absent",B["identity"],"carrier_bytes + image_fields + evidence_refs","Change-stream admission and stitching compiler","Consumes provider/runtime receipts as values; performs no stream read.","Provider change-kind evolution requires mapping review/new edition."),
    operation(owner,"Qualify Transaction Group","TransactionGroupInput",["AdmittedSourceChangeRecordSet","TransactionEvidence","CommitVisibilityEvidence"],"QualifiedTransactionGroup",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Transaction Visibility Is Qualified"),lid(owner,"Order Is Scoped")],[did(owner,"Transaction Visibility"),did(owner,"Order Scope")],"No self-authority; source/provider transaction evidence required",B["identity"],"records + transaction_claims + evidence_refs","Stitching transaction preservation and batch atomicity analysis","May emit runtime buffering/commit obligations; no transaction execution.","Transaction profile changes invalidate prior grouping assumptions."),
    operation(owner,"Validate Change Sequence","ChangeSequenceInput",["AdmittedSourceContinuation","AdmittedSourceChangeRecordSet","OrderEvidence","HorizonEvidence"],"ChangeSequenceValidation",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Order Is Scoped"),lid(owner,"Continuity Is Evidenced")],[did(owner,"Order Scope"),did(owner,"Transaction Visibility")],"No additional authority; retain source/provider evidence",B["identity"],"records + predecessor_checks + partitions + evidence_refs","Stitching precondition and recovery planner","Emits continuity/runtime obligations; no stream consumption.","Order profile or source horizon changes require revalidation."),
    operation(owner,"Deduplicate Change Records","ChangeDeduplicationInput",["AdmittedSourceChangeRecordSet","DuplicateIdentityProfile"],"DeduplicatedChangeRecords",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Duplicate And Conflict Differ"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"Duplicate Identity")],"No additional authority",B["identity"],"records + candidate_hashes + conflict_pairs","Stitching and incremental computation compiler","No runtime effect; runtime may implement selected idempotency requirement.","Changing duplicate identity is breaking for replay equivalence."),
    operation(owner,"Normalize Change Batch","ChangeBatchNormalizationInput",["AdmittedSourceChangeRecordSet","ChangeModeMapping","SemanticLossProfile"],"NormalizedChangeBatch",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Change Kind Is Explicit"),lid(owner,"Before And After Are Not Assumed"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"Change Mode")],"Mapping owner authority; no business enrichment authority",B["identity"],"records + field_mappings + images","Portable change-program compilation","No I/O; emits transformation and loss obligations.","Mapping changes require replay/migration analysis."),
    operation(owner,"Qualify Structure Change Visibility","StructureChangeVisibilityInput",["ChangeStreamProfile","ObservedStructureSignals","SourceCapabilityEvidence"],"QualifiedStructureChangeVisibility",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Structural Visibility Is Not Guaranteed")],[did(owner,"Structure Change Visibility")],"Source/profile evidence authority",B["identity"],"signal_types + evidence_refs","Schema-evolution admission and diagnostics","May emit external schema-introspection obligation.","Visibility evidence expires and is version-specific."),
    operation(owner,"Project Change Stream Requirement","ChangeStreamRequirementInput",["ChangeStreamRequirement","ContractHeaderRequirement"],"ProviderNeutralChangeStreamRequirement",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Change Kind Is Explicit"),lid(owner,"Transaction Visibility Is Qualified"),lid(owner,"Continuity Is Evidenced")],[d["identity"] for d in decs],"Requirement author authority",B["identity"],"requirement_fields + guarantee_vector","CON requirement projection and provider linker","No provider offer authored.","Requirement evolves under CON compatibility."),
    operation(owner,"Project Committed Fact Requirement","ChangeToFactBoundaryInput",["AdmittedSourceChangeRecord","ApplicationFactBoundaryRef"],"CommittedFactAdmissionRequirement",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Change Record Is Source Observation")],[],"Application ontology/kernel authority",B["identity"],"record_refs + boundary_refs","Host Role Composition and application linker","Any authoritative mutation must re-enter Host Role Composition → Kernel.","Boundary changes block direct source-to-business promotion."),
    operation(owner,"Compare Change Profiles","ChangeProfileComparisonInput",["ChangeStreamProfile","ChangeStreamProfile"],"ChangeProfileDelta",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Change Kind Is Explicit"),lid(owner,"Transaction Visibility Is Qualified"),lid(owner,"Delete Must Identify Subject")],[d["identity"] for d in decs],"No additional authority",B["identity"],"left_profile + right_profile","Semantic diff, provider replacement, replay planning","No runtime effect.","Produces compatibility, replay, and data-loss consequences."),
]
sm = state_machine(owner,"SourceChangeStreamLifecycle",["DECLARED","ACTIVE","INTERRUPTED","EXHAUSTED","INVALIDATED","RETIRED"],["ACTIVATE","OBSERVE_RECORD","INTERRUPT","EXHAUST","INVALIDATE","RETIRE"],{
    ("DECLARED","ACTIVATE"):("ACTIVE","ChangeStreamActivated"),
    ("ACTIVE","OBSERVE_RECORD"):("ACTIVE","SourceChangeObserved"),
    ("ACTIVE","INTERRUPT"):("INTERRUPTED","ChangeStreamInterrupted"),
    ("INTERRUPTED","ACTIVATE"):("ACTIVE","ChangeStreamResumed"),
    ("ACTIVE","EXHAUST"):("EXHAUSTED","ChangeStreamHorizonExhausted"),
    ("INTERRUPTED","EXHAUST"):("EXHAUSTED","ChangeStreamHorizonExhausted"),
    ("ACTIVE","INVALIDATE"):("INVALIDATED","ChangeStreamInvalidated"),
    ("INTERRUPTED","INVALIDATE"):("INVALIDATED","ChangeStreamInvalidated"),
    ("DECLARED","RETIRE"):("RETIRED","ChangeStreamRetired"),
    ("ACTIVE","RETIRE"):("RETIRED","ChangeStreamRetired"),
    ("INTERRUPTED","RETIRE"):("RETIRED","ChangeStreamRetired"),
},["EXHAUSTED","INVALIDATED","RETIRED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,3,11,14,15,16,17,19,20,21,24,25,26,27,28,29,30,31,32,35,43,44,45,47,48,49,50,60,81,82,83,85,89,92,94,95,96,99),
    "hard_data_dependencies":["DAT-SOURCE-OBSERVATION","DAT-SOURCE-CONTINUATION"],
    "owned":["source change record semantics","source transaction-visibility posture","delete/before/after qualification","source order scope","duplicate/conflict distinction","change-stream continuity claim"],
    "exclusions":["application event","Journal fact","message broker implementation","connector loop","checkpoint implementation","generic Causality","Schema","business identity resolution"],
    "terms":[
        term("Source Change Record","A source-qualified observation of one mutation or protocol signal after a continuation.",owner,"OBSERVATION",["CDC record"],["domain event"]),
        term("Change Kind","The source-qualified mutation species: insert, update, replace, delete, truncate, patch, structure signal, heartbeat, unknown, or profile extension.",owner,"CLASSIFICATION",[],["business command"]),
        term("Transaction Group","A qualified grouping of change records believed to share source transaction/commit visibility.",owner,"CLAIM",[],["message batch"]),
        term("Before/After Profile","Which prior, resulting, changed, generated, unchanged, and omitted values the source makes visible.",owner,"VALUE",[],["full row image assumed"]),
        term("Source Order Scope","The exact transaction, partition, key, source coordinate, or global scope for an ordering claim.",owner,"VALUE",[],["global causal order"]),
        term("Change Duplicate Identity","The admitted source-level identity used to distinguish retry duplicate from distinct occurrence.",owner,"DECISION",[],["business entity key"]),
        term("Change History Gap","A source interval that cannot be proven covered by admitted changes.",owner,"FINDING",[],["connector stopped"]),
        term("Structure Change Visibility","A qualified statement of which DDL, metadata, custom-field, or schema signals the change source can expose.",owner,"CLAIM",[],["Schema compatibility"]),
    ],
    "false_twins":["Source Change Record ≠ Domain Event","Message batch ≠ source transaction","Broker offset ≠ source continuation","Delete notification ≠ erasure proof","Per-partition order ≠ global order","Duplicate ≠ conflicting duplicate","No DDL event ≠ no schema change"],
    "types":[
        type_def("ChangeRecordCarrier","HOSTILE_CARRIER","Bounded untrusted source change record.",owner,carrier=True),
        type_def("AdmittedSourceChangeRecord","ADMITTED_OBSERVATION","Invariant-protected source change observation.",owner,admitted=True),
        type_def("SourceChangeKind","OPEN_PROFILE_ENUM","Closed core plus source-profile extension with Unknown preservation.",owner),
        type_def("BeforeAfterPayload","VALUE","Qualified before, after, changed-field, generated-field, and omission posture.",owner),
        type_def("QualifiedTransactionGroup","CLAIM","Transaction grouping and commit-visibility claim retaining evidence.",owner),
        type_def("ChangeSequenceValidation","EVIDENCE_RESULT","Scoped order and continuity validation result.",owner),
        type_def("NormalizedChangeBatch","VALUE","Provider-neutral change representation retaining mapping loss and source identity.",owner),
        type_def("ChangeProfileDelta","SEMANTIC_DELTA","Compatibility and replay-impact delta between source change profiles.",owner),
    ],
    "decisions":decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-POSTGRES-18-LOGICAL-REPLICATION","SRC-DEBEZIUM-POSTGRES-STABLE","SRC-MS-GRAPH-DELTA","SRC-MONGODB-CHANGE-STREAMS","SRC-AWS-S3-EVENT-NOTIFICATIONS"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-CHANGE-STREAM-RECORD","title":"Change Record and Images","classification":"CORE","question":"What mutation did the source expose and which values are visible?"},
        {"identity":"SUBDOMAIN-DAT-CHANGE-STREAM-TRANSACTION","title":"Transaction and Order Scope","classification":"CORE","question":"Which changes belong together and in what scope are they ordered?"},
        {"identity":"SUBDOMAIN-DAT-CHANGE-STREAM-CONTINUITY","title":"Continuity, Duplicates and Gaps","classification":"CORE","question":"Can the record sequence cover the required history without conflict or omission?"},
        {"identity":"SUBDOMAIN-DAT-CHANGE-STREAM-STRUCTURE","title":"Structural Change Visibility","classification":"SUPPORTING","question":"Which source structural changes can or cannot be observed?"},
    ],
}

# ---------------------------------------------------------------------------
# DAT-SNAPSHOT-CONTINUATION-STITCHING
# ---------------------------------------------------------------------------
owner = "DAT-SNAPSHOT-CONTINUATION-STITCHING"
refs = common_refusals(owner) + [
    refusal(owner,"INPUT-SCOPE-MISMATCH","Snapshot, continuation, or changes differ in source, principal, selection, schema interpretation, key, or mapping scope.",["prepare_stitch_plan","execute_stitch_semantics"],20),
    refusal(owner,"UNOBSERVED-INTERVAL","The continuation starts after a source interval not covered by the snapshot or admitted overlap.",["prepare_stitch_plan","verify_stitched_history"],25),
    refusal(owner,"OVERLAP-POLICY-UNDEFINED","Snapshot/stream overlap exists without a deterministic inclusion, exclusion, or deduplication rule.",["prepare_stitch_plan"],30),
    refusal(owner,"CONFLICTING-DUPLICATE","Two observations sharing the admitted duplicate identity differ semantically.",["execute_stitch_semantics"],35),
    refusal(owner,"ORDER-REGRESSION","A change record regresses under the admitted source order/predecessor relation.",["execute_stitch_semantics"],35),
    refusal(owner,"TRANSACTION-SPLIT","The stitching result would expose or apply only part of a source transaction required to remain atomic.",["execute_stitch_semantics","verify_stitched_history"],40),
    refusal(owner,"KEY-OR-DELETE-INSUFFICIENT","Updates/deletes cannot be applied to snapshot state under the admitted key and delete posture.",["execute_stitch_semantics"],40),
    refusal(owner,"SEMANTIC-EDITION-MISMATCH","Snapshot and changes were interpreted under incompatible Schema, mapping, identity, or change-mode editions without migration.",["prepare_stitch_plan"],30),
    refusal(owner,"STITCH-PROOF-INCOMPLETE","No complete proof can be produced for omission, duplicate, scope, transaction, and final frontier obligations.",["verify_stitched_history"],45),
]
B = budget(owner, 134_217_728, 4_000_000, 128, 268_435_456, max_state_items=4_000_000, max_iterations=128)
decs = [
    decision(owner,"Overlap Policy","SnapshotStreamOverlapPolicy","AUTHORING","ABSENT_IS_INVALID","Changing inclusion/exclusion at the frontier changes reconstructed history and is breaking.",[oid(owner,"Prepare Stitch Plan"),oid(owner,"Execute Stitch Semantics")],"Source snapshot/continuation frontier evidence."),
    decision(owner,"Duplicate Identity","StitchDuplicateIdentity","AUTHORING","ABSENT_IS_INVALID","Changing identity may create omission or double application.",[oid(owner,"Execute Stitch Semantics")],"Source record identity, coordinate, and key evidence."),
    decision(owner,"Transaction Preservation","TransactionPreservationPosture","AUTHORING","ABSENT_MEANS_PRESERVE_REQUIRED","Weakening atomicity requires explicit consumer approval and disclosure.",[oid(owner,"Prepare Stitch Plan"),oid(owner,"Verify Stitched History")],"Source transaction visibility and consumer requirement."),
    decision(owner,"State Application Mode","StitchStateApplicationMode","AUTHORING","ABSENT_IS_INVALID","Append, upsert, retract, replace, and patch modes are not interchangeable.",[oid(owner,"Execute Stitch Semantics")],"Admitted changelog/change-mode contract."),
    decision(owner,"Final Frontier Policy","StitchFinalFrontierPolicy","AUTHORING","ABSENT_MEANS_LATEST_VALIDATED_CHANGE","Changing final frontier changes output cut identity.",[oid(owner,"Finalize Stitched Cut")],"Validated change sequence and completeness evidence."),
    decision(owner,"Semantic Migration Policy","StitchSemanticMigrationPolicy","AUTHORING","ABSENT_MEANS_REFUSE_INCOMPATIBLE_EDITIONS","A migration may change history and requires proof/replay evidence.",[oid(owner,"Prepare Stitch Plan"),oid(owner,"Migrate Stitch Inputs")],"SEM Schema/mapping/identity evolution evidence."),
]
laws = [
    law(owner,"No Omission","Every source member visible in the qualified snapshot and every required source change after the snapshot frontier appears in the stitched history exactly according to the admitted change semantics.",[oid(owner,"Execute Stitch Semantics"),oid(owner,"Verify Stitched History")],[rid(owner,"UNOBSERVED-INTERVAL"),rid(owner,"STITCH-PROOF-INCOMPLETE")]),
    law(owner,"No Double Application","No source mutation or snapshot member is applied twice under the admitted duplicate identity and overlap policy.",[oid(owner,"Execute Stitch Semantics"),oid(owner,"Verify Stitched History")],[rid(owner,"CONFLICTING-DUPLICATE"),rid(owner,"STITCH-PROOF-INCOMPLETE")]),
    law(owner,"Scopes Must Match","Snapshot, continuation, change records, source subject/key, principal, selection, source structure, semantic mapping, and relevant editions match or are connected by an admitted migration.",[oid(owner,"Prepare Stitch Plan"),oid(owner,"Migrate Stitch Inputs")],[rid(owner,"INPUT-SCOPE-MISMATCH"),rid(owner,"SEMANTIC-EDITION-MISMATCH")]),
    law(owner,"Overlap Is Deterministic","The snapshot/stream frontier and overlap range have one deterministic inclusion/exclusion/deduplication rule that is invariant under batching and retry.",[oid(owner,"Prepare Stitch Plan"),oid(owner,"Execute Stitch Semantics")],[rid(owner,"OVERLAP-POLICY-UNDEFINED")]),
    law(owner,"Source Order Is Respected","Changes are applied only under an admitted order or predecessor relation and regressions are refused rather than silently sorted across incomparable coordinates.",[oid(owner,"Execute Stitch Semantics")],[rid(owner,"ORDER-REGRESSION")]),
    law(owner,"Transactions Are Preserved Or Weakened Explicitly","Source transactions required to be atomic are applied as complete groups; any weaker behavior is a named guarantee weakening with consumer authority and disclosure.",[oid(owner,"Execute Stitch Semantics"),oid(owner,"Verify Stitched History")],[rid(owner,"TRANSACTION-SPLIT")]),
    law(owner,"Delete And Update Are Reconstructible","Every state-changing update/delete has sufficient subject identity and before/after/change-mode information for the selected state application mode or stitching refuses.",[oid(owner,"Execute Stitch Semantics")],[rid(owner,"KEY-OR-DELETE-INSUFFICIENT")]),
    law(owner,"Batching And Replay Equivalence","For equal admitted inputs and decisions, any lawful batching, restart, or replay partition yields an equivalent stitched history and proof.",[oid(owner,"Execute Stitch Semantics"),oid(owner,"Replay Stitch Plan"),oid(owner,"Verify Stitched History")],[rid(owner,"STITCH-PROOF-INCOMPLETE")]),
    law(owner,"Proof Precedes Cut Publication","A stitched output is not admitted as a data cut until scope, gap, duplicate, order, transaction, semantic-edition, and completeness obligations are discharged.",[oid(owner,"Verify Stitched History"),oid(owner,"Finalize Stitched Cut")],[rid(owner,"STITCH-PROOF-INCOMPLETE")]),
    law(owner,"Aggregate Budget Precharge","Snapshot members, change records, state items, transaction groups, dedup candidates, evidence, proof nodes, and diagnostics are aggregate-precharged before state allocation.",[oid(owner,"Execute Stitch Semantics"),oid(owner,"Replay Stitch Plan")],[rid(owner,"BUDGET-EXHAUSTED"),rid(owner,"BUDGET-ARITHMETIC-OVERFLOW")]),
]
ops = [
    operation(owner,"Prepare Stitch Plan","StitchPlanCarrier",["ClosedSourceSnapshot","AdmittedSourceContinuation","ChangeStreamProfile","SnapshotContinuationBinding","StitchDecisions","SemanticEditionSet","EvidenceBundle"],"AdmittedStitchPlan",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Scopes Must Match"),lid(owner,"Overlap Is Deterministic"),lid(owner,"Transactions Are Preserved Or Weakened Explicitly")],[d["identity"] for d in decs],"Stitch plan owner plus source/snapshot/continuation evidence",B["identity"],"snapshot_segments + change_profile_fields + evidence_refs","Application compilation, obligation closure, runtime plan generation","Emits provider-neutral acquisition/state requirements; performs no data processing.","Any input semantic edition change requires re-planning."),
    operation(owner,"Execute Stitch Semantics","StitchExecutionInput",["AdmittedStitchPlan","ClosedSourceSnapshot","DeduplicatedChangeRecords","QualifiedTransactionGroups","ChangeSequenceValidation"],"StitchedHistory",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"No Omission"),lid(owner,"No Double Application"),lid(owner,"Overlap Is Deterministic"),lid(owner,"Source Order Is Respected"),lid(owner,"Transactions Are Preserved Or Weakened Explicitly"),lid(owner,"Delete And Update Are Reconstructible"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"Overlap Policy"),did(owner,"Duplicate Identity"),did(owner,"Transaction Preservation"),did(owner,"State Application Mode")],"No new authority; consumes admitted evidence and decisions",B["identity"],"snapshot_members + changes + state_items + transaction_members + dedup_candidates","Reference semantics, conformance, and target plan validation","Pure reference operation; runtime engine must demonstrate equivalent behavior.","Logic edition is pinned; changes require replay/migration analysis."),
    operation(owner,"Verify Stitched History","StitchVerificationInput",["AdmittedStitchPlan","StitchedHistory","SnapshotEvidence","ContinuationEvidence","ChangeEvidence","CompletenessEvidence"],"StitchProofCandidate",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"No Omission"),lid(owner,"No Double Application"),lid(owner,"Transactions Are Preserved Or Weakened Explicitly"),lid(owner,"Batching And Replay Equivalence"),lid(owner,"Proof Precedes Cut Publication")],[did(owner,"Final Frontier Policy"),did(owner,"Transaction Preservation")],"Independent verifier or admitted proof evidence; semantic owner cannot self-certify",B["identity"],"history_items + proof_nodes + evidence_refs","Publication gate, assurance case, and cut admission","No publication effect; produces proof candidate only.","Proof is bound to plan, input cuts, logic edition, and evidence validity."),
    operation(owner,"Finalize Stitched Cut","StitchedCutInput",["StitchedHistory","StitchProofCandidate","CollectionRef","FinalFrontier"],"AdmittedDataCutCandidate",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Proof Precedes Cut Publication"),lid(owner,"No Omission"),lid(owner,"No Double Application")],[did(owner,"Final Frontier Policy")],"Data cut publisher plus independent proof authority",B["identity"],"history_manifest + proof_nodes","DAT-DATA-CUT admission and analytical publication planning","Does not publish; submits a hostile/admitted candidate to DAT-DATA-CUT.","A later frontier creates a new cut."),
    operation(owner,"Replay Stitch Plan","StitchReplayInput",["AdmittedStitchPlan","ClosedSourceSnapshot","DeduplicatedChangeRecords","ReplayPartitioning"],"StitchReplayResult",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Batching And Replay Equivalence"),lid(owner,"Aggregate Budget Precharge")],[did(owner,"State Application Mode"),did(owner,"Duplicate Identity")],"No additional authority",B["identity"],"snapshot_members + changes + replay_partitions + state_items","Migration/recovery planner and conformance harness","No I/O; runtime replay must conform.","Replay under changed logic is reproduction/restatement, not equivalent replay."),
    operation(owner,"Migrate Stitch Inputs","StitchMigrationInput",["AdmittedStitchPlan","SnapshotMigrationEvidence","ChangeMappingMigrationEvidence","TargetSemanticEditionSet"],"MigratedStitchInputs",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Scopes Must Match"),lid(owner,"Batching And Replay Equivalence")],[did(owner,"Semantic Migration Policy")],"Schema/mapping owners and migration authority",B["identity"],"input_items + mapping_rules + evidence_refs","Semantic diff and migration planner","No runtime migration; emits typed rebuild/replay obligations.","Historical interpretation retains original and migrated editions."),
    operation(owner,"Compare Stitch Plans","StitchPlanComparisonInput",["AdmittedStitchPlan","AdmittedStitchPlan"],"StitchPlanDelta",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Scopes Must Match"),lid(owner,"Overlap Is Deterministic"),lid(owner,"Transactions Are Preserved Or Weakened Explicitly")],[d["identity"] for d in decs],"No additional authority",B["identity"],"left_plan + right_plan","Semantic diff, provider replacement, and migration planning","No runtime effect.","Produces compatibility/rebuild/recertification consequences."),
    operation(owner,"Explain Stitch Refusal","StitchRefusalExplanationInput",["AdmittedStitchPlan","StitchRefusal","DisclosureContext"],"BoundedStitchExplanation",f"{camel(owner.replace('DAT-',''))}Refusal",[lid(owner,"Proof Precedes Cut Publication")],[],"Disclosure authority imported from Authorization/Classification",B["identity"],"refusal_fields + evidence_refs + max_diagnostics","Compiler/operator explanation","No effect; output is bounded and redacted.","Diagnostic wording may evolve without changing refusal identity."),
]
sm = state_machine(owner,"StitchLifecycle",["PREPARED","APPLYING","COMPLETE","VERIFIED","REFUSED"],["START","APPLY_BATCH","COMPLETE","VERIFY","REJECT"],{
    ("PREPARED","START"):("APPLYING","StitchStarted"),
    ("APPLYING","APPLY_BATCH"):("APPLYING","StitchBatchApplied"),
    ("APPLYING","COMPLETE"):("COMPLETE","StitchCompleted"),
    ("COMPLETE","VERIFY"):("VERIFIED","StitchVerified"),
    ("PREPARED","REJECT"):("REFUSED","StitchRefused"),
    ("APPLYING","REJECT"):("REFUSED","StitchRefused"),
    ("COMPLETE","REJECT"):("REFUSED","StitchRefused"),
},["VERIFIED","REFUSED"])
LIB_DEFS[owner] = {
    "imports": common_imports(1,2,3,11,14,15,16,17,19,20,21,24,25,26,27,28,29,30,31,32,35,36,43,44,45,47,48,49,50,60,81,82,83,85,89,90,91,92,94,95,96,99),
    "hard_data_dependencies":["DAT-DATA-CUT","DAT-SOURCE-SNAPSHOT","DAT-SOURCE-CONTINUATION","DAT-SOURCE-CHANGE-STREAM"],
    "owned":["snapshot/continuation overlap semantics","gap-free reconstruction law","duplicate/conflict handling","transaction-preserving stitching","pure reference stitching semantics","stitch proof obligations"],
    "exclusions":["connector execution","checkpoint storage","source I/O","provider implementation","application fact mutation","generic migration execution","Data Cut admission authority","Schema meaning"],
    "terms":[
        term("Stitch Plan","An admitted provider-neutral plan binding one snapshot, continuation, change profile, overlap, duplicate, transaction, state-application, and semantic-edition posture.",owner,"PLAN",[],["runtime job"]),
        term("Snapshot–Stream Overlap","The source interval represented both by snapshot observations and later change observations.",owner,"VALUE",[],["history gap"]),
        term("Overlap Policy","A deterministic inclusion/exclusion/deduplication rule for the overlap interval.",owner,"DECISION",[],["best effort"]),
        term("Stitched History","The reconstructed collection history produced by pure application of admitted snapshot and changes.",owner,"VALUE",[],["application Journal"]),
        term("Stitch Proof Candidate","A non-self-certifying proof structure covering scope, gap, duplicate, order, transactions, semantics, completeness, and replay equivalence.",owner,"PROOF_CANDIDATE",[],["certification"]),
        term("Final Frontier","The last validated source coordinate/time scope included in a stitched output candidate.",owner,"VALUE",[],["watermark"]),
        term("Stitch Gap","An interval or required mutation that cannot be proved represented exactly once.",owner,"FINDING",[],["late data"]),
        term("State Application Mode","How append, upsert, retract, replace, patch, delete, or truncate changes alter reconstructed state.",owner,"DECISION",[],["storage merge mode"]),
    ],
    "false_twins":["Stitched History ≠ application Journal","Overlap ≠ gap","Duplicate ≠ conflicting duplicate","Source coordinate ≠ event time","Replay under same logic ≠ restatement under new logic","Proof candidate ≠ certification","Final frontier ≠ watermark"],
    "types":[
        type_def("StitchPlanCarrier","HOSTILE_CARRIER","Bounded untrusted snapshot-continuation stitching declaration.",owner,carrier=True),
        type_def("AdmittedStitchPlan","ADMITTED_PLAN","Invariant-protected provider-neutral stitch plan.",owner,admitted=True),
        type_def("SnapshotStreamOverlapPolicy","CLOSED_ENUM","SnapshotWins, ChangeWins, CoordinateDedup, KeyStateReconcile, ExplicitNoOverlap, or Refuse.",owner),
        type_def("StitchedHistory","ADMITTED_VALUE","Pure reconstructed history with source coordinates and derivation references.",owner,admitted=True),
        type_def("StitchProofCandidate","PROOF_CANDIDATE","Private non-deserializable proof candidate requiring independent appraisal.",owner,admitted=True),
        type_def("StitchReplayResult","EVIDENCE_RESULT","Replay-equivalence result tied to plan and partitioning.",owner),
        type_def("StitchPlanDelta","SEMANTIC_DELTA","Typed difference and compatibility/rebuild consequences between plans.",owner),
        type_def("BoundedStitchExplanation","ANSWER","Disclosure-safe bounded explanation of a stitch outcome or refusal.",owner),
    ],
    "decisions":decs,"laws":laws,"operations":ops,"refusals":refs,"budget":B,"state_machine":sm,
    "source_ids":["SRC-POSTGRES-18-LOGICAL-REPLICATION","SRC-DEBEZIUM-POSTGRES-STABLE","SRC-MS-GRAPH-DELTA","SRC-MONGODB-CHANGE-STREAMS","SRC-FLINK-CHECKPOINTING"],
    "subdomains":[
        {"identity":"SUBDOMAIN-DAT-STITCH-BOUNDARY","title":"Snapshot and Continuation Boundary","classification":"CORE","question":"Where do snapshot coverage and change coverage meet or overlap?"},
        {"identity":"SUBDOMAIN-DAT-STITCH-APPLICATION","title":"State Reconstruction","classification":"CORE","question":"How are source changes applied exactly once under keys, order, and transaction semantics?"},
        {"identity":"SUBDOMAIN-DAT-STITCH-PROOF","title":"Stitch Proof and Replay Equivalence","classification":"CORE","question":"What evidence establishes no omission, no double application, and replay equivalence?"},
        {"identity":"SUBDOMAIN-DAT-STITCH-EVOLUTION","title":"Semantic Migration","classification":"SUPPORTING","question":"How may snapshot and changes from different semantic editions be migrated without historical laundering?"},
    ],
}

assert set(FIRST_BATCH_IDS) == set(LIB_DEFS), (FIRST_BATCH_IDS, list(LIB_DEFS))


def normalize_title(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def map_data_target(title: str) -> tuple[str | None, str]:
    t = normalize_title(title)
    patterns: list[tuple[list[str], str, str]] = [
        (["snapshot continuation", "snapshot incremental handoff", "snapshot log stitching"], "DAT-SNAPSHOT-CONTINUATION-STITCHING", "The meaning belongs to the gap-free snapshot/change composition owner."),
        (["source snapshot", "full snapshot capture", "snapshot acquisition"], "DAT-SOURCE-SNAPSHOT", "The meaning belongs to source-qualified finite snapshot semantics."),
        (["source continuation", "cursor horizon", "delta token", "source cursor"], "DAT-SOURCE-CONTINUATION", "The meaning belongs to source-qualified continuation scope and eligibility."),
        (["change data capture", "change feed", "source change stream", "cdc"], "DAT-SOURCE-CHANGE-STREAM", "The meaning belongs to provider-neutral source change observations."),
        (["source observation", "source asset discovery", "source system", "discovery inventory", "source structure observation"], "DAT-SOURCE-OBSERVATION", "The reusable portion is source-qualified observation; product/source-family details remain profiles."),
        (["distribution", "analytical export"], "DAT-DISTRIBUTION", "The meaning is an accessible representation of a collection/cut."),
        (["data cut", "dataset version", "immutable occurrence", "publication cut", "version snapshot cut"], "DAT-DATA-CUT", "The reusable portion is the exact immutable occurrence of a collection."),
        (["data collection", "dataset collection", "dataset & collection", "dataset and collection"], "DAT-COLLECTION", "The reusable portion is provider-neutral collection and membership semantics."),
        (["data product"], "DAT-DATA-PRODUCT", "The provider-neutral product meaning remains a later DATA owner; ports/contracts import CON and related owners."),
        (["relational", "relation table record field", "table record field"], "DAT-RELATIONAL-COLLECTION-ALGEBRA", "Relational meaning belongs to the later relational algebra owner; Schema and physical planning are imported."),
        (["document variant", "nested semi structured", "semi-structured", "document algebra"], "DAT-DOCUMENT-VARIANT-ALGEBRA", "Document/variant operations form a later modality algebra."),
        (["time series", "signal algebra"], "DAT-TIME-SERIES-SIGNAL-ALGEBRA", "Time-series/signal semantics form a later modality algebra."),
        (["property graph", "graph path"], "DAT-GRAPH-PATH-ALGEBRA", "Graph/path operations form a later modality algebra."),
        (["spatial", "geospatial", "raster coverage"], "DAT-SPATIAL-COVERAGE-ALGEBRA", "Spatial/coverage meaning forms a later modality algebra while Place remains SEM-owned."),
        (["array tensor", "tensor algebra"], "DAT-ARRAY-TENSOR-ALGEBRA", "Array/tensor semantics form a later modality algebra."),
        (["search ranking", "inverted retrieval"], "DAT-SEARCH-RANKING-ALGEBRA", "Search/ranking semantics form a later modality algebra."),
        (["vector embedding retrieval", "vector retrieval"], "DAT-VECTOR-RETRIEVAL-ALGEBRA", "Vector retrieval semantics form a later modality algebra; provider indexes are offers."),
        (["object centric process", "event object process", "process algebra"], "DAT-EVENT-OBJECT-PROCESS-ALGEBRA", "Event-object process semantics form a later modality algebra."),
        (["metric", "grain", "dimension", "cube additivity", "semantic model"], "DAT-ANALYTICAL-GRAIN-METRIC", "Provider-neutral analytical grain/metric semantics form a later owner; generic Measure stays SEM-087."),
        (["statistical", "sampling", "estimate", "population"], "DAT-STATISTICAL-STUDY-ESTIMATE", "Study, sampling, and estimate semantics form a later owner; generic approximation stays SEM-091."),
        (["forecast"], "DAT-FORECAST-PRODUCT", "Forecast product semantics form a later owner."),
        (["experiment"], "DAT-EXPERIMENT-ANALYSIS", "Experiment analysis semantics form a later owner."),
        (["causal"], "DAT-CAUSAL-ANALYSIS", "Causal analysis semantics form a later owner; business decision authority remains external."),
        (["optimization", "scenario", "prescriptive"], "DAT-OPTIMIZATION-SCENARIO", "Optimization/scenario result semantics form a later owner; solver engines are providers/EXT."),
        (["feature dataset", "point in time feature"], "DAT-FEATURE-DATASET", "Feature dataset semantics form a later owner."),
        (["training evaluation dataset", "training dataset", "label dataset"], "DAT-TRAINING-EVALUATION-DATASET", "Training/evaluation dataset semantics form a later owner."),
        (["retrieval augmented", "chunked corpus", "retrieval context", "rag"], "DAT-RETRIEVAL-CONTEXT-DATASET", "Retrieval context dataset semantics form a later owner."),
        (["incremental computation", "differential computation"], "DAT-INCREMENTAL-COMPUTATION", "Incremental maintenance semantics form a later owner."),
        (["materialized result", "materialized view"], "DAT-MATERIALIZED-RESULT", "Materialized result semantics form a later owner; substitution search is compiler-owned."),
        (["backfill", "replay reprocess reproduce", "historical recompute"], "DAT-HISTORICAL-RECALCULATION", "Historical recalculation distinctions form a later owner while execution is runtime/management."),
        (["analytical restatement", "dataset repair restatement"], "DAT-ANALYTICAL-RESTATEMENT", "Analytical correction/restatement forms a later owner; Journal remains SEM-025."),
        (["analytical table", "table snapshot"], "DAT-ANALYTICAL-TABLE-SNAPSHOT", "Logical analytical table/snapshot semantics form a later owner; files/manifests are target/provider concerns."),
        (["serving cut", "analytical serving"], "DAT-ANALYTICAL-SERVING-CUT", "Consumer-visible coherent cut semantics form a later owner."),
        (["data share", "clean room", "controlled collaboration"], "DAT-DATA-SHARING-COLLABORATION", "Sharing/collaboration semantics form a later owner while Authorization/Purpose remain SEM-owned."),
    ]
    for needles, target, why in patterns:
        if any(n in t for n in needles):
            return target, why
    return None, "No direct canonical DATA owner mapping was established."


def classify_occurrence(title: str, question: str = "", placement: str = "", source_id: str = "") -> dict[str, Any]:
    t = normalize_title(" ".join([title, question, placement]))
    target, target_why = map_data_target(title + " " + question)
    if target:
        return {"disposition":"NEW_DATA_OWNER" if target in LIB_INDEX else "OPEN_UNRESOLVED", "target":target, "rationale":target_why}

    sem_keywords = {
        "SEM-014":["identifier", "stable identity", "asset identity"],
        "SEM-021":["namespace"],
        "SEM-013":["path", "traversal"],
        "SEM-011":["instant", "time scale"],
        "SEM-019":["causality", "order sequence", "partial order"],
        "SEM-025":["journal", "institutional record"],
        "SEM-026":["bitemporal", "valid time", "recording time", "double cut"],
        "SEM-027":["provenance", "lineage"],
        "SEM-028":["evidence", "proof sufficiency", "verification"],
        "SEM-029":["vocabulary", "glossary", "terminology"],
        "SEM-030":["schema", "type constraint"],
        "SEM-031":["identity denotation", "entity identity"],
        "SEM-032":["reference"],
        "SEM-033":["locator", "endpoint location"],
        "SEM-034":["designation", "label"],
        "SEM-035":["correspondence", "mapping correspondence"],
        "SEM-036":["recognition", "entity resolution", "match"],
        "SEM-037":["place geography"],
        "SEM-042":["tenancy"],
        "SEM-043":["jurisdiction"],
        "SEM-044":["rule"],
        "SEM-045":["decision"],
        "SEM-046":["adjudication"],
        "SEM-047":["obligation"],
        "SEM-048":["classification"],
        "SEM-049":["purpose"],
        "SEM-050":["consent"],
        "SEM-060":["authorization", "access policy"],
        "SEM-081":["retention"],
        "SEM-082":["residency"],
        "SEM-083":["erasure", "deletion right"],
        "SEM-085":["derivation"],
        "SEM-086":["query contract"],
        "SEM-087":["measure"],
        "SEM-088":["model inference"],
        "SEM-089":["data quality", "quality dimension", "quality assessment"],
        "SEM-091":["approximation", "numerical function"],
        "SEM-092":["artifact"],
        "SEM-093":["release"],
        "SEM-094":["telemetry"],
        "SEM-095":["health"],
        "SEM-096":["service objective", "slo", "sla"],
        "SEM-098":["incident"],
        "SEM-099":["continuity", "disaster recovery"],
    }
    for sem, needles in sem_keywords.items():
        if any(n in t for n in needles):
            return {"disposition":"EXISTING_OWNER_REUSE", "target":sem, "rationale":f"The reusable meaning is already owned by {sem} {SEM_NAMES[int(sem[-3:])]} or is a projection of it."}

    if any(n in t for n in ["optimizer", "memo", "equivalence search", "rewrite rule", "join order", "cost model", "physical planning", "materialization substitution", "provider selection", "query federation", "application linker", "closure"]):
        return {"disposition":"COMPILER_CONTEXT", "target":"Application Compilation and Closure", "rationale":"Equivalence search, planning, selection, and application closure are compiler responsibilities, not DATA semantic ownership."}
    if any(n in t for n in ["file format", "compression", "encoding", "serialization", "physical type", "memory layout", "portable ir", "physical plan", "target dialect", "storage layout"]):
        return {"disposition":"PORTABLE_TARGET_IR", "target":"Portable Target IR or Governed Reference Publication", "rationale":"Representation and lowering are target/reference concerns unless an independently semantic DATA question survives."}
    if any(n in t for n in ["connector", "provider offer", "database product", "engine implementation", "adapter", "sdk", "source package"]):
        return {"disposition":"PROVIDER_CAPABILITY", "target":"Provider Implementation Evidence", "rationale":"A concrete connector/product capability is a provider offer or reference profile, never the semantic owner."}
    if any(n in t for n in ["checkpoint", "savepoint", "worker", "task attempt", "executor", "runtime", "orchestration", "schedule", "retry", "backpressure", "spill", "backup restore", "vacuum", "compaction", "cache", "deployment", "controller", "reconciliation", "repair", "incident response"]):
        return {"disposition":"RUNTIME_OR_PLATFORM", "target":"Runtime Mechanism / Provider-Neutral Resource Guarantee / Desired-State Control / Management and Repair", "rationale":"The concept describes execution, control, resources, or operator work rather than provider-neutral DATA meaning."}
    if any(n in t for n in ["catalog record", "catalog publication", "source family", "product family", "format catalog", "reference publication", "code list", "industry standard"]):
        return {"disposition":"ONTOLOGY_OR_REFERENCE_PACK", "target":"Governed Reference Publication", "rationale":"The concept is an open-world publication/profile/catalog, not a finite sovereign semantic owner."}
    if any(n in t for n in ["dashboard", "visualization", "report", "notebook", "workspace", "client experience", "served page"]):
        return {"disposition":"PROJECTION_OR_VIEW", "target":"Client-Facing Contract", "rationale":"The concept is a user/client projection over owned meaning."}
    if any(n in t for n in ["data service", "consumer contract profile"]):
        return {"disposition":"PROJECTION_OR_VIEW", "target":"SEM-084 Integration + SEM-086 Query Contract + Constitutional Contract Metamodel + Runtime/Client-Facing Contract", "rationale":"The proposed owner combines service interface, query contract, distribution, runtime endpoint, and provider behavior and should not be one DATA library."}
    if any(n in t for n in ["dataset series", "data asset"]):
        return {"disposition":"MERGED", "target":"DAT-COLLECTION / DAT-DATA-PRODUCT / SEM-092 Artifact", "rationale":"The label is a profile or composition; no independent owner was justified without an exact sovereign question."}
    if any(n in t for n in ["data operating model", "portfolio", "stewardship operations", "adoption", "training", "consulting", "managed service", "workforce"]):
        return {"disposition":"ONTOLOGY_OR_REFERENCE_PACK", "target":"Domain Ontology / Management and Repair / Client-Facing Contract", "rationale":"Organizational work and business operating models are not generic DATA semantics."}
    return {"disposition":"OPEN_UNRESOLVED", "target":None, "rationale":"The occurrence remains a research question; no sovereign owner is minted from title matching."}


def parse_prior_occurrences() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    # Edition-3 99 candidate registry.
    p99 = Path("/mnt/data/SAN-DAT-DOMAIN-MODEL-REGISTRY-EDITION-3-RUST-ENRICHED-REVIEW-CANDIDATE/DAT-LIBRARIES.json")
    if p99.exists():
        data = load_json(p99)
        for item in data.get("libraries", []):
            ruling = classify_occurrence(item.get("title", ""), item.get("sovereign_question", ""), item.get("domain", ""), item.get("identity", ""))
            rows.append({
                "occurrence_identity": stable_hash_id("PRIOR", "ED3-99", item.get("identity", "")),
                "source": "SAN-DAT-DOMAIN-MODEL-REGISTRY-EDITION-3",
                "source_identity": item.get("identity"),
                "title": item.get("title"),
                "question": item.get("sovereign_question"),
                "prior_owner_claim": "Data Sovereign Library",
                **ruling,
            })

    # Edition-1 112 candidate registry.
    p112 = Path("/mnt/data/SAN-DATA-ANALYTICS-PLATFORM-REGISTRY-EDITION-1-CANDIDATE/REGISTRY.json")
    if p112.exists():
        data = load_json(p112)
        for item in data.get("libraries", []):
            ruling = classify_occurrence(item.get("title", ""), item.get("sovereign_question", ""), item.get("domain_group", ""), item.get("identity", ""))
            rows.append({
                "occurrence_identity": stable_hash_id("PRIOR", "ED1-112", item.get("identity", "")),
                "source": "SAN-DATA-ANALYTICS-PLATFORM-REGISTRY-EDITION-1",
                "source_identity": item.get("identity"),
                "title": item.get("title"),
                "question": item.get("sovereign_question"),
                "prior_owner_claim": item.get("owner_track", "Data and Analytics"),
                **ruling,
            })

    # Mathematical atlas 168 rows.
    atlas = ROOT / "03-DATA-RESEARCH/SAN-DATA-INTELLIGENCE-PLATFORM-MATHEMATICAL-ATLAS-EDITION-0.2.md"
    if atlas.exists():
        for lineno, line in enumerate(atlas.read_text(encoding="utf-8").splitlines(), 1):
            m = re.match(r"\|\s*(DP-[A-Z]+-\d+)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|\s*([^|]+?)\s*\|", line)
            if not m:
                continue
            sid, title, question, archetype, placement = [x.strip() for x in m.groups()]
            ruling = classify_occurrence(title, question, placement, sid)
            rows.append({
                "occurrence_identity": stable_hash_id("PRIOR", "ATLAS-168", sid),
                "source": "SAN-DATA-INTELLIGENCE-PLATFORM-MATHEMATICAL-ATLAS-EDITION-0.2",
                "source_identity": sid,
                "source_line": lineno,
                "title": title,
                "question": question,
                "prior_owner_claim": placement,
                "formal_archetype": archetype,
                **ruling,
            })

    # Data-motion 55 atom inventory. Retain each atom occurrence.
    motion = ROOT / "03-DATA-RESEARCH/DATA-MOTION-ONTOLOGY.md"
    if motion.exists():
        section = None
        for lineno, line in enumerate(motion.read_text(encoding="utf-8").splitlines(), 1):
            sm = re.match(r"###\s+1\.\d+\s+(.+)", line)
            if sm:
                section = sm.group(1).strip()
            m = re.match(r"\|\s*`?([^|`]+(?:<[^>]+>)?)`?\s*\|\s*([^|]+)\s*\|\s*([^|]+)\s*\|", line)
            if not m or not section or "Atom" in m.group(1):
                continue
            title, atom_status, purpose = [x.strip() for x in m.groups()]
            if not title or title.startswith("---") or title.startswith("#"):
                continue
            sid = f"MOTION-{section}-{lineno}"
            ruling = classify_occurrence(title, purpose, section, sid)
            rows.append({
                "occurrence_identity": stable_hash_id("PRIOR", "MOTION-55", sid),
                "source": "DATA-MOTION-ONTOLOGY",
                "source_identity": sid,
                "source_line": lineno,
                "title": title,
                "question": purpose,
                "prior_owner_claim": f"Data-motion atom / {section}",
                "prior_status": atom_status,
                **ruling,
            })

    # Prior 15-domain aggregate model. These are shells, not atomic owners.
    report = ROOT / "05-PREVIOUS-PROPOSALS/DATA-COMPILER-DOMAIN-MODEL-V0.4-REPORT.txt"
    if report.exists():
        for lineno, line in enumerate(report.read_text(encoding="utf-8").splitlines(), 1):
            m = re.match(r"\|\s*`?([A-Z]{2,3})`?\s*\|\s*([^|]+?)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|", line)
            if not m:
                continue
            sid, title, subs, leaves = m.groups()
            ruling = classify_occurrence(title, f"Aggregate shell with {subs} subdomains and {leaves} generated leaves", title, sid)
            rows.append({
                "occurrence_identity": stable_hash_id("PRIOR", "V04-DOMAIN", sid),
                "source": "DATA-COMPILER-DOMAIN-MODEL-V0.4-REPORT",
                "source_identity": sid,
                "source_line": lineno,
                "title": title.strip(),
                "question": f"Prior aggregate domain shell containing {subs} subdomains and {leaves} generated leaves.",
                "prior_owner_claim": "Prior 15-domain decomposition shell",
                "aggregate_counts": {"subdomains":int(subs),"leaves":int(leaves)},
                **ruling,
            })
        rows.append({
            "occurrence_identity": stable_hash_id("PRIOR", "V04-LEAF-CORPUS", "219-851"),
            "source": "DATA-COMPILER-DOMAIN-MODEL-V0.4-REPORT",
            "source_identity": "AGGREGATE-219-SUBDOMAIN-851-LEAF-CORPUS",
            "title": "219-subdomain / 851-leaf generated corpus",
            "question": "The report supplies aggregate counts but not an owner-reviewed source occurrence for every generated leaf in this handoff archive.",
            "prior_owner_claim": "Generated broad data compiler corpus",
            "disposition": "OPEN_UNRESOLVED",
            "target": None,
            "rationale": "The aggregate is accounted for as unavailable detailed source. It cannot be silently promoted or individually adjudicated without its machine source.",
            "gap": "GAP-PRIOR-851-LEAF-SOURCE-NOT-IN-HANDOFF",
        })

    # Candidate questions explicitly supplied by the current prompt.
    prompt_questions = [
        ("PROMPT-Q1","Data asset, collection, dataset, series, version, cut, and snapshot"),
        ("PROMPT-Q2","Data product identity, lifecycle, contract, ports, distributions, and services"),
        ("PROMPT-Q3","Relation, table, record, field, grain, keys, cardinality, and missingness"),
        ("PROMPT-Q4","Source observation, extraction, capture coordinates, delivery, and continuation"),
        ("PROMPT-Q5","Change records, CDC, transaction visibility, ordering, replay, and recovery"),
        ("PROMPT-Q6","Logical query and analytics semantics and semantic-preserving transformations"),
        ("PROMPT-Q7","Data quality assertions, assessments, dimensions, incidents, and remedies"),
        ("PROMPT-Q8","Lineage/provenance projection, catalog publication, serving, and consumption"),
    ]
    for sid, title in prompt_questions:
        ruling = classify_occurrence(title, title, "Current prompt candidate question", sid)
        rows.append({
            "occurrence_identity": stable_hash_id("PRIOR", "CURRENT-PROMPT", sid),
            "source": "CURRENT-PROMPT",
            "source_identity": sid,
            "title": title,
            "question": title,
            "prior_owner_claim": "Candidate question, no mandated owner",
            **ruling,
        })

    # Hypergraph implementation proposal is explicitly rejected as a parallel owner.
    rows.append({
        "occurrence_identity": stable_hash_id("PRIOR", "HYPERGRAPH", "UNIVERSAL-DOMAIN-OWNER"),
        "source": "DOMAIN-HYPERGRAPH-PROPOSAL-REPORT",
        "source_identity": "UNIVERSAL-DOMAIN-HYPERGRAPH-COMPILER",
        "title": "Universal domain hypergraph authoring/compiler ownership",
        "question": "Should a parallel hypergraph core own stable identity, digest, contract algebra, compiler/linker, IR and provider selection?",
        "prior_owner_claim": "Proposed universal domain hypergraph workspace",
        "disposition": "REJECTED_DUPLICATE",
        "target": "Existing Constitution, Sovereign Semantics, Constitutional Contract Metamodel, Application Compilation and Closure, Portable Target IR",
        "rationale": "The useful hypergraph is a projection/authoring mechanism; the proposal duplicated current owners and failed fresh Rust compilation per the handoff review.",
    })

    # Ensure occurrence identities unique.
    seen = set()
    for row in rows:
        if row["occurrence_identity"] in seen:
            row["occurrence_identity"] = stable_hash_id("PRIOR", row["source"], row["source_identity"], str(len(seen)))
        seen.add(row["occurrence_identity"])
    return rows

SSPEC_SECTION_NAMES = [
    "01 Identity","02 Sovereign question","03 Research basis","04 Ubiquitous language",
    "05 Domain decomposition","06 Ontology and types","07 Time and state","08 Behavior",
    "09 Laws","10 Decisions","11 Authority and governance","12 Contracts and composition",
    "13 Data and evidence","14 Failure model","15 Resource model","16 Evolution",
    "17 Compiler surface","18 IR and lowering","19 Runtime obligations","20 Diagnostics",
    "21 Dependency DAG","22 Proof and completion",
]

COMPLETION_FALSE = {
    "research_complete": False,
    "machine_source_complete": True,
    "source_verified": False,
    "ownership_closed": False,
    "dependency_closed": False,
    "operation_surface_complete": True,
    "semantic_execution_verified": False,
    "implementation_verified": False,
    "compiler_integration_verified": False,
    "lowering_verified": False,
    "runtime_vertical_verified": False,
    "provider_conformance_verified": False,
    "migration_verified": False,
    "independently_verified": False,
    "ratified": False,
    "certified": False,
}

SPEC_SCHEMA = {
    "$schema":"https://json-schema.org/draft/2020-12/schema",
    "$id":"urn:san:schema:data-sovereign-spec:1",
    "title":"SAN Data Sovereign Library SPEC",
    "type":"object",
    "additionalProperties":False,
    "required":["identity","edition","title","registry","architectural_class","status","certification","source_occurrences","semantic_owner","sovereign_question","purpose","owned_meanings","explicit_exclusions","negative_charter","research_basis","sspec_sections","completion"],
    "properties":{
        "identity":{"type":"string","pattern":"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$"},
        "edition":{"type":"integer","minimum":1},
        "title":{"type":"string","minLength":1},
        "registry":{"type":"object","additionalProperties":False,"required":["code","name"],"properties":{"code":{"const":"DAT"},"name":{"const":"Data Sovereign Library Registry"}}},
        "architectural_class":{"const":"DATA_SOVEREIGN_LIBRARY"},
        "status":{"const":"REVIEW_CANDIDATE"},
        "certification":{"const":"NONE"},
        "source_occurrences":{"type":"array","minItems":1,"items":{"type":"object","additionalProperties":False,"required":["kind","identity","sha256_or_url"],"properties":{"kind":{"type":"string"},"identity":{"type":"string"},"sha256_or_url":{"type":"string"}}}},
        "semantic_owner":{"type":"string","minLength":1},
        "sovereign_question":{"type":"string","minLength":20},
        "purpose":{"type":"string","minLength":20},
        "owned_meanings":{"type":"array","minItems":1,"items":{"type":"string"}},
        "explicit_exclusions":{"type":"array","minItems":1,"items":{"type":"string"}},
        "negative_charter":{"type":"array","minItems":1,"items":{"type":"string"}},
        "research_basis":{"type":"array","minItems":1,"items":{"type":"string"}},
        "sspec_sections":{"type":"array","minItems":22,"maxItems":22,"items":{"type":"object","additionalProperties":False,"required":["section","disposition","artifact"],"properties":{"section":{"type":"string"},"disposition":{"enum":["PUBLISHED","EXTERNAL_CONTRACT","INAPPLICABLE","OPEN_GAP"]},"artifact":{"type":"string"},"reason":{"type":"string"},"law":{"type":"string"}}}},
        "completion":{"type":"object","additionalProperties":False,"required":list(COMPLETION_FALSE.keys()),"properties":{k:{"type":"boolean"} for k in COMPLETION_FALSE}},
    },
}

CONTEXT_SCHEMA = {
    "$schema":"https://json-schema.org/draft/2020-12/schema",
    "$id":"urn:san:schema:data-context-spec:1",
    "title":"SAN Data Sovereign Context Specification",
    "type":"object",
    "additionalProperties":False,
    "required":["identity","edition","title","strategic_classification","bounded_contexts","subdomains","context_map","ownership_matrix"],
    "properties":{
        "identity":{"type":"string","pattern":"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$"},
        "edition":{"type":"integer","minimum":1},
        "title":{"type":"string"},
        "strategic_classification":{"enum":["CORE","SUPPORTING","GENERIC_IMPORT_COMPOSITE"]},
        "bounded_contexts":{"type":"array","minItems":1,"items":{"type":"object","additionalProperties":False,"required":["identity","title","sovereign_question","inside","outside"],"properties":{"identity":{"type":"string"},"title":{"type":"string"},"sovereign_question":{"type":"string"},"inside":{"type":"array","items":{"type":"string"}},"outside":{"type":"array","items":{"type":"string"}}}}},
        "subdomains":{"type":"array","minItems":1,"items":{"type":"object","additionalProperties":False,"required":["identity","title","classification","question"],"properties":{"identity":{"type":"string"},"title":{"type":"string"},"classification":{"enum":["CORE","SUPPORTING","GENERIC_IMPORTED"]},"question":{"type":"string"}}}},
        "context_map":{"type":"array","items":{"type":"object","additionalProperties":False,"required":["other","relationship","direction","contract"],"properties":{"other":{"type":"string"},"relationship":{"type":"string"},"direction":{"type":"string"},"contract":{"type":"string"}}}},
        "ownership_matrix":{"type":"array","items":{"type":"object","additionalProperties":False,"required":["meaning","owner","disposition"],"properties":{"meaning":{"type":"string"},"owner":{"type":"string"},"disposition":{"enum":["NATIVE","IMPORTED","EXCLUDED","DELEGATED"]}}}},
    },
}


def diagnostics_for(defn: dict[str, Any], lib_id: str) -> list[dict[str, Any]]:
    diags = []
    for idx, ref in enumerate(defn["refusals"], 1):
        diags.append({
            "identity": f"DIAG-{slug(lib_id)}-{idx:03d}",
            "code": f"D-{slug(lib_id)}-{idx:03d}",
            "severity": "ERROR" if ref["variant"] not in {"UNKNOWN-OR-INCOMPLETE"} else "WARNING",
            "refusal": ref["identity"],
            "source_locus": ref["production_locus"],
            "violated_law": next((law["identity"] for law in defn["laws"] if ref["identity"] in law["refusal_on_violation"]), None),
            "responsible_owner": lib_id,
            "human_explanation": ref["meaning"],
            "machine_explanation": {"refusal":ref["identity"],"precedence":ref["validation_precedence"]},
            "remediation": "Change the carrier, supply the missing admitted dependency/evidence/authority, reduce the declared scope, or select a lawful alternative. Never downgrade the refusal by default.",
            "evidence": "Retain bounded evidence references; do not echo unrestricted hostile payloads.",
            "disclosure": ref["disclosure"],
            "determinism": "Equal refusal identity, locus, admitted context, and disclosure context yield equal bounded explanation.",
            "max_output_bytes": 16_384,
        })
    return diags


def conformance_for(defn: dict[str, Any], lib_id: str) -> dict[str, Any]:
    cases = []
    for law_rec in defn["laws"]:
        base = slug(law_rec["identity"])
        for kind in ["POSITIVE","NEGATIVE_TWIN","BOUNDARY_MAX","BOUNDARY_MAX_PLUS_ONE","MUTATION","EXHAUSTION"]:
            cases.append({
                "identity": f"CASE-{base}-{kind}",
                "law": law_rec["identity"],
                "kind": kind,
                "input_class": "GENERATED_OR_HAND_AUTHORED_BOUNDED_VECTOR",
                "expected": "ACCEPT" if kind in {"POSITIVE","BOUNDARY_MAX"} else "REFUSE_OR_DETECT",
                "oracle": f"Exercise {law_rec['identity']} through each governed operation and compare exact admitted output or refusal.",
                "status": "AUTHORED_NOT_EXECUTED",
            })
        # Replay only when applicable. Still explicit, never omitted.
        replay_ops = [op for op in law_rec["operations_affected"] if any(word in op for word in ["REPLAY","EXECUTE-STITCH","VERIFY-STITCH","ADMIT-CHANGE","MERGE-SNAPSHOT"])]
        if replay_ops:
            cases.append({"identity":f"CASE-{base}-REPLAY","law":law_rec["identity"],"kind":"REPLAY","input_class":"BOUNDED_REPLAY_VECTOR","expected":"EQUIVALENT_OR_TYPED_REFUSAL","oracle":"Repeat under legal batching/replay and compare canonical admitted result and proof obligations.","status":"AUTHORED_NOT_EXECUTED"})
        else:
            cases.append({"identity":f"CASE-{base}-REPLAY","law":law_rec["identity"],"kind":"REPLAY","disposition":"INAPPLICABLE","reason":"This law governs immutable admission/comparison rather than an event-fold or replayable operation.","governing_law":"SSPEC-CONFORMANCE-REPLAY-01","status":"INAPPLICABLE"})
    return {
        "identity": f"CONFORMANCE-{lib_id}",
        "edition": 1,
        "status": "AUTHORED_NOT_EXECUTED",
        "cases": cases,
        "coverage": {
            "laws": len(defn["laws"]),
            "cases": len(cases),
            "positive": sum(1 for c in cases if c.get("kind")=="POSITIVE"),
            "negative_twins": sum(1 for c in cases if c.get("kind")=="NEGATIVE_TWIN"),
            "boundary": sum(1 for c in cases if c.get("kind") in {"BOUNDARY_MAX","BOUNDARY_MAX_PLUS_ONE"}),
            "mutation": sum(1 for c in cases if c.get("kind")=="MUTATION"),
            "exhaustion": sum(1 for c in cases if c.get("kind")=="EXHAUSTION"),
            "replay": sum(1 for c in cases if c.get("kind")=="REPLAY" and c.get("disposition")!="INAPPLICABLE"),
        },
        "independent_provider_conformance": False,
    }


def source_records_for(defn: dict[str, Any]) -> list[dict[str, Any]]:
    index = {s["identity"]:s for s in WEB_SOURCES}
    return [deepcopy(index[sid]) for sid in defn["source_ids"]]


def build_library_artifacts(lib: dict[str, Any], sem_records: dict[str, dict[str, Any]], source_locks: list[dict[str, Any]]) -> dict[str, Any]:
    lib_id = lib["identity"]
    defn = LIB_DEFS[lib_id]
    source_records = source_records_for(defn)
    imports = defn.get("imports", [])
    hard_data = defn.get("hard_data_dependencies", [])
    seams = defn.get("semantic_seams", [])
    local_source_occ = [
        {"kind":"HANDOFF_ARCHIVE","identity":row["path"],"sha256_or_url":row["sha256"]}
        for row in source_locks if row["path"] in {
            "00-START/START-HERE.md",
            "00-START/PROMPT-FOR-GPT-PRO.md",
            "00-START/REVIEW-OF-CURRENT-PROPOSALS.md",
            "01-CONSTITUTION/PURE-LIBRARY-CONSTITUTION.html",
            "01-CONSTITUTION/PURE-LIBRARY-RULES.md",
            "02-CURRENT-REGISTRIES/CURRENT-SEM-CONVERGENCE.json",
        }
    ]
    local_source_occ += [{"kind":"WEB_PRIMARY","identity":s["identity"],"sha256_or_url":s["url"]} for s in source_records]

    sspec_sections = []
    artifact_for = {
        "01 Identity":"SPEC.json","02 Sovereign question":"SPEC.json","03 Research basis":"RESEARCH-SOURCES.json","04 Ubiquitous language":"VOCABULARY.json",
        "05 Domain decomposition":"CONTEXT-SPEC.json","06 Ontology and types":"ONTOLOGY.json","07 Time and state":"STATES.json","08 Behavior":"OPERATIONS.json",
        "09 Laws":"LAWS.json","10 Decisions":"DECISIONS.json","11 Authority and governance":"CAPABILITIES.json","12 Contracts and composition":"CONTRACTS.json",
        "13 Data and evidence":"DOMAIN-MODEL.json","14 Failure model":"REFUSALS.json","15 Resource model":"BUDGETS.json","16 Evolution":"EVOLUTION.json",
        "17 Compiler surface":"COMPILER-QUERIES.json","18 IR and lowering":"IR.json","19 Runtime obligations":"RUNTIME-OBLIGATIONS.json","20 Diagnostics":"DIAGNOSTICS.json",
        "21 Dependency DAG":"DEPENDENCY-DAG.json","22 Proof and completion":"PROOF-OBLIGATIONS.json",
    }
    for section in SSPEC_SECTION_NAMES:
        sspec_sections.append({"section":section,"disposition":"PUBLISHED","artifact":artifact_for[section]})

    spec = {
        "identity":lib_id,
        "edition":1,
        "title":lib["title"],
        "registry":{"code":"DAT","name":"Data Sovereign Library Registry"},
        "architectural_class":"DATA_SOVEREIGN_LIBRARY",
        "status":STATUS,
        "certification":CERTIFICATION,
        "source_occurrences":local_source_occ,
        "semantic_owner":f"Data Sovereign Library: {lib['title']}",
        "sovereign_question":lib["question"],
        "purpose":f"Provide one pure, provider-neutral, editioned semantic owner for {', '.join(defn['owned'])}, while importing adjacent meanings through exact admitted contracts.",
        "owned_meanings":defn["owned"],
        "explicit_exclusions":defn["exclusions"],
        "negative_charter":[
            "MUST NOT perform I/O, network, filesystem, database, broker, SDK, clock, random, secret, runtime-loop, or deployment work.",
            "MUST NOT redefine imported Sovereign Semantics, Constitutional Contract Metamodel, Application Compilation and Closure, Portable Target IR, Runtime Mechanism, Provider-Neutral Resource Guarantee, or provider meanings.",
            "MUST NOT author implementation offers, provider conformance, independent certification, or authoritative application mutations.",
        ],
        "research_basis":[s["identity"] for s in source_records],
        "sspec_sections":sspec_sections,
        "completion":deepcopy(COMPLETION_FALSE),
    }

    bounded_context = {
        "identity":f"CONTEXT-{lib_id}",
        "title":lib["title"],
        "sovereign_question":lib["question"],
        "inside":defn["owned"],
        "outside":defn["exclusions"],
    }
    context_map = []
    for imp in imports:
        context_map.append({"other":imp["coordinate"],"relationship":"CUSTOMER_SUPPLIER_EXACT_TYPED_IMPORT","direction":f"{imp['coordinate']} -> {lib_id}","contract":f"Admitted {imp['name']} values or exact ContractRequirement"})
    for dep in hard_data:
        context_map.append({"other":dep,"relationship":"HARD_DEPENDENCY","direction":f"{dep} -> {lib_id}","contract":f"Public admitted contract of {dep}"})
    for seam in seams:
        context_map.append({"other":seam,"relationship":"RECIPROCAL_SEMANTIC_SEAM","direction":"TYPED_BIDIRECTIONAL_WITHOUT_CARGO_CYCLE","contract":f"SEAM-{lib_id}-{seam}"})
    ownership_matrix = ([{"meaning":m,"owner":lib_id,"disposition":"NATIVE"} for m in defn["owned"]]
                        + [{"meaning":imp["name"],"owner":imp["coordinate"],"disposition":"IMPORTED"} for imp in imports]
                        + [{"meaning":m,"owner":"EXTERNAL_OR_OTHER_TRACK","disposition":"EXCLUDED"} for m in defn["exclusions"]])
    context_spec = {
        "identity":f"CONTEXT-{lib_id}","edition":1,"title":lib["title"],"strategic_classification":"CORE",
        "bounded_contexts":[bounded_context],"subdomains":defn["subdomains"],"context_map":context_map,"ownership_matrix":ownership_matrix,
    }

    entities = [t for t in defn["types"] if t["kind"] in {"ADMITTED_ENTITY","ADMITTED_OCCURRENCE"}]
    values = [t for t in defn["types"] if t["kind"] not in {"ADMITTED_ENTITY","ADMITTED_OCCURRENCE","HOSTILE_CARRIER"}]
    carriers = [t for t in defn["types"] if t["carrier"]]
    ontology = {
        "identity":f"ONTOLOGY-{lib_id}","edition":1,"owner":lib_id,
        "concepts":[{"identity":t["identity"],"label":t["term"],"kind":t["kind"],"definition":t["definition"]} for t in defn["terms"]],
        "relations":[
            {"identity":f"REL-{slug(lib_id)}-OWNS","name":"owns","domain":lib_id,"range":"OwnedMeaning","cardinality":"1:N","owner":lib_id},
            {"identity":f"REL-{slug(lib_id)}-IMPORTS","name":"imports","domain":lib_id,"range":"ExternalAdmittedValue","cardinality":"0:N","owner":"Constitutional Contract Metamodel"},
            {"identity":f"REL-{slug(lib_id)}-PROVEN-BY","name":"proven by","domain":"ClaimOrResult","range":"EvidenceReference","cardinality":"0:N","owner":"SEM-027/SEM-028"},
        ],
        "values":[t["rust_name"] for t in values],
        "entities":[t["rust_name"] for t in entities],
        "roles":["Author","Contributor","Verifier","Consumer"],
        "aggregates":[{"identity":f"AGGREGATE-{lib_id}","root":next((t["rust_name"] for t in entities),defn["types"][0]["rust_name"]),"consistency_boundary":"Only local admission invariants; cross-owner facts arrive as admitted evidence or requirements."}],
        "claims_vs_facts":"All source/analytical statements are claims, observations, findings, or proposals unless admitted by an authoritative application owner. This library never mints application facts.",
        "policies":[d["identity"] for d in defn["decisions"]],
        "rules":[l["identity"] for l in defn["laws"]],
        "obligations":[f"OBLIGATION-{slug(lib_id)}-PRESERVE-IMPORTED-EVIDENCE",f"OBLIGATION-{slug(lib_id)}-RETAIN-DECISION-PROVENANCE"],
        "evidence_proofs":["SEM-027 Provenance references","SEM-028 Evidence and verifier results","CON satisfaction proofs when provider requirements are bound"],
        "closed_taxonomies":[t["rust_name"] for t in defn["types"] if t["kind"] in {"CLOSED_ENUM","OPEN_PROFILE_ENUM"}],
        "disjointness":[{"left":"HostileCarrier","right":"AdmittedSemanticValue"},{"left":"ProviderOffer","right":"SemanticRequirement"},{"left":"ObservationOrProposal","right":"ApplicationFact"}],
    }

    domain_model = {
        "identity":f"DOMAIN-MODEL-{lib_id}","edition":1,"owner":lib_id,
        "purpose":spec["purpose"],"sovereign_question":lib["question"],"inside":defn["owned"],"outside":defn["exclusions"],
        "subdomains":defn["subdomains"],"bounded_context":bounded_context,
        "values":[t["rust_name"] for t in values],"entities":[t["rust_name"] for t in entities],"roles":["Author","Contributor","Verifier","Consumer"],
        "aggregate":ontology["aggregates"][0],"claims_facts_observations":ontology["claims_vs_facts"],
        "state_machine":defn["state_machine"]["identity"],"operations":[o["identity"] for o in defn["operations"]],
        "laws":[l["identity"] for l in defn["laws"]],"decisions":[d["identity"] for d in defn["decisions"]],
        "data_evidence":{
            "hostile_carriers":[t["rust_name"] for t in carriers],
            "admitted_values":[t["rust_name"] for t in defn["types"] if t["admitted"]],
            "canonical_projection":external_contract("SEM-001 Canonical Form and SEM-002 Digest","Canonical projection and digest are imported; this library supplies only identity-defining semantic fields."),
            "provenance":external_contract("SEM-027 Provenance","Retain exact source, derivation, activity, agent/responsibility and historical references."),
            "lineage":"Technical/runtime lineage is a projection; semantic provenance remains imported.",
            "freshness":"Freshness is a qualified claim using imported time and service-objective semantics; absence is Unknown.",
            "completeness":"Completeness uses library-owned scoped posture where applicable and SEM-028 evidence; never an unqualified boolean.",
            "conflict":"Conflicts remain typed values/findings until a legitimate owner adjudicates them.",
            "disclosure_safe_projection":"All explanation outputs are bounded, classified and redacted through imported Authorization/Classification contracts.",
        },
    }

    rust_types = []
    for t in defn["types"]:
        rust_types.append({
            "semantic_identity":t["identity"],"candidate_rust_name":t["rust_name"],"kind":t["kind"],"fields_private":t["fields_private"],
            "derives":["Clone","Debug","PartialEq","Eq"] + (["Serialize","Deserialize"] if t["deserializable"] else ["Serialize"] if t["admitted"] else []),
            "deserialize_constructor":t["deserializable"],"construction":t["construction"],"forbidden":t["forbidden_construction"],
            "serialization":"Carrier is portable and bounded; admitted/proof values serialize only through an explicit disclosure-safe projection and do not implement Deserialize.",
        })
    rust_api = {
        "identity":f"RUST-API-{lib_id}","edition":1,"status":"CANDIDATE_NOT_COMPILED",
        "module_candidate":f"san_data::{lib_id.lower().replace('-','_').replace('dat_','')}",
        "crate_posture":"MODULE_FIRST_IN_SHARED_NO_STD_DATA_AUTHORING_CRATE; crate split requires measured independent boundary evidence.",
        "crate_attributes":["#![no_std]","#![forbid(unsafe_code)]"],
        "types":rust_types,
        "operations":[{"identity":o["identity"],"rust_symbol":o["rust_symbol"],"signature":o["candidate_signature"],"status":"CANDIDATE_NOT_COMPILED"} for o in defn["operations"]],
        "traits":inapplicable("This pure semantic library publishes values, operations and Constitutional Contract requirements; it does not define generic provider ports. Named sealed capabilities may be added only when an actual compiler consumer requires them.","PURE-LIBRARY-NO-PORTS"),
        "generics":"Only stable reusable structural parameters are permitted; industry, tenant, provider, environment, jurisdiction and policy remain admitted descriptor axes.",
        "forbidden":["serde_json::Value","Any","ambient time","ambient randomness","I/O","provider SDK","generic provider trait","panic for domain refusal","stringly authority","public admitted-value constructor","Deserialize on admitted/proof/authority types"],
        "construction_parity":"Direct Rust construction and declaration/card construction MUST call the same admission operation and yield canonically equal admitted values or identical refusal.",
        "compilation_claim":False,
    }

    # Contracts deliberately reuse CON-owned algebra.
    contracts = {
        "identity":f"CONTRACTS-{lib_id}","edition":1,"owner":lib_id,
        "headers":external_contract("Constitutional Contract Metamodel","All ContractHeader values and identities are imported; this library does not mint a second header type."),
        "requirements":[{
            "identity":f"REQUIREMENT-{slug(lib_id)}-SEMANTIC",
            "owner":lib_id,"provider_neutral":True,"binding_phase":"APPLICATION_LINK",
            "guarantees":[l["identity"] for l in defn["laws"][:4]],
            "cardinality":"EXACTLY_ONE_ADMITTED_SEMANTIC_IMPLEMENTATION_FOR_EACH_SELECTED_OWNER",
            "external_contract_type":"CON-005 ContractRequirement",
        }],
        "contributions":[{"identity":f"CONTRIBUTION-{slug(lib_id)}-DESCRIPTOR","owner":lib_id,"payload":"Canonical admitted descriptor and exact obligations","merge":"CON-owned contribution merge algebra"}],
        "offers":inapplicable("A pure Data Sovereign Library does not author implementation/provider offers.","CON-NO-SELF-OFFER"),
        "satisfaction":external_contract("Constitutional Contract Metamodel and Application Compilation and Closure","Offer satisfaction, selection and retained SatisfactionProof are external."),
        "seams":[{"identity":f"SEAM-{slug(lib_id)}-{slug(seam)}","consumer":lib_id,"provider":seam,"direction":"RECIPROCAL_TYPED_CONTRACT","hard_dependency":False,"guarantees":["editioned payload","typed refusal","no private model access"]} for seam in seams],
    }

    compiler_queries = []
    for i,(name,consumer,answer) in enumerate([
        ("Describe Owner Semantics","CMP-005 Family Closure","Owned meanings, exclusions, laws, decisions, dependencies and gaps"),
        ("Admit Declaration","CMP-002 Admission and Poison Recovery","Admitted semantic value or exact refusal"),
        ("Resolve Imported Owners","CMP-003 Name Binding","Exact external coordinates and edition requirements"),
        ("Project Requirements","CMP-007 Obligation Fixed-Point Closure","Provider-neutral requirements and obligations"),
        ("Build Semantic Graph Slice","CMP-008 Closed Semantic Application Graph Builder","Canonical graph nodes/edges with provenance"),
        ("Explain Refusal Or Gap","CMP-008 verifier and client explanation","Bounded deterministic explanation"),
        ("Diff Editions","CMP-012 Semantic Diff and Migration Planner","Typed semantic delta and migration/rebuild consequences"),
    ],1):
        compiler_queries.append({"identity":f"QUERY-{slug(lib_id)}-{i:02d}","title":name,"owner":lib_id,"consumer":consumer,"inputs":["admitted values","exact edition lock","declared decisions","evidence references","finite query budget"],"answer":answer,"absence":"Typed gap or refusal; never empty success","determinism":"Equal canonical inputs yield equal answer/fingerprint."})

    ir = {
        "identity":f"IR-{lib_id}","edition":1,"owner":"Portable Target IR / Application Compilation and Closure",
        "disposition":"EXTERNAL_CONTRACT",
        "reason":"This Data Sovereign Library does not own a parallel portable IR dialect. It contributes a typed canonical semantic slice to the existing closed semantic application graph and names required target features.",
        "native_representation":"Private admitted Rust values and exact operations described in RUST-API.json.",
        "portable_projection":{
            "node_kind":"SharedSemanticOwnerNode","owner_coordinate":lib_id,"fields":["identity","edition","canonical descriptor reference","law references","decision bindings","requirements","obligations","evidence references","source map"]
        },
        "validation":["owner identity exists","edition positive","all law/decision/refusal references resolve","no provider implementation data","canonical fingerprint externally verified"],
        "normalization":"Uses SEM-001 Canonical Form and shared CSAG normalization; no local canonical algorithm.",
        "consumer":"CMP-008 Closed Semantic Application Graph Builder and CMP-009 Target Lowering Framework",
        "source_ir_native_parity":"Requires direct-vs-declaration admission equality plus source-map-preserving graph projection tests.",
    }

    lowering = {
        "identity":f"LOWERING-{lib_id}","edition":1,"owner":"Portable Target IR",
        "disposition":"EXTERNAL_CONTRACT",
        "reason":"Target lowerers are not owned by the Data Sovereign Library.",
        "prerequisites":["verified CSAG slice","resolved decisions","satisfied provider-neutral requirements","finite resource plan","no blocking gap"],
        "preservation_obligations":["identity","edition","owned semantic distinctions","absence/unknown posture","time/cut scope","evidence/provenance references","refusal semantics","budget and runtime obligations"],
        "unsupported_feature_refusal":f"DIAG-{slug(lib_id)}-UNSUPPORTED-TARGET-FEATURE",
        "source_map_required":True,
        "lowering_verified":False,
    }

    runtime_obligations = {
        "identity":f"RUNTIME-OBLIGATIONS-{lib_id}","edition":1,"semantic_owner":lib_id,"runtime_owner":"Runtime Mechanism / Provider-Neutral Resource Guarantee / Provider Implementation Evidence",
        "runtime_state":inapplicable("The pure library owns no mutable runtime process state; runtime observations are admitted as values.","PURE-LIBRARY-NO-RUNTIME-STATE"),
        "required_capabilities":[
            {"identity":f"RUNTIME-REQ-{slug(lib_id)}-ADMISSION","requirement":"Bounded carrier parsing and owner admission before any semantic use.","provider_neutral":True},
            {"identity":f"RUNTIME-REQ-{slug(lib_id)}-EVIDENCE","requirement":"Receipts and observations retain source, cut/time, tenant, authority and provider configuration evidence.","provider_neutral":True},
            {"identity":f"RUNTIME-REQ-{slug(lib_id)}-BUDGET","requirement":"Enforce emitted work/allocation/state/output budgets and refuse unsafe defaults at boot.","provider_neutral":True},
        ],
        "effect_intents":inapplicable("The first-batch pure semantic operations produce values, requirements and observations only; no external effect intent is owned here.","PURE-LIBRARY-NO-EFFECT"),
        "mutation_path":"Any analytical observation/proposal that could affect authoritative application state must re-enter Host Role Composition → Mutation Kernel → Journal/Event Store → Outbox/Audit/Projection/Receipt.",
        "retries_deadlines":"Runtime-owned; retry must preserve idempotency identity and total budget and must not convert ambiguous outcome into failure.",
        "receipts":"Required for any provider execution; semantic owner cannot self-issue provider or independent assurance receipts.",
        "audit_metrics_traces":"Use imported Telemetry Contract, Health Contract and Service Objective semantics; runtime signal is not semantic correctness proof.",
        "recovery":"Runtime must prove recovery/replay equivalence against library conformance vectors where applicable.",
        "production_eligibility":"FALSE until provider conformance, runtime vertical and independent assurance are separately proven.",
    }

    validation = {
        "identity":f"VALIDATION-{lib_id}","edition":1,"owner":lib_id,
        "precedence":["checked budget arithmetic","carrier byte/element/depth bounds","syntax and shape","import reference existence","authority/evidence availability","decision validation","semantic invariants","conflicts","canonical projection","compiler closure"],
        "hostile_carrier_rules":["Reject unknown fields unless explicitly open-profiled","Reject edition-suffixed identities","Reject raw strings in authority/identity/evidence fields","Reject unbounded arrays/maps/graphs","Reject admitted/proof values supplied by deserialization"],
        "cross_file_rules":["operation/API parity","operation-law-refusal parity","decision absence semantics","total state×command matrix","finite budgets","dependency DAG acyclic","semantic seams not duplicated as hard dependencies","source claim references exist"],
        "negative_controls":["no provider offer","no I/O","no direct application mutation","no local copies of SEM/CON/CMP/TGT meanings","no certification overclaim"],
    }

    evolution = {
        "identity":f"EVOLUTION-{lib_id}","edition":1,"owner":lib_id,
        "identity_equality":"Stable semantic identity is suffix-free and separate from positive edition, carrier schema edition, implementation version, provider version, and occurrence identity.",
        "compatibility_relations":["IDENTICAL","BACKWARD_COMPATIBLE","FORWARD_COMPATIBLE","BIDIRECTIONAL","REQUIRES_MIGRATION","REQUIRES_REBUILD_OR_REPLAY","INCOMPATIBLE","UNKNOWN"],
        "same_edition_mutation":"FORBIDDEN for identity-defining semantic changes.",
        "semantic_delta":"Every changed term/type/operation/decision/law/refusal/budget/contract carries an exact delta and affected consumer set.",
        "coexistence":"Multiple editions may coexist when references are exact and no owner ambiguity exists.",
        "correction":"Correction never rewrites historical admitted value; it creates a successor edition/occurrence and explicit relation.",
        "migration":"Migration requires owner authority, source/target editions, total or partial mapping, loss account, evidence and rollback/refusal posture.",
        "rebuild_replay":"Required when derivation, membership, cut, mapping, order, or change semantics make prior outputs invalid.",
        "supersession":"Historical interpretation retains the edition originally in force.",
        "retirement":"Retirement blocks new binding but preserves historical verification references.",
        "recall":"Recall invalidates future reliance and reopens all dependent assurance cases; history is not erased.",
        "unknown_future_members":"Open foreign vocabularies preserve unknown values; closed owner decisions refuse unknowns unless edition evolution admits them.",
    }

    capabilities = {
        "identity":f"CAPABILITIES-{lib_id}","edition":1,"owner":lib_id,
        "semantic_capabilities":[{"identity":f"CAP-{slug(lib_id)}-{i:02d}","name":m,"authority":"Data Sovereign Library owner","scope":lib_id,"delegation":"Only through admitted SEM-058 Delegation when applicable","fail_closed":True} for i,m in enumerate(defn["owned"],1)],
        "authority_sources":["Constitutional owner registry","admitted Execution Context","exact evidence/verification references","external application/domain authority when business mutation is implicated"],
        "tenancy":"Imported SEM-042 Tenancy; tenant is explicit in any runtime/provider requirement and evidence.",
        "jurisdiction":"Imported SEM-043 Jurisdiction; no jurisdictional law is hard-coded in this library.",
        "classification_disclosure":"Imported SEM-048 Classification and SEM-060 Authorization govern disclosure; explanations are bounded/redacted.",
        "consent_purpose":"Imported SEM-049 Purpose and SEM-050 Consent; absence or unavailable authority fails closed.",
        "recall":"Imported constitutional/SEM/CON recall semantics; self-recall does not erase historical artifacts.",
    }

    gaps = []
    for imp in imports:
        rec = sem_records.get(imp["coordinate"], {})
        if not rec.get("source_verified", False) or not rec.get("contract_source_complete", False):
            gaps.append({
                "identity":f"GAP-{slug(lib_id)}-{imp['coordinate']}-UPSTREAM",
                "owner":imp["coordinate"],"blocked_scope":f"Exact admitted import or requirement from {imp['coordinate']} {imp['name']}",
                "status":"OPEN_EXTERNAL","current_evidence":rec.get("posture", rec.get("registry_disposition", "UNKNOWN")),
                "required_evidence":"Owner-local verified source, exact public contract identity/edition, and operation/authority evidence.",
                "dependencies":[imp["coordinate"]],"closure_rule":"Reconcile against the owner; never create a local alias or substitute.",
                "reopening_rule":"Reopen on owner edition change, recall, or source verification failure.","certification_impact":"BLOCKS_RATIFICATION_WHERE_LOAD_BEARING",
            })
    gaps += [
        {"identity":f"GAP-{slug(lib_id)}-DATA-REGISTRY-RATIFICATION","owner":"Data Sovereign Library Registry","blocked_scope":"Permanent coordinate and owner ratification","status":"OPEN_INTERNAL","current_evidence":"This package is a review candidate.","required_evidence":"Independent ownership review and registry ratification.","dependencies":[],"closure_rule":"Ratify only after no collision, dependency cycle, or unowned behavior remains.","reopening_rule":"Any new counterexample or owner collision.","certification_impact":"BLOCKS_RATIFICATION"},
        {"identity":f"GAP-{slug(lib_id)}-RUST-COMPILATION","owner":lib_id,"blocked_scope":"Rust API candidate compilation and source/API parity","status":"OPEN_IMPLEMENTATION","current_evidence":"Signatures are candidates; no SAN Rust implementation is produced in this pass.","required_evidence":"Owner-reviewed Rust implementation, cargo fmt/check/test/clippy and source-to-spec parity.","dependencies":[],"closure_rule":"All gates pass with exact implementation mapping.","reopening_rule":"API or law change.","certification_impact":"BLOCKS_IMPLEMENTATION_VERIFICATION"},
        {"identity":f"GAP-{slug(lib_id)}-PROVIDER-CONFORMANCE","owner":"Independent Assurance","blocked_scope":"Provider/runtime conformance","status":"OPEN_EXTERNAL","current_evidence":"Official documentation only; no independent provider suite executed.","required_evidence":"Exact product/version/configuration conformance and fault-injection results.","dependencies":[],"closure_rule":"Independent verifier accepts all mandatory vectors.","reopening_rule":"Provider upgrade, configuration change, incident, or recall.","certification_impact":"BLOCKS_PRODUCTION"},
    ]

    conformance = conformance_for(defn, lib_id)
    proof_obligations = {
        "identity":f"PROOF-OBLIGATIONS-{lib_id}","edition":1,"owner":lib_id,
        "obligations":[{
            "identity":f"PROOF-{slug(law_rec['identity'])}","law":law_rec["identity"],"status":"AUTHORED_NOT_EXECUTED",
            "required_evidence":["positive witness","negative twin","boundary max","boundary max-plus-one","mutation test","exhaustion test"] + (["replay/metamorphic test"] if any(c.get("law")==law_rec["identity"] and c.get("kind")=="REPLAY" and c.get("disposition")!="INAPPLICABLE" for c in conformance["cases"]) else []),
            "implementation_locus":"Owner-reviewed Rust implementation not present in this pass.","independent_verifier":False,
        } for law_rec in defn["laws"]],
        "operation_census":{"specified":len(defn["operations"]),"implemented":0,"executed":0},
        "gaps":[g["identity"] for g in gaps],
        "positive_witnesses":"Authored in conformance matrix, not executed.",
        "negative_twins":"Authored in conformance matrix, not executed.",
        "mutation_tests":"Specified, not executed.",
        "executable_verticals":False,"independent_review":False,"ratification_evidence":None,"certification_evidence":None,
    }

    dependency_nodes = [lib_id] + [imp["coordinate"] for imp in imports] + hard_data
    dependency_edges = ([{"from":imp["coordinate"],"to":lib_id,"kind":"EXACT_TYPED_IMPORT","hard":True} for imp in imports]
                        + [{"from":dep,"to":lib_id,"kind":"DATA_SEMANTIC_DEPENDENCY","hard":True} for dep in hard_data])
    dependency_dag = {"identity":f"DEPENDENCY-DAG-{lib_id}","edition":1,"nodes":sorted(set(dependency_nodes)),"edges":dependency_edges,"semantic_seams":[f"SEAM-{slug(lib_id)}-{slug(seam)}" for seam in seams],"acyclic":True}

    diagnostics = diagnostics_for(defn, lib_id)
    refusals_obj = {"identity":f"REFUSALS-{lib_id}","edition":1,"owner":lib_id,"family":f"{camel(lib_id.replace('DAT-',''))}Refusal","variants":defn["refusals"],"precedence":sorted([{ "refusal":r["identity"],"order":r["validation_precedence"]} for r in defn["refusals"]],key=lambda x:x["order"]),"opaque_strings_forbidden":True}

    source_graph = {
        "identity":f"SOURCE-GRAPH-{lib_id}","edition":1,
        "sources":[s["identity"] for s in source_records] + [row["path"] for row in source_locks[:3]],
        "claims":[{"identity":f"CLAIM-{slug(lib_id)}-{i:02d}","statement":s["supported_propositions"][0],"source":s["identity"],"limitations":s["limitations"],"decision":f"Adopt as boundary/operation/failure evidence; never as owner authority."} for i,s in enumerate(source_records,1)],
        "decisions":[d["identity"] for d in defn["decisions"]],
        "laws":[l["identity"] for l in defn["laws"]],
        "artifacts":["SPEC.json","DOMAIN-MODEL.json","OPERATIONS.json","LAWS.json","CONFORMANCE-MATRIX.json"],
        "closure":"Every material source supports at least one explicit claim; every adopted claim retains limitations and affected artifacts.",
    }

    implementation_packet = {
        "identity":f"IMPLEMENTATION-PACKET-{lib_id}","edition":1,"status":"READY_FOR_OWNER_REVIEW_NOT_IMPLEMENTATION_COMPLETE",
        "recommended_module":rust_api["module_candidate"],"crate_decision":"Begin as a module in a shared pure no_std Data authoring crate; split only after measured independent boundary proof.",
        "implementation_order":["types and carriers","budget precharge","admission","pure operations","laws and property tests","compiler descriptor projection","conformance corpus","source/API parity"],
        "type_mapping":[{"spec":t["semantic_identity"],"candidate_rust":t["candidate_rust_name"],"status":"CANDIDATE"} for t in rust_types],
        "operation_mapping":[{"operation":o["identity"],"rust_symbol":o["rust_symbol"],"signature":o["candidate_signature"],"status":"CANDIDATE_NOT_COMPILED"} for o in defn["operations"]],
        "law_mapping":[{"law":l["identity"],"operations":l["operations_affected"],"test_oracles":[c["identity"] for c in conformance["cases"] if c.get("law")==l["identity"]]} for l in defn["laws"]],
        "refusal_mapping":[{"refusal":r["identity"],"variant":r["variant"],"loci":r["production_locus"]} for r in defn["refusals"]],
        "required_rust_gates":["cargo fmt --all -- --check","cargo check --workspace --all-targets --all-features","cargo test --workspace --all-features","cargo clippy --workspace --all-targets --all-features -- -D warnings","no_std/unsafe/provider dependency checks"],
        "implementation_claim":False,"compiler_integration_claim":False,"runtime_claim":False,"provider_conformance_claim":False,
    }

    status = {"identity":f"STATUS-{lib_id}","edition":1,"status":STATUS,"certification":CERTIFICATION,**deepcopy(COMPLETION_FALSE),"blocking_gaps":[g["identity"] for g in gaps]}

    artifacts = {
        "SPEC.json":spec,
        "SPEC.schema.json":SPEC_SCHEMA,
        "CONTEXT-SPEC.json":context_spec,
        "CONTEXT-SPEC.schema.json":CONTEXT_SCHEMA,
        "DOMAIN-MODEL.json":domain_model,
        "ONTOLOGY.json":ontology,
        "VOCABULARY.json":{"identity":f"VOCABULARY-{lib_id}","edition":1,"owner":lib_id,"terms":defn["terms"],"false_twins":defn["false_twins"],"prohibited_ambiguous_terms":defn["false_twins"],"imports":[{"coordinate":i["coordinate"],"name":i["name"],"translation":"Use exact admitted owner values; no local aliases."} for i in imports]},
        "TYPES.json":{"identity":f"TYPES-{lib_id}","edition":1,"owner":lib_id,"types":defn["types"],"carrier_admission_law":"Only bounded carriers deserialize. Admitted/proof/authority values have private fields and no Deserialize constructor."},
        "STATES.json":{"identity":f"STATES-{lib_id}","edition":1,"owner":lib_id,"state_machine":defn["state_machine"]},
        "TRANSITIONS.json":{"identity":f"TRANSITIONS-{lib_id}","edition":1,"owner":lib_id,"machine":defn["state_machine"]["identity"],"matrix":defn["state_machine"]["matrix"],"totality_expected_cells":defn["state_machine"]["totality_expected_cells"]},
        "OPERATIONS.json":{"identity":f"OPERATIONS-{lib_id}","edition":1,"owner":lib_id,"operations":defn["operations"],"exact_signature_required":True,"all_pure":True},
        "RUST-API.json":rust_api,
        "DECISIONS.json":{"identity":f"DECISIONS-{lib_id}","edition":1,"owner":lib_id,"decisions":defn["decisions"],"hidden_decisions_forbidden":True},
        "CONTRACTS.json":contracts,
        "LAWS.json":{"identity":f"LAWS-{lib_id}","edition":1,"owner":lib_id,"laws":defn["laws"],"bidirectional_coverage":"Every law maps to operations and conformance cases; every semantic operation branch must map back to a law or decision in implementation."},
        "REFUSALS.json":refusals_obj,
        "BUDGETS.json":{"identity":f"BUDGETS-{lib_id}","edition":1,"owner":lib_id,"budgets":[defn["budget"]],"unbounded_work_forbidden":True},
        "CAPABILITIES.json":capabilities,
        "EVOLUTION.json":evolution,
        "COMPILER-QUERIES.json":{"identity":f"COMPILER-QUERIES-{lib_id}","edition":1,"owner":lib_id,"queries":compiler_queries,"family_local_compiler_forbidden":True},
        "IR.json":ir,
        "VALIDATION.json":validation,
        "LOWERING.json":lowering,
        "RUNTIME-OBLIGATIONS.json":runtime_obligations,
        "DIAGNOSTICS.json":{"identity":f"DIAGNOSTICS-{lib_id}","edition":1,"owner":lib_id,"diagnostics":diagnostics,"unbounded_hostile_echo_forbidden":True},
        "DEPENDENCY-DAG.json":dependency_dag,
        "PROOF-OBLIGATIONS.json":proof_obligations,
        "GAPS.json":{"identity":f"GAPS-{lib_id}","edition":1,"gaps":gaps,"none_suppressed":True},
        "CONFORMANCE-MATRIX.json":conformance,
        "RESEARCH-SOURCES.json":{"identity":f"RESEARCH-SOURCES-{lib_id}","edition":1,"sources":source_records,"secondary_only_laws":[],"source_conflicts":[],"research_complete":False},
        "SOURCE-GRAPH.json":source_graph,
        "IMPLEMENTATION-PACKET.json":implementation_packet,
        "STATUS.json":status,
    }

    readme = f"""# {lib_id} · {lib['title']}

**Status:** `{STATUS}`  
**Certification:** `{CERTIFICATION}`

## Sovereign question

{lib['question']}

## Boundary

Owns:
{chr(10).join('- ' + x for x in defn['owned'])}

Explicitly excludes:
{chr(10).join('- ' + x for x in defn['exclusions'])}

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

{chr(10).join('- ' + x for x in hard_data) if hard_data else '- No first-batch Data Sovereign Library dependency.'}

## Reciprocal semantic seams

{chr(10).join('- ' + x for x in seams) if seams else '- None in this edition.'}

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
"""
    return {"artifacts":artifacts,"readme":readme,"definition":defn}


def build_hard_dag() -> dict[str, Any]:
    deps: dict[str, list[str]] = {
        "DAT-COLLECTION":[],
        "DAT-DATA-CUT":["DAT-COLLECTION"],
        "DAT-DISTRIBUTION":["DAT-COLLECTION"],
        "DAT-SOURCE-OBSERVATION":[],
        "DAT-SOURCE-SNAPSHOT":["DAT-SOURCE-OBSERVATION","DAT-DATA-CUT"],
        "DAT-SOURCE-CONTINUATION":["DAT-SOURCE-OBSERVATION"],
        "DAT-SOURCE-CHANGE-STREAM":["DAT-SOURCE-OBSERVATION","DAT-SOURCE-CONTINUATION"],
        "DAT-SNAPSHOT-CONTINUATION-STITCHING":["DAT-DATA-CUT","DAT-SOURCE-SNAPSHOT","DAT-SOURCE-CONTINUATION","DAT-SOURCE-CHANGE-STREAM"],
        "DAT-DATA-PRODUCT":["DAT-COLLECTION","DAT-DATA-CUT","DAT-DISTRIBUTION"],
        "DAT-RELATIONAL-COLLECTION-ALGEBRA":["DAT-COLLECTION"],
        "DAT-DOCUMENT-VARIANT-ALGEBRA":["DAT-COLLECTION"],
        "DAT-TIME-SERIES-SIGNAL-ALGEBRA":["DAT-COLLECTION"],
        "DAT-GRAPH-PATH-ALGEBRA":["DAT-COLLECTION"],
        "DAT-SPATIAL-COVERAGE-ALGEBRA":["DAT-COLLECTION"],
        "DAT-ARRAY-TENSOR-ALGEBRA":["DAT-COLLECTION"],
        "DAT-SEARCH-RANKING-ALGEBRA":["DAT-COLLECTION"],
        "DAT-VECTOR-RETRIEVAL-ALGEBRA":["DAT-COLLECTION"],
        "DAT-EVENT-OBJECT-PROCESS-ALGEBRA":["DAT-COLLECTION"],
        "DAT-ANALYTICAL-GRAIN-METRIC":["DAT-COLLECTION","DAT-DATA-CUT","DAT-RELATIONAL-COLLECTION-ALGEBRA"],
        "DAT-STATISTICAL-STUDY-ESTIMATE":["DAT-COLLECTION","DAT-DATA-CUT"],
        "DAT-FORECAST-PRODUCT":["DAT-STATISTICAL-STUDY-ESTIMATE","DAT-TIME-SERIES-SIGNAL-ALGEBRA"],
        "DAT-EXPERIMENT-ANALYSIS":["DAT-STATISTICAL-STUDY-ESTIMATE","DAT-ANALYTICAL-GRAIN-METRIC"],
        "DAT-CAUSAL-ANALYSIS":["DAT-STATISTICAL-STUDY-ESTIMATE","DAT-EXPERIMENT-ANALYSIS"],
        "DAT-OPTIMIZATION-SCENARIO":["DAT-STATISTICAL-STUDY-ESTIMATE"],
        "DAT-FEATURE-DATASET":["DAT-COLLECTION","DAT-DATA-CUT","DAT-TIME-SERIES-SIGNAL-ALGEBRA"],
        "DAT-TRAINING-EVALUATION-DATASET":["DAT-COLLECTION","DAT-DATA-CUT","DAT-FEATURE-DATASET"],
        "DAT-RETRIEVAL-CONTEXT-DATASET":["DAT-COLLECTION","DAT-DATA-CUT","DAT-SEARCH-RANKING-ALGEBRA","DAT-VECTOR-RETRIEVAL-ALGEBRA"],
        "DAT-INCREMENTAL-COMPUTATION":["DAT-SOURCE-CHANGE-STREAM","DAT-RELATIONAL-COLLECTION-ALGEBRA"],
        "DAT-MATERIALIZED-RESULT":["DAT-DATA-CUT","DAT-INCREMENTAL-COMPUTATION"],
        "DAT-HISTORICAL-RECALCULATION":["DAT-DATA-CUT","DAT-MATERIALIZED-RESULT"],
        "DAT-ANALYTICAL-RESTATEMENT":["DAT-DATA-CUT","DAT-HISTORICAL-RECALCULATION"],
        "DAT-ANALYTICAL-TABLE-SNAPSHOT":["DAT-COLLECTION","DAT-DATA-CUT"],
        "DAT-ANALYTICAL-SERVING-CUT":["DAT-DATA-CUT","DAT-DISTRIBUTION","DAT-ANALYTICAL-TABLE-SNAPSHOT"],
        "DAT-DATA-SHARING-COLLABORATION":["DAT-DISTRIBUTION","DAT-ANALYTICAL-SERVING-CUT"],
    }
    edges = []
    for node, prerequisites in deps.items():
        for prerequisite in prerequisites:
            edges.append({"from":prerequisite,"to":node,"kind":"HARD_DATA_SEMANTIC_DEPENDENCY"})
    # Topological order.
    indegree = {n:0 for n in deps}
    nexts: dict[str,list[str]] = defaultdict(list)
    for e in edges:
        indegree[e["to"]]+=1
        nexts[e["from"]].append(e["to"])
    q = deque(sorted([n for n,d in indegree.items() if d==0]))
    order=[]
    while q:
        n=q.popleft(); order.append(n)
        for m in sorted(nexts[n]):
            indegree[m]-=1
            if indegree[m]==0:q.append(m)
    return {"identity":"SAN-DATA-HARD-DEPENDENCY-DAG","edition":1,"nodes":sorted(deps),"edges":edges,"topological_order":order,"acyclic":len(order)==len(deps),"strongly_connected_components":[[n] for n in order]}


def build_semantic_seams(hard_dag: dict[str, Any]) -> dict[str, Any]:
    seams = [
        {"identity":"SEAM-DAT-DISTRIBUTION-DATA-CUT","consumer":"DAT-DISTRIBUTION","provider":"DAT-DATA-CUT","direction":"OPTIONAL_EXACT_CUT_BINDING","requirement":"An immutable exact distribution may require a verified data cut; rolling distributions remain possible.","offer":"AdmittedDataCut + verification evidence","refusals":["EXACT-CUT-NOT-BOUND"],"hard_dependency":False},
        {"identity":"SEAM-DAT-SOURCE-OBSERVATION-SEM-SCHEMA","consumer":"DAT-SOURCE-OBSERVATION","provider":"SEM-030","direction":"SOURCE_STRUCTURE_TO_SCHEMA_ADMISSION","requirement":"Source structural observation submitted as hostile carrier, never self-elevated.","offer":"Admitted Schema or typed refusal","refusals":["SOURCE-CLAIM-ELEVATION"],"hard_dependency":False},
        {"identity":"SEAM-DAT-SOURCE-OBSERVATION-APPLICATION-FACT","consumer":"DAT-SOURCE-OBSERVATION","provider":"Host Role Composition / Application Kernel","direction":"ANALYTICAL_REENTRY","requirement":"Any authoritative mutation or fact admission re-enters through the application boundary.","offer":"Committed journal fact / receipt","refusals":["SOURCE-CLAIM-ELEVATION"],"hard_dependency":False},
        {"identity":"SEAM-DAT-CONTINUATION-SNAPSHOT","consumer":"DAT-SOURCE-CONTINUATION","provider":"DAT-SOURCE-SNAPSHOT","direction":"FRONTIER_CORRESPONDENCE","requirement":"Typed snapshot frontier and overlap relation without reciprocal crate dependency.","offer":"SnapshotContinuationBinding","refusals":["HISTORY-GAP-UNBRIDGED"],"hard_dependency":False},
        {"identity":"SEAM-DAT-CUT-INDEPENDENT-ASSURANCE","consumer":"DAT-DATA-CUT","provider":"Independent Assurance","direction":"EVIDENCE_APPRAISAL","requirement":"Cut verification is independently appraised; semantic owner does not self-certify.","offer":"Attestation/verification result","refusals":["COMPLETENESS-OVERCLAIM"],"hard_dependency":False},
        {"identity":"SEAM-DAT-STITCHING-RUNTIME","consumer":"DAT-SNAPSHOT-CONTINUATION-STITCHING","provider":"Runtime Mechanism","direction":"REFERENCE_SEMANTICS_TO_EXECUTION","requirement":"Runtime implementation proves equivalence to pure stitching laws and finite budgets.","offer":"Execution receipts and conformance evidence","refusals":["STITCH-PROOF-INCOMPLETE"],"hard_dependency":False},
        {"identity":"SEAM-DAT-DISTRIBUTION-CLIENT","consumer":"Client-Facing Contract","provider":"DAT-DISTRIBUTION","direction":"DISCLOSURE_SAFE_PRESENTATION","requirement":"Client surface consumes bounded qualified distribution/cut claims.","offer":"Distribution contract contribution and qualified access answer","refusals":["ACCESS-CLAIM-OVERREACH"],"hard_dependency":False},
        {"identity":"SEAM-DAT-PRODUCT-CONTRACT","consumer":"DAT-DATA-PRODUCT","provider":"Constitutional Contract Metamodel","direction":"PRODUCT_REQUIREMENT_COMPOSITION","requirement":"Product ports and promises reuse ContractHeader/Requirement/Offer/Satisfaction algebra.","offer":"Resolved contract closure","refusals":["MISSING_OR_INCOMPATIBLE_REQUIREMENT"],"hard_dependency":False},
    ]
    hard_pairs = {tuple(sorted((e["from"],e["to"]))) for e in hard_dag["edges"]}
    for s in seams:
        s["overlaps_hard_edge"] = tuple(sorted((s["consumer"],s["provider"]))) in hard_pairs
    return {"identity":"SAN-DATA-SEMANTIC-SEAM-GRAPH","edition":1,"seams":seams,"hard_edges_duplicated":sum(1 for s in seams if s["overlaps_hard_edge"])}


def build_ownership_matrix() -> dict[str, Any]:
    rows = [
        ("Collection and membership semantics","DAT-COLLECTION","NEW_DATA_OWNER"),
        ("Exact immutable data cut occurrence","DAT-DATA-CUT","NEW_DATA_OWNER"),
        ("Accessible data representation/distribution","DAT-DISTRIBUTION","NEW_DATA_OWNER"),
        ("Data product analytical identity and product lifecycle","DAT-DATA-PRODUCT","NEW_DATA_OWNER_LATER"),
        ("Dataset","DAT-COLLECTION + publication/reference profile","MERGED_PROFILE"),
        ("Dataset series","DAT-COLLECTION + DAT-DATA-PRODUCT + reference profile","MERGED_PROFILE"),
        ("Dataset version","SEM-092 Artifact / Constitution edition / DAT-DATA-CUT as applicable","SPLIT_BY_QUESTION"),
        ("Catalog record","SEM-077 Offering and Catalog / Governed Reference Publication","EXISTING_OWNER_OR_PROJECTION"),
        ("Data service","SEM-084 Integration + SEM-086 Query Contract + Runtime Mechanism + Client-Facing Contract","REJECT_OVERSIZED_COMPOSITE"),
        ("Schema, type and constraints","SEM-030 Schema","EXISTING_OWNER_REUSE"),
        ("Identifier and issuance","SEM-014 Identifier","EXISTING_OWNER_REUSE"),
        ("Identity/denotation","SEM-031 Identity","EXISTING_OWNER_REUSE"),
        ("Namespace","SEM-021 Namespace","EXISTING_OWNER_REUSE"),
        ("Reference and locator","SEM-032 Reference + SEM-033 Locator","EXISTING_OWNER_REUSE"),
        ("Instant/calendar/causality/bitemporality","SEM-011 + SEM-022 + SEM-019 + SEM-026","EXISTING_OWNER_REUSE"),
        ("Provenance and lineage meaning","SEM-027 Provenance; OpenLineage/technical lineage are projections","EXISTING_OWNER_REUSE"),
        ("Evidence and independent verification","SEM-028 Evidence + Independent Assurance","EXISTING_OWNER_REUSE"),
        ("Data quality reusable meaning","SEM-089 Data Quality + Independent Assurance","EXISTING_OWNER_REUSE"),
        ("Source-qualified observation","DAT-SOURCE-OBSERVATION","NEW_DATA_OWNER"),
        ("Source snapshot","DAT-SOURCE-SNAPSHOT","NEW_DATA_OWNER"),
        ("Source continuation coordinate/scope","DAT-SOURCE-CONTINUATION","NEW_DATA_OWNER"),
        ("Source change stream semantics","DAT-SOURCE-CHANGE-STREAM","NEW_DATA_OWNER"),
        ("Snapshot-continuation stitching","DAT-SNAPSHOT-CONTINUATION-STITCHING","NEW_DATA_OWNER"),
        ("Source connector and I/O loop","Provider Implementation Evidence + Runtime Mechanism","PROVIDER_RUNTIME"),
        ("Execution checkpoint/savepoint","Runtime Mechanism","RUNTIME_OWNER"),
        ("Watermark/frontier/window/stateful dataflow","Later Data Sovereign Libraries + Runtime Mechanism implementation","SPLIT_SEMANTICS_MECHANISM"),
        ("Query equivalence/rewrite/search/cost/provider selection","Application Compilation and Closure","COMPILER_OWNER"),
        ("Logical/physical portable plan representation","Portable Target IR","TARGET_OWNER"),
        ("Physical operators, engines, storage commits","Runtime Mechanism / Specialized Engine / Provider Implementation Evidence","RUNTIME_PROVIDER"),
        ("Data catalog publication","SEM-077 Offering and Catalog + Governed Reference Publication","PROJECTION_REFERENCE"),
        ("Analytical dashboard/report/workspace","Client-Facing Contract","CLIENT_PROJECTION"),
        ("Business/industry metric, feature or dataset meaning","Domain Ontology / industry pack importing DATA libraries","ONTOLOGY_PACK"),
        ("Maintenance, repair, backup, restore, compaction and vacuum execution","Management and Repair / Runtime Mechanism","MANAGEMENT_RUNTIME"),
        ("Provider product capabilities","Provider Implementation Evidence","PROVIDER_OWNER"),
    ]
    return {"identity":"SAN-DATA-OWNERSHIP-MATRIX","edition":1,"rows":[{"meaning":m,"owner":o,"disposition":d} for m,o,d in rows],"one_primary_owner_required":True}


def build_sem_crosswalk(sem_data: dict[str, Any]) -> dict[str, Any]:
    reuse_by: dict[str,list[str]] = defaultdict(list)
    for lib_id,defn in LIB_DEFS.items():
        for imp in defn["imports"]:
            reuse_by[imp["coordinate"]].append(lib_id)
    records=[]
    for rec in sem_data["records"]:
        records.append({
            "coordinate":rec["coordinate"],"name":rec["name"],"registry_disposition":rec.get("registry_disposition"),
            "source_present":rec.get("source_present",False),"source_verified":rec.get("source_verified",False),"contract_source_complete":rec.get("contract_source_complete",False),
            "current_posture":rec.get("posture") or next((k for k,v in sem_data.get("posture_counts",{}).items() if False),None),
            "reused_by_first_batch":sorted(reuse_by.get(rec["coordinate"],[])),
            "local_data_duplicate_forbidden":True,
            "gap_if_unavailable":None if rec.get("source_verified") and rec.get("contract_source_complete") else f"GAP-UPSTREAM-{rec['coordinate']}",
        })
    return {"identity":"SAN-DATA-EXISTING-SEM-CROSSWALK","edition":1,"registered_sem_coordinates":sem_data["registered_sem_coordinates"],"records":records,"rule":"Missing or incomplete owner contracts remain typed external gaps; no DATA alias/substitute is permitted."}


def build_open_questions() -> dict[str, Any]:
    questions = [
        ("OPEN-DATA-SERVICE-SOVEREIGNTY","Does any provider-neutral Data Service meaning survive decomposition into Integration, Query Contract, Distribution, Serving Cut, Runtime endpoint and Client-Facing Contract?","BOUNDARY_ADJUDICATION"),
        ("OPEN-DATA-ASSET-PROFILE","Is Data Asset merely an Artifact/Offering/Catalog classification, or is a narrower reusable DATA subject needed?","OWNERSHIP"),
        ("OPEN-SERIES-PROFILE","Are dataset series always Collection/Product profiles, or do any cross-domain series laws justify a separate owner?","BOUNDARY_ADJUDICATION"),
        ("OPEN-MULTI-SOURCE-CUT","What provider-neutral guarantees can be claimed for coherent cuts across unrelated source systems without a shared transaction authority?","SEMANTICS_AND_PROVIDER"),
        ("OPEN-SOURCE-FINALIZATION","Should source object/export finalization remain part of Source Snapshot or become an independent source-observation protocol?","SPLIT_TEST"),
        ("OPEN-EXTRACTION-READ","Does source-side projection/filter/pagination have enough independent semantic law to become a library, or remain Source Observation operations/profile data?","SPLIT_TEST"),
        ("OPEN-TRANSFORMATION-PROGRAM","Which provider-neutral transformation-program semantics belong to DATA after expression meaning, compiler plans and runtime execution are removed?","BOUNDARY_ADJUDICATION"),
        ("OPEN-RDF-PROPERTY-GRAPH-SPLIT","Should RDF/entailment and property-graph/path semantics remain separate owners?","SPLIT_TEST"),
        ("OPEN-TIME-SERIES-SIGNAL-SPLIT","Do time-series and general signal-processing semantics evolve independently enough to split?","SPLIT_TEST"),
        ("OPEN-METRIC-GRAIN-SPLIT","Should metric evaluation, grain/dimension modeling and cube/additivity be one library or several dependency-adjacent owners?","SPLIT_TEST"),
        ("OPEN-STATISTICAL-STUDY-SPLIT","Should population/sampling, estimate/uncertainty and analytical study be separate owners?","SPLIT_TEST"),
        ("OPEN-OPTIMIZATION-SIMULATION-SPLIT","Do optimization-result and simulation/scenario product semantics require separate owners?","SPLIT_TEST"),
        ("OPEN-AI-DATA-SPLITS","Should annotation, embedding, prompt/context, agent trace, feedback/preference and evaluation datasets be separate libraries?","SPLIT_TEST"),
        ("OPEN-CLEAN-ROOM-SPLIT","Does controlled collaboration require a separate DATA owner from sharing/federation plus privacy/authorization contracts?","SPLIT_TEST"),
        ("OPEN-PUBLICATION-ATOMICITY","Which parts of atomic multi-surface analytical publication are DATA semantics versus control/runtime protocol?","BOUNDARY_ADJUDICATION"),
        ("OPEN-DERIVATIVE-ERASURE","What proof is possible for erasure propagation through materializations, sketches, models, indexes, caches, exports and backups?","RESEARCH_GAP"),
        ("OPEN-PROVIDER-RECALL","How are historical releases and cuts reassessed when a provider semantic claim or conformance certificate is recalled?","ASSURANCE_GAP"),
        ("OPEN-SOURCE-STRUCTURE-SCHEMA-SEAM","What exact anti-corruption contract admits source structural observations to SEM-030 without source/provider authority leakage?","UPSTREAM_SEAM"),
    ]
    return {"identity":"SAN-DATA-OPEN-QUESTIONS","edition":1,"questions":[{"identity":i,"question":q,"class":c,"status":"OPEN","owner":"TO_BE_ADJUDICATED"} for i,q,c in questions]}


def build_root_gaps(sem_crosswalk: dict[str, Any], boundary_rows: list[dict[str, Any]]) -> dict[str, Any]:
    gaps = [
        {"identity":"GAP-DATA-REGISTRY-NOT-RATIFIED","owner":"Data Sovereign Library Registry","blocked_scope":"Permanent DATA coordinates and ownership authority","status":"OPEN","required_evidence":"Independent boundary review, exact owner approval, no unresolved collision, ratification record.","closure_rule":"Ratification of a dependency-closed registry edition.","certification_impact":"BLOCKS_ALL_CERTIFICATION"},
        {"identity":"GAP-PRIOR-851-LEAF-SOURCE-NOT-IN-HANDOFF","owner":"Prior proposal author/source archive","blocked_scope":"Individual adjudication of the reported 851 generated leaves","status":"OPEN","required_evidence":"Original machine source with stable source occurrences and definitions.","closure_rule":"Import and adjudicate each occurrence; aggregate counts do not prove meaning.","certification_impact":"BLOCKS_RESEARCH_SATURATION_CLAIM"},
        {"identity":"GAP-CMP-TGT-INTEGRATION","owner":"Application Compilation and Closure / Portable Target IR","blocked_scope":"Actual compiler query, CSAG and target-lowering integration","status":"OPEN","required_evidence":"Current owner contracts, implementation, source maps and preservation tests.","closure_rule":"Execute first-batch declarations through current compiler and target gates.","certification_impact":"BLOCKS_COMPILER_INTEGRATION"},
        {"identity":"GAP-RUNTIME-PROVIDER-CONFORMANCE","owner":"Runtime Mechanism / Provider Implementation Evidence / Independent Assurance","blocked_scope":"Exact source/provider execution and fault behavior","status":"OPEN","required_evidence":"Independent product/version/configuration conformance and fault injection.","closure_rule":"All mandatory provider vectors pass or produce lawful refusal.","certification_impact":"BLOCKS_RUNTIME_AND_PRODUCTION"},
        {"identity":"GAP-SNAPSHOT-STITCHING-MODEL-CHECK","owner":"DAT-SNAPSHOT-CONTINUATION-STITCHING","blocked_scope":"Concurrent crash/retry/interleaving proof","status":"OPEN","required_evidence":"TLA+/Alloy/state-machine model plus property/differential tests.","closure_rule":"No safety/liveness counterexample in declared bound and executable runtime trace conformance.","certification_impact":"BLOCKS_STITCHING_CERTIFICATION"},
        {"identity":"GAP-ATOMIC-ANALYTICAL-PUBLICATION","owner":"DAT-ANALYTICAL-SERVING-CUT + Desired-State Control + Runtime Mechanism","blocked_scope":"Atomic cutover across table, catalog, semantic API, cache and BI surface","status":"OPEN","required_evidence":"Provider-neutral publication protocol, fencing, CAS, rollback and fault-injection evidence.","closure_rule":"All partial-publication interleavings refuse or recover.","certification_impact":"BLOCKS_GOVERNED_SERVING_VERTICAL"},
        {"identity":"GAP-RESEARCH-SATURATION","owner":"Data research programme","blocked_scope":"Claim of exhaustive decomposition","status":"OPEN","required_evidence":"Two consecutive materially diverse gap-search waves find no new owner, law, operation, seam, lifecycle, failure family or counterexample.","closure_rule":"Independent red-team confirms every discovered item has a disposition.","certification_impact":"BLOCKS_RESEARCH_COMPLETE"},
    ]
    for rec in sem_crosswalk["records"]:
        if rec["gap_if_unavailable"]:
            gaps.append({"identity":rec["gap_if_unavailable"],"owner":rec["coordinate"],"blocked_scope":f"Exact reuse of {rec['coordinate']} {rec['name']}","status":"OPEN_EXTERNAL","required_evidence":"Verified owner-local source and exact public admitted contract.","closure_rule":"Reconcile to the existing owner; do not create a DATA substitute.","certification_impact":"BLOCKS_DEPENDENT_LIBRARY_IF_LOAD_BEARING"})
    unresolved = sum(1 for row in boundary_rows if row["disposition"]=="OPEN_UNRESOLVED")
    gaps.append({"identity":"GAP-PRIOR-BOUNDARY-ADJUDICATION","owner":"Data Sovereign Library Registry","blocked_scope":f"{unresolved} prior research occurrences remain unresolved","status":"OPEN","required_evidence":"Candidate-level primary research and owner/split/merge adjudication.","closure_rule":"Every occurrence receives a non-open disposition.","certification_impact":"BLOCKS_DECOMPOSITION_RATIFICATION"})
    return {"identity":"SAN-DATA-GAP-LEDGER","edition":1,"gaps":gaps,"certification":"NONE"}


def build_adversarial_reviews() -> dict[str, Any]:
    reviews = [
        ("ADV-01-OWNERSHIP-COLLISION","Ownership collision with existing Sovereign Semantics, Constitutional Contract Metamodel, Application Compilation and Closure, Portable Target IR, Runtime Mechanism and Resource owners","PASS_WITH_OPEN_GAPS","Generic identity, schema, time, provenance, evidence, quality, contracts, compiler search, IR and runtime/provider meanings were rehomed; unresolved upstream source gaps remain."),
        ("ADV-02-FALSE-DECOMPOSITION","False decomposition and over-splitting","PASS_REVIEW_CANDIDATE","Dataset/series/version/service/catalog-record were merged, split or rehomed; later queue remains subject to split/merge review."),
        ("ADV-03-PROVIDER-LEAKAGE","Hidden provider or I/O leakage","PASS","Pure operations author no offers, SDKs, I/O, storage, brokers, clocks, secrets or process loops."),
        ("ADV-04-UNBOUNDED-WORK","Unbounded work, allocation or state","PASS_STRUCTURAL","Every first-batch operation maps to a finite multi-axis budget and aggregate precharge; measurements remain unexecuted."),
        ("ADV-05-ABSENCE-CONFLATION","Absence, null, unknown, default, withheld, redacted and unavailable conflation","PASS","Collection membership and source absence use typed qualified outcomes; defaults cannot grant authority."),
        ("ADV-06-TIME-CONFLATION","Event time, record time, processing time and transaction time conflation","PASS","The first batch imports time owners and expressly refuses source timestamp elevation."),
        ("ADV-07-CUT-CONFLATION","Snapshot, data cut, checkpoint, watermark, cursor, offset and savepoint conflation","PASS","Separate owners and false-twin laws are present."),
        ("ADV-08-DATASET-CONFLATION","Dataset, version, distribution, service and catalog record conflation","PASS","Collection, Cut and Distribution are separate; Data Service and CatalogRecord are rehomed/composite; series/version are profiles or split by question."),
        ("ADV-09-AUTHORITY-LAUNDERING","Authority, evidence and self-certification laundering","PASS_STRUCTURAL","Admitted/proof candidates have private construction, no Deserialize, and certification remains NONE; independent assurance is external."),
        ("ADV-10-EVOLUTION-HAZARDS","Evolution, correction, replay and historical reinterpretation hazards","PASS_WITH_GAPS","Every library contains same-edition mutation prohibition and migration/rebuild/recall posture; executable migration evidence remains open."),
        ("ADV-11-COMPILER-RUNTIME-LEAKAGE","Compiler, IR and runtime ownership leakage","PASS","Family-owned IR/lowering/runtime implementations are not invented; only exact external contracts and obligations are published."),
        ("ADV-12-VACUOUS-COMPLETION","Vacuous tests and symbol-only implementation-complete claims","PASS","Conformance cases are authored but explicitly unexecuted; implementation/compiler/runtime/provider booleans remain false."),
    ]
    return {"identity":"SAN-DATA-ADVERSARIAL-REVIEWS","edition":1,"reviews":[{"identity":i,"challenge":q,"result":r,"finding":f,"certification":"NONE"} for i,q,r,f in reviews]}


def build_war_games() -> list[dict[str, Any]]:
    return [
        {
            "identity":"WAR-DATA-BOUNDED-BATCH-PUBLICATION",
            "title":"Bounded Batch Publication",
            "declaration":"Publish a bounded collection as an exact distribution after a coherent finite cut is verified.",
            "semantic_steps":[
                {"step":1,"owner":"DAT-COLLECTION","action":"Admit collection and membership/duplicate/boundedness semantics.","imports":["SEM-014","SEM-030","SEM-027","SEM-028"]},
                {"step":2,"owner":"DAT-DATA-CUT","action":"Admit immutable exact cut and qualify completeness.","imports":["SEM-011","SEM-025","SEM-026","SEM-027","SEM-028"]},
                {"step":3,"owner":"DAT-DISTRIBUTION","action":"Admit representation/loss/access posture and bind exact cut.","imports":["SEM-003","SEM-020","SEM-033","SEM-060","SEM-081","SEM-082"]},
                {"step":4,"owner":"Application Compilation and Closure","action":"Resolve decisions, obligations and provider-neutral requirements."},
                {"step":5,"owner":"Portable Target IR / Runtime Mechanism","action":"Lower and execute storage/publication plan only after provider evidence."},
            ],
            "runtime_obligations":["finite read/write bounds","atomic immutable cut publication","cut/representation digest receipts","classification/residency/retention enforcement"],
            "required_refusals":["CUT-MEMBERSHIP-NOT-FROZEN","COMPLETENESS-OVERCLAIM","EXACT-CUT-NOT-BOUND","LOSS-UNDISCLOSED","MISSING_PROVIDER_OFFER"],
            "current_result":"MODELLED_NOT_EXECUTED",
        },
        {
            "identity":"WAR-DATA-TRANSACTIONAL-CDC-STITCHING",
            "title":"Transactional CDC to Snapshot Continuation",
            "declaration":"Reconstruct a source collection from one coherent snapshot plus a transaction-aware continuation stream.",
            "semantic_steps":[
                {"step":1,"owner":"DAT-SOURCE-OBSERVATION","action":"Admit source, interface, principal, selection, visibility and structural observations.","imports":["SEM-014","SEM-015","SEM-027","SEM-028","SEM-030","SEM-060"]},
                {"step":2,"owner":"DAT-SOURCE-SNAPSHOT","action":"Admit source cut, segments, isolation/finalization and completeness.","imports":["SEM-011","SEM-019","SEM-026","SEM-099"]},
                {"step":3,"owner":"DAT-SOURCE-CONTINUATION","action":"Admit exact source/query/principal coordinate scope and current horizon eligibility."},
                {"step":4,"owner":"DAT-SOURCE-CHANGE-STREAM","action":"Admit changes, deletes, order scope, transaction visibility and continuity."},
                {"step":5,"owner":"DAT-SNAPSHOT-CONTINUATION-STITCHING","action":"Apply deterministic overlap/dedup/order/transaction laws and produce proof candidate."},
                {"step":6,"owner":"DAT-DATA-CUT","action":"Admit the verified stitched history as a new data-cut candidate."},
            ],
            "runtime_obligations":["consistent snapshot mechanism","retained source history","idempotent capture receipts","transaction grouping/buffering","checkpoint and sink mechanisms remain runtime-owned"],
            "required_refusals":["SNAPSHOT-CUT-INCOHERENT","CONTINUATION-SCOPE-MISMATCH","HISTORY-GAP-UNBRIDGED","TRANSACTION-VISIBILITY-UNKNOWN","UNOBSERVED-INTERVAL","CONFLICTING-DUPLICATE","TRANSACTION-SPLIT"],
            "current_result":"MODELLED_NOT_EXECUTED_AND_MODEL_CHECKING_OPEN",
        },
        {
            "identity":"WAR-DATA-GOVERNED-ANALYTICAL-SERVING",
            "title":"Governed Analytical Serving",
            "declaration":"Serve a coherent analytical cut with exact disclosure, authorization, freshness and provider evidence.",
            "semantic_steps":[
                {"step":1,"owner":"DAT-DATA-CUT","action":"Provide the exact verified analytical cut."},
                {"step":2,"owner":"DAT-DISTRIBUTION","action":"Provide representation and access/loss posture."},
                {"step":3,"owner":"DAT-ANALYTICAL-SERVING-CUT","action":"Later library must define multi-request cut consistency, partial-result and last-known-good semantics."},
                {"step":4,"owner":"SEM-060 / SEM-049 / SEM-050 / SEM-048","action":"Supply authorization, purpose, consent and classification values."},
                {"step":5,"owner":"Application Compilation and Closure","action":"Bind a serving runtime/provider only if all guarantees and evidence satisfy."},
            ],
            "runtime_obligations":["shared snapshot token or equivalent","bounded result streaming","cancellation/timeout","disclosure-safe diagnostics","cache and endpoint behavior are runtime/client-owned"],
            "required_refusals":["ANALYTICAL_SERVING_CUT_NOT_YET_SPECIFIED","AUTHORITY_UNAVAILABLE","MISSING_PROVIDER_CONFORMANCE","PARTIAL_MULTI_SURFACE_PUBLICATION"],
            "current_result":"REFUSE_NOW_BECAUSE_LATER_SERVING_OWNER_AND_PROVIDER_EVIDENCE_ARE_ABSENT",
        },
    ]


def build_research_ledger(source_locks: list[dict[str, Any]]) -> dict[str, Any]:
    local=[]
    for row in source_locks:
        local.append({
            "identity":stable_hash_id("SRC-LOCAL",row["path"]),"title":row["path"],"publisher":"SAN repository/handoff archive","url":f"archive://{row['path']}",
            "edition_or_date":BUILD_DATE,"source_type":row["authority_class"],"authority":"BINDING" if row["authority_class"] in {"BINDING_CONSTITUTION","CURRENT_REGISTRY"} else "RESEARCH_ONLY",
            "sha256":row["sha256"],"supported_propositions":["Source is locked as part of the adjudication basis."],"limitations":["Authority depends on archive precedence; previous proposals remain non-authoritative."],"affected_libraries":FIRST_BATCH_IDS,
        })
    return {"identity":"SAN-DATA-RESEARCH-LEDGER","edition":1,"retrieval_date":BUILD_DATE,"sources":local+deepcopy(WEB_SOURCES),"rule":"Every adopted claim retains exact source, scope, limitations, competing alternatives and affected artifacts; vendor documentation never becomes semantic owner authority."}


def root_readme(catalog: dict[str, Any], counts: dict[str, Any]) -> str:
    first = "\n".join(f"{i+1}. `{row['identity']}` — {row['title']}" for i,row in enumerate(catalog["libraries"][:8]))
    return f"""# SAN Data Sovereign Libraries · Edition 1

**Status:** `{STATUS}`  
**Certification:** `{CERTIFICATION}`

This package adjudicates the reusable Data Sovereign Library boundary against the live SAN constitution, 99 existing Sovereign Semantic Libraries, compiler/target/runtime/resource owners, current reference implementations, primary standards, official system documentation, and prior candidate corpora.

It deliberately publishes full implementation-ready SSPEC packages for only the first eight dependency-safe libraries. Later candidates remain a queue, not copy-shaped specifications.

## Canonical first batch

{first}

## Counts

```json
{json.dumps(counts, indent=2, sort_keys=True)}
```

## Authority rule

Binding constitution and current owner registries outrank research and previous proposals. Missing owner contracts remain typed gaps. No local aliases, compatibility shims, placeholder passports, provider offers, or self-issued evidence are created.

## Verification

Run:

```bash
python VERIFY/verify.py .
```

The verifier checks schemas, identity/edition discipline, reference closure, operation/API/law/refusal/budget parity, total state matrices, hard-DAG acyclicity, semantic-seam separation, carrier/admitted construction posture, finite hostile work, provider neutrality, research-claim closure, status honesty, fixtures, and manifests.
"""


def codex_start() -> str:
    return """# Codex Start Here

1. Read `README.md`, `CATALOG.json`, `OWNERSHIP-MATRIX.json`, `BOUNDARY-ADJUDICATION.json`, `HARD-DEPENDENCY-DAG.json`, and `FIRST-BATCH-SELECTION.json`.
2. Treat all eight specifications as `REVIEW_CANDIDATE`, certification `NONE`.
3. Do not write a library until its external Sovereign Semantic imports and current compiler contracts are reconciled.
4. Use `IMPLEMENTATION-PACKET.json` as an implementation plan, not as evidence of implementation.
5. Implement carriers and budget precharge first; admitted values have private fields and no `Deserialize` constructor.
6. Keep semantic requirements separate from provider offers and runtime mechanisms.
7. Run `python VERIFY/verify.py .` after every generated or manual change.
8. No analytical result may mutate application state directly; mutation re-enters Host Role Composition → Kernel.
"""



def build_boundary_adjudication() -> dict[str, Any]:
    rows = parse_prior_occurrences()
    counts = defaultdict(int)
    for row in rows:
        counts[row["disposition"]] += 1
    return {
        "identity": "SAN-DATA-BOUNDARY-ADJUDICATION",
        "edition": 1,
        "status": STATUS,
        "certification": CERTIFICATION,
        "rule": "Every located prior occurrence is retained and assigned an explicit disposition; aggregate prior counts unavailable as individual source records remain a typed gap rather than invented rows.",
        "allowed_dispositions": [
            "EXISTING_OWNER_REUSE", "NEW_DATA_OWNER", "ONTOLOGY_OR_REFERENCE_PACK",
            "COMPILER_CONTEXT", "PORTABLE_TARGET_IR", "RUNTIME_OR_PLATFORM",
            "PROVIDER_CAPABILITY", "PROJECTION_OR_VIEW", "MERGED",
            "REJECTED_DUPLICATE", "OPEN_UNRESOLVED",
        ],
        "occurrence_count": len(rows),
        "counts_by_disposition": dict(sorted(counts.items())),
        "occurrences": rows,
        "unmaterialized_prior_aggregate": {
            "claim": "Prior research cited 219 subdomains and 851 generated leaves, but the handoff archive does not contain independently addressable source rows for all of them.",
            "disposition": "OPEN_UNRESOLVED",
            "gap": "GAP-PRIOR-AGGREGATE-LEAVES-UNAVAILABLE",
            "rule": "Do not fabricate occurrence rows from aggregate counts.",
        },
    }


def build_catalog(boundary: dict[str, Any], dag: dict[str, Any]) -> dict[str, Any]:
    groups: dict[str, list[str]] = defaultdict(list)
    for lib in CANONICAL_LIBRARIES:
        groups[lib["group"]].append(lib["identity"])
    return {
        "identity": PACKAGE_ID,
        "edition": PACKAGE_EDITION,
        "title": "SAN Data Sovereign Library Registry",
        "status": STATUS,
        "certification": CERTIFICATION,
        "registry_name": "Data Sovereign Library Registry",
        "architectural_rule": "Smallest cohesive provider-neutral semantic owners; open-world formats, products, providers, recipes and runtime mechanisms remain outside sovereign library ownership.",
        "libraries": deepcopy(CANONICAL_LIBRARIES),
        "first_batch": FIRST_BATCH_IDS,
        "later_queue": [r["identity"] for r in CANONICAL_LIBRARIES if r["status"] == "LATER_QUEUE"],
        "groups": [{"title": k, "libraries": v} for k, v in sorted(groups.items())],
        "boundary_occurrences_adjudicated": boundary["occurrence_count"],
        "hard_dependency_dag": dag["identity"],
        "completion": deepcopy(COMPLETION_FALSE),
    }


def build_implementation_order(dag: dict[str, Any]) -> dict[str, Any]:
    rows = []
    for pos, lib_id in enumerate(dag["topological_order"], 1):
        lib = LIB_INDEX[lib_id]
        rows.append({
            "position": pos,
            "identity": lib_id,
            "title": lib["title"],
            "phase": lib["phase"],
            "batch": "FIRST_EIGHT_FULL_SSPEC" if lib_id in FIRST_BATCH_IDS else "LATER_EVIDENCE_QUEUE",
            "prerequisites": [e["from"] for e in dag["edges"] if e["to"] == lib_id],
            "status": "IMPLEMENTATION_PACKET_AUTHORED_NOT_IMPLEMENTED" if lib_id in FIRST_BATCH_IDS else "BOUNDARY_REVIEW_QUEUE",
        })
    return {"identity":"SAN-DATA-IMPLEMENTATION-ORDER","edition":1,"rows":rows,"rule":"Order follows hard semantic prerequisites only; reciprocal seams do not become Cargo cycles."}


def build_first_batch_selection(dag: dict[str, Any]) -> dict[str, Any]:
    rationale = {
        "DAT-COLLECTION":"Foundational identity and membership semantics used by later products and algebras.",
        "DAT-DATA-CUT":"Exact immutable occurrence of a collection; necessary before snapshots, publications and reproducibility.",
        "DAT-DISTRIBUTION":"Separates accessible representation from collection, service, storage and provider protocol.",
        "DAT-SOURCE-OBSERVATION":"Establishes the non-elevation boundary from hostile foreign claims to admitted meaning.",
        "DAT-SOURCE-SNAPSHOT":"Defines coherent finite source observation independently of table snapshots and checkpoints.",
        "DAT-SOURCE-CONTINUATION":"Defines resumable source coordinates independently of messages, offsets, checkpoints and watermarks.",
        "DAT-SOURCE-CHANGE-STREAM":"Defines observed source mutations and transaction/order posture over an admitted continuation.",
        "DAT-SNAPSHOT-CONTINUATION-STITCHING":"Closes the first nontrivial vertical by proving or refusing snapshot-plus-change reconstruction.",
    }
    return {
        "identity":"SAN-DATA-FIRST-BATCH-SELECTION","edition":1,"status":STATUS,
        "selection_rule":"Choose the smallest dependency-closed set that establishes collection/cut representation and the complete source snapshot-to-continuation seam without importing later analytics or runtime mechanisms.",
        "libraries":[{
            "position":i+1,"identity":lib_id,"title":LIB_INDEX[lib_id]["title"],
            "rationale":rationale[lib_id],
            "hard_prerequisites":[e["from"] for e in dag["edges"] if e["to"]==lib_id],
        } for i,lib_id in enumerate(FIRST_BATCH_IDS)],
        "dependency_closed_within_first_batch": all(e["from"] in FIRST_BATCH_IDS for e in dag["edges"] if e["to"] in FIRST_BATCH_IDS),
        "excluded_from_first_batch":[
            {"identity":"DAT-DATA-PRODUCT","reason":"Requires collection, cut and distribution closure but is not required to prove source acquisition."},
            {"identity":"DAT-RELATIONAL-COLLECTION-ALGEBRA","reason":"Query and transformation semantics follow the acquisition foundation."},
            {"identity":"DAT-ANALYTICAL-GRAIN-METRIC","reason":"Requires modality algebra and exact cuts."},
            {"identity":"DAT-ANALYTICAL-SERVING-CUT","reason":"Requires table/persistence and serving contracts not yet authored."},
        ],
    }


def build_sspec_compliance(spec_artifacts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    rows=[]
    for lib_id, bundle in spec_artifacts.items():
        sections=bundle["artifacts"]["SPEC.json"]["sspec_sections"]
        rows.append({
            "identity":lib_id,"section_count":len(sections),
            "published":sum(1 for x in sections if x["disposition"]=="PUBLISHED"),
            "external_contract":sum(1 for x in sections if x["disposition"]=="EXTERNAL_CONTRACT"),
            "inapplicable":sum(1 for x in sections if x["disposition"]=="INAPPLICABLE"),
            "open_gap":sum(1 for x in sections if x["disposition"]=="OPEN_GAP"),
            "all_22_present":len(sections)==22 and {x["section"] for x in sections}==set(SSPEC_SECTION_NAMES),
            "status":STATUS,"certification":CERTIFICATION,
        })
    return {"identity":"SAN-DATA-SSPEC-COMPLIANCE-MATRIX","edition":1,"rows":rows,"rule":"Presence and structural consistency are not semantic execution, implementation, ratification or certification."}


def build_conformance_coverage(spec_artifacts: dict[str, dict[str, Any]]) -> dict[str, Any]:
    rows=[]
    for lib_id,bundle in spec_artifacts.items():
        a=bundle["artifacts"]
        c=a["CONFORMANCE-MATRIX.json"]
        rows.append({
            "identity":lib_id,
            "operations":len(a["OPERATIONS.json"]["operations"]),
            "laws":len(a["LAWS.json"]["laws"]),
            "refusals":len(a["REFUSALS.json"]["variants"]),
            "decisions":len(a["DECISIONS.json"]["decisions"]),
            "types":len(a["TYPES.json"]["types"]),
            "states":len(a["STATES.json"]["state_machine"]["states"]),
            "commands":len(a["STATES.json"]["state_machine"]["commands"]),
            "state_matrix_cells":len(a["TRANSITIONS.json"]["matrix"]),
            "conformance_cases":len(c["cases"]),
            "executed_cases":sum(1 for x in c["cases"] if x.get("status") not in {"AUTHORED_NOT_EXECUTED","INAPPLICABLE"}),
            "provider_conformance_verified":False,
        })
    return {"identity":"SAN-DATA-CONFORMANCE-COVERAGE","edition":1,"rows":rows,"all_execution_unverified":True}


def build_package_counts(spec_artifacts: dict[str, dict[str, Any]], boundary: dict[str, Any], dag: dict[str, Any], seams: dict[str, Any]) -> dict[str, Any]:
    return {
        "canonical_libraries":len(CANONICAL_LIBRARIES),
        "first_batch_full_specs":len(FIRST_BATCH_IDS),
        "later_queue":len(CANONICAL_LIBRARIES)-len(FIRST_BATCH_IDS),
        "prior_occurrences_adjudicated":boundary["occurrence_count"],
        "hard_dag_nodes":len(dag["nodes"]),
        "hard_dag_edges":len(dag["edges"]),
        "hard_dag_cycles":0 if dag["acyclic"] else 1,
        "semantic_seams":len(seams["seams"]),
        "operations":sum(len(x["artifacts"]["OPERATIONS.json"]["operations"]) for x in spec_artifacts.values()),
        "laws":sum(len(x["artifacts"]["LAWS.json"]["laws"]) for x in spec_artifacts.values()),
        "refusals":sum(len(x["artifacts"]["REFUSALS.json"]["variants"]) for x in spec_artifacts.values()),
        "decisions":sum(len(x["artifacts"]["DECISIONS.json"]["decisions"]) for x in spec_artifacts.values()),
        "types":sum(len(x["artifacts"]["TYPES.json"]["types"]) for x in spec_artifacts.values()),
        "conformance_cases":sum(len(x["artifacts"]["CONFORMANCE-MATRIX.json"]["cases"]) for x in spec_artifacts.values()),
        "certified_libraries":0,
    }


def per_library_verifier_source() -> str:
    return r'''#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path

ID_RE=re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$")

def load(p): return json.loads(p.read_text(encoding="utf-8"))
def fail(msg): print("FAIL",msg); raise SystemExit(1)

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
    spec=load(root/"SPEC.json"); ops=load(root/"OPERATIONS.json")["operations"]
    rust=load(root/"RUST-API.json"); laws=load(root/"LAWS.json")["laws"]
    refs=load(root/"REFUSALS.json")["variants"]; decs=load(root/"DECISIONS.json")["decisions"]
    budget=load(root/"BUDGETS.json")["budgets"]; st=load(root/"STATES.json")["state_machine"]
    tx=load(root/"TRANSITIONS.json")["matrix"]
    if not ID_RE.fullmatch(spec["identity"]): fail("invalid stable identity")
    if re.search(r"(?:/v\d+|@v\d+|[-_]v\d+)$",spec["identity"],re.I): fail("edition suffix embedded in identity")
    if spec["edition"]<1 or spec["status"]!="REVIEW_CANDIDATE" or spec["certification"]!="NONE": fail("dishonest status")
    opids={x["identity"] for x in ops}; lawids={x["identity"] for x in laws}; refids={x["identity"] for x in refs}; decids={x["identity"] for x in decs}
    if len(opids)!=len(ops) or len(lawids)!=len(laws) or len(refids)!=len(refs) or len(decids)!=len(decs): fail("duplicate local identity")
    api={x["identity"] for x in rust["operations"]}
    if api!=opids: fail("operation/Rust API drift")
    for op in ops:
        if not op["candidate_signature"].startswith("pub fn ") or "Result<" not in op["candidate_signature"]: fail("placeholder signature")
        if not set(op["law_coverage"])<=lawids: fail("unknown law in operation")
        if not set(op["decision_dependencies"])<=decids: fail("unknown decision in operation")
        if op["side_effect_posture"]!="PURE_NO_IO": fail("I/O leakage")
    for law in laws:
        if not set(law["operations_affected"])<=opids: fail("unknown operation in law")
        if not set(law["refusal_on_violation"])<=refids: fail("unknown refusal in law")
    for d in decs:
        if not d.get("absence_semantics"): fail("decision lacks absence semantics")
    for t in rust["types"]:
        if t["kind"] in {"ADMITTED_VALUE","ADMITTED_ENTITY","PROOF","AUTHORITY"} and (not t["fields_private"] or t["deserialize_constructor"]): fail("forgeable admitted/proof type")
    if len(tx)!=len(st["states"])*len(st["commands"]): fail("incomplete state×command matrix")
    if len({(x["state"],x["command"]) for x in tx})!=len(tx): fail("duplicate state cell")
    for b in budget:
        for key in ["max_input_bytes","max_items","max_depth","max_output_bytes","max_iterations"]:
            if not isinstance(b[key],int) or b[key]<=0: fail("unbounded budget")
        if "allocate" not in b["precharge_order"] or b["precharge_order"].index("allocate") < b["precharge_order"].index("charge allocation") or not b["overflow_behavior"].startswith("REFUSE_"): fail("unsafe budget charging")
    print(json.dumps({"result":"PASS","identity":spec["identity"],"operations":len(ops),"laws":len(laws),"state_cells":len(tx)},sort_keys=True))
if __name__=="__main__": main()
'''


def root_verifier_source() -> str:
    return r'''#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, subprocess, sys
from collections import defaultdict, deque
from pathlib import Path
try:
    import jsonschema
except Exception as e:
    print("FAIL jsonschema unavailable",e); raise SystemExit(1)

ID_RE=re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$")
SUFFIX_RE=re.compile(r"(?:/v\d+|@v\d+|[-_]v\d+)$",re.I)
REQUIRED_ROOT=["CODEX-START-HERE.md","CATALOG.json","OWNERSHIP-MATRIX.json","EXISTING-SEM-CROSSWALK.json","BOUNDARY-ADJUDICATION.json","HARD-DEPENDENCY-DAG.json","SEMANTIC-SEAM-GRAPH.json","IMPLEMENTATION-ORDER.json","FIRST-BATCH-SELECTION.json","OPEN-QUESTIONS.json","GAP-LEDGER.json","RESEARCH-LEDGER.json","SSPEC-COMPLIANCE-MATRIX.json","CONFORMANCE-COVERAGE.json","MANIFEST.json","PACKAGE-VERIFY.json","README.md"]
REQUIRED_SPEC=["SPEC.json","SPEC.schema.json","CONTEXT-SPEC.json","CONTEXT-SPEC.schema.json","DOMAIN-MODEL.json","ONTOLOGY.json","VOCABULARY.json","TYPES.json","STATES.json","TRANSITIONS.json","OPERATIONS.json","RUST-API.json","DECISIONS.json","CONTRACTS.json","LAWS.json","REFUSALS.json","BUDGETS.json","CAPABILITIES.json","EVOLUTION.json","COMPILER-QUERIES.json","IR.json","VALIDATION.json","LOWERING.json","RUNTIME-OBLIGATIONS.json","DIAGNOSTICS.json","DEPENDENCY-DAG.json","PROOF-OBLIGATIONS.json","GAPS.json","CONFORMANCE-MATRIX.json","RESEARCH-SOURCES.json","SOURCE-GRAPH.json","IMPLEMENTATION-PACKET.json","STATUS.json","MANIFEST.json","README.md","VERIFY/verify.py"]

def load(p): return json.loads(p.read_text(encoding="utf-8"))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
class V:
    def __init__(self): self.errors=[]; self.checks=0
    def check(self,c,m): self.checks+=1; (None if c else self.errors.append(m))

def acyclic(nodes,edges):
    indeg={n:0 for n in nodes}; nxt=defaultdict(list)
    for e in edges:
        if e["from"] not in indeg or e["to"] not in indeg: return False
        indeg[e["to"]]+=1; nxt[e["from"]].append(e["to"])
    q=deque(sorted(n for n,d in indeg.items() if d==0)); seen=[]
    while q:
        n=q.popleft(); seen.append(n)
        for m in nxt[n]:
            indeg[m]-=1
            if indeg[m]==0:q.append(m)
    return len(seen)==len(nodes)

def detect_fixture(root, fixture):
    import copy
    mut=fixture["mutation"]; kind=mut["kind"]
    cat=copy.deepcopy(load(root/"CATALOG.json")); dag=copy.deepcopy(load(root/"HARD-DEPENDENCY-DAG.json"))
    if kind=="CATALOG_DUPLICATE":
        row=next(x for x in cat["libraries"] if x["identity"]==mut["identity"]); cat["libraries"].append(copy.deepcopy(row))
        ids=[x["identity"] for x in cat["libraries"]]; return "DUPLICATE_IDENTITY" if len(ids)!=len(set(ids)) else None
    if kind=="CATALOG_ADD":
        cat["libraries"].append({"identity":mut["identity"]}); return "EDITION_SUFFIX" if SUFFIX_RE.search(mut["identity"]) else None
    if kind=="DAG_EDGE":
        dag["edges"].append({"from":mut["from"],"to":mut["to"],"kind":"FIXTURE"})
        if mut["from"] not in dag["nodes"] or mut["to"] not in dag["nodes"]: return "UNKNOWN_DEPENDENCY"
        if not acyclic(dag["nodes"],dag["edges"]): return "HARD_DEPENDENCY_CYCLE"
        seams=load(root/"SEMANTIC-SEAM-GRAPH.json")["seams"]
        if any({x["consumer"],x["provider"]}=={mut["from"],mut["to"]} for x in seams): return "SEAM_HARD_EDGE_COLLISION"
        return None
    lib=root/"LIBRARIES"/mut.get("library","DAT-COLLECTION")
    if kind=="REMOVE_STATE_CELL":
        st=load(lib/"STATES.json")["state_machine"]; cells=copy.deepcopy(load(lib/"TRANSITIONS.json")["matrix"]); cells.pop()
        return "STATE_MATRIX_INCOMPLETE" if len(cells)!=len(st["states"])*len(st["commands"]) else None
    if kind=="OPERATION_ADD_UNKNOWN_LAW":
        ops=copy.deepcopy(load(lib/"OPERATIONS.json")["operations"]); ops[0]["law_coverage"].append("LAW-NOT-THERE")
        known={x["identity"] for x in load(lib/"LAWS.json")["laws"]}; return "UNKNOWN_LAW" if not set(ops[0]["law_coverage"])<=known else None
    if kind=="REMOVE_DECISION_ABSENCE":
        dec=copy.deepcopy(load(lib/"DECISIONS.json")["decisions"]); dec[0]["absence_semantics"]=""
        return "DECISION_ABSENCE_MISSING" if not dec[0].get("absence_semantics") else None
    if kind=="ZERO_BUDGET":
        b=copy.deepcopy(load(lib/"BUDGETS.json")["budgets"]); b[0]["max_input_bytes"]=0
        return "UNBOUNDED_BUDGET" if b[0]["max_input_bytes"]<=0 else None
    if kind=="ADMITTED_DESERIALIZABLE":
        types=copy.deepcopy(load(lib/"RUST-API.json")["types"]); t=next(x for x in types if x["kind"] in {"ADMITTED_VALUE","ADMITTED_ENTITY","PROOF","AUTHORITY"}); t["deserialize_constructor"]=True
        return "FORGEABLE_ADMITTED_TYPE" if t["deserialize_constructor"] or not t["fields_private"] else None
    if kind=="LOCAL_PROVIDER_OFFER":
        c=copy.deepcopy(load(lib/"CONTRACTS.json")); c["offers"]={"provider":"FORGED"}
        return "PROVIDER_OFFER_LEAK" if c["offers"].get("disposition")!="INAPPLICABLE" else None
    if kind=="SET_LOWERING_VERIFIED":
        low=copy.deepcopy(load(lib/"LOWERING.json")); low["lowering_verified"]=True
        return "LOWERING_OVERCLAIM" if low["lowering_verified"] else None
    if kind=="ADD_UNKNOWN_SOURCE":
        known={x["identity"] for x in load(root/"RESEARCH-LEDGER.json")["sources"]}; sources=copy.deepcopy(load(lib/"RESEARCH-SOURCES.json")["sources"]); sources.append({"identity":"SRC-NOT-THERE"})
        return "UNKNOWN_RESEARCH_SOURCE" if any(x["identity"] not in known for x in sources) else None
    if kind=="CERTIFY":
        st=copy.deepcopy(load(lib/"STATUS.json")); st["certified"]=True; st["certification"]="PRODUCTION"
        return "CERTIFICATION_OVERCLAIM" if st["certified"] or st["certification"]!="NONE" else None
    if kind=="DIRECT_MUTATION":
        rt=copy.deepcopy(load(lib/"RUNTIME-OBLIGATIONS.json")); rt["mutation_path"]="DIRECT_DATABASE_WRITE"
        return "MUTATION_PATH_BYPASS" if "Host Role Composition → Mutation Kernel" not in rt["mutation_path"] else None
    return None

def verify(root):
    v=V()
    for rel in REQUIRED_ROOT: v.check((root/rel).exists(),f"missing root {rel}")
    cat=load(root/"CATALOG.json"); libs=cat["libraries"]; ids=[x["identity"] for x in libs]
    v.check(len(ids)==len(set(ids)),"duplicate catalog identity")
    for x in libs:
        v.check(bool(ID_RE.fullmatch(x["identity"])),f"invalid identity {x['identity']}")
        v.check(not SUFFIX_RE.search(x["identity"]),f"edition suffix {x['identity']}")
    batch=cat["first_batch"]; v.check(len(batch)==8,"first batch must be exactly eight")
    dag=load(root/"HARD-DEPENDENCY-DAG.json")
    v.check(set(dag["nodes"])==set(ids),"DAG/catalog node drift")
    v.check(acyclic(dag["nodes"],dag["edges"]),"hard dependency cycle")
    hard_pairs={(e["from"],e["to"]) for e in dag["edges"]}|{(e["to"],e["from"]) for e in dag["edges"]}
    seams=load(root/"SEMANTIC-SEAM-GRAPH.json")["seams"]
    for s in seams:
        if s["consumer"] in ids and s["provider"] in ids:
            v.check((s["consumer"],s["provider"]) not in hard_pairs,"semantic seam duplicated as hard edge")
    source_ids={x["identity"] for x in load(root/"RESEARCH-LEDGER.json")["sources"]}
    global_ops=set(); global_laws=set(); global_refs=set()
    for lib_id in batch:
        d=root/"LIBRARIES"/lib_id
        for rel in REQUIRED_SPEC: v.check((d/rel).exists(),f"{lib_id} missing {rel}")
        spec=load(d/"SPEC.json"); context=load(d/"CONTEXT-SPEC.json")
        jsonschema.Draft202012Validator(load(d/"SPEC.schema.json")).validate(spec)
        jsonschema.Draft202012Validator(load(d/"CONTEXT-SPEC.schema.json")).validate(context)
        v.check(spec["identity"]==lib_id,"directory/spec identity drift")
        v.check(spec["edition"]>=1 and spec["status"]=="REVIEW_CANDIDATE" and spec["certification"]=="NONE","status overclaim")
        ops=load(d/"OPERATIONS.json")["operations"]; rust=load(d/"RUST-API.json")
        laws=load(d/"LAWS.json")["laws"]; refs=load(d/"REFUSALS.json")["variants"]; decs=load(d/"DECISIONS.json")["decisions"]
        opids={x["identity"] for x in ops}; lawids={x["identity"] for x in laws}; refids={x["identity"] for x in refs}; decids={x["identity"] for x in decs}
        v.check(len(opids)==len(ops) and len(lawids)==len(laws) and len(refids)==len(refs),f"{lib_id} duplicate local IDs")
        v.check({x["identity"] for x in rust["operations"]}==opids,f"{lib_id} operation/Rust API drift")
        for op in ops:
            v.check(op["candidate_signature"].startswith("pub fn ") and "Result<" in op["candidate_signature"],f"{op['identity']} placeholder signature")
            v.check(set(op["law_coverage"])<=lawids,f"{op['identity']} unknown law")
            v.check(set(op["decision_dependencies"])<=decids,f"{op['identity']} unknown decision")
            v.check(op["side_effect_posture"]=="PURE_NO_IO",f"{op['identity']} provider/I/O leakage")
            v.check(op["budget"],f"{op['identity']} budget missing")
        for law in laws:
            v.check(set(law["operations_affected"])<=opids,f"{law['identity']} unknown operation")
            v.check(set(law["refusal_on_violation"])<=refids,f"{law['identity']} unknown refusal")
        for dec in decs: v.check(bool(dec.get("absence_semantics")),f"{dec['identity']} missing absence")
        for t in rust["types"]:
            if t["kind"] in {"ADMITTED_VALUE","ADMITTED_ENTITY","PROOF","AUTHORITY"}:
                v.check(t["fields_private"] and not t["deserialize_constructor"],f"{lib_id} forgeable {t['candidate_rust_name']}")
        st=load(d/"STATES.json")["state_machine"]; matrix=load(d/"TRANSITIONS.json")["matrix"]
        v.check(len(matrix)==len(st["states"])*len(st["commands"]),f"{lib_id} state matrix incomplete")
        v.check(len({(x["state"],x["command"]) for x in matrix})==len(matrix),f"{lib_id} state matrix duplicate")
        for cell in matrix:
            v.check((cell["outcome"]=="TRANSITION" and cell["event"] and not cell["refusal"]) or (cell["outcome"]=="REFUSAL" and cell["refusal"] in refids),f"{lib_id} transition/refusal drift")
        for b in load(d/"BUDGETS.json")["budgets"]:
            for key in ["max_input_bytes","max_items","max_depth","max_output_bytes","max_iterations"]: v.check(isinstance(b[key],int) and b[key]>0,f"{lib_id} unbounded {key}")
            v.check("allocate" in b["precharge_order"] and b["precharge_order"].index("allocate") > b["precharge_order"].index("charge allocation") and b["overflow_behavior"].startswith("REFUSE_"),f"{lib_id} unsafe budget")
        conf=load(d/"CONFORMANCE-MATRIX.json")["cases"]
        for law_id in lawids:
            kinds={x["kind"] for x in conf if x["law"]==law_id}
            v.check({"POSITIVE","NEGATIVE_TWIN","BOUNDARY_MAX","BOUNDARY_MAX_PLUS_ONE","MUTATION","EXHAUSTION","REPLAY"}<=kinds,f"{law_id} conformance incomplete")
        rsrc=load(d/"RESEARCH-SOURCES.json")["sources"]
        for s in rsrc: v.check(s["identity"] in source_ids,f"{lib_id} source not in root ledger {s['identity']}")
        sgraph=load(d/"SOURCE-GRAPH.json")
        local_paths={x["path"] for x in load(root/"SOURCE-LOCK.json")["sources"]}
        for sid in sgraph["sources"]:
            v.check(sid in source_ids or sid in local_paths,f"{lib_id} source graph unresolved {sid}")
        status=load(d/"STATUS.json")
        for key in ["semantic_execution_verified","implementation_verified","compiler_integration_verified","lowering_verified","runtime_vertical_verified","provider_conformance_verified","independently_verified","ratified","certified"]: v.check(status[key] is False,f"{lib_id} overclaims {key}")
        v.check("Host Role Composition → Mutation Kernel" in load(d/"RUNTIME-OBLIGATIONS.json")["mutation_path"],f"{lib_id} mutation bypass")
        manifest=load(d/"MANIFEST.json")
        for row in manifest["files"]: v.check((d/row["path"]).exists() and digest(d/row["path"])==row["sha256"],f"{lib_id} manifest mismatch {row['path']}")
        global_ops|=opids; global_laws|=lawids; global_refs|=refids
    manifest=load(root/"MANIFEST.json")
    for row in manifest["files"]: v.check((root/row["path"]).exists() and digest(root/row["path"])==row["sha256"],f"root manifest mismatch {row['path']}")
    fixture_rows=[]
    for entry in load(root/"VERIFY/FIXTURE-INDEX.json")["fixtures"]:
        fixture=load(root/"VERIFY"/entry["path"]); actual=detect_fixture(root,fixture)
        row={"path":entry["path"],"expected":fixture["expected_code"],"actual":actual,"result":"PASS" if actual==fixture["expected_code"] else "FAIL"}
        fixture_rows.append(row); v.check(row["result"]=="PASS",f"negative fixture failed {entry['path']}: {actual}")
    v.fixture_rows=fixture_rows
    return v

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve(); v=verify(root)
    result={"result":"PASS" if not v.errors else "FAIL","checks":v.checks,"errors":v.errors,"negative_fixtures":getattr(v,"fixture_rows",[])}
    print(json.dumps(result,indent=2,sort_keys=True)); raise SystemExit(0 if not v.errors else 1)
if __name__=="__main__": main()
'''


def negative_fixtures() -> dict[str, dict[str, Any]]:
    return {
        "duplicate-identity.json":{"expected_code":"DUPLICATE_IDENTITY","mutation":{"kind":"CATALOG_DUPLICATE","identity":"DAT-COLLECTION"}},
        "edition-suffixed-identity.json":{"expected_code":"EDITION_SUFFIX","mutation":{"kind":"CATALOG_ADD","identity":"DAT-FAKE/v1"}},
        "unknown-dependency.json":{"expected_code":"UNKNOWN_DEPENDENCY","mutation":{"kind":"DAG_EDGE","from":"DAT-NOT-THERE","to":"DAT-COLLECTION"}},
        "hard-cycle.json":{"expected_code":"HARD_DEPENDENCY_CYCLE","mutation":{"kind":"DAG_EDGE","from":"DAT-SNAPSHOT-CONTINUATION-STITCHING","to":"DAT-COLLECTION"}},
        "semantic-seam-as-hard-edge.json":{"expected_code":"SEAM_HARD_EDGE_COLLISION","mutation":{"kind":"DAG_EDGE","from":"DAT-DATA-CUT","to":"DAT-DISTRIBUTION"}},
        "missing-state-cell.json":{"expected_code":"STATE_MATRIX_INCOMPLETE","mutation":{"kind":"REMOVE_STATE_CELL","library":"DAT-COLLECTION"}},
        "unknown-law.json":{"expected_code":"UNKNOWN_LAW","mutation":{"kind":"OPERATION_ADD_UNKNOWN_LAW","library":"DAT-COLLECTION"}},
        "decision-without-absence.json":{"expected_code":"DECISION_ABSENCE_MISSING","mutation":{"kind":"REMOVE_DECISION_ABSENCE","library":"DAT-COLLECTION"}},
        "unbounded-budget.json":{"expected_code":"UNBOUNDED_BUDGET","mutation":{"kind":"ZERO_BUDGET","library":"DAT-COLLECTION"}},
        "forgeable-admitted-type.json":{"expected_code":"FORGEABLE_ADMITTED_TYPE","mutation":{"kind":"ADMITTED_DESERIALIZABLE","library":"DAT-COLLECTION"}},
        "provider-offer-leak.json":{"expected_code":"PROVIDER_OFFER_LEAK","mutation":{"kind":"LOCAL_PROVIDER_OFFER","library":"DAT-COLLECTION"}},
        "unsupported-lowering-claim.json":{"expected_code":"LOWERING_OVERCLAIM","mutation":{"kind":"SET_LOWERING_VERIFIED","library":"DAT-COLLECTION"}},
        "unknown-source.json":{"expected_code":"UNKNOWN_RESEARCH_SOURCE","mutation":{"kind":"ADD_UNKNOWN_SOURCE","library":"DAT-COLLECTION"}},
        "certification-overclaim.json":{"expected_code":"CERTIFICATION_OVERCLAIM","mutation":{"kind":"CERTIFY","library":"DAT-COLLECTION"}},
        "direct-business-mutation.json":{"expected_code":"MUTATION_PATH_BYPASS","mutation":{"kind":"DIRECT_MUTATION","library":"DAT-COLLECTION"}},
    }


def build_manifest(root: Path, exclude: set[str]) -> dict[str, Any]:
    rows=[]
    for p in sorted(root.rglob("*"), key=lambda x:x.relative_to(root).as_posix()):
        if not p.is_file(): continue
        rel=p.relative_to(root).as_posix()
        if rel in exclude: continue
        rows.append({"path":rel,"bytes":p.stat().st_size,"sha256":sha256_file(p)})
    manifest_subject = root.name if root.name in FIRST_BATCH_IDS else PACKAGE_ID
    return {"identity":f"MANIFEST-{manifest_subject}","edition":1,"hash_algorithm":"SHA-256","files":rows,"file_count":len(rows)}


def deterministic_zip(source: Path, target: Path) -> None:
    if target.exists(): target.unlink()
    with zipfile.ZipFile(target,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(source.rglob("*"),key=lambda x:x.relative_to(source).as_posix()):
            if not p.is_file(): continue
            rel=p.relative_to(source).as_posix()
            info=zipfile.ZipInfo(rel,date_time=(1980,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED; info.create_system=3; info.external_attr=0o644<<16
            z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)


def materialize(out: Path) -> dict[str, Any]:
    if out.exists(): shutil.rmtree(out)
    out.mkdir(parents=True)
    locks=source_lock()
    sem_data=load_json(ROOT/"02-CURRENT-REGISTRIES/CURRENT-SEM-CONVERGENCE.json")
    sem_records={x["coordinate"]:x for x in sem_data["records"]}
    boundary=build_boundary_adjudication(); dag=build_hard_dag(); seams=build_semantic_seams(dag)
    ownership=build_ownership_matrix(); crosswalk=build_sem_crosswalk(sem_data)
    spec_bundles={}
    for lib_id in FIRST_BATCH_IDS:
        lib=LIB_INDEX[lib_id]; bundle=build_library_artifacts(lib,sem_records,locks); spec_bundles[lib_id]=bundle
        d=out/"LIBRARIES"/lib_id
        for name,obj in bundle["artifacts"].items(): write_json(d/name,obj)
        write_text(d/"README.md",bundle["readme"])
        write_text(d/"VERIFY/verify.py",per_library_verifier_source())
        # Manifest excludes itself and generated verification result.
        write_json(d/"MANIFEST.json",build_manifest(d,{"MANIFEST.json","VERIFY/VALIDATION-REPORT.json"}))
    catalog=build_catalog(boundary,dag); counts=build_package_counts(spec_bundles,boundary,dag,seams)
    root_artifacts={
        "CATALOG.json":catalog,
        "OWNERSHIP-MATRIX.json":ownership,
        "EXISTING-SEM-CROSSWALK.json":crosswalk,
        "BOUNDARY-ADJUDICATION.json":boundary,
        "HARD-DEPENDENCY-DAG.json":dag,
        "SEMANTIC-SEAM-GRAPH.json":seams,
        "IMPLEMENTATION-ORDER.json":build_implementation_order(dag),
        "FIRST-BATCH-SELECTION.json":build_first_batch_selection(dag),
        "OPEN-QUESTIONS.json":build_open_questions(),
        "GAP-LEDGER.json":build_root_gaps(crosswalk,boundary["occurrences"]),
        "RESEARCH-LEDGER.json":build_research_ledger(locks),
        "SSPEC-COMPLIANCE-MATRIX.json":build_sspec_compliance(spec_bundles),
        "CONFORMANCE-COVERAGE.json":build_conformance_coverage(spec_bundles),
        "ADVERSARIAL-REVIEWS.json":build_adversarial_reviews(),
        "WAR-GAMES.json":{"identity":"SAN-DATA-WAR-GAMES","edition":1,"scenarios":build_war_games(),"executed":False},
        "SOURCE-LOCK.json":{"identity":"SAN-DATA-SOURCE-LOCK","edition":1,"sources":locks},
        "PACKAGE-COUNTS.json":counts,
    }
    for name,obj in root_artifacts.items(): write_json(out/name,obj)
    write_text(out/"README.md",root_readme(catalog,counts))
    write_text(out/"CODEX-START-HERE.md",codex_start())
    write_text(out/"VERIFY/verify.py",root_verifier_source())
    fixtures=negative_fixtures()
    for name,obj in fixtures.items(): write_json(out/"VERIFY/negative-fixtures"/name,obj)
    write_json(out/"VERIFY/FIXTURE-INDEX.json",{"identity":"SAN-DATA-NEGATIVE-FIXTURES","edition":1,"fixtures":[{"path":f"negative-fixtures/{name}",**obj} for name,obj in sorted(fixtures.items())]})
    # Copy deterministic generator source itself.
    shutil.copy2(Path(__file__),out/"generate.py")
    # Placeholder is required by the verifier; it is replaced with exact results after verification.
    write_json(out/"PACKAGE-VERIFY.json",{
        "identity":"SAN-DATA-PACKAGE-VERIFY","edition":1,"result":"PENDING",
        "manifest_sha256":"PENDING","root_verifier_checks":0,
        "negative_fixtures_passed":0,"negative_fixtures_total":len(fixtures),
        "deterministic_generation":"PENDING_SECOND_GENERATION",
        "status":STATUS,"certification":CERTIFICATION,
    })
    # Initial root manifest excludes self-referential verification artifacts.
    write_json(out/"MANIFEST.json",build_manifest(out,{"MANIFEST.json","PACKAGE-VERIFY.json","VERIFY/VALIDATION-REPORT.json"}))
    return {"out":out,"counts":counts,"catalog":catalog,"spec_bundles":spec_bundles,"fixtures":fixtures}


def execute_verification(out: Path) -> dict[str, Any]:
    proc=subprocess.run([sys.executable,str(out/"VERIFY/verify.py"),str(out)],capture_output=True,text=True)
    try: root_result=json.loads(proc.stdout)
    except Exception: root_result={"result":"FAIL","stdout":proc.stdout,"stderr":proc.stderr,"returncode":proc.returncode}
    per=[]
    for lib_id in FIRST_BATCH_IDS:
        d=out/"LIBRARIES"/lib_id
        p=subprocess.run([sys.executable,str(d/"VERIFY/verify.py"),str(d)],capture_output=True,text=True)
        try:r=json.loads(p.stdout)
        except Exception:r={"result":"FAIL","stdout":p.stdout,"stderr":p.stderr,"returncode":p.returncode}
        per.append(r)
    fixture_rows=root_result.get("negative_fixtures",[])
    if not fixture_rows:
        fixture_rows=[{"path":"ROOT-VERIFIER","expected":"EXECUTED_FIXTURES","actual":"MISSING","result":"FAIL"}]
    all_pass=proc.returncode==0 and root_result.get("result")=="PASS" and all(x.get("result")=="PASS" for x in per) and all(x["result"]=="PASS" for x in fixture_rows)
    report={
        "identity":"SAN-DATA-VALIDATION-REPORT","edition":1,"result":"PASS" if all_pass else "FAIL",
        "root_verifier":root_result,"per_library":per,"negative_fixtures":fixture_rows,
        "honesty":{"implementation_verified":False,"compiler_integration_verified":False,"runtime_vertical_verified":False,"provider_conformance_verified":False,"independently_verified":False,"certification":"NONE"},
    }
    write_json(out/"VERIFY/VALIDATION-REPORT.json",report)
    package_verify={
        "identity":"SAN-DATA-PACKAGE-VERIFY","edition":1,"result":report["result"],
        "manifest_sha256":sha256_file(out/"MANIFEST.json"),
        "root_verifier_checks":root_result.get("checks",0),
        "negative_fixtures_passed":sum(1 for x in fixture_rows if x["result"]=="PASS"),
        "negative_fixtures_total":len(fixture_rows),
        "deterministic_generation":"PENDING_SECOND_GENERATION",
        "status":STATUS,"certification":CERTIFICATION,
    }
    write_json(out/"PACKAGE-VERIFY.json",package_verify)
    return report


def package_once(out: Path, zip_path: Path) -> dict[str, Any]:
    materialize(out)
    report=execute_verification(out)
    if report["result"]!="PASS":
        raise RuntimeError(json.dumps(report,indent=2)[:10000])
    deterministic_zip(out,zip_path)
    with zipfile.ZipFile(zip_path) as z:
        bad=z.testzip()
        if bad: raise RuntimeError(f"ZIP corruption at {bad}")
    return {"zip":str(zip_path),"sha256":sha256_file(zip_path),"bytes":zip_path.stat().st_size,"report":report}


def main() -> None:
    global ROOT
    parser=argparse.ArgumentParser()
    parser.add_argument("--source-root",type=Path,default=ROOT)
    parser.add_argument("--output",type=Path,default=DEFAULT_OUT)
    parser.add_argument("--zip",type=Path,default=Path("/mnt/data")/ARCHIVE_NAME)
    parser.add_argument("--skip-second-generation",action="store_true")
    args=parser.parse_args(); ROOT=args.source_root
    first=package_once(args.output,args.zip)
    second_hash=None
    if not args.skip_second_generation:
        temp=Path(str(args.output)+"-SECOND")
        temp_zip=args.zip.with_name(args.zip.stem+"-SECOND.zip")
        second=package_once(temp,temp_zip); second_hash=second["sha256"]
        if second_hash!=first["sha256"]: raise RuntimeError(f"Non-deterministic ZIP: {first['sha256']} != {second_hash}")
        for directory in [args.output, temp]:
            pv=load_json(directory/"PACKAGE-VERIFY.json")
            pv["deterministic_generation"]="PASS_TWO_BYTE_IDENTICAL_GENERATIONS"
            pv["baseline_generation_zip_sha256"]=first["sha256"]
            pv["baseline_generation_zip_bytes"]=first["bytes"]
            write_json(directory/"PACKAGE-VERIFY.json",pv)
        # Repackage both already-generated trees with identical final verification metadata.
        deterministic_zip(args.output,args.zip)
        deterministic_zip(temp,temp_zip)
        final_hash=sha256_file(args.zip)
        if sha256_file(temp_zip)!=final_hash: raise RuntimeError("Final package non-deterministic after package verification update")
        shutil.rmtree(temp); temp_zip.unlink()
        first["sha256"]=final_hash; first["bytes"]=args.zip.stat().st_size
    sidecar=args.zip.with_suffix(args.zip.suffix+".sha256")
    sidecar.write_text(f"{first['sha256']}  {args.zip.name}\n",encoding="utf-8")
    print(json.dumps({"result":"PASS","output":str(args.output),"zip":str(args.zip),"sha256":first["sha256"],"bytes":first["bytes"]},indent=2))


if __name__ == "__main__":
    main()
