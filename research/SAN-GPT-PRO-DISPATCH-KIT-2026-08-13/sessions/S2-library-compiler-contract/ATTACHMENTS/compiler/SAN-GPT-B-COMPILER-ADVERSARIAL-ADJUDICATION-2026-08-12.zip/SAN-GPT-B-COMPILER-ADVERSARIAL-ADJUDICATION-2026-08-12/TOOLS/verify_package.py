#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from pathlib import Path

def load(p): return json.loads(p.read_text())
def cycle(nodes, edges):
    adj={n:[] for n in nodes}
    for e in edges: adj.setdefault(e['from'],[]).append(e['to'])
    state={}
    def dfs(n):
        state[n]=1
        for m in adj.get(n,[]):
            if state.get(m)==1: return True
            if not state.get(m) and dfs(m): return True
        state[n]=2
        return False
    return any(not state.get(n) and dfs(n) for n in adj)

def main(root):
    root=Path(root); errors=[]; checks=0
    required=['VERDICT.md','ACCEPT-AMEND-REJECT.json','CURRENT-RUST-REACHABILITY.json','GPT-A-CLAIM-TO-EVIDENCE.json','STAGE-ARTIFACT-DAG.json','TYPE-AUTHORITY-AUDIT.json','BUDGET-AUDIT.json','DEPENDENCY-CYCLE-AUDIT.json','DEPRECATED-IMPORT-AUDIT.json','VERTICAL-TEST-MATRIX.json','REQUIRED-PATCHES.md','CARGO-OUTCOMES.json','DELETION-MIGRATION-LIST.json','BLOCKERS.json','MANIFEST.json']
    for f in required:
        checks+=1
        if not (root/f).is_file(): errors.append('missing '+f)
    for p in root.rglob('*.json'):
        checks+=1
        try: load(p)
        except Exception as e: errors.append(f'json {p.relative_to(root)}: {e}')
    a=load(root/'ACCEPT-AMEND-REJECT.json')
    checks+=3
    if len(a['contexts'])!=16: errors.append('context matrix must contain 14 compiler + 2 domain contexts')
    if len(a['cmp_movements'])!=13: errors.append('CMP movement map must cover CMP-001..013')
    if {x['subject'] for x in a['naming_rulings']} != {'ApplicationBinding versus ApplicationClosure','Csag versus VerifiedCsag','AppRelease versus BackendAppRelease'}: errors.append('naming rulings incomplete')
    r=load(root/'CURRENT-RUST-REACHABILITY.json'); checks+=1
    if r['first_exact_stop']['stage']!='Stage-0 package authority supplier-inventory closure': errors.append('wrong first stop')
    t=load(root/'TYPE-AUTHORITY-AUDIT.json'); checks+=1
    if t['supplier_role_count']!=58 or len(t['supplier_roles'])!=58: errors.append('supplier roles not 58')
    v=load(root/'VERTICAL-TEST-MATRIX.json'); checks+=1
    required_names={'selected release supplier inventory omitted','forged proof/admitted output','missing offer','duplicate/ambiguous offer','unresolved decision','incompatible cardinality','unclosed obligation','cyclic/nonmonotone obligation','undeclared/omitted/blocking gap','graph inconsistency','target incapable','missing runtime capability/provider','target/provider substitution after sealing','different package lock replay','budget boundary suite'}
    if not required_names.issubset({x['name'] for x in v['tests']}): errors.append('negative twin matrix incomplete')
    dag=load(root/'STAGE-ARTIFACT-DAG.json'); checks+=2
    names=[n['artifact'] for n in dag['nodes']]
    if len(names)!=len(set(names)): errors.append('duplicate artifact issuer/name')
    if cycle(names,dag['production_edges']): errors.append('artifact cycle')
    dep=load(root/'DEPENDENCY-CYCLE-AUDIT.json'); checks+=1
    if dep['production_cycles']: errors.append('actual production cargo cycle')
    claims=load(root/'GPT-A-CLAIM-TO-EVIDENCE.json'); checks+=1
    allowed={'PROVEN','CONTRADICTED','PARTIALLY_PROVEN','STRUCTURAL_ONLY','UNREACHABLE','UNTESTED'}
    if any(c['classification'] not in allowed for c in claims['claims']): errors.append('unknown claim classification')
    manifest=load(root/'MANIFEST.json'); checks+=1
    for e in manifest['files']:
        p=root/e['path']; checks+=1
        if not p.is_file(): errors.append('manifest missing '+e['path']); continue
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        if h!=e['sha256']: errors.append('hash mismatch '+e['path'])
    result={'passed':not errors,'checks':checks,'errors':errors,'status':'REVIEW_CANDIDATE','certification':'NONE'}
    print(json.dumps(result,indent=2))
    return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main(sys.argv[1] if len(sys.argv)>1 else '.'))
