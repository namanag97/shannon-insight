
# Deterministic Build Source

`build_package.py` is the exact generator used for this package. It expects the two input archives and the already extracted evidence paths recorded at the top of the script. It performs source-span hashing, artifact generation, package verification and deterministic ZIP construction.

A successful schema or package verifier proves the checks it actually executes. It does not ratify architecture or manufacture production compiler evidence.
