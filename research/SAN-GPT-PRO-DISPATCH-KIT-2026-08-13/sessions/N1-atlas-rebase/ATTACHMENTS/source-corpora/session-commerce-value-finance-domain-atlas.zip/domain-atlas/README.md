# SAN Domain Atlas: Commerce, Agreements, Value, Accounting, and Financial Exchange

This package is a research corpus and boundary proposal. It does not build software and does not mutate or ratify the attached SAN Global Program Registry.

JSON and JSONL files are the source of truth. Markdown files are navigation only.

## Validation

Run from the extracted `domain-atlas` directory:

```text
python tools/validate_corpus.py .
```

The validator parses every JSON and JSONL file, validates all records against JSON Schema Draft 2020-12, checks global identifier uniqueness, controlled vocabularies, references, relation roles, lifecycle values, duplicate fingerprints, deterministic JSONL ordering, forbidden catch-all fields, checksums, and required package structure.

## Boundary posture

A coverage label is not presumed to be a bounded context. Every candidate is assigned a research disposition and cross-walked to the attached candidate registry. Existing `san.*` identities are referenced only as existing registry evidence; all new identities use the `candidate.commerce-value-finance` namespace.

## Scope limits

Jurisdiction-specific contract, tax, property, settlement-finality and accounting profiles remain explicit gaps where primary authority was insufficient. Provider gateways, distributed ledgers, storage engines and other technical mechanisms are not promoted into semantic owners.
