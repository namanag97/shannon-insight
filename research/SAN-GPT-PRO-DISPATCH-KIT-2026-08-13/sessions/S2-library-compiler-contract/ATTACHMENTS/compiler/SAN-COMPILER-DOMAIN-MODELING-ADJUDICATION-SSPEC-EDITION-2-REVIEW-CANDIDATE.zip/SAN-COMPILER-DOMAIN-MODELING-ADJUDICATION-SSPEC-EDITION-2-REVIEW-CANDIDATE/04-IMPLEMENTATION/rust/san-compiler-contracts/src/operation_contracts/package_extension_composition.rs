//! Operation contracts owned by `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`.

pub trait PackageExtensionCompositionContracts {
    /// `domain-package.module.admit`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_domain_module(
        &self,
        arg0: crate::catalog_types::package_extension_composition::DomainModuleMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::DomainModule, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.imports.bind`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_domain_module_imports(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::DomainModuleSet,
        arg1: &crate::catalog_types::package_extension_composition::DomainImportPolicy,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackageBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::BoundDomainModuleSet, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.profile.apply`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn apply_domain_profile(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::BoundDomainModuleSet,
        arg1: &crate::catalog_types::package_extension_composition::DomainProfile,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackageBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::ProfiledDomainModuleSet, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.pack.expand`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn expand_domain_pack(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::ProfiledDomainModuleSet,
        arg1: &crate::catalog_types::package_extension_composition::FiniteDomainPack,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackageBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::DomainContributionSet, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.extension.verify`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_domain_extension(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::CertifiedExtensionContract,
        arg1: &crate::catalog_types::package_extension_composition::ExtensionBinding,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackageBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::VerifiedExtensionBinding, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.closure.verify`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_domain_package_closure(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::DomainContributionSet,
        arg1: &crate::catalog_types::package_extension_composition::VerifiedExtensionBindingSet,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackagePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::DomainPackageClosureProof, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.release.build`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_domain_package_release(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::BoundDomainModuleSet,
        arg1: &crate::catalog_types::package_extension_composition::DomainContributionSet,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackageClosureProof,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::DomainPackageRelease, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.release.verify`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_domain_package_release(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::DomainPackageRelease,
        arg1: &crate::catalog_types::package_extension_composition::DomainPackageVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::DomainPackageVerificationProof, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.delta.classify`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_domain_package_delta(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::DomainPackageRelease,
        arg1: &crate::catalog_types::package_extension_composition::DomainPackageRelease,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackageBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::DomainPackageDelta, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-package.explain`. Owner: `SAN-DOMAIN-MODELING-PACKAGE-AND-EXTENSION-COMPOSITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_domain_package(
        &self,
        arg0: &crate::catalog_types::package_extension_composition::DomainPackageRelease,
        arg1: &crate::catalog_types::package_extension_composition::DomainPackageExplanationRequest,
        arg2: &crate::catalog_types::package_extension_composition::DomainPackageBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::package_extension_composition::DomainPackageExplanation, crate::catalog_types::package_extension_composition::DomainPackageRefusal, crate::waist::CompilerNeedsInput>;

}
