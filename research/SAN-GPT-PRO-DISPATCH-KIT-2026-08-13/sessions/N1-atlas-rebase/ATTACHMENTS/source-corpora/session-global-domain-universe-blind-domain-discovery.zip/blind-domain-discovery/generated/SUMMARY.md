# Global Domain-Universe Blind Discovery Index

## Canonical entry points

- `manifest.json`: package identity, counts, schema map, source treatment, and contract reconciliation.
- `coverage/coverage_matrix.json`: the 24 discovery directions, candidate coverage, record kinds, and explicit non-completeness statement.
- `corpus/bounded_contexts.jsonl`: 153 boundary candidates; only 71 currently have the bounded-context candidate disposition.
- `corpus/relations.jsonl`: 2592 qualified binary and n-ary relations.
- `boundary_analysis/evaluations.jsonl`: twelve-test evaluation of every candidate boundary.
- `issues/unresolved_boundaries.jsonl`: highest-impact unresolved decompositions and ownership questions.
- `registry_intake/existing_record_crosswalk.jsonl`: non-mutating crosswalk to the supplied SAN registry.
- `coverage/research_sequence.json`: recommended sequence for deeper research.
- `VALIDATION.json` and `CHECKSUMS.txt`: mechanical validation and file integrity.

## Canonical-format rule

JSON and JSONL are authoritative. This Markdown file is navigation only. Context records live in `corpus/bounded_contexts.jsonl`; `corpus/contexts.jsonl` contains only a compatibility pointer so the two supplied package contracts do not create duplicate records.
