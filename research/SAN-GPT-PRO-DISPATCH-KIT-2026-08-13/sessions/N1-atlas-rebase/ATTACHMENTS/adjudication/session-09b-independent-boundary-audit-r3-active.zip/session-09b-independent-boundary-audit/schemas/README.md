# Schemas

All JSON and JSONL outputs mapped by `validation/SCHEMA-MAP.json` are validated with JSON Schema Draft 2020-12. Additional relationship schemas cover each declared context relation, aggregate pattern finding, reclassification proposal and relationship coverage. Schemas validate structure; they do not ratify semantic correctness.
