//! Operation contracts owned by `SAN-COMPILER-APP-RELEASE-ASSEMBLY`.

pub trait AppReleaseContracts {
    /// `app-release.input.admit`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_release_input(
        &self,
        arg0: crate::catalog_types::app_release::ReleaseAssemblyInputMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseAssemblyInput, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.inputs.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_release_inputs(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseAssemblyInput,
        arg1: &crate::catalog_types::app_release::ReleaseVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::VerifiedReleaseInputs, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.artifacts.collect`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn collect_release_artifacts(
        &self,
        arg0: &crate::catalog_types::app_release::VerifiedReleaseInputs,
        arg1: crate::catalog_types::app_release::ReleaseBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseArtifactSet, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.descriptor.admit`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_release_descriptor(
        &self,
        arg0: crate::catalog_types::app_release::ReleaseArtifactDescriptorMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseArtifactDescriptor, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.graph.build`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_release_content_graph(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseArtifactSet,
        arg1: &crate::catalog_types::app_release::AttachmentPlan,
        arg2: crate::catalog_types::app_release::ReleaseBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseContentGraph, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.graph.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_release_content_graph(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseContentGraph,
        arg1: &crate::catalog_types::app_release::ReleaseGraphPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseContentGraphProof, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.core.build`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_release_core(
        &self,
        arg0: &crate::catalog_types::app_release::VerifiedReleaseInputs,
        arg1: &crate::catalog_types::app_release::ReleaseContentGraph,
        arg2: &crate::catalog_types::app_release::ReleasePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseCore, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.canonical.project`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_release_core(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseCoreCanonicalProjection, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.seal.attach`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn attach_release_seal(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCoreCanonicalProjection,
        arg1: &crate::catalog_types::app_release::ExternalSealBundle,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseSeal, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.inventory.derive`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_release_inventory(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        arg1: &crate::catalog_types::app_release::InventoryPolicy,
        arg2: crate::catalog_types::app_release::ReleaseBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseInventory, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.sbom.spdx`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_spdx(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseInventory,
        arg1: &crate::catalog_types::app_release::SpdxProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::SpdxProjection, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.sbom.cyclonedx`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_cyclonedx(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseInventory,
        arg1: &crate::catalog_types::app_release::CycloneDxProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::CycloneDxProjection, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.provenance.plan`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_provenance_attestations(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        arg1: &crate::catalog_types::app_release::ProvenancePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::AttestationRequestSet, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.signature.plan`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_release_signatures(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseSeal,
        arg1: &crate::catalog_types::app_release::SignaturePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::SignatureRequestSet, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.attestation.admit`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_attestation_bundle(
        &self,
        arg0: crate::catalog_types::app_release::AttestationBundleMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::AttestationBundle, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.attestation.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_attestation_bundle(
        &self,
        arg0: &crate::catalog_types::app_release::AttestationBundle,
        arg1: &crate::catalog_types::app_release::ReleaseCore,
        arg2: &crate::catalog_types::app_release::AttestationPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::AttestationVerificationProof, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.signature.admit`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_signature_bundle(
        &self,
        arg0: crate::catalog_types::app_release::SignatureBundleMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::SignatureBundle, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.signature.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_signature_bundle(
        &self,
        arg0: &crate::catalog_types::app_release::SignatureBundle,
        arg1: &crate::catalog_types::app_release::ReleaseSeal,
        arg2: &crate::catalog_types::app_release::SignaturePolicy,
        arg3: &crate::catalog_types::app_release::TrustRootSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::SignatureVerificationProof, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.evidence.close`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_release_evidence(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        arg1: &crate::catalog_types::app_release::VerifiedSignatureSet,
        arg2: &crate::catalog_types::app_release::VerifiedAttestationSet,
        arg3: &crate::catalog_types::app_release::InventorySet,
        arg4: &crate::catalog_types::app_release::ReleasePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseEvidenceClosure, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.oci.project`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_oci_release(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        arg1: &crate::catalog_types::app_release::ReleaseEvidenceClosure,
        arg2: &crate::catalog_types::app_release::OciPackagingProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::OciReleaseProjection, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.archive.project`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_archive_release(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        arg1: &crate::catalog_types::app_release::ReleaseEvidenceClosure,
        arg2: &crate::catalog_types::app_release::ArchivePackagingProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ArchiveReleaseProjection, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.packaging.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_packaging_projection(
        &self,
        arg0: &crate::catalog_types::app_release::PackagingProjection,
        arg1: &crate::catalog_types::app_release::ReleaseCore,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::PackagingProjectionProof, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.envelope.build`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_release_envelope(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        arg1: &crate::catalog_types::app_release::ReleaseSeal,
        arg2: &crate::catalog_types::app_release::ReleaseEvidenceClosure,
        arg3: &crate::catalog_types::app_release::PackagingProjectionSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseEnvelope, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.release.build`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_app_release(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCore,
        arg1: &crate::catalog_types::app_release::ReleaseEnvelope,
        arg2: &crate::catalog_types::app_release::ReleasePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::AppRelease, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.release.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_app_release(
        &self,
        arg0: &crate::vertical::AppRelease,
        arg1: &crate::catalog_types::app_release::AppReleaseVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::AppReleaseVerificationProof, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.distribution.requirements`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_distribution_requirements(
        &self,
        arg0: &crate::vertical::AppRelease,
        arg1: &crate::catalog_types::app_release::DistributionPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::DistributionRequirementSet, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.lifecycle.admit`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_release_lifecycle_notice(
        &self,
        arg0: crate::catalog_types::app_release::ReleaseLifecycleNoticeMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseLifecycleNotice, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.lifecycle.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_release_lifecycle(
        &self,
        arg0: &crate::vertical::AppRelease,
        arg1: &crate::catalog_types::app_release::ReleaseLifecycleNoticeSet,
        arg2: &crate::catalog_types::app_release::HistoricalUsePolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseLifecycleProof, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.platform.select`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn select_release_variant(
        &self,
        arg0: &crate::vertical::AppRelease,
        arg1: &crate::catalog_types::app_release::PlatformRequirement,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseVariant, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.explain`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_app_release(
        &self,
        arg0: crate::catalog_types::app_release::ReleaseExplainTarget,
        arg1: &crate::catalog_types::app_release::AppReleaseOutcome,
        arg2: crate::waist::DisclosurePolicyRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseExplanation, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.checkpoint.resume`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_release_build(
        &self,
        arg0: &crate::catalog_types::app_release::ReleaseCheckpoint,
        arg1: &crate::catalog_types::app_release::ReleaseAssemblyInput,
        arg2: &crate::catalog_types::app_release::ReleaseExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseBuildOutcome, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.delta.hint`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_release_delta_hint(
        &self,
        arg0: &crate::vertical::AppRelease,
        arg1: &crate::vertical::AppRelease,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseDeltaHint, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

    /// `app-release.parity.verify`. Owner: `SAN-COMPILER-APP-RELEASE-ASSEMBLY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_release_parity(
        &self,
        arg0: crate::catalog_types::app_release::ReleaseVectorCorpus,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::app_release::ReleaseParityReport, crate::vertical::AppReleaseAssemblyRefusal, crate::waist::CompilerNeedsInput>;

}
