//! Operation contracts owned by `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`.

pub trait DomainDefinitionContracts {
    /// `domain-definition.charter.admit`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_domain_charter(
        &self,
        arg0: crate::catalog_types::domain_definition::DomainCharterMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::AdmittedDomainCharter, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.vocabulary.admit`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_domain_vocabulary(
        &self,
        arg0: &crate::catalog_types::domain_definition::AdmittedDomainCharter,
        arg1: crate::catalog_types::domain_definition::DomainVocabularyMaterial,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::DomainVocabulary, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.concept.admit`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_domain_concepts(
        &self,
        arg0: &crate::catalog_types::domain_definition::DomainVocabulary,
        arg1: &[crate::catalog_types::domain_definition::DomainConceptMaterial],
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::DomainConceptSet, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.aggregate.admit`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_aggregate_definitions(
        &self,
        arg0: &crate::catalog_types::domain_definition::DomainConceptSet,
        arg1: &[crate::catalog_types::domain_definition::AggregateDefinitionMaterial],
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::AggregateDefinitionSet, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.behavior.admit`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_domain_behavior(
        &self,
        arg0: &crate::catalog_types::domain_definition::DomainConceptSet,
        arg1: &crate::catalog_types::domain_definition::AggregateDefinitionSet,
        arg2: crate::catalog_types::domain_definition::DomainBehaviorMaterial,
        arg3: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::DomainBehaviorModel, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.state-machine.verify`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_domain_state_machines(
        &self,
        arg0: &crate::catalog_types::domain_definition::AggregateDefinitionSet,
        arg1: &crate::catalog_types::domain_definition::DomainBehaviorModel,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::StateMachineTotalityProof, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.law-coverage.verify`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_domain_law_coverage(
        &self,
        arg0: &crate::catalog_types::domain_definition::DomainBehaviorModel,
        arg1: &crate::catalog_types::domain_definition::DomainLawSet,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::LawDecisionCoverageProof, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.authority.verify`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_domain_authority(
        &self,
        arg0: &crate::catalog_types::domain_definition::DomainBehaviorModel,
        arg1: &crate::catalog_types::domain_definition::AuthorityContractSet,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::DomainAuthorityProof, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.contracts.admit`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_owner_contracts(
        &self,
        arg0: &crate::catalog_types::domain_definition::VerifiedDomainModel,
        arg1: &crate::catalog_types::domain_definition::OwnerContractMaterialSet,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::OwnerContractSet, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.evolution.classify`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_domain_evolution(
        &self,
        arg0: &crate::catalog_types::domain_definition::VerifiedDomainDefinition,
        arg1: &crate::catalog_types::domain_definition::VerifiedDomainDefinition,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::DomainSemanticDelta, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.verify`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_domain_definition(
        &self,
        arg0: &crate::catalog_types::domain_definition::DomainDefinitionSource,
        arg1: &crate::catalog_types::domain_definition::DomainVerificationPolicy,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::VerifiedDomainDefinition, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

    /// `domain-definition.explain`. Owner: `SAN-DOMAIN-MODELING-DOMAIN-DEFINITION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_domain_definition(
        &self,
        arg0: &crate::catalog_types::domain_definition::VerifiedDomainDefinition,
        arg1: &crate::catalog_types::domain_definition::DomainExplanationRequest,
        arg2: &crate::catalog_types::domain_definition::DomainBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::domain_definition::DomainDefinitionExplanation, crate::catalog_types::domain_definition::DomainDefinitionRefusal, crate::waist::CompilerNeedsInput>;

}
