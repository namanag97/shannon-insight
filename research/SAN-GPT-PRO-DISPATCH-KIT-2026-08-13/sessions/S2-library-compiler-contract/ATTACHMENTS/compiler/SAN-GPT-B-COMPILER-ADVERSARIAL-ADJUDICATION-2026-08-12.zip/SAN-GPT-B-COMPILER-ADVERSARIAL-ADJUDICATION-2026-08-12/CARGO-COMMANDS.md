# Cargo Commands and Outcomes

```bash
cargo --version
```

Return code: `127`

```text
bash: line 1: cargo: command not found
```

```bash
RUSTC_WRAPPER= cargo check --release --all-targets -p san-canonical -p san-digest -p san-application-linker -p san-csag-model -p san-csag -p san-target-lowering-framework -p san-target-translation-validation -p san-app-release -p san-environment-binder
```

Return code: `127`

```text
bash: line 1: cargo: command not found
```

```bash
RUSTC_WRAPPER= cargo test --release --all-targets -p san-application-linker -p san-csag -p san-target-lowering-framework -p san-app-release -p san-environment-binder
```

Return code: `127`

```text
bash: line 1: cargo: command not found
```

```bash
RUSTC_WRAPPER= cargo clippy --release --all-targets -p san-application-linker -p san-csag -p san-target-lowering-framework -p san-app-release -p san-environment-binder -- -D warnings
```

Return code: `127`

```text
bash: line 1: cargo: command not found
```
