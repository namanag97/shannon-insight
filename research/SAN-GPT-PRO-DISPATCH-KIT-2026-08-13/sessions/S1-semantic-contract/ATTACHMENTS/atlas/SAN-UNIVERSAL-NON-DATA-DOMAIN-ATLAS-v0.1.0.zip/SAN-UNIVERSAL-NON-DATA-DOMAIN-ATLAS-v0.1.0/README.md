# SAN Universal Non-Data Domain Atlas v0.1.0

Candidate release only. This package does **not** ratify registry units and does not implement libraries, compiler code, services, provider bindings, or deployments.

## Architecture

A. Horizontal semantic domains own reusable, implementation-independent meanings and laws.
B. Vertical domain packs specialize horizontal meanings or own genuinely industry/public-function-specific law.
C. Technical realization domains cover compiler/IR/runtime/resources/providers/deployment/management/assurance without taking semantic ownership.

## Evidence and limitations

The release directly verifies the uploaded reconciliation, competency suite, and three audit ZIPs. The reconciliation itself cryptographically verifies ten source research archives and contains 48,606 normalized source records. Those ten raw source ZIPs and the raw current Global Program Registry archive are not directly attached to this release turn, so exact registry admission remains deferred. The task text says eight source corpora while the verified reconciliation inventory contains ten; all ten are preserved as provenance.

The latest richer audit revision is used as active audit evidence. The two earlier audit uploads are preserved as duplicate predecessor copies and are not triple-counted.

Competency and adversarial scenario results in this release are deterministic structural-semantic representability checks, not execution proof. Relationship labels that the independent audit found under-evidenced remain `DISPUTED` or `BOUNDED_CONTEXT_HYPOTHESIS`. Humanity has suffered enough from diagrams where every arrow means “somehow.”

## Counts

- Horizontal candidate contexts: 275
- Vertical contexts: 26
- Canonical context relationships: 3942
- Canonical concepts/families/algebras: 685
- Contextual meanings: 2151
- Horizontal laws: 923
- Registry exact-match candidates: 27
- Registry new-unit candidates: 95

See `validation/VALIDATION.json` and `coverage/` for machine-readable results.
