# Session 09B — Independent Adversarial Boundary Audit

## Verdict

This package independently audits the supplied non-data candidate decompositions and Global Program Registry. It **does not merge the corpora, ratify a final atlas, or treat source self-classification as authority**. Mechanical validity is necessary but not semantic correctness, a distinction humanity keeps rediscovering after building a graph with very impressive arrows.

## Verified inputs

All 11 recovered input artifacts pass independent ZIP, checksum and JSON/JSONL validation: 10 discovery/atlas archives plus the Global Program Registry. The rerun verifies 955 declared checksums, 559 JSON files, 399 JSONL files and 48,606 JSONL records with no parse or checksum failure. Exact archive hashes and validator results are preserved in `validation/independent_input_validation.json`.

## Audit coverage

- Candidate units audited once: **1,078**; unaudited: **0**.
- Declared relationship artifacts audited once: **2,160** = 1,530 session context relations + 615 registry context-map edges + 15 registry semantic seams.
- Cross-domain ownership questions: **12**.
- Duplicate-owner conflict families: **41**.
- False-boundary records: **253**.
- Missing regions confirmed after qualification: **8**, producing **12** narrower, non-ratifying owner hypotheses.
- Official or primary external sources recorded: **64**.

## Headline severity counts

Canonical unique defects: **P0 0 · P1 297 · P2 57 · P3 2**. These are deduplicated defect keys, not raw record occurrences. `coverage/severity_summary.json` gives both views and the exact counting rule.

## Highest-impact findings

1. **Premature semantic admission:** 143 registry semantic records are labelled `ACCEPT_AS_SOVEREIGN_UNIT` without proof of unique ownership, ratification, exact semantic surface, independent review or execution evidence.
2. **Compiler-stage identity duplication:** current 12-stage and proposed 14-stage coordinates register equivalent compiler work as parallel units instead of editions or variants.
3. **Registry kind violation:** three `ontology_artifact_kind` records are admitted although the registry’s own unit-kind rules say that kind is not registerable.
4. **Cross-category ownership corruption:** semantic, runtime, resource, provider, profile, composition, portable representation and compiler behavior are repeatedly mixed.
5. **Homonym ownership conflicts:** identity, authorization, evidence, process, product, resource, failure and revision require typed translations rather than a universal master owner.
6. **Relationship-map corruption:** compound `CUSTOMER_SUPPLIER_OR_ANTICORRUPTION_LAYER`, blanket ACLs, unproven Customer/Supplier assertions, duplicate edges, mirrored import/publication edges, invalid endpoints and implementation flows appear as semantic relations.
7. **Residual missing regions:** communications allocation, rulemaking, individual administrative acts, succession/estate administration, personal status/guardianship, collective insolvency, intellectual-property right constitution and international-protection status remain absent or materially incomplete.
8. **Vertical leakage:** most industry entries are evidence or vertical specializations, not reusable horizontal semantic owners.

## Relationship audit posture

A context relationship is not accepted merely because both endpoints sound respectable. Each relation is checked for endpoint validity, semantic versus implementation character, exact pattern, authority direction, duplicate/mirrored encoding and evidence for translation or governance. DDD context-map labels are treated as claims requiring model and team evidence, not decorative edge types.

## Missing-domain posture

The search evaluates 31 regions. Confirmed gaps are deliberately split when one umbrella hides multiple authorities. `new_candidate_proposals.jsonl` contains hypotheses only; every proposal states negative scope, lifecycle, refusals, consumers, next tests and the explicit non-effect `NEW_CANDIDATE_PROPOSAL_ONLY_NOT_A_FINAL_ATLAS_ENTRY`. Official statistics is identified but referred to the data/analytics corpus rather than duplicated here.

## Directory guide

- `audit/context_findings.jsonl`: all 1,078 candidate-unit audits and the 12 correctness tests.
- `audit/context_relationship_findings.jsonl`: all 2,160 relationship-artifact audits.
- `audit/ownership_conflicts.jsonl`: competing owners, translations and decisions.
- `audit/false_boundaries.jsonl`: false/profile/composition/implementation/vertical boundary records.
- `audit/missing_domains.jsonl`: qualified residual search, including rejected and deferred regions.
- `audit/cross_domain_question_results.jsonl`: the 12 adversarial ownership questions.
- `audit/registry_findings.jsonl`: governed-unit, category, evidence and registry-graph defects.
- `audit/relationship_pattern_findings.jsonl`: deduplicated relationship defects.
- `proposals/`: split, merge, reclassification, relationship-reclassification and new-candidate hypotheses.
- `coverage/`: candidate, relationship and severity coverage.
- `research/`: source ledger, claim mapping and research scope.
- `schemas/` and `validation/`: closed schemas, schema map, independent input validation and executable package validator.

## Validation

Run:

```bash
python3 validation/validate_package.py .
python3 validation/validate_package.py ../session-09b-independent-boundary-audit.zip
```

The validator checks ZIP safety/CRC, checksum and manifest coverage, every mapped schema and record, all 12-test sets, candidate and relationship coverage, source references, claim-map completeness, proposal links, headline counts and the prohibition on a merged atlas.

## Non-goals

No final merged atlas, canonical domain map, compiler, runtime, application, provider implementation or corpus admission is emitted.
