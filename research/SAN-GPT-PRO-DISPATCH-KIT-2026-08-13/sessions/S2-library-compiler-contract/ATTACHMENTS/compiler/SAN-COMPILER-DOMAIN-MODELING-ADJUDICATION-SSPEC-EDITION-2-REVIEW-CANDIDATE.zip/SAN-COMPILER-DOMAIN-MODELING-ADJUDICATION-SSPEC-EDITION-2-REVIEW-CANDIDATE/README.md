
# SAN Compiler Domain Modeling Adjudication SSPEC Edition 2

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

This is a hard-cut replacement for Edition 1. It preserves the existing fourteen compiler and two domain-model contexts, replaces all 751 fieldless type rows with field-level algebra, removes generated names, assigns every retained operation/law/contract/refusal/proof obligation to exactly one owner, and includes a non-vacuous Rust reference vertical.

The decisive artifact thread is:

```text
Stage0PackageAuthority
  -> ParsedSourceSet
  -> AdmittedDeclarationSet
  -> BoundDeclarationGraph
  -> ExpandedContributionSet
  -> ResolvedDecisionSet
  -> FamilyPlanSet
  -> ApplicationBinding
  -> ObligationClosure
  -> Csag
  -> TargetCompilationSet
  -> RuntimeRequirementClosure
  -> ApplicationClosure
  -> AppRelease
  -> DeploymentPlan
  -> BootInput
  -> OfflineVerificationReport
```

`ApplicationClosure` is final only after target feasibility/lowering and RUN requirement closure. `AppRelease` remains provider-neutral. `DeploymentPlan` performs provider/environment binding. No compatibility aliases exist.

## Start here

1. `EXECUTIVE-ADJUDICATION.md`
2. `CORRECTION-LEDGER.md`
3. `01-ARCHITECTURE/ARTIFACT-DAG.json`
4. `01-ARCHITECTURE/CLOSURE-RULING.json`
5. `04-IMPLEMENTATION/rust/san-compiler-contracts/src/vertical/fixture.rs`
6. `VERIFY/STATIC-VERIFICATION.json`
7. `VERIFY/CARGO-VERIFICATION.json`

The Rust source has not been Cargo-verified in this audit environment because no Rust toolchain was available. Static verification is deliberately reported as static verification, not dressed up as execution with a tiny fake moustache.
