//! Types owned by `declaration_admission`.

use std::collections::{BTreeMap, BTreeSet};

/// Field-complete contract model for `AdmissionBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `AdmissionCheckpoint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionCheckpoint {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: Vec<crate::waist::ArtifactRef>,
    work_spent: u64,
    remaining_budget: crate::waist::WorkBudget,
}

impl AdmissionCheckpoint {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.completed
    }
    #[must_use]
    pub fn work_spent(&self) -> u64 {
        self.work_spent
    }
    #[must_use]
    pub fn remaining_budget(&self) -> &crate::waist::WorkBudget {
        &self.remaining_budget
    }
}

/// Field-complete contract model for `AdmissionContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `AdmissionDiagnosticGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionDiagnosticGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl AdmissionDiagnosticGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `AdmissionDispatchTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionDispatchTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl AdmissionDispatchTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `AdmissionExplainTarget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum AdmissionExplainTarget {
    Artifact {
        artifact: crate::waist::ArtifactRef,
    },
    Subject {
        subject: crate::waist::SubjectKey,
    },
    Refusal {
        refusal_id: crate::waist::StableId,
    },
}

/// Field-complete contract model for `AdmissionExplanation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionExplanation {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl AdmissionExplanation {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `AdmissionOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum AdmissionOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::DeclarationAdmissionRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `AdmissionPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `AdmissionProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl AdmissionProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `AdmissionState`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmissionState {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl AdmissionState {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `AdmittedDeclaration`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedDeclaration {
    identity: crate::waist::StableId,
    edition: crate::waist::Edition,
    owner: crate::waist::AuthorityRef,
    kind: crate::waist::RegistryKind,
    members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl AdmittedDeclaration {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn edition(&self) -> &crate::waist::Edition {
        &self.edition
    }
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn kind(&self) -> &crate::waist::RegistryKind {
        &self.kind
    }
    #[must_use]
    pub fn members(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::ScalarValue> {
        &self.members
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `AdmittedField`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedField {
    identity: crate::waist::StableId,
    owner: crate::waist::AuthorityRef,
    edition: crate::waist::Edition,
    kind: crate::waist::StableId,
    members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl AdmittedField {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn edition(&self) -> &crate::waist::Edition {
        &self.edition
    }
    #[must_use]
    pub fn kind(&self) -> &crate::waist::StableId {
        &self.kind
    }
    #[must_use]
    pub fn members(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::ScalarValue> {
        &self.members
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `AdmittedFieldSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedFieldSet {
    owner: crate::waist::AuthorityRef,
    items: Vec<crate::waist::SemanticMember>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl AdmittedFieldSet {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn items(&self) -> &Vec<crate::waist::SemanticMember> {
        &self.items
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `AffectedArtifactRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AffectedArtifactRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `CascadeDiagnostic`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CascadeDiagnostic {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `DeclarationDescriptor`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeclarationDescriptor {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub owner: crate::waist::AuthorityRef,
    pub kind: crate::waist::RegistryKind,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub source: crate::waist::ArtifactRef,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `DeclarationDescriptorRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeclarationDescriptorRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `DependentArtifactRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DependentArtifactRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `DescriptorIndex`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DescriptorIndex {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl DescriptorIndex {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `DiagnosticId`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DiagnosticId {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `FieldDescriptor`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FieldDescriptor {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub owner: crate::waist::AuthorityRef,
    pub kind: crate::waist::RegistryKind,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub source: crate::waist::ArtifactRef,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `MappingEntryRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct MappingEntryRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `OpaqueOwnerValue`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OpaqueOwnerValue {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `OwnerAdmissionFns`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OwnerAdmissionFns {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `PoisonReason`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PoisonReason {
    Declared,
    Applicable,
    Inapplicable {
        reason: crate::waist::StableId,
    },
    Blocked {
        gap: crate::waist::ArtifactRef,
    },
}

/// Field-complete contract model for `PoisonRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PoisonRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `ReferenceDescriptor`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceDescriptor {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub owner: crate::waist::AuthorityRef,
    pub kind: crate::waist::RegistryKind,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub source: crate::waist::ArtifactRef,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ScalarLexemeRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ScalarLexemeRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `SyntaxNodeRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SyntaxNodeRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `SyntheticInsertionSpan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SyntheticInsertionSpan {
    pub source: crate::waist::ArtifactRef,
    pub span: crate::waist::SourceSpan,
    pub kind: crate::waist::StableId,
    pub lexeme: String,
}

/// Field-complete contract model for `UnknownFieldDisposition`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UnknownFieldDisposition {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl UnknownFieldDisposition {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `UnknownFieldPosture`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum UnknownFieldPosture {
    Declared,
    Applicable,
    Inapplicable {
        reason: crate::waist::StableId,
    },
    Blocked {
        gap: crate::waist::ArtifactRef,
    },
}

/// Field-complete contract model for `ValueDescriptor`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ValueDescriptor {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub owner: crate::waist::AuthorityRef,
    pub kind: crate::waist::RegistryKind,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub source: crate::waist::ArtifactRef,
    pub commitment: crate::waist::DigestClaim,
}
