//! Operation contracts owned by `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`.

pub trait DeclarationAdmissionContracts {
    /// `admission.dispatch.bind`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_admission_dispatch(
        &self,
        arg0: &crate::vertical::FamilyDescriptorSet,
        arg1: &crate::catalog_types::family_compilation::FamilySurfaceSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmissionDispatchTable, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.set.admit`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_declaration_set(
        &self,
        arg0: &crate::vertical::ParsedSourceSet,
        arg1: &crate::vertical::FamilyDescriptorSet,
        arg2: &crate::catalog_types::declaration_admission::AdmissionPolicy,
        arg3: crate::catalog_types::declaration_admission::AdmissionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmissionOutcome, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.declaration.select-schema`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn select_declaration_schema(
        &self,
        arg0: crate::catalog_types::declaration_admission::SyntaxNodeRef,
        arg1: &crate::catalog_types::declaration_admission::DescriptorIndex,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::DeclarationDescriptorRef, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.declaration.admit`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_declaration(
        &self,
        arg0: crate::catalog_types::declaration_admission::SyntaxNodeRef,
        arg1: &crate::catalog_types::declaration_admission::DeclarationDescriptor,
        arg2: &crate::catalog_types::declaration_admission::AdmissionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmittedDeclaration, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.field.admit`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_field(
        &self,
        arg0: crate::catalog_types::declaration_admission::MappingEntryRef,
        arg1: &crate::catalog_types::declaration_admission::FieldDescriptor,
        arg2: &crate::catalog_types::declaration_admission::AdmissionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmittedField, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.value.construct`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn construct_owner_value(
        &self,
        arg0: &crate::catalog_types::declaration_admission::ValueDescriptor,
        arg1: &crate::catalog_types::declaration_admission::AdmittedFieldSet,
        arg2: &crate::catalog_types::declaration_admission::OwnerAdmissionFns,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::OpaqueOwnerValue, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.missing.synthesize`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn synthesize_missing_field_span(
        &self,
        arg0: crate::catalog_types::declaration_admission::SyntaxNodeRef,
        arg1: &crate::catalog_types::declaration_admission::FieldDescriptor,
        arg2: &crate::catalog_types::application_source_parsing::SourceMap,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::SyntheticInsertionSpan, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.unknown.resolve`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_unknown_field(
        &self,
        arg0: crate::catalog_types::declaration_admission::MappingEntryRef,
        arg1: &crate::catalog_types::declaration_admission::UnknownFieldPosture,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::UnknownFieldDisposition, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.reference.admit`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_unresolved_name_ref(
        &self,
        arg0: crate::catalog_types::declaration_admission::ScalarLexemeRef,
        arg1: &crate::catalog_types::declaration_admission::ReferenceDescriptor,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::name_binding::UnresolvedNameRef, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.poison.create`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_admission_poison(
        &self,
        arg0: crate::catalog_types::declaration_admission::DiagnosticId,
        arg1: crate::catalog_types::declaration_admission::AffectedArtifactRef,
        arg2: crate::catalog_types::declaration_admission::PoisonReason,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::PoisonRef, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.poison.propagate`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn propagate_admission_poison(
        &self,
        arg0: &crate::catalog_types::declaration_admission::PoisonRef,
        arg1: crate::catalog_types::declaration_admission::DependentArtifactRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::CascadeDiagnostic, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.diagnostics.finalize`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn finalize_admission_diagnostics(
        &self,
        arg0: crate::catalog_types::compiler_host::DiagnosticAccumulator,
        arg1: crate::catalog_types::declaration_admission::AdmissionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmissionDiagnosticGraph, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.checkpoint.create`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_admission_checkpoint(
        &self,
        arg0: &crate::catalog_types::declaration_admission::AdmissionState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmissionCheckpoint, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.checkpoint.resume`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_admission(
        &self,
        arg0: &crate::catalog_types::declaration_admission::AdmissionCheckpoint,
        arg1: &crate::vertical::ParsedSourceSet,
        arg2: &crate::vertical::FamilyDescriptorSet,
        arg3: crate::catalog_types::declaration_admission::AdmissionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmissionOutcome, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.verify`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_admitted_set(
        &self,
        arg0: &crate::vertical::AdmittedDeclarationSet,
        arg1: &crate::vertical::FamilyDescriptorSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmissionProof, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

    /// `admission.explain`. Owner: `SAN-COMPILER-DECLARATION-ADMISSION-AND-POISON-RECOVERY`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_admission_target(
        &self,
        arg0: crate::catalog_types::declaration_admission::AdmissionExplainTarget,
        arg1: &crate::catalog_types::declaration_admission::AdmissionOutcome,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::declaration_admission::AdmissionExplanation, crate::vertical::DeclarationAdmissionRefusal, crate::waist::CompilerNeedsInput>;

}
