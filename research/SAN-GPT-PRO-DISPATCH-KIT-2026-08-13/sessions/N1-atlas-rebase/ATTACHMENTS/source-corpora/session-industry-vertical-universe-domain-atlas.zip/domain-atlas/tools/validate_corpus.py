#!/usr/bin/env python3
"""Portable validator for the packaged SAN industry vertical universe atlas."""
from __future__ import annotations
import argparse, hashlib, json, sys
from collections import Counter
from pathlib import Path
import jsonschema
from referencing import Registry, Resource

PREFIX = "candidate.industry-vertical-universe."
ENVELOPE = {"schema_version","id","kind","canonical_name","definition","aliases","version","lifecycle_status","classification","applicability","confidence","evidence_refs","created_at","updated_at"}
FORBIDDEN = {"metadata","properties","attributes","payload","extensions","custom_fields","notes"}

def walk_keys(obj):
    if isinstance(obj, dict):
        for k,v in obj.items():
            yield k
            yield from walk_keys(v)
    elif isinstance(obj, list):
        for x in obj: yield from walk_keys(x)

def walk_refs(obj):
    if isinstance(obj, dict):
        for k,v in obj.items():
            if k.endswith("_ref") or k.endswith("_refs") or k == "participant_ref":
                if isinstance(v,str): yield k,v
                elif isinstance(v,list):
                    for x in v:
                        if isinstance(x,str): yield k,x
            yield from walk_refs(v)
    elif isinstance(obj,list):
        for x in obj: yield from walk_refs(x)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("root", nargs="?", default=str(Path(__file__).resolve().parents[1])); args=ap.parse_args()
    root=Path(args.root).resolve(); failures=[]; records=[]; file_records={}; parse_count=0
    for path in sorted(root.rglob("*.json")):
        try: json.loads(path.read_text(encoding="utf-8")); parse_count+=1
        except Exception as exc: failures.append(f"parse {path.relative_to(root)}: {exc}")
    for path in sorted(root.rglob("*.jsonl")):
        items=[]
        try:
            for n,line in enumerate(path.read_text(encoding="utf-8").splitlines(),1):
                if line.strip(): items.append(json.loads(line))
            parse_count+=1
        except Exception as exc: failures.append(f"parse {path.relative_to(root)}: {exc}")
        records.extend(items); file_records[path]=items
    ids=[r.get("id") for r in records]; dup=[x for x,c in Counter(ids).items() if c>1]
    if dup: failures.append(f"duplicate ids: {dup[:20]}")
    known=set(ids)
    for r in records:
        missing=ENVELOPE-set(r)
        if missing: failures.append(f"{r.get('id')}: missing envelope {sorted(missing)}")
        bad=set(walk_keys(r))&FORBIDDEN
        if bad: failures.append(f"{r.get('id')}: forbidden keys {sorted(bad)}")
        if not str(r.get("id","")).startswith(PREFIX): failures.append(f"{r.get('id')}: bad candidate namespace")
        for key,ref in walk_refs(r):
            if ref.startswith(PREFIX) and ref not in known: failures.append(f"{r.get('id')}: dangling {key}={ref}")
    for path,items in file_records.items():
        file_ids=[r["id"] for r in items]
        if file_ids != sorted(file_ids): failures.append(f"non-deterministic ordering: {path.relative_to(root)}")
    schema_paths=sorted((root/"schemas").rglob("*.schema.json")); resources=[]; schemas={}
    for path in schema_paths:
        obj=json.loads(path.read_text(encoding="utf-8")); schemas[path]=obj; resources.append((obj["$id"],Resource.from_contents(obj)))
    registry=Registry().with_resources(resources)
    path_to_collection={
        "corpus/coverage_areas.jsonl":"coverage_areas","corpus/concepts.jsonl":"concepts","corpus/contextual_meanings.jsonl":"contextual_meanings","corpus/claims.jsonl":"claims","corpus/value_objects.jsonl":"value_objects","corpus/entities.jsonl":"entities","corpus/states.jsonl":"states","corpus/commands.jsonl":"commands","corpus/events.jsonl":"events","corpus/queries.jsonl":"queries","corpus/refusals.jsonl":"refusals","corpus/laws.jsonl":"laws","corpus/policies.jsonl":"policies","corpus/capabilities.jsonl":"capabilities","corpus/artifacts.jsonl":"artifacts","corpus/contexts.jsonl":"contexts","corpus/context_relationships.jsonl":"context_relationships","corpus/relations.jsonl":"relations","corpus/profiles.jsonl":"profiles","corpus/compositions.jsonl":"compositions","corpus/mappings.jsonl":"mappings","corpus/evidence.jsonl":"evidence","corpus/decisions.jsonl":"decisions","scenarios/competency_questions.jsonl":"competency_questions","scenarios/positive_examples.jsonl":"positive_examples","scenarios/negative_examples.jsonl":"negative_examples","scenarios/boundary_examples.jsonl":"boundary_examples","scenarios/cross_domain_examples.jsonl":"cross_domain_examples","registry_intake/candidate_units.jsonl":"candidate_units","registry_intake/existing_record_crosswalk.jsonl":"existing_record_crosswalk","registry_intake/merge_split_proposals.jsonl":"merge_split_proposals","registry_intake/disposition_ledger.jsonl":"disposition_ledger","registry_intake/registry_change_requests.jsonl":"registry_change_requests","issues/conflicts.jsonl":"conflicts","issues/gaps.jsonl":"gaps","issues/unresolved_boundaries.jsonl":"unresolved_boundaries","issues/unresolved_references.jsonl":"unresolved_references"}
    schema_by_name={p.stem.replace(".schema",""):obj for p,obj in schemas.items()}
    for rel,collection in path_to_collection.items():
        path=root/rel; schema=schema_by_name.get(collection)
        if not path.exists(): failures.append(f"missing required collection {rel}"); continue
        if schema is None: failures.append(f"missing schema for {collection}"); continue
        validator=jsonschema.Draft202012Validator(schema, registry=registry, format_checker=jsonschema.FormatChecker())
        for r in file_records.get(path,[]):
            errs=list(validator.iter_errors(r))
            if errs: failures.append(f"schema {r['id']}: {errs[0].message}")
    checksums=root/"CHECKSUMS.txt"
    if checksums.exists():
        for line in checksums.read_text(encoding="utf-8").splitlines():
            if not line.strip(): continue
            expected,rel=line.split("  ",1); path=root/rel
            if not path.exists(): failures.append(f"checksum missing file {rel}")
            elif hashlib.sha256(path.read_bytes()).hexdigest()!=expected: failures.append(f"checksum mismatch {rel}")
    else: failures.append("CHECKSUMS.txt missing")
    result={"status":"PASS" if not failures else "FAIL","parsed_files":parse_count,"record_count":len(records),"failures":failures[:200]}
    print(json.dumps(result,sort_keys=True))
    return 0 if not failures else 1
if __name__=="__main__": raise SystemExit(main())
