# SAN Party, Authority, Governance, Trust, Security, and Privacy Domain Atlas

> Generated navigation only. JSON and JSONL are authoritative.

## Package posture

Research candidate, not registry admission, ratification, implementation, or legal advice.

## Canonical collections

| Collection | Records | Source file |
|---|---:|---|
| `coverage_areas` | 18 | `corpus/coverage_areas.jsonl` |
| `concepts` | 201 | `corpus/concepts.jsonl` |
| `contextual_meanings` | 37 | `corpus/contextual_meanings.jsonl` |
| `claims` | 55 | `corpus/claims.jsonl` |
| `value_objects` | 49 | `corpus/value_objects.jsonl` |
| `entities` | 32 | `corpus/entities.jsonl` |
| `states` | 233 | `corpus/states.jsonl` |
| `commands` | 77 | `corpus/commands.jsonl` |
| `events` | 74 | `corpus/events.jsonl` |
| `queries` | 37 | `corpus/queries.jsonl` |
| `refusals` | 78 | `corpus/refusals.jsonl` |
| `laws` | 86 | `corpus/laws.jsonl` |
| `policies` | 19 | `corpus/policies.jsonl` |
| `capabilities` | 37 | `corpus/capabilities.jsonl` |
| `artifacts` | 34 | `corpus/artifacts.jsonl` |
| `contexts` | 49 | `corpus/contexts.jsonl` |
| `context_relationships` | 149 | `corpus/context_relationships.jsonl` |
| `relations` | 251 | `corpus/relations.jsonl` |
| `profiles` | 13 | `corpus/profiles.jsonl` |
| `compositions` | 10 | `corpus/compositions.jsonl` |
| `mappings` | 41 | `corpus/mappings.jsonl` |
| `evidence_sources` | 38 | `corpus/evidence_sources.jsonl` |
| `competency_questions` | 62 | `scenarios/competency_questions.jsonl` |
| `positive_examples` | 12 | `scenarios/positive_examples.jsonl` |
| `negative_examples` | 12 | `scenarios/negative_examples.jsonl` |
| `boundary_examples` | 12 | `scenarios/boundary_examples.jsonl` |
| `cross_domain_examples` | 12 | `scenarios/cross_domain_examples.jsonl` |
| `ambiguous_examples` | 12 | `scenarios/ambiguous_examples.jsonl` |
| `conflicting_examples` | 12 | `scenarios/conflicting_examples.jsonl` |
| `candidate_units` | 49 | `registry_intake/candidate_units.jsonl` |
| `existing_record_crosswalk` | 184 | `registry_intake/existing_record_crosswalk.jsonl` |
| `merge_split_proposals` | 6 | `registry_intake/merge_split_proposals.jsonl` |
| `disposition_ledger` | 49 | `registry_intake/disposition_ledger.jsonl` |
| `registry_change_requests` | 18 | `registry_intake/registry_change_requests.jsonl` |
| `conflicts` | 12 | `issues/conflicts.jsonl` |
| `gaps` | 20 | `issues/gaps.jsonl` |
| `unresolved_boundaries` | 16 | `issues/unresolved_boundaries.jsonl` |
| `unresolved_references` | 3 | `issues/unresolved_references.jsonl` |

## Boundary dispositions

| Disposition | Count |
|---|---:|
| `CANDIDATE_BOUNDED_CONTEXT` | 28 |
| `COMPOSITION` | 1 |
| `FOUNDATION_ALGEBRA_CANDIDATE` | 2 |
| `IMPLEMENTATION_CONCERN` | 1 |
| `MERGE_REQUIRED` | 2 |
| `PROFILE` | 1 |
| `REJECT_FALSE_BOUNDARY` | 3 |
| `SEMANTIC_FAMILY_CANDIDATE` | 7 |
| `SPLIT_REQUIRED` | 4 |

## Highest-impact unresolved boundaries

- `candidate.party-authority-governance.unresolved-boundary.adjudication-versus-review`: Adjudication, Administrative Review, and Appeal
- `candidate.party-authority-governance.unresolved-boundary.anonymization-boundary`: Anonymization and Identifiability
- `candidate.party-authority-governance.unresolved-boundary.compliance-versus-assurance`: Compliance Assessment versus Assurance
- `candidate.party-authority-governance.unresolved-boundary.consent-versus-agreement`: Consent versus Agreement or Assent
- `candidate.party-authority-governance.unresolved-boundary.credential-boundary`: Credential Boundary
- `candidate.party-authority-governance.unresolved-boundary.entitlement-right`: Entitlement as Access Grant versus Benefit Right
- `candidate.party-authority-governance.unresolved-boundary.erasure-derived-models`: Erasure and Derived Models
- `candidate.party-authority-governance.unresolved-boundary.liability-owner`: Liability Ownership
- `candidate.party-authority-governance.unresolved-boundary.non-repudiation-term`: Non-repudiation Terminology
- `candidate.party-authority-governance.unresolved-boundary.office-versus-position`: Office versus Position

## Validation

Status: **PASS**

Run `python tools/validate_corpus.py .` from the `domain-atlas` directory.
