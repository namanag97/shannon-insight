//! Operation contracts owned by `SAN-COMPILER-APPLICATION-SOURCE-PARSING`.

pub trait ApplicationSourceParsingContracts {
    /// `restricted-parser.profile.admit`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_syntax_profile(
        &self,
        arg0: crate::catalog_types::application_source_parsing::RestrictedSyntaxProfileMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.source.admit`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_source_octets(
        &self,
        arg0: crate::catalog_types::application_source_parsing::SourceArtifactRef,
        arg1: &[u8],
        arg2: &crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::AdmittedSource, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.source.normalize`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn normalize_source_view(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::AdmittedSource,
        arg1: &crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::NormalizedSourceView, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.lex`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn lex_source(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::NormalizedSourceView,
        arg1: &crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile,
        arg2: crate::catalog_types::application_source_parsing::ParseBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::TokenStream, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.forbidden.scan`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn scan_forbidden_features(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::TokenStream,
        arg1: &crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ForbiddenFeatureReport, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.parse.document`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn parse_document(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::TokenStream,
        arg1: &crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile,
        arg2: crate::catalog_types::application_source_parsing::ParseBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ParseOutcome, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.parse.mapping`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn parse_mapping(
        &self,
        arg0: &mut crate::catalog_types::application_source_parsing::ParserState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::SyntaxNodeId, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.parse.sequence`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn parse_sequence(
        &self,
        arg0: &mut crate::catalog_types::application_source_parsing::ParserState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::SyntaxNodeId, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.parse.scalar`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn parse_scalar_lexeme(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::Token,
        arg1: &crate::catalog_types::application_source_parsing::ScalarGrammar,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ParsedScalarLexeme, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.duplicates.detect`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn detect_duplicate_keys(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::ConcreteSyntaxTree,
        arg1: &crate::catalog_types::application_source_parsing::SourceMap,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::DuplicateKeyReport, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.recovery.synchronize`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn synchronize_parser(
        &self,
        arg0: &mut crate::catalog_types::application_source_parsing::ParserState,
        arg1: crate::catalog_types::application_source_parsing::RecoveryBoundary,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::RecoveryResult, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.diagnostics.finalize`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn finalize_parse_diagnostics(
        &self,
        arg0: crate::catalog_types::compiler_host::DiagnosticAccumulator,
        arg1: crate::catalog_types::application_source_parsing::ParseBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ParseDiagnosticSet, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.checkpoint.create`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_parser_checkpoint(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::ParserState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ParserCheckpoint, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.checkpoint.resume`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_parse(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::ParserCheckpoint,
        arg1: &crate::catalog_types::application_source_parsing::AdmittedSource,
        arg2: &crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile,
        arg3: crate::catalog_types::application_source_parsing::ParseBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ParseOutcome, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.verify`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_parsed_source(
        &self,
        arg0: &crate::catalog_types::application_source_parsing::ParsedSource,
        arg1: &crate::catalog_types::application_source_parsing::RestrictedSyntaxProfile,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ParseProof, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

    /// `restricted-parser.explain`. Owner: `SAN-COMPILER-APPLICATION-SOURCE-PARSING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_parse_target(
        &self,
        arg0: crate::catalog_types::application_source_parsing::ParseExplainTarget,
        arg1: &crate::vertical::ParsedSourceSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_source_parsing::ParseExplanation, crate::vertical::ApplicationSourceParsingRefusal, crate::waist::CompilerNeedsInput>;

}
