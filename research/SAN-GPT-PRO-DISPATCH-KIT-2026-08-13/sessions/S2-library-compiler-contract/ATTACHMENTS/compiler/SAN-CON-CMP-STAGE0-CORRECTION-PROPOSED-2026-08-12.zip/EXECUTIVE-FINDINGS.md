# SAN CON/CMP Stage-0 Compiler Spine Audit

**Package status:** `PROPOSED`  
**Certification:** `NONE`  
**As of:** `2026-08-12`  

## Primary ruling

**No. The supplied snapshot cannot currently execute the full signed Stage-0 → non-empty sealed CSAG → portable target portfolio → AppRelease → complete offline-reverification vertical lawfully.** It reaches a bounded planless Stage-0 fixture through the current CMP-006 `ApplicationClosure`, then stops. The first mandatory downstream stage can reject that value, so the current artifact name is semantically false if CMP-008 remains mandatory.

The smallest coherent correction is **`PROPOSED_SELECT_CMP013_HARD_CUT`**:

```text
PinnedStage0TrustAnchor
  -> Stage0PackageAuthority
  -> VerifiedPackageLock + CompleteSupplierDispositionMatrix
  -> AdmittedContextSpec + VerifiedFamilyRelease
  -> CompiledFamilyDescriptor
  -> FamilyPlanSet
  -> ApplicationBinding                 [CMP-006]
  -> ObligationClosure                  [CMP-007]
  -> VerifiedCsag                       [CMP-008]
  -> VerifiedApplicationClosure         [CMP-013, PROPOSED]
  -> TargetCompilationSet               [CMP-009]
  -> AppRelease                         [CMP-010]
  -> OfflineVerificationBundle/Report
```

No compatibility alias is permitted. The old CMP-006 `ApplicationClosure` must disappear in the same hard cut that introduces the new stage boundaries. A renamed wrapper around the old value would merely perfume the authority laundering, which is the sort of ritual software projects perform when deleting the wrong abstraction feels emotionally difficult.

## Why this is not a cycle ruling

The audit distinguishes four graphs:

1. **Rust dependency DAG.** Must remain acyclic. The proposed split is lawful only if `san-application-linker -> san-obligation-fixed-point` is deleted atomically before adding `san-obligation-fixed-point -> san-application-linker`.
2. **Artifact-production DAG.** Both the current and recommended graphs are topologically acyclic. The defect in the current graph is semantic finality, not graph theory.
3. **Semantic seam graph.** May be reciprocal. CMP-008 may ask a relation owner to verify an authority cycle and receive a proof value without introducing a reverse crate dependency.
4. **Proof-reference graph.** Must point from earlier proof subjects into later aggregations. A predecessor may be retained by a final proof, but it must not require that later proof for its own validity.

## Hard blockers on the exact vertical

- **PATH-001**: Complete signed Stage-0 authority for every selected release is not proven. Shortest chain: PackageLock selects compiler.application-linker and sem.stage0-planless → disposition carriers contain compiler.application-linker only → verify_complete_supplier_inventories iterates supplied owner groups → Stage0PackageAuthority is issued without sem.stage0-planless disposition set. Missing issuer/provider: `Stage-0 disposition issuer for sem.stage0-planless edition 1, covering every CompilerSupplierRole`. Sources: `SNAPSHOT/compiler/san-constitution-model/src/stage0.rs:L985-L1021`, `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L53-L118`, `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L198-L239`.
- **PATH-002**: Observed family surface is caller-supplied in the positive fixture rather than independently produced by a package-selected surface verifier. Shortest chain: fixture constructs ObservedNativeSurface → compile checks consistency → no exact package-selected observer/verifier proof is retained for the observation. Missing issuer/provider: `Available CompilerFamilySurfaceVerification supplier selected for the exact family/compiler owner, or a typed structural inapplicability proof accepted by the constitution`. Sources: `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L702-L731`, `SNAPSHOT/compiler/san-constitution-model/src/package_authority.rs:L534-L545`.
- **PATH-003**: Current CMP-006 ApplicationClosure cannot lawfully be final because CMP-008 remains mandatory and may refuse. Shortest chain: CMP-006 issues value named ApplicationClosure → CMP-008 is still mandatory → CMP-008 may refuse graph laws or authority cycle → therefore prior artifact was not final closure. Missing issuer/provider: `PROPOSED CMP-013 final closure issuer after VerifiedCsag`. Sources: `SNAPSHOT/compiler/san-application-linker/src/closure.rs:L14-L33`, `SNAPSHOT/compiler/san-csag-model/src/graph.rs:L822-L859`, `SNAPSHOT/docs/specs/SAN-CONSTITUTIONAL-CONTRACT-SYSTEM-EDITION-1/SOURCE/CONSTITUTION/PURE-LIBRARY-CONSTITUTION-EDITION-2.txt:L899-L903`.
- **PATH-004**: Planless ApplicationClosure cannot produce a lawful non-empty CSAG. Shortest chain: PlanlessApplicationClosureProjection emits nodes=[] → no family projection may fabricate plan semantics → assembled graph has zero nodes → Csag::assemble returns GraphEmpty. Missing issuer/provider: `CMP-008 compiler-owned CsagClosureProjection implementation that emits exactly one san.csag.application-anchor node`. Sources: `SNAPSHOT/compiler/san-csag/src/projection.rs:L63-L123`, `SNAPSHOT/compiler/san-csag-model/src/graph.rs:L822-L859`.
- **PATH-005**: A cyclic authority graph cannot reach CMP-008 under current CMP-006 even when an owner verifier could prove attenuation. Shortest chain: CMP-006 derives authority graph → verify_authority_acyclic detects cycle → CMP-006 refuses before CMP-008 owner verifier can run. Missing issuer/provider: `No missing provider when cycle verifier is available; the blocker is duplicated ownership in CMP-006`. Sources: `SNAPSHOT/compiler/san-application-linker/src/graph.rs:L617-L642`, `SNAPSHOT/compiler/san-csag/src/views.rs:L232-L286`.
- **PATH-006**: VerifiedCsag cannot lower to any target because target executable authority cannot bind. Shortest chain: at least one target request is required → BoundTargetCompilerPortfolio calls component binders → bind_target_supplier ignores dispositions/lock and returns SupplierUnavailable. Missing issuer/provider: `Implemented Stage-0 binder plus Available suppliers for TargetCompilation, TargetSeeding, ConversionTarget, TranslationValidation and applicable conditional target roles`. Sources: `SNAPSHOT/compiler/san-target-lowering-model/src/authority.rs:L47-L62`, `SNAPSHOT/compiler/san-target-lowering-framework/src/engine.rs:L115-L129`.
- **PATH-007**: Target executable descriptors cannot satisfy the QualifiedDigestClaim hard cut. Shortest chain: Stage-0 supplier carries QualifiedDigestClaim → target descriptor accepts DigestClaimCarrier → exact canonical subject/schema/separation binding is erased. Missing issuer/provider: `No new issuer; exact QualifiedDigestClaim must be retained by every target executable descriptor`. Sources: `SNAPSHOT/compiler/san-target-lowering-model/src/authority.rs:L3-L24`, `SNAPSHOT/compiler/san-app-release/src/mechanism.rs:L17-L25`.
- **PATH-008**: AppRelease cannot be assembled from the supplied vertical because no target set exists and no complete release verifier/adapter portfolio is implemented. Shortest chain: TargetCompilationSet absent → release input verification requires exact target verification → release source/artifact/seal/crypto/adapter suppliers absent → no AppRelease issued. Missing issuer/provider: `Available package-selected ReleaseSourceVerification, ReleaseArtifactVerification, ReleaseSealVerification, ReleaseAdapterVerification, lifecycle, applicable signature/attestation, inventory/packaging, and optional parity suppliers`. Sources: `SNAPSHOT/compiler/san-app-release/src/mechanism.rs:L381-L519`, `SNAPSHOT/compiler/san-app-release/src/input.rs:L551-L624`.
- **PATH-009**: Offline reverification of every retained proof is impossible without a full AppRelease and archived exact historical executables/trust material. Shortest chain: no AppRelease exists → no complete archive of selected executables and historical trust material exists → offline contexts cannot be reconstructed. Missing issuer/provider: `Original Stage-0-selected verifier implementations plus immutable historical trust/canonical/source/proof archive; no network lookup substitute`. Sources: `SNAPSHOT/compiler/san-csag/src/offline.rs:L1-L8`, `SNAPSHOT/compiler/san-app-release/src/release.rs:L700-L767`.
- **PATH-010**: Production-eligible release is independently blocked even after a smoke AppRelease becomes executable. Shortest chain: smoke implementations may execute → normative blocking gaps remain → all mechanism classifiers production_eligible=false → certification remains NONE. Missing issuer/provider: `Independent certification authority and closed normative gaps; not a code-local provider substitution`. Sources: `SNAPSHOT/compiler/san-app-release/src/mechanism.rs:L381-L519`, `SNAPSHOT/docs/specs/SAN-CONSTITUTIONAL-CONTRACT-SYSTEM-EDITION-1/SOURCE/CONSTITUTION/PURE-LIBRARY-CONSTITUTION-EDITION-2.txt:L281-L304`.

## Finding register

### F-001 · FOUNDATIONAL · `ACCEPT_INTEGRITY_REJECT_AUTHORITY_PROMOTION`

The proposed SSPEC archive is integrity-valid but remains a review candidate and cannot override the snapshot by verifier success alone.

**Consequence:** The archive may supply a candidate decomposition, not ratification or certification.  
**Sources:** `HANDOFF/README.md:L7-L21`, `PROPOSAL/01-SYSTEM/ARTIFACT-LADDER-DECISION.json:L2-L27`, `SNAPSHOT/docs/specs/SAN-CONSTITUTIONAL-CONTRACT-SYSTEM-EDITION-1/SOURCE/CONSTITUTION/PURE-LIBRARY-CONSTITUTION-EDITION-2.txt:L281-L304`

### F-002 · PRESERVE · `PRESERVE`

Stage-0 correctly avoids circular package authority by using a pinned out-of-band Ed25519 trust anchor that package content cannot replace.

**Consequence:** Do not invent a Stage-0 issuer or let a selected package supplier authorize the first lock.  
**Sources:** `SNAPSHOT/compiler/san-constitution-model/src/stage0.rs:L1-L8`, `SNAPSHOT/compiler/san-constitution-model/src/stage0.rs:L833-L890`

### F-003 · CRITICAL · `CORRECT_BEFORE_LADDER_MIGRATION`

Stage-0 does not prove complete role inventories for every selected release because completeness iteration begins from supplied dispositions and never enumerates omitted selected releases.

**Consequence:** A selected release may have no disposition set at all while Stage0PackageAuthority claims complete inventories.  
**Sources:** `SNAPSHOT/compiler/san-constitution-model/src/stage0.rs:L985-L1021`, `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L53-L118`, `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L198-L239`

### F-004 · HIGH · `CORRECT`

Stage-0 work precharge is based on hostile carrier count rather than the exact selected-release × closed-role matrix, and allocation occurs before proving that exact cardinality.

**Consequence:** Precharge exact expected count and aggregate allocation from the admitted lock before scanning or allocating disposition storage.  
**Sources:** `SNAPSHOT/compiler/san-constitution-model/src/stage0.rs:L719-L758`, `SNAPSHOT/compiler/san-constitution-model/src/package_authority.rs:L638-L699`

### F-005 · CRITICAL · `HARDEN`

PackageLockVerificationProof is caller-constructible because every proof field is public even though VerifiedPackageLock itself has a crate-private constructor.

**Consequence:** A caller can author a proof value and move it through APIs that accept the proof separately; proof fields must be private and non-deserializable.  
**Sources:** `SNAPSHOT/compiler/san-constitution-model/src/package_authority.rs:L458-L495`

### F-006 · HIGH · `RETAIN_AS_FIXTURE_ADD_NEGATIVE_TWIN_AND_COMPLETE_MATRIX`

The first positive Stage-0 test is a bounded fixture, not a complete constitutional vertical: it uses one deterministic test signer, omits the planless release inventory, and marks most roles structurally inapplicable with generic artifact references.

**Consequence:** The test must not be cited as proof of package-wide supplier completeness or production issuer availability.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L121-L149`, `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L198-L260`

### F-007 · CRITICAL · `DO_NOT_CLAIM_FULL_VERTICAL`

The executable positive vertical currently ends at a sealed CMP-006 ApplicationClosure; it does not build CSAG, target portfolio, AppRelease, or offline-reverify the whole retained chain.

**Consequence:** The exact architecture in the prompt cannot currently execute end to end.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/tests/stage0_execution.rs:L682-L804`, `HANDOFF/README.md:L61-L78`

### F-008 · CRITICAL · `PROPOSED_SELECT_CMP013_HARD_CUT`

The current CMP-006 name ApplicationClosure is semantically premature because mandatory CMP-008 graph construction may later refuse or invalidate the result.

**Consequence:** A pre-CSAG artifact may be an ApplicationBinding, not a final application closure.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/src/closure.rs:L14-L33`, `SNAPSHOT/compiler/san-csag/src/projection.rs:L63-L123`, `SNAPSHOT/compiler/san-csag-model/src/graph.rs:L822-L859`, `SNAPSHOT/docs/specs/SAN-CONSTITUTIONAL-CONTRACT-SYSTEM-EDITION-1/SOURCE/CONSTITUTION/PURE-LIBRARY-CONSTITUTION-EDITION-2.txt:L186-L210`, `PROPOSAL/01-SYSTEM/ARTIFACT-LADDER-DECISION.json:L12-L27`

### F-009 · HIGH · `MOVE_EXACT_BINDING_PROOFS_TO_APPLICATION_BINDING`

CMP-006 retains binding provenance artifacts rather than the exact ContractBindingVerificationProof values, so its proof manifest cannot independently reverify every binding.

**Consequence:** The CMP-006 output must retain one exact binding proof per resolved binding, plus explicit empty/absence proof where no bindings apply.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/src/closure.rs:L315-L347`, `SNAPSHOT/compiler/san-contract-model/src/selection.rs:L3083-L3116`

### F-010 · CRITICAL · `REPLACE_WITH_REPROJECTION_RECANONICALIZATION_RECOMMITMENT`

Current ApplicationClosure offline verification checks stored projection equality and subject coordinates but does not recompute canonical octets or compare them to the retained commitment.

**Consequence:** Stored closure fields can be internally consistent yet not prove the exact semantic bytes claimed by the seal.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/src/operations.rs:L670-L699`, `SNAPSHOT/compiler/san-application-linker/src/seal.rs:L465-L504`

### F-011 · HIGH · `RESTORE_TYPED_NEEDS_INPUT`

CMP-006 flattens CMP-007 NeedsSelection into Refused even though the public outcome enum has no typed NeedsInput branch.

**Consequence:** Refused, exhausted, and authority input required are semantically distinct and must remain distinct at each stage.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/src/closure.rs:L176-L185`, `SNAPSHOT/compiler/san-application-linker/src/engine.rs:L323-L340`

### F-012 · CRITICAL · `DELETE_CMP006_CYCLE_JUDGMENT_PRESERVE_CMP008_OWNER_VERIFICATION`

Authority-cycle handling conflicts across stages: CMP-006 rejects every delegation cycle, while CMP-008 correctly treats a cycle as conditionally lawful when an exact package-selected owner verifier proves non-amplification.

**Consequence:** Absence is lawful only for acyclic graphs; replay of a cyclic graph without the exact verifier must refuse.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/src/graph.rs:L569-L642`, `SNAPSHOT/compiler/san-csag/src/authority.rs:L1-L7`, `SNAPSHOT/compiler/san-csag/src/views.rs:L232-L286`

### F-013 · CRITICAL · `ADD_MINIMAL_COMPILER_OWNED_APPLICATION_ANCHOR`

Planless applications have no positive CSAG path because the compiler-owned closure projector emits zero nodes and Csag::assemble requires at least one node.

**Consequence:** The anchor must prove application graph existence without fabricating any family plan or domain semantic node.  
**Sources:** `SNAPSHOT/compiler/san-csag/src/projection.rs:L63-L123`, `SNAPSHOT/compiler/san-csag-model/src/graph.rs:L822-L859`, `HANDOFF/README.md:L66-L73`

### F-014 · PRESERVE_AND_SPECIALIZE · `PROPOSED_ANCHOR_KIND_SAN_CSAG_APPLICATION_ANCHOR`

The existing CSAG metamodel already has ApplicationEntrypoint, so the minimal anchor can use an existing node class rather than adding a competing semantic class.

**Consequence:** Exactly one compiler-owned anchor node per graph, zero family claims, fixed owner-qualified identity, and exact predecessor proof provenance.  
**Sources:** `SNAPSHOT/compiler/san-csag-model/src/class.rs:L35-L73`

### F-015 · HIGH · `STRENGTHEN_EXACT_SUBJECT_KEY`

CSAG Canonical + Digest plumbing is package-selected, but the subject verifier checks schema and editions without checking the exact application/release/package-lock/binding/obligation subject tuple.

**Consequence:** Bind canonical bytes to exact release occurrence, package-lock commitment, ApplicationBinding fingerprint, ObligationClosure fingerprint, graph schema, and a dedicated separation domain.  
**Sources:** `SNAPSHOT/compiler/san-csag/src/canonical.rs:L177-L220`, `SNAPSHOT/compiler/san-csag/src/canonical.rs:L222-L335`, `SNAPSHOT/compiler/san-csag/src/canonical.rs:L343-L394`, `SNAPSHOT/compiler/san-csag/src/canonical.rs:L474-L507`

### F-016 · CRITICAL · `IMPLEMENT_EXACT_STAGE0_TARGET_SUPPLIER_BINDING`

CMP-009 has no positive executable supplier path because bind_target_supplier discards all coordinates and unconditionally returns SupplierUnavailable.

**Consequence:** No TargetCompilationSet can be emitted until TargetCompilation, TargetSeeding, ConversionTarget, TranslationValidation, and applicable conditional roles bind successfully.  
**Sources:** `SNAPSHOT/compiler/san-target-lowering-model/src/authority.rs:L17-L62`, `SNAPSHOT/compiler/san-target-lowering-model/src/authority.rs:L126-L215`, `SNAPSHOT/compiler/san-target-lowering-framework/src/engine.rs:L115-L129`

### F-017 · HIGH · `HARD_CUT_TO_QUALIFIED_DIGEST_CLAIM`

CMP-009 executable surface coordinates still use DigestClaimCarrier rather than the post-hard-cut QualifiedDigestClaim used by Stage-0 supplier authority.

**Consequence:** A digest value without canonical subject/schema/separation coordinates cannot prove exact executable surface binding.  
**Sources:** `SNAPSHOT/compiler/san-target-lowering-model/src/authority.rs:L3-L24`, `SNAPSHOT/compiler/san-app-release/src/mechanism.rs:L1-L25`

### F-018 · CRITICAL · `ADD_REAL_PACKAGE_SELECTED_SMOKE_PORTFOLIO_WITHOUT_PRODUCTION_CLAIM`

CMP-010 has exact supplier-binding shape but every classified verifier/adapter mechanism is currently production-ineligible, and the test surface does not execute a positive AppRelease assembly.

**Consequence:** A genuine smoke AppRelease may be executable and certification NONE; it must not be mislabeled production eligible.  
**Sources:** `SNAPSHOT/compiler/san-app-release/src/mechanism.rs:L17-L72`, `SNAPSHOT/compiler/san-app-release/src/mechanism.rs:L381-L519`, `SNAPSHOT/compiler/san-app-release/tests/public_cmp010.rs:L1-L40`

### F-019 · HIGH · `BIND_FINAL_CLOSURE_COMMITMENT_TO_RETAINED_SEAL`

Release input admission replays an external closure verifier but does not compare its result with the retained closure seal commitment, while it performs that exact comparison for CSAG.

**Consequence:** CMP-010 must refuse a substituted external closure commitment even when the verifier is deterministic.  
**Sources:** `SNAPSHOT/compiler/san-app-release/src/input.rs:L551-L604`

### F-020 · CRITICAL · `BOUNDARY_WIDE_PROOF_PRIVACY_HARD_CUT`

Proof-bearing values remain broadly caller-constructible across the vertical, including FamilyPlanSetProof, ObligationClosureVerificationProof, CSAG proofs, and AppReleaseVerificationProof.

**Consequence:** All admitted/proof-bearing stage outputs require private fields, sealed constructors, public read-only accessors, Serialize only, and no public Deserialize path.  
**Sources:** `SNAPSHOT/compiler/san-family-closure/src/plan.rs:L235-L309`, `SNAPSHOT/compiler/san-family-closure/src/plan.rs:L405-L436`, `SNAPSHOT/compiler/san-obligation-fixed-point/src/closure.rs:L428-L437`, `SNAPSHOT/compiler/san-csag-model/src/proof.rs:L292-L315`, `SNAPSHOT/compiler/san-app-release/src/release.rs:L725-L767`

### F-021 · FOUNDATIONAL · `PROPOSED_NOT_RATIFIED`

The governing constitution establishes the compiler order and final application-closure concept but does not ratify the exact CMP-006/CMP-013 ownership split.

**Consequence:** The recommended hard cut requires an explicit constitutional/registry decision before implementation can claim normative authority.  
**Sources:** `SNAPSHOT/docs/specs/SAN-CONSTITUTIONAL-CONTRACT-SYSTEM-EDITION-1/SOURCE/CONSTITUTION/PURE-LIBRARY-CONSTITUTION-EDITION-2.txt:L186-L210`, `SNAPSHOT/docs/specs/SAN-CONSTITUTIONAL-CONTRACT-SYSTEM-EDITION-1/SOURCE/CONSTITUTION/PURE-LIBRARY-CONSTITUTION-EDITION-2.txt:L899-L903`, `PROPOSAL/02-COMPILER/CMP-013/SPEC.json:L4-L37`, `PROPOSAL/02-COMPILER/CMP-013/SPEC.json:L45-L73`

### F-022 · PRESERVE · `SEPARATE_FOUR_GRAPHS`

The current Rust dependency graph is acyclic even though semantic seams are reciprocal; the hard cut can remain acyclic by placing each artifact and proof in its producing stage and retaining only predecessor references.

**Consequence:** A value may reference predecessor proofs without creating a Rust cycle; semantic callbacks must live behind lower neutral contracts or owner descriptors.  
**Sources:** `SNAPSHOT/compiler/san-application-linker/Cargo.toml:L18-L28`, `SNAPSHOT/compiler/san-obligation-fixed-point/Cargo.toml:L18-L25`, `SNAPSHOT/compiler/san-csag/Cargo.toml:L18-L30`, `SNAPSHOT/compiler/san-app-release/Cargo.toml:L18-L30`, `SNAPSHOT/docs/specs/SAN-CONSTITUTIONAL-CONTRACT-SYSTEM-EDITION-1/SOURCE/CONSTITUTION/PURE-LIBRARY-CONSTITUTION-EDITION-2.txt:L885-L917`

### F-023 · MEDIUM · `DELETE_STALE_PACKAGING_ENTRY_AND_CORRECT_COMMENTS`

The handoff manifest has one stale .DS_Store entry, and constitution-compiler comments still describe Stage-0 issuance as unavailable even though executable code now accepts Stage-0-issued releases.

**Consequence:** Packaging and source commentary must not contradict executable behavior or verification reports.  
**Sources:** `HANDOFF/MANIFEST.sha256:L1-L8`, `SNAPSHOT/compiler/san-constitution-compiler/src/lib.rs:L153-L170`, `SNAPSHOT/compiler/san-constitution-compiler/src/lib.rs:L253-L306`

## Minimal compiler-owned application anchor

The CSAG must contain exactly one compiler-owned node for every application, including a planless one:

- class: existing `ApplicationEntrypoint`;
- nominal kind: `san.csag.application-anchor`;
- owner: exact selected CMP-008 compiler release, proposed owner-qualified namespace `compiler.csag/application-anchor`;
- subject: exact application identity, application-release occurrence, package-lock commitment, `ApplicationBinding` fingerprint, `ObligationClosure` fingerprint and CSAG schema edition;
- provenance: exact CMP-008 release, projection implementation, executable `QualifiedDigestClaim`, certification and predecessor proof occurrences;
- laws: exactly one anchor; no family may emit the reserved kind; the anchor never counts as family semantics, a decision, requirement, obligation, gap, or domain node; planless graph is one node and zero hyperedges.

This creates graph existence, not family meaning. It is the compiler admitting that an application exists, an intellectual burden humans apparently needed a dedicated node to carry.

## Smoke vertical versus production eligibility

A genuine smoke vertical needs one non-empty anchor-rooted CSAG slice, one portable target request, real package-selected aggregate compiler/seeder/conversion-target/independent-validator implementations, and real release source/artifact/seal/adapter verification. The current CMP-009 supplier binder always refuses and every listed CMP-010 mechanism is explicitly non-production-eligible. Therefore the corrected smoke release must retain `certification: NONE` and `production_eligible: false`; it may demonstrate executable evidence without pretending to be a production certification.

## Verification performed for this package

- The proposed SSPEC archive SHA-256 matched the expected digest exactly.
- Its bundled structural verifier reported pass, but that was treated only as structural evidence.
- Every cited source path, line span, file hash and span hash in the generated JSON was rechecked by the independent package verifier.
- Every JSON artifact was validated against a recursively closed Draft 2020-12 schema.
- Cross-file record references, duplicate identities, embedded-edition record identities, required CON/CMP coverage dimensions, test-vector category coverage and acyclic Rust/artifact/proof DAGs were checked.
- The handoff manifest was rechecked; all present entries matched, but it contains one stale missing `.DS_Store` entry.
- `cargo` is not installed in this execution environment, so the snapshot’s claimed prior Cargo checks could not be independently rerun here. This limitation is recorded, not tactically forgotten.

## Authority status

No supplied constitutional source ratifies the exact CMP-013 coordinate or the proposed separation-domain constants. The artifact-ladder selection, CMP-013 owner coordinate, application-anchor support schema, CSAG/final-closure digest domains, portable smoke target profile and release applicability policy therefore remain explicitly `PROPOSED` in `OPEN-DECISIONS.json`.

The package preserves source/code behavior that is already coherent and changes only the seams that block lawful execution. It does not expand into SEM, DOM, DAT or UI, because one compiler spine is quite enough administrative misery for a single archive.
