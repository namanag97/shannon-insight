# Assets, Resources, Operations Domain Atlas

JSON and JSONL are canonical. This Markdown file is navigation only.

## Principal collections

| Kind | Records | Canonical file |
|---|---:|---|
| `artifact` | 65 | `corpus/artifacts.jsonl` |
| `boundary_example` | 102 | `scenarios/boundary_examples.jsonl` |
| `capability` | 75 | `corpus/capabilities.jsonl` |
| `claim` | 33 | `corpus/claims.jsonl` |
| `command` | 131 | `corpus/commands.jsonl` |
| `competency_question` | 105 | `scenarios/competency_questions.jsonl` |
| `composition` | 11 | `corpus/compositions.jsonl` |
| `concept` | 263 | `corpus/concepts.jsonl` |
| `conflict` | 15 | `issues/conflicts.jsonl` |
| `context_candidate` | 30 | `corpus/contexts.jsonl` |
| `context_relationship` | 121 | `corpus/context_relationships.jsonl` |
| `contextual_meaning` | 283 | `corpus/contextual_meanings.jsonl` |
| `coverage_area` | 29 | `corpus/coverage_areas.jsonl` |
| `cross_domain_example` | 35 | `scenarios/cross_domain_examples.jsonl` |
| `disposition_ledger_entry` | 30 | `registry_intake/disposition_ledger.jsonl` |
| `entity` | 108 | `corpus/entities.jsonl` |
| `event` | 132 | `corpus/events.jsonl` |
| `evidence` | 38 | `corpus/evidence.jsonl` |
| `existing_record_crosswalk` | 39 | `registry_intake/existing_record_crosswalk.jsonl` |
| `gap` | 20 | `issues/gaps.jsonl` |
| `law` | 141 | `corpus/laws.jsonl` |
| `mapping` | 35 | `corpus/mappings.jsonl` |
| `merge_split_proposal` | 12 | `registry_intake/merge_split_proposals.jsonl` |
| `negative_example` | 80 | `scenarios/negative_examples.jsonl` |
| `policy` | 55 | `corpus/policies.jsonl` |
| `positive_example` | 77 | `scenarios/positive_examples.jsonl` |
| `profile` | 16 | `corpus/profiles.jsonl` |
| `query` | 69 | `corpus/queries.jsonl` |
| `refusal` | 262 | `corpus/refusals.jsonl` |
| `registry_candidate_unit` | 30 | `registry_intake/candidate_units.jsonl` |
| `registry_change_request` | 12 | `registry_intake/registry_change_requests.jsonl` |
| `relation` | 3228 | `corpus/relations.jsonl` |
| `state` | 194 | `corpus/states.jsonl` |
| `unresolved_boundary` | 15 | `issues/unresolved_boundaries.jsonl` |
| `unresolved_reference` | 5 | `issues/unresolved_references.jsonl` |
| `value_object` | 89 | `corpus/value_objects.jsonl` |

## Boundary dispositions

| Disposition | Count |
|---|---:|
| `CANDIDATE_BOUNDED_CONTEXT` | 20 |
| `COMPOSITION` | 2 |
| `FOUNDATION_ALGEBRA_CANDIDATE` | 1 |
| `PROFILE` | 1 |
| `REJECT_FALSE_BOUNDARY` | 1 |
| `RESOURCE_CONTRACT` | 1 |
| `SEMANTIC_FAMILY_CANDIDATE` | 1 |
| `SPLIT_REQUIRED` | 3 |

## Validation and coverage

- `VALIDATION.json` is the canonical mechanical validation report.
- `coverage/coverage_matrix.json` records populated and excluded coverage.
- `coverage/boundary_evaluation.json` records the twelve boundary tests.
- `registry_intake/` contains non-mutating intake and change proposals.
- `issues/` preserves conflicts, gaps, unresolved boundaries, and unresolved references.
