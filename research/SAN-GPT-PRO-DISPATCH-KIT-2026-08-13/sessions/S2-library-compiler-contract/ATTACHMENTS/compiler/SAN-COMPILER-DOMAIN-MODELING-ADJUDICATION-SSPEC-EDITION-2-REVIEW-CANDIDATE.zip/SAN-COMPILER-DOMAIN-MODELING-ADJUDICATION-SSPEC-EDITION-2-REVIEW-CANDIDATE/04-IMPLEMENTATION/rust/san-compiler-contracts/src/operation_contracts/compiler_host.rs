//! Operation contracts owned by `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`.

pub trait CompilerHostContracts {
    /// `compiler-host.snapshot.admit`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_compiler_snapshot(
        &self,
        arg0: crate::catalog_types::compiler_host::CompilerSnapshotMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CompilerSnapshot, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.query.register`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn register_compiler_query(
        &self,
        arg0: crate::catalog_types::compiler_host::CompilerQueryDescriptor,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::RegisteredCompilerQuery, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.attempt.start`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn start_compilation_attempt(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilerSnapshot,
        arg1: &crate::catalog_types::compiler_host::CompilerRequest,
        arg2: &crate::catalog_types::compiler_host::CompilerBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CompilationAttempt, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.query.evaluate`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn evaluate_compiler_query(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilationAttempt,
        arg1: &crate::catalog_types::compiler_host::RegisteredCompilerQuery,
        arg2: &crate::catalog_types::compiler_host::CanonicalQueryInput,
        arg3: &crate::catalog_types::compiler_host::CompilerBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CompilerQueryOutcome, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.cache.verify`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_cache_entry(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilerCacheEntry,
        arg1: &crate::catalog_types::compiler_host::CompilerSnapshot,
        arg2: &crate::catalog_types::compiler_host::RegisteredCompilerQuery,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CacheReuseProof, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.checkpoint.create`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_compiler_checkpoint(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilationAttempt,
        arg1: &crate::catalog_types::compiler_host::QueryFrontier,
        arg2: &crate::catalog_types::compiler_host::CompilerBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CompilerCheckpoint, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.checkpoint.resume`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_compiler_checkpoint(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilerCheckpoint,
        arg1: &crate::catalog_types::compiler_host::CompilerSnapshot,
        arg2: &crate::catalog_types::compiler_host::CompilerBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CompilationAttempt, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.attempt.cancel`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn cancel_compilation_attempt(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilationAttempt,
        arg1: &crate::catalog_types::compiler_host::CancellationAuthority,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CancelledAttemptReceipt, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.attempt.finalize`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn finalize_compilation_attempt(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilationAttempt,
        arg1: &crate::catalog_types::compiler_host::CompilerQueryOutcomeSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::CompilationAttemptReceipt, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

    /// `compiler-host.incremental.compare-clean`. Owner: `SAN-COMPILER-HOST-AND-INCREMENTAL-EVALUATION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn compare_incremental_with_clean(
        &self,
        arg0: &crate::catalog_types::compiler_host::CompilerQueryOutcome,
        arg1: &crate::catalog_types::compiler_host::CompilerQueryOutcome,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::compiler_host::IncrementalEquivalenceProof, crate::catalog_types::compiler_host::CompilerHostRefusal, crate::waist::CompilerNeedsInput>;

}
