#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, sys
from collections import Counter
from pathlib import Path
from typing import Any
from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
MANIFEST = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))

def read_jsonl(path: Path):
    records=[]
    for n,line in enumerate(path.read_text(encoding="utf-8").splitlines(),1):
        if line.strip():
            obj=json.loads(line); records.append(obj)
    return records

def walk_refs(value: Any):
    if isinstance(value,dict):
        for child in value.values(): yield from walk_refs(child)
    elif isinstance(value,list):
        for child in value: yield from walk_refs(child)
    elif isinstance(value,str) and value.startswith("candidate.foundational-semantics."):
        yield value

errors=[]; records=[]; by_kind={}
for kind, rel in sorted(MANIFEST["record_files_by_kind"].items()):
    parsed=read_jsonl(ROOT / rel); by_kind[kind]=parsed; records.extend(parsed)
    ids=[r["id"] for r in parsed]
    if ids != sorted(ids): errors.append(f"{rel}: not sorted by id")
    schema=json.loads((ROOT / MANIFEST["schema_files_by_kind"][kind]).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    validator=Draft202012Validator(schema, format_checker=FormatChecker())
    for record in parsed:
        for err in validator.iter_errors(record):
            errors.append(f"{record.get('id')}: {'/'.join(map(str,err.absolute_path))}: {err.message}")
ids=[r["id"] for r in records]; counts=Counter(ids)
errors += [f"duplicate id: {rid}" for rid,n in counts.items() if n>1]
idset=set(ids)
for record in records:
    for ref in walk_refs(record):
        if ref not in idset: errors.append(f"{record['id']}: missing ref {ref}")
relation_types={x["code"] for x in json.loads((ROOT/"vocabularies/relation_types.json").read_text())["values"]}
roles={x["code"] for x in json.loads((ROOT/"vocabularies/participant_roles.json").read_text())["values"]}
for relation in by_kind["relation"]:
    if relation["relation_type"] not in relation_types: errors.append(f"{relation['id']}: bad relation type")
    if relation["arity"] != len(relation["participants"]): errors.append(f"{relation['id']}: arity mismatch")
    for p in relation["participants"]:
        if p["role"] not in roles: errors.append(f"{relation['id']}: bad role {p['role']}")
for line in (ROOT/"CHECKSUMS.txt").read_text().splitlines():
    if not line.strip(): continue
    expected, rel=line.split("  ",1); data=(ROOT/rel).read_bytes(); actual=hashlib.sha256(data).hexdigest()
    if actual != expected: errors.append(f"checksum mismatch: {rel}")
result={"status":"PASS" if not errors else "FAIL","records":len(records),"errors":errors}
print(json.dumps(result,sort_keys=True))
raise SystemExit(0 if not errors else 1)
