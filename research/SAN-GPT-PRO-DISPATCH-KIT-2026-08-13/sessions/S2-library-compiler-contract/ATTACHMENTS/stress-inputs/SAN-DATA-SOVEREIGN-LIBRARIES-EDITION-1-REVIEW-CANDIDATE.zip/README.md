# SAN Data Sovereign Libraries · Edition 1

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

This package adjudicates the reusable Data Sovereign Library boundary against the live SAN constitution, 99 existing Sovereign Semantic Libraries, compiler/target/runtime/resource owners, current reference implementations, primary standards, official system documentation, and prior candidate corpora.

It deliberately publishes full implementation-ready SSPEC packages for only the first eight dependency-safe libraries. Later candidates remain a queue, not copy-shaped specifications.

## Canonical first batch

1. `DAT-COLLECTION` — Data Collection Semantics
2. `DAT-DATA-CUT` — Data Cut Semantics
3. `DAT-DISTRIBUTION` — Data Distribution Semantics
4. `DAT-SOURCE-OBSERVATION` — Source-Qualified Observation Semantics
5. `DAT-SOURCE-SNAPSHOT` — Source Snapshot Semantics
6. `DAT-SOURCE-CONTINUATION` — Source Continuation Semantics
7. `DAT-SOURCE-CHANGE-STREAM` — Source Change Stream Semantics
8. `DAT-SNAPSHOT-CONTINUATION-STITCHING` — Snapshot–Continuation Stitching

## Counts

```json
{
  "canonical_libraries": 34,
  "certified_libraries": 0,
  "conformance_cases": 462,
  "decisions": 36,
  "first_batch_full_specs": 8,
  "hard_dag_cycles": 0,
  "hard_dag_edges": 60,
  "hard_dag_nodes": 34,
  "later_queue": 26,
  "laws": 66,
  "operations": 58,
  "prior_occurrences_adjudicated": 560,
  "refusals": 115,
  "semantic_seams": 8,
  "types": 63
}
```

## Authority rule

Binding constitution and current owner registries outrank research and previous proposals. Missing owner contracts remain typed gaps. No local aliases, compatibility shims, placeholder passports, provider offers, or self-issued evidence are created.

## Verification

Run:

```bash
python VERIFY/verify.py .
```

The verifier checks schemas, identity/edition discipline, reference closure, operation/API/law/refusal/budget parity, total state matrices, hard-DAG acyclicity, semantic-seam separation, carrier/admitted construction posture, finite hostile work, provider neutrality, research-claim closure, status honesty, fixtures, and manifests.
