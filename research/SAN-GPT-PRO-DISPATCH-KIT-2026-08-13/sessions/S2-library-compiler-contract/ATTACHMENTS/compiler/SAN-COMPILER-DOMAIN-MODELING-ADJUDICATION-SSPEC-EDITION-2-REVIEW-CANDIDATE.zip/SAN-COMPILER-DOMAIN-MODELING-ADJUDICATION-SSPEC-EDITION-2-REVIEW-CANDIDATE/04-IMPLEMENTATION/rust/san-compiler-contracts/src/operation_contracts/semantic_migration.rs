//! Operation contracts owned by `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`.

pub trait SemanticMigrationContracts {
    /// `semantic-migration.input.admit`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_migration_input(
        &self,
        arg0: crate::catalog_types::semantic_migration::MigrationInputMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationInput, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.release-pair.verify`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_release_pair(
        &self,
        arg0: &crate::vertical::AppRelease,
        arg1: &crate::vertical::AppRelease,
        arg2: &crate::catalog_types::semantic_migration::MigrationPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::VerifiedReleasePair, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.diff-surfaces.bind`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_owner_diff_surfaces(
        &self,
        arg0: &crate::catalog_types::semantic_migration::VerifiedReleasePair,
        arg1: &crate::catalog_types::semantic_migration::OwnerDiffSurfaceSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::DiffDispatchTable, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.inventory.admit`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_state_inventory(
        &self,
        arg0: crate::catalog_types::semantic_migration::StateInventoryMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::StateInventorySnapshot, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.inventory.verify`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_state_inventory(
        &self,
        arg0: &crate::catalog_types::semantic_migration::StateInventorySnapshot,
        arg1: &crate::catalog_types::app_release::InventoryPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::InventoryProof, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.correspondence.propose`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn propose_correspondences(
        &self,
        arg0: &crate::catalog_types::semantic_migration::VerifiedReleasePair,
        arg1: &crate::catalog_types::semantic_migration::CorrespondenceHeuristicPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::CorrespondenceProposalSet, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.correspondence.admit`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_correspondence_directive(
        &self,
        arg0: crate::catalog_types::semantic_migration::CorrespondenceDirectiveMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::SemanticCorrespondence, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.correspondence.verify`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_correspondences(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SemanticCorrespondenceSet,
        arg1: &crate::catalog_types::semantic_migration::VerifiedReleasePair,
        arg2: &crate::catalog_types::semantic_migration::DiffDispatchTable,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::CorrespondenceProof, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.delta.family`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_family_delta(
        &self,
        arg0: crate::catalog_types::semantic_migration::FamilyReleasePair,
        arg1: &crate::catalog_types::semantic_migration::DiffDispatchTable,
        arg2: crate::catalog_types::semantic_migration::MigrationBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::FamilySemanticDelta, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.delta.target`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_target_delta(
        &self,
        arg0: &crate::catalog_types::semantic_migration::TargetCompilationPair,
        arg1: &crate::catalog_types::semantic_migration::SourceTargetMapPair,
        arg2: crate::catalog_types::semantic_migration::MigrationBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::TargetArtifactDelta, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.delta.all`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_semantic_deltas(
        &self,
        arg0: &crate::catalog_types::semantic_migration::VerifiedReleasePair,
        arg1: &crate::catalog_types::semantic_migration::DiffDispatchTable,
        arg2: &crate::catalog_types::semantic_migration::CorrespondenceSet,
        arg3: crate::catalog_types::semantic_migration::MigrationBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::SemanticDeltaSet, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.compatibility.one`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn assess_compatibility(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SemanticDelta,
        arg1: &crate::catalog_types::semantic_migration::CompatibilityQuestion,
        arg2: &crate::catalog_types::semantic_migration::DiffDispatchTable,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::CompatibilityRuling, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.compatibility.matrix`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_compatibility_matrix(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SemanticDeltaSet,
        arg1: &crate::catalog_types::semantic_migration::DiffDispatchTable,
        arg2: &crate::catalog_types::semantic_migration::MigrationPolicy,
        arg3: crate::catalog_types::semantic_migration::MigrationBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::CompatibilityMatrix, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.inventory.condition`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn condition_on_inventory(
        &self,
        arg0: &crate::catalog_types::semantic_migration::CompatibilityMatrix,
        arg1: &crate::catalog_types::semantic_migration::StateInventorySnapshot,
        arg2: &crate::catalog_types::semantic_migration::InventoryConditionPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::InventoryConditionedCompatibility, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.impact.build`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_migration_impact_graph(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SemanticDeltaSet,
        arg1: &crate::catalog_types::semantic_migration::CsagPair,
        arg2: &crate::catalog_types::semantic_migration::TargetCompilationPair,
        arg3: &crate::catalog_types::semantic_migration::StateInventorySnapshot,
        arg4: crate::catalog_types::semantic_migration::MigrationBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationImpactGraph, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.recipes.discover`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn discover_migration_recipes(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SemanticDeltaSet,
        arg1: &crate::catalog_types::semantic_migration::CompatibilityMatrix,
        arg2: &crate::catalog_types::semantic_migration::MigrationRecipeCatalog,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::RecipeCandidateSet, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.recipes.select`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn select_migration_recipes(
        &self,
        arg0: &crate::catalog_types::semantic_migration::RecipeCandidateSet,
        arg1: &crate::catalog_types::semantic_migration::MigrationPolicy,
        arg2: Option<&crate::catalog_types::semantic_migration::MigrationRecipeDirectiveSet>,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::SelectedRecipeSet, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.conversion.plan`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_conversions(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SelectedRecipeSet,
        arg1: &crate::catalog_types::semantic_migration::DiffDispatchTable,
        arg2: &crate::catalog_types::semantic_migration::CorrespondenceSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::ConversionPlanSet, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.inflight.plan`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_inflight_work(
        &self,
        arg0: &crate::catalog_types::semantic_migration::StateInventorySnapshot,
        arg1: &crate::catalog_types::semantic_migration::SemanticDeltaSet,
        arg2: &crate::catalog_types::semantic_migration::ProcessMigrationPolicySet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::InFlightPortableMigrationPlan, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.coexistence.plan`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_coexistence(
        &self,
        arg0: &crate::catalog_types::semantic_migration::CompatibilityMatrix,
        arg1: &crate::catalog_types::semantic_migration::ConversionPlanSet,
        arg2: &crate::catalog_types::semantic_migration::InFlightPortableMigrationPlan,
        arg3: &crate::catalog_types::semantic_migration::MigrationPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::CoexistencePlan, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.steps.build`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_migration_step_graph(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SelectedRecipeSet,
        arg1: &crate::catalog_types::semantic_migration::ConversionPlanSet,
        arg2: &crate::catalog_types::semantic_migration::CoexistencePlan,
        arg3: &crate::catalog_types::semantic_migration::ImpactGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationStepGraph, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.gates.build`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_migration_gates(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStepGraph,
        arg1: &crate::catalog_types::semantic_migration::CompatibilityMatrix,
        arg2: &crate::catalog_types::semantic_migration::MigrationPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationGateSet, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.rollback.plan`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_rollback_envelope(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStepGraph,
        arg1: &crate::catalog_types::semantic_migration::MigrationGateSet,
        arg2: &crate::catalog_types::semantic_migration::ConversionPlanSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::RollbackEnvelope, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.history.plan`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_historical_interpretation(
        &self,
        arg0: &crate::catalog_types::semantic_migration::VerifiedReleasePair,
        arg1: &crate::catalog_types::semantic_migration::SemanticDeltaSet,
        arg2: &crate::catalog_types::semantic_migration::MigrationPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::HistoricalInterpretationPlan, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.manual.plan`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_manual_adjudication_queue(
        &self,
        arg0: &crate::catalog_types::semantic_migration::SemanticDeltaSet,
        arg1: &crate::catalog_types::semantic_migration::StateInventorySnapshot,
        arg2: &crate::catalog_types::semantic_migration::ConversionPlanSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::ManualAdjudicationQueue, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.requirements.derive`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_migration_capability_requirements(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStepGraph,
        arg1: &crate::catalog_types::semantic_migration::CoexistencePlan,
        arg2: &crate::catalog_types::semantic_migration::RollbackEnvelope,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationCapabilityRequirementSet, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.plan.verify`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_migration_plan_semantics(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStageArtifacts,
        arg1: &crate::catalog_types::semantic_migration::MigrationVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::PortableMigrationPlanningProof, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.proof.build`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_migration_proof_manifest(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStageArtifacts,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationProofManifest, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.explain.build`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_migration_explanation_graph(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStageArtifacts,
        arg1: crate::waist::DisclosurePolicyRef,
        arg2: crate::catalog_types::semantic_migration::MigrationBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationExplanationGraph, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.canonical.project`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_migration_plan(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStageArtifacts,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationCanonicalProjection, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.seal.attach`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn attach_migration_seal(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationCanonicalProjection,
        arg1: &crate::catalog_types::app_release::ExternalSealBundle,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationSeal, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.plan.build`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_migration_plan(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationStageArtifacts,
        arg1: &crate::catalog_types::semantic_migration::MigrationSeal,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::PortableMigrationPlan, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.plan.offline-verify`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_migration_plan(
        &self,
        arg0: &crate::catalog_types::semantic_migration::PortableMigrationPlan,
        arg1: &crate::catalog_types::semantic_migration::MigrationVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::PortableMigrationPlanProof, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.checkpoint.resume`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_migration_planning(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationCheckpoint,
        arg1: &crate::catalog_types::semantic_migration::MigrationInput,
        arg2: &crate::catalog_types::semantic_migration::MigrationExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::PortableMigrationPlanningOutcome, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.plan.delta`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_migration_plan_delta(
        &self,
        arg0: &crate::catalog_types::semantic_migration::PortableMigrationPlan,
        arg1: &crate::catalog_types::semantic_migration::PortableMigrationPlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::PortableMigrationPlanDelta, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.explain`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_migration_target(
        &self,
        arg0: crate::catalog_types::semantic_migration::MigrationExplainTarget,
        arg1: &crate::catalog_types::semantic_migration::PortableMigrationPlanOrRefusal,
        arg2: crate::waist::DisclosurePolicyRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::MigrationExplanation, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

    /// `semantic-migration.plan`. Owner: `SAN-COMPILER-SEMANTIC-DIFF-AND-MIGRATION-PLANNING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_migration(
        &self,
        arg0: &crate::catalog_types::semantic_migration::MigrationInput,
        arg1: &crate::catalog_types::semantic_migration::MigrationExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::semantic_migration::PortableMigrationPlanningOutcome, crate::catalog_types::semantic_migration::SemanticMigrationRefusal, crate::waist::CompilerNeedsInput>;

}
