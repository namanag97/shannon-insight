# Blind Domain Discovery Navigation

## Session

- Work package: `LANGUAGE, SPECIFICATION, COMPILATION, INTERMEDIATE REPRESENTATION, AND LOWERING`
- Session id: `SESSION-LANGUAGE-COMPILER-IR-BLIND-DISCOVERY-2026-08-12`
- Mechanical status: `PASS_WITH_RESEARCH_GAPS`
- Corpus records excluding typed relations: `1251`
- Typed relations: `389`
- Candidate boundary records: `19`

## Entry Points

- [`manifest.json`](manifest.json): package identity, format, scope, file inventory, and summary.
- [`coverage/coverage_matrix.json`](coverage/coverage_matrix.json): requested-topic, boundary-question, and adversarial-scenario coverage.
- [`coverage/maturity_report.json`](coverage/maturity_report.json): separate correctness dimensions and highest-impact open boundaries.
- [`corpus/bounded_contexts.jsonl`](corpus/bounded_contexts.jsonl): full candidate boundary records.
- [`boundary_analysis/evaluations.jsonl`](boundary_analysis/evaluations.jsonl): twelve-test evaluation for every candidate.
- [`corpus/relations.jsonl`](corpus/relations.jsonl): qualified n-ary relationships and artifact handoffs.
- [`scenarios/negative_examples.jsonl`](scenarios/negative_examples.jsonl): all required adversarial scenarios.
- [`issues/gaps.jsonl`](issues/gaps.jsonl): remaining research gaps.
- [`issues/unresolved_questions.jsonl`](issues/unresolved_questions.jsonl): decisions still blocked.
- [`VALIDATION.json`](VALIDATION.json): parse, schema, identifier, reference, vocabulary, duplicate, ordering, checksum, and ZIP checks.
- [`CHECKSUMS.txt`](CHECKSUMS.txt): SHA-256 checksums for every package file except the checksum file itself.

## Collections

- [`corpus/`](corpus/): vocabulary, concepts, tactical semantics, artifacts, contracts, contexts, profiles, compositions, examples, and counterexamples.
- [`boundary_analysis/`](boundary_analysis/): evaluations, split and merge proposals, rejected boundaries, and unresolved ownership.
- [`scenarios/`](scenarios/): competency questions and positive, negative, boundary, and cross-domain tests.
- [`issues/`](issues/): conflicts, gaps, and unresolved questions.
- [`schemas/`](schemas/): JSON Schema Draft 2020-12 schemas.
- [`vocabularies/`](vocabularies/): controlled values and primary evidence catalog.
