
//! Nominal semantic and artifact algebra for the cross-registry reference model.

use crate::CanonicalCommitment;
use std::collections::BTreeSet;
use std::fmt;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IdentifierError {
    pub value: String,
    pub reason: &'static str,
}

impl fmt::Display for IdentifierError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "invalid identifier {:?}: {}", self.value, self.reason)
    }
}

impl std::error::Error for IdentifierError {}

macro_rules! nominal_identifier {
    ($name:ident) => {
        #[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
        pub struct $name(String);

        impl $name {
            pub fn parse(value: impl Into<String>) -> Result<Self, IdentifierError> {
                let value = value.into();
                if value.is_empty() {
                    return Err(IdentifierError { value, reason: "empty" });
                }
                if value.len() > 512 {
                    return Err(IdentifierError { value, reason: "longer than 512 bytes" });
                }
                if value.chars().any(char::is_whitespace) {
                    return Err(IdentifierError { value, reason: "contains whitespace" });
                }
                Ok(Self(value))
            }

            pub fn as_str(&self) -> &str {
                &self.0
            }
        }
    };
}

nominal_identifier!(StableCoordinate);
nominal_identifier!(OccurrenceId);
nominal_identifier!(SemanticEdition);
nominal_identifier!(SovereignOwner);
nominal_identifier!(ArtifactKindId);
nominal_identifier!(SourceAuthorityId);
nominal_identifier!(PackageLockId);
nominal_identifier!(VerifierId);
nominal_identifier!(ContractId);
nominal_identifier!(RequirementId);
nominal_identifier!(OfferId);
nominal_identifier!(DecisionId);
nominal_identifier!(ObligationId);
nominal_identifier!(GapId);
nominal_identifier!(CapabilityId);
nominal_identifier!(RuntimeRequirementId);
nominal_identifier!(TargetId);
nominal_identifier!(ImplementationId);
nominal_identifier!(EnvironmentId);
nominal_identifier!(ToolchainId);
nominal_identifier!(RuleEdition);
nominal_identifier!(SchemaEdition);
nominal_identifier!(QueryKey);
nominal_identifier!(CheckpointId);

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ContributionClass {
    Semantic,
    GovernedData,
    DomainOntology,
    HumanWorkExperience,
    UserInterface,
    ConstitutionalContract,
    Compiler,
    RuntimeResource,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum FacetKind {
    Contract,
    Graph,
    PortableIntermediateRepresentation,
    CompilerQuery,
    RuntimeObligation,
    ProofObligation,
    Decision,
    Gap,
    Budget,
    Evolution,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EvolutionPosture {
    Stable,
    Additive,
    BreakingMigrationRequired {
        migration_contract: ContractId,
    },
    Correction {
        supersedes_occurrence: OccurrenceId,
        reason_commitment: CanonicalCommitment,
    },
    Recalled {
        authority: SourceAuthorityId,
        reason_commitment: CanonicalCommitment,
    },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Provenance {
    pub source_authority: SourceAuthorityId,
    pub source_occurrence: OccurrenceId,
    pub source_digest: CanonicalCommitment,
    pub admitted_by: VerifierId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeclaredOperation {
    pub coordinate: StableCoordinate,
    pub input_contracts: Vec<ContractId>,
    pub output_contracts: Vec<ContractId>,
    pub refusal_contracts: Vec<ContractId>,
    pub effect_requirements: Vec<RuntimeRequirementId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeclaredDecision {
    pub coordinate: StableCoordinate,
    pub authority_owner: SovereignOwner,
    pub input_contracts: Vec<ContractId>,
    pub output_contract: ContractId,
    pub explanation_contract: ContractId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContributionEnvelope {
    pub stable_coordinate: StableCoordinate,
    pub occurrence: OccurrenceId,
    pub semantic_edition: SemanticEdition,
    pub sovereign_owner: SovereignOwner,
    pub contribution_class: ContributionClass,
    pub artifact_kind: ArtifactKindId,
    pub source_authority: SourceAuthorityId,
    pub package_lock: PackageLockId,
    pub package_lock_commitment: CanonicalCommitment,
    pub provenance: Provenance,
    pub declared_operations: Vec<DeclaredOperation>,
    pub declared_decisions: Vec<DeclaredDecision>,
    pub facet_kinds: BTreeSet<FacetKind>,
    pub declared_budget_ceiling: u64,
    pub evolution_posture: EvolutionPosture,
    pub canonical_commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticProjection {
    pub owned_meanings: Vec<StableCoordinate>,
    pub semantic_laws: Vec<ContractId>,
    pub pure_operations: Vec<DeclaredOperation>,
    pub required_external_contracts: Vec<ContractId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GovernedDataProjection {
    pub governed_grains: Vec<StableCoordinate>,
    pub identity_contracts: Vec<ContractId>,
    pub time_and_order_contracts: Vec<ContractId>,
    pub lineage_contracts: Vec<ContractId>,
    pub query_contracts: Vec<ContractId>,
    pub quality_obligations: Vec<ObligationId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DomainOntologyProjection {
    pub bounded_context: StableCoordinate,
    pub concepts: Vec<StableCoordinate>,
    pub relations: Vec<ContractId>,
    pub invariants: Vec<ContractId>,
    pub correspondence_seams: Vec<ContractId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExperienceProjection {
    pub work_intents: Vec<StableCoordinate>,
    pub actor_roles: Vec<StableCoordinate>,
    pub task_and_handoff_contracts: Vec<ContractId>,
    pub cognitive_and_access_needs: Vec<ContractId>,
    pub ui_authority_claimed: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct UserInterfaceProjection {
    pub interaction_contracts: Vec<ContractId>,
    pub navigation_contracts: Vec<ContractId>,
    pub presentation_contracts: Vec<ContractId>,
    pub accessibility_contracts: Vec<ContractId>,
    pub input_modality_contracts: Vec<ContractId>,
    pub responsive_behavior_contracts: Vec<ContractId>,
    pub client_state_contracts: Vec<ContractId>,
    pub localization_contracts: Vec<ContractId>,
    pub rendering_contracts: Vec<ContractId>,
    pub media_contracts: Vec<ContractId>,
    pub design_token_contracts: Vec<ContractId>,
    pub client_effect_requirements: Vec<RuntimeRequirementId>,
    pub source_authority: SourceAuthorityId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ClassProjection {
    Semantic(SemanticProjection),
    GovernedData(GovernedDataProjection),
    DomainOntology(DomainOntologyProjection),
    HumanWorkExperience(ExperienceProjection),
    UserInterface(UserInterfaceProjection),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RequirementContribution {
    pub occurrence: OccurrenceId,
    pub requirement_id: RequirementId,
    pub owner: SovereignOwner,
    pub contract: ContractId,
    pub cardinality: Cardinality,
    pub authority_required: ContractId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OfferContribution {
    pub occurrence: OccurrenceId,
    pub offer_id: OfferId,
    pub owner: SovereignOwner,
    pub contract: ContractId,
    pub offered_for: RequirementId,
    pub authority_contract: ContractId,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Cardinality {
    pub minimum: usize,
    pub maximum: usize,
}

impl Cardinality {
    pub fn new(minimum: usize, maximum: usize) -> Result<Self, IdentifierError> {
        if minimum > maximum {
            return Err(IdentifierError {
                value: format!("{minimum}..{maximum}"),
                reason: "minimum exceeds maximum",
            });
        }
        Ok(Self { minimum, maximum })
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionDecision {
    pub occurrence: OccurrenceId,
    pub decision_id: DecisionId,
    pub authority_owner: SovereignOwner,
    pub requirement: RequirementId,
    pub considered_offers: Vec<OfferId>,
    pub selected_offers: Vec<OfferId>,
    pub basis_commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationContribution {
    pub occurrence: OccurrenceId,
    pub obligation_id: ObligationId,
    pub owner: SovereignOwner,
    pub seeded_by: DecisionId,
    pub depends_on: Vec<ObligationId>,
    pub discharge_contract: ContractId,
    pub discharge_evidence: Option<OccurrenceId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GapDisposition {
    pub gap_id: GapId,
    pub blocking: bool,
    pub disposition: GapDispositionKind,
    pub authority: SourceAuthorityId,
    pub evidence_commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum GapDispositionKind {
    Resolved,
    AuthorizedDeferral { decision: DecisionId },
    Refused { refusal_contract: ContractId },
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum GraphNodeKind {
    ApplicationAnchor,
    SemanticDeclaration,
    GovernedDataSemantic,
    OntologyConcept,
    WorkIntent,
    InteractionContract,
    Contract,
    Decision,
    Obligation,
    Authority,
    PortableIntermediateRepresentationModule,
    RuntimeRequirement,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum HyperedgeKind {
    BindsContract,
    SatisfiesRequirement,
    SelectsOffer,
    SeedsObligation,
    DischargesObligation,
    CorrespondsTo,
    RealizesWorkIntent,
    DelegatesAuthority,
    LowersTo,
    RequiresRuntime,
    EvolvesFrom,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HostileGraphNode {
    pub occurrence: OccurrenceId,
    pub kind: GraphNodeKind,
    pub owner: SovereignOwner,
    pub source_contribution: OccurrenceId,
    pub semantic_commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HostileHyperedge {
    pub occurrence: OccurrenceId,
    pub kind: HyperedgeKind,
    pub owner: SovereignOwner,
    pub endpoints: Vec<OccurrenceId>,
    pub source_contribution: OccurrenceId,
    pub semantic_commitment: CanonicalCommitment,
}

#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum PortableIrKind {
    GovernedDataAndQuery,
    BehaviorAndEffect,
    EventAndProtocol,
    WorkflowAndProcess,
    PolicyAndDecision,
    InteractionPresentationAndAccessibility,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PortableIrContribution {
    pub occurrence: OccurrenceId,
    pub kind: PortableIrKind,
    pub semantic_owner: SovereignOwner,
    pub producer_contribution: OccurrenceId,
    pub type_system_edition: SchemaEdition,
    pub legality_contract: ContractId,
    pub preserved_laws: Vec<ContractId>,
    pub required_capabilities: BTreeSet<CapabilityId>,
    pub runtime_obligations: BTreeSet<RuntimeRequirementId>,
    pub canonical_commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReleaseOccurrence {
    pub coordinate: StableCoordinate,
    pub edition: SemanticEdition,
    pub occurrence: OccurrenceId,
    pub content_digest: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PackageLock {
    pub id: PackageLockId,
    pub occurrence: OccurrenceId,
    pub selected_releases: Vec<ReleaseOccurrence>,
    pub commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SupplierRole {
    name: &'static str,
}

impl SupplierRole {
    pub fn from_registry_name(name: &'static str) -> Option<Self> {
        if ALL_SUPPLIER_ROLE_NAMES.contains(&name) {
            Some(Self { name })
        } else {
            None
        }
    }

    pub fn name(&self) -> &'static str {
        self.name
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum SupplierDispositionKind {
    Available { evidence: OccurrenceId },
    StructurallyInapplicable { authority: OccurrenceId },
    Refused { evidence: OccurrenceId, reason: ContractId },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SupplierDisposition {
    pub release_occurrence: OccurrenceId,
    pub role: SupplierRole,
    pub disposition: SupplierDispositionKind,
}

pub const ALL_SUPPLIER_ROLE_NAMES: [&str; 58] = [
    "SourceDigestVerification",
    "ConstitutionVerification",
    "OwnerAdmission",
    "NameDeclarationProjection",
    "PackageLockVerification",
    "PackVerification",
    "PackDecisionDeclarationProjection",
    "CompilerFamilySurfaceVerification",
    "DecisionAlgebra",
    "ContractAlgebra",
    "OpaqueOwnerValueReadmission",
    "FamilyCompilation",
    "FamilyGraphProjection",
    "RequirementAuthorityVerification",
    "SelectionBasisVerification",
    "SelectionAuthorityVerification",
    "CentralLinkerBindingVerification",
    "SemanticSubjectBindingVerification",
    "ApplicationClosureCommitmentVerification",
    "ObligationLattice",
    "ObligationValueCodec",
    "ObligationRule",
    "ObligationDischargeValidation",
    "ObligationReferenceVerification",
    "RequirementResolutionKernel",
    "CsagFamilyProjection",
    "CsagClosureProjection",
    "CsagCommitment",
    "AuthorityCycleVerification",
    "SliceAuthorityVerification",
    "TargetSeeding",
    "TargetTypeConversion",
    "ConversionTarget",
    "TargetPatternRewrite",
    "TargetArtifactContractAlgebra",
    "TranslationValidation",
    "TargetCompilation",
    "ReleaseSourceVerification",
    "ReleaseArtifactVerification",
    "ReleaseSealVerification",
    "ReleaseAdapterVerification",
    "SignatureVerification",
    "AttestationVerification",
    "ReleaseParityVerification",
    "ReleaseLifecycleVerification",
    "ReleaseInventoryProjection",
    "ReleasePackaging",
    "DeploymentRequirementProjection",
    "ResourceSatisfactionAlgebra",
    "EnvironmentSnapshotVerification",
    "ProviderPlanAdaptation",
    "DeploymentSealVerification",
    "DeploymentLeakageVerification",
    "EnvironmentBindingParityVerification",
    "MigrationInventoryVerification",
    "OwnerSemanticDiff",
    "MigrationSealVerification",
    "MigrationParityVerification",
];

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetDescriptor {
    pub target: TargetId,
    pub occurrence: OccurrenceId,
    pub supported_capabilities: BTreeSet<CapabilityId>,
    pub lowering_implementation: ImplementationId,
    pub translation_validator: VerifierId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LoweredTargetArtifact {
    pub occurrence: OccurrenceId,
    pub target_occurrence: OccurrenceId,
    pub source_ir_occurrence: OccurrenceId,
    pub content_commitment: CanonicalCommitment,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeImplementation {
    pub requirement: RuntimeRequirementId,
    pub implementation: ImplementationId,
    pub occurrence: OccurrenceId,
    pub conformance_evidence: OccurrenceId,
    pub portable: bool,
    pub declared_environment_fields: BTreeSet<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EnvironmentBindingInput {
    pub environment: EnvironmentId,
    pub occurrence: OccurrenceId,
    pub release_occurrence: OccurrenceId,
    pub region: String,
    pub placement: String,
    pub endpoint_references: Vec<String>,
    pub credential_references: Vec<String>,
    pub capacity_evidence: OccurrenceId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IncrementalCheckpoint {
    pub checkpoint: CheckpointId,
    pub query_key: QueryKey,
    pub exact_input_commitment: CanonicalCommitment,
    pub package_lock_commitment: CanonicalCommitment,
    pub rule_edition: RuleEdition,
    pub schema_edition: SchemaEdition,
    pub toolchain: ToolchainId,
    pub next_work_cursor: u64,
    pub partial_result_commitment: CanonicalCommitment,
}
