# Registry intake protocol

## Intake record

Preserve the candidate exactly enough to reproduce it: source identifier, archive/member digest, proposed name and kind, claimed owner, claimed dependencies, proposed semantic question, evidence posture and known conflicts. Candidate intake is separate from admitted records.

## Qualification workflow

1. **Identity test**: Is the proposed identity stable, edition-free and non-colliding?
2. **Independent-question test**: Does the candidate answer a durable question not already owned elsewhere?
3. **Semantic-algebra test**: Does it have vocabulary, value/state model, laws or invariants, refusals and evolution behavior?
4. **Authority test**: Is one owner competent to decide admission, changes and disputes?
5. **Boundary test**: Are positive scope, negative scope and false twins explicit?
6. **Consumer test**: Are named consumers and typed seams known?
7. **Lifecycle test**: Does the candidate have meaningful edition, supersession and deprecation behavior?
8. **Failure test**: Does it have a domain-specific failure taxonomy rather than generic validation errors?
9. **Implementation-independence test**: Does the meaning survive provider, framework, database, UI toolkit and crate changes?
10. **Anti-explosion test**: Would accepting it create one unit per noun, bounded context, dataset shape, provider, artifact or proof scenario?

A sovereign unit must pass all ten or retain an explicit blocking gap. Failing the sovereign test does not mean deletion; it may be a composition, profile, module, artifact kind, publication, implementation or proof vertical.

## Dispositions

Use only the controlled dispositions in `REGISTRY-METAMODEL.json`. `MERGE_INTO`, `SPLIT_INTO` and `RENAME_WITH_ALIAS` require migration mappings. `REJECT_*` records remain in the adjudication ledger as historical evidence. `DEFER_RESEARCH` names the missing evidence and next admissible transition.

## Owner and dependency review

- One capability has one sovereign owner.
- Imports do not confer co-ownership.
- Hard dependencies encode directed compile/build prerequisites only.
- Reciprocal collaboration, payload authority and evidence return belong in the seam hypergraph.
- Provider identities are forbidden in semantic requirements and resource guarantee definitions.
- Compiler stages consume typed descriptors and contracts; candidate family names are never dispatch keys.

## Completion posture

Set each of the fifteen completion axes independently. `source_structurally_verified` does not imply exact semantics, implementation, execution, compiler integration, lowering, runtime proof, review, ratification or certification. Evidence references are mandatory for every `PROVEN` state.

## Review outputs

An intake review emits the candidate record, disposition, owner ruling, alias/supersession changes, graph changes, count-projection changes, completion posture, gaps, next transition and verifier result. No broad corpus batch proceeds merely because a target count remains aesthetically unfulfilled.
