//! Field-complete owner definitions for all non-vertical catalog types.
//! Consumer contexts import these definitions rather than minting shadows.

pub mod app_release;
pub mod application_binding;
pub mod application_closure;
pub mod application_source_parsing;
pub mod compiler_host;
pub mod csag;
pub mod decision_resolution;
pub mod declaration_admission;
pub mod domain_definition;
pub mod family_compilation;
pub mod name_binding;
pub mod obligation_closure;
pub mod pack_expansion;
pub mod package_extension_composition;
pub mod semantic_migration;
pub mod target_compilation;
