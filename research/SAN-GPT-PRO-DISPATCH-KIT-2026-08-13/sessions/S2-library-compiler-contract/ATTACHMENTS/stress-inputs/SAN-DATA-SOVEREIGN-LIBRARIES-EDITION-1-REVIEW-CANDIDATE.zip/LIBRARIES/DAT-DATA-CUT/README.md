# DAT-DATA-CUT · Data Cut Semantics

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

What exact immutable occurrence of a collection is identified, with which membership, source or derivation scope, temporal scope, completeness posture, and evidence?

## Boundary

Owns:
- data cut identity
- immutable cut occurrence
- cut membership binding
- qualified completeness
- cut supersession relation

Explicitly excludes:
- collection membership theory
- source snapshot
- table-format snapshot
- cursor
- watermark
- checkpoint
- savepoint
- publication action
- provenance meaning

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- DAT-COLLECTION

## Reciprocal semantic seams

- None in this edition.

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
