# Required Patches

## P0 — Repair Stage-0 authority completeness

`verify_complete_supplier_inventories` and `build_disposition_sets` must iterate the package lock's selected releases, not the owners that happened to appear in the disposition carrier. The expected row count is `selected_releases × CompilerSupplierRole::ALL.len()` with checked arithmetic and budget admission before allocation.

A compile-ready candidate diff is in `PATCHES/0001-stage0-complete-role-matrix.patch`. It has not been compiled here because `cargo` and `rustc` are unavailable.

## P1 — Make proof values nonforgeable

At minimum, make `PackageLockVerificationProof`, `CsagClosureProof`, `CsagVerificationProof`, and `TargetCompilationSetVerification` fields private. Provide verifier-owned constructors and read-only accessors. `CsagParts` must not accept caller-authored closure proof material without a verifier-issued capability.

A focused visibility diff is in `PATCHES/0002-proof-visibility.patch`. It demonstrates the required direction; downstream field access must be repaired by the owner crates and compiled before acceptance.

## P2 — Hard-cut CMP-006

Delete from `san-application-linker`:

- direct dependency on `san-obligation-fixed-point`;
- `application-linker.obligation.*`;
- `application-linker.graph.*` and `GraphViewBundle` ownership;
- final closure seal and `ApplicationClosure` contract.

Introduce `ApplicationBinding` with private fields and one verified constructor. CMP-007, CMP-008, targets and release assembly consume later artifacts in order. No alias.

## P3 — Close CSAG correctly

`Csag` remains the final graph type. Its canonical projection must explicitly retain exact `FamilyPlanSet`, `ApplicationBinding`, and `ObligationClosure` occurrence/digest commitments. Introduce a single compiler-owned `ApplicationAnchor` node for lawful planless graphs. The anchor has no family payload and cannot satisfy any business requirement.

## P4 — Move final ApplicationClosure after feasibility

After `TargetCompilationSet`, invoke the existing binding algebra at an `ExecutionBind` phase to resolve exact runtime/provider implementation offers into `ExecutionBinding`. Final `ApplicationClosure` consumes:

```
ApplicationBinding
ObligationClosure
Csag
TargetCompilationSet
ExecutionBinding
complete GapDispositionSet
```

It excludes concrete region, endpoint, secret and resource-instance bindings, which remain in EnvironmentBinding.

## P5 — Add positive paths before more metamodel work

Implement `VT-001` before claiming compiler reachability. Then run every negative twin in `VERTICAL-TEST-MATRIX.json`, including all max/max-plus-one budget cases.

## Exact source evidence

The machine-readable locations are retained in `CURRENT-RUST-REACHABILITY.json`, `TYPE-AUTHORITY-AUDIT.json`, and `GPT-A-CLAIM-TO-EVIDENCE.json`.
