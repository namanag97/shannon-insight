# DAT-DISTRIBUTION · Data Distribution Semantics

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

What accessible representation of a collection or data cut is made available, and which representation, loss, access, rights, resolution, and validity claims attach to it?

## Boundary

Owns:
- distribution identity
- representation profile
- exact versus rolling binding posture
- representation loss disclosure
- qualified access claim

Explicitly excludes:
- collection
- data product
- data service
- catalog record
- file format definition
- encoding definition
- locator meaning
- authorization
- provider endpoint
- service runtime

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- DAT-COLLECTION

## Reciprocal semantic seams

- DAT-DATA-CUT

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
