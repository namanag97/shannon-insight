# DAT-SOURCE-CONTINUATION · Source Continuation Semantics

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

What source-qualified coordinate and exact observation scope can resume source observation, and when is it eligible, expired, invalidated, incomparable, or unable to bridge a history gap?

## Boundary

Owns:
- source continuation identity
- coordinate space and opacity
- continuation scope binding
- resume eligibility
- history horizon relation
- snapshot frontier binding

Explicitly excludes:
- consumer acknowledgement
- broker offset ownership
- watermark
- checkpoint
- savepoint
- data cut
- provider token implementation
- source I/O

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- DAT-SOURCE-OBSERVATION

## Reciprocal semantic seams

- DAT-SOURCE-SNAPSHOT

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
