//! Types owned by `obligation_closure`.

use std::collections::{BTreeMap, BTreeSet};

/// Field-complete contract model for `AdmittedDischargeEvidence`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedDischargeEvidence {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    artifacts: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
    work: crate::waist::WorkReceipt,
}

impl AdmittedDischargeEvidence {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn artifacts(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.artifacts
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `AdmittedObligationSeedSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedObligationSeedSet {
    owner: crate::waist::AuthorityRef,
    items: Vec<crate::waist::SemanticMember>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl AdmittedObligationSeedSet {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn items(&self) -> &Vec<crate::waist::SemanticMember> {
        &self.items
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `AffectedSccRecomputePlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AffectedSccRecomputePlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl AffectedSccRecomputePlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ApplicationLinkerKernel`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationLinkerKernel {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CheckpointResumeProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CheckpointResumeProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl CheckpointResumeProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `CommitReceipt`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CommitReceipt {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    artifacts: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
    work: crate::waist::WorkReceipt,
}

impl CommitReceipt {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn artifacts(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.artifacts
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `CompiledObligationRule`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompiledObligationRule {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `DeltaFrontier`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeltaFrontier {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl DeltaFrontier {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `DerivationFrontier`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DerivationFrontier {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl DerivationFrontier {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `DerivedRequirementOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DerivedRequirementOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::ObligationClosureRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `DerivedRequirementResolution`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DerivedRequirementResolution {
    subject: crate::waist::StableId,
    selected: Vec<crate::waist::StableId>,
    basis: Vec<crate::waist::ArtifactRef>,
    cardinality: crate::waist::Cardinality,
    proof: crate::waist::ProofRef,
}

impl DerivedRequirementResolution {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::StableId {
        &self.subject
    }
    #[must_use]
    pub fn selected(&self) -> &Vec<crate::waist::StableId> {
        &self.selected
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn cardinality(&self) -> &crate::waist::Cardinality {
        &self.cardinality
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `DerivedRequirementSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DerivedRequirementSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `DerivedRequirementState`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DerivedRequirementState {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl DerivedRequirementState {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `DirtyRuleSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DirtyRuleSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `DischargeBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DischargeBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `DischargeEvidenceMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DischargeEvidenceMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `DischargeEvidenceSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DischargeEvidenceSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `DischargeProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DischargeProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl DischargeProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ExecutionPlanProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExecutionPlanProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl ExecutionPlanProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `FiniteParameterSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FiniteParameterSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `GeneratedRulePlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeneratedRulePlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl GeneratedRulePlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `LeastFixedPointProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LeastFixedPointProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl LeastFixedPointProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `NoDroppedObligationProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NoDroppedObligationProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl NoDroppedObligationProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ObligationClosureBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `ObligationClosureCanonicalProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureCanonicalProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl ObligationClosureCanonicalProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `ObligationClosureCheckpoint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureCheckpoint {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: Vec<crate::waist::ArtifactRef>,
    work_spent: u64,
    remaining_budget: crate::waist::WorkBudget,
}

impl ObligationClosureCheckpoint {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.completed
    }
    #[must_use]
    pub fn work_spent(&self) -> u64 {
        self.work_spent
    }
    #[must_use]
    pub fn remaining_budget(&self) -> &crate::waist::WorkBudget {
        &self.remaining_budget
    }
}

/// Field-complete contract model for `ObligationClosureDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl ObligationClosureDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `ObligationClosureExplanationGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureExplanationGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl ObligationClosureExplanationGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ObligationClosureInput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureInput {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `ObligationClosureInputMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureInputMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `ObligationClosureOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ObligationClosureOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::ObligationClosureRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `ObligationClosureProofManifest`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureProofManifest {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationClosureVerificationProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureVerificationProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl ObligationClosureVerificationProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ObligationDispatchTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationDispatchTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl ObligationDispatchTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ObligationEvaluationState`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationEvaluationState {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl ObligationEvaluationState {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ObligationExecutionContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationExecutionContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `ObligationExplainTarget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ObligationExplainTarget {
    Artifact {
        artifact: crate::waist::ArtifactRef,
    },
    Subject {
        subject: crate::waist::SubjectKey,
    },
    Refusal {
        refusal_id: crate::waist::StableId,
    },
}

/// Field-complete contract model for `ObligationExplanation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationExplanation {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl ObligationExplanation {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ObligationFact`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationFact {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationKeyIndex`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationKeyIndex {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl ObligationKeyIndex {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ObligationProgress`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationProgress {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl ObligationProgress {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ObligationProofContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationProofContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `ObligationProofGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationProofGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl ObligationProofGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ObligationReadView`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationReadView {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationSeedSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationSeedSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationStore`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationStore {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationTrustPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationTrustPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `ObligationUniverse`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationUniverse {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationVerificationContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationVerificationContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `OptimizationParityProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OptimizationParityProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl OptimizationParityProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ParallelBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ParallelBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `ParallelSccLayer`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ParallelSccLayer {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ProgressLedger`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProgressLedger {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl ProgressLedger {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `QuiescenceProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct QuiescenceProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl QuiescenceProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `RecentDeltaView`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RecentDeltaView {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ReferenceClosureProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceClosureProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl ReferenceClosureProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ReferenceClosureResult`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceClosureResult {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ReferenceExecutionContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceExecutionContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `ResumableStage`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ResumableStage {
    Declared,
    Applicable,
    Inapplicable {
        reason: crate::waist::StableId,
    },
    Blocked {
        gap: crate::waist::ArtifactRef,
    },
}

/// Field-complete contract model for `RuleBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `RuleDependencyGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleDependencyGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl RuleDependencyGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `RuleEvaluation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleEvaluation {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `RuleProgramClosure`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleProgramClosure {
    identity: crate::waist::StableId,
    owner: crate::waist::AuthorityRef,
    edition: crate::waist::Edition,
    kind: crate::waist::StableId,
    members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl RuleProgramClosure {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn edition(&self) -> &crate::waist::Edition {
        &self.edition
    }
    #[must_use]
    pub fn kind(&self) -> &crate::waist::StableId {
        &self.kind
    }
    #[must_use]
    pub fn members(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::ScalarValue> {
        &self.members
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `RuleProposal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleProposal {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `RuleSubscriberIndex`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuleSubscriberIndex {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl RuleSubscriberIndex {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `SccClosureProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SccClosureProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl SccClosureProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `SccExecutionPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SccExecutionPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl SccExecutionPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `SccId`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SccId {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `SccProposalBatch`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SccProposalBatch {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SelectionRequestSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectionRequestSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SemiNaivePlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemiNaivePlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl SemiNaivePlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `StableObligationKey`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StableObligationKey {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `TerminationProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TerminationProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl TerminationProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ValidatedProposal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ValidatedProposal {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `VerifiedObligationProgram`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VerifiedObligationProgram {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl VerifiedObligationProgram {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `WorkerProposalBuffer`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkerProposalBuffer {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}
