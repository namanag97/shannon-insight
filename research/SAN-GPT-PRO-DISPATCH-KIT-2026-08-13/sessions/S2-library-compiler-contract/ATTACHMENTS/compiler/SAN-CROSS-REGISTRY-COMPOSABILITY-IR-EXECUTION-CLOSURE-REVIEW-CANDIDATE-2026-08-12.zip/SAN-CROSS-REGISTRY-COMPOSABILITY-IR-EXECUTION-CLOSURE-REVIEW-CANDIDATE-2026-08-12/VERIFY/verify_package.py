
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Callable

try:
    import jsonschema
except ImportError as error:  # pragma: no cover - an absent validator is a failed schema gate
    raise SystemExit(f"jsonschema is required: {error}")

from deterministic_zip import build_zip
from reference_model import (
    canonical_bytes,
    run_negative_cases,
    stable_commitment,
    static_branch_scan,
    validate_reference_fixture,
)

REQUIRED_PATHS = [
    "VERDICT.md",
    "INPUT-MANIFEST.json",
    "SOURCE-AND-CLAIM-LEDGER.json",
    "REGISTRY-KIND-COMPILER-MATRIX.json",
    "UNIVERSAL-CONTRIBUTION-MODEL.json",
    "UNIVERSAL-CONTRIBUTION-MODEL.schema.json",
    "ARTIFACT-AND-FINALITY-DAG.json",
    "SEMANTIC-SEAM-HYPERGRAPH.json",
    "CSAG-OWNERSHIP-AND-COVERAGE.json",
    "IR-PORTFOLIO.json",
    "LOWERING-AND-PRESERVATION-CONTRACTS.json",
    "RUNTIME-IMPLEMENTATION-BINDING.json",
    "OFFLINE-REPLAY-CLOSURE.json",
    "CURRENT-RUST-ACCEPT-AMEND-REJECT.json",
    "COMPILER-A-B-RECONCILIATION.json",
    "REGISTRY-REBASE-REPORT.json",
    "MIXED-VERTICAL.json",
    "NEGATIVE-TWIN-MATRIX.json",
    "BOUNDED-WORK-AND-CHECKPOINTS.json",
    "MIGRATION-ORDER.json",
    "GAPS.json",
    "STATUS.json",
    "PACKAGE-VERIFY.json",
    "MANIFEST.json",
    "rust-reference/Cargo.toml",
    "rust-reference/Cargo.lock",
    "rust-reference/san-composition-reference/Cargo.toml",
    "rust-reference/san-composition-reference/src/lib.rs",
    "rust-reference/san-composition-reference/src/model.rs",
    "rust-reference/san-composition-reference/src/proof.rs",
    "rust-reference/san-composition-reference/src/compiler.rs",
    "rust-reference/san-composition-reference/src/canonical.rs",
    "rust-reference/san-composition-reference/tests/vertical.rs",
    "rust-reference/san-composition-reference/tests/negative_twins.rs",
    "rust-reference/compile-fail/caller_constructs_proof.rs",
]

EXPECTED_FINALITY_ORDER = [
    "SelectedReleaseSet",
    "Stage0SupplierInventoryClosure",
    "FamilyPlanSet",
    "ApplicationBinding",
    "ObligationClosure",
    "Csag",
    "PortableIrPortfolio",
    "TargetCapabilityNegotiation",
    "TargetLegalityReport",
    "LoweredTargetArtifactSet",
    "TranslationValidationSet",
    "TargetCompilationSet",
    "ExecutionBinding",
    "ApplicationClosure",
    "AppRelease",
    "EnvironmentBinding",
    "DeploymentPlan",
    "BootInput",
    "BootReport",
]

IGNORED_MANIFEST_PARTS = {"target", "__pycache__", ".pytest_cache", ".git"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def topological_order(nodes: list[str], edges: list[tuple[str, str]]) -> list[str]:
    node_set = set(nodes)
    if len(node_set) != len(nodes):
        raise AssertionError("duplicate DAG node")
    outgoing: dict[str, list[str]] = defaultdict(list)
    indegree = {node: 0 for node in nodes}
    for source, target in edges:
        if source not in node_set or target not in node_set:
            raise AssertionError(f"unknown DAG endpoint: {source}->{target}")
        outgoing[source].append(target)
        indegree[target] += 1
    queue = deque(sorted(node for node, degree in indegree.items() if degree == 0))
    result = []
    while queue:
        node = queue.popleft()
        result.append(node)
        for target in sorted(outgoing[node]):
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    if len(result) != len(nodes):
        raise AssertionError("DAG contains a cycle")
    return result


class Gate:
    def __init__(self) -> None:
        self.checks: list[dict[str, Any]] = []
        self.errors: list[dict[str, str]] = []
        self.warnings: list[dict[str, str]] = []

    def run(self, check_id: str, function: Callable[[], Any]) -> Any | None:
        try:
            detail = function()
        except Exception as error:  # noqa: BLE001 - verifier must record every gate failure
            self.checks.append({"check_id": check_id, "status": "FAIL", "detail": str(error)})
            self.errors.append({"check_id": check_id, "error": str(error)})
            return None
        self.checks.append({"check_id": check_id, "status": "PASS", "detail": detail})
        return detail

    def blocked(self, check_id: str, detail: str) -> None:
        self.checks.append({"check_id": check_id, "status": "BLOCKED", "detail": detail})
        self.warnings.append({"check_id": check_id, "warning": detail})


def verify_required_paths(root: Path) -> dict[str, int]:
    missing = [relative for relative in REQUIRED_PATHS if not (root / relative).is_file()]
    if missing:
        raise AssertionError(f"missing required paths: {missing}")
    return {"required_file_count": len(REQUIRED_PATHS)}


def verify_json_and_canonical(root: Path) -> dict[str, int]:
    files = sorted(
        path
        for path in root.rglob("*.json")
        if not any(part in IGNORED_MANIFEST_PARTS for part in path.relative_to(root).parts)
    )
    for path in files:
        value = load_json(path)
        if path.read_bytes() != canonical_bytes(value):
            raise AssertionError(f"non-canonical JSON serialization: {path.relative_to(root)}")
    return {"json_files": len(files)}


def verify_schemas(root: Path) -> dict[str, int]:
    schema_paths = sorted(root.glob("*.schema.json"))
    if not schema_paths:
        raise AssertionError("no JSON Schema files")
    for path in schema_paths:
        schema = load_json(path)
        jsonschema.Draft202012Validator.check_schema(schema)
    schema = load_json(root / "UNIVERSAL-CONTRIBUTION-MODEL.schema.json")
    model = load_json(root / "UNIVERSAL-CONTRIBUTION-MODEL.json")
    jsonschema.Draft202012Validator(schema).validate(model)
    return {"schemas": len(schema_paths), "instances_validated": 1, "draft": "2020-12"}


def verify_identities_and_owners(root: Path) -> dict[str, int]:
    universal = load_json(root / "UNIVERSAL-CONTRIBUTION-MODEL.json")
    field_ids = [row["field_id"] for row in universal["universal_fields"]]
    field_names = [row["name"] for row in universal["universal_fields"]]
    facet_ids = [row["facet_kind_id"] for row in universal["facet_kinds"]]
    projection_ids = [row["projection_id"] for row in universal["class_specific_projections"]]
    for label, values in {
        "universal field ids": field_ids,
        "universal field names": field_names,
        "facet ids": facet_ids,
        "projection ids": projection_ids,
    }.items():
        if len(values) != len(set(values)):
            raise AssertionError(f"duplicate {label}")
    for row in universal["universal_fields"] + universal["facet_kinds"] + universal["class_specific_projections"]:
        owner = row.get("semantic_owner") or row.get("owner") or row.get("admission_owner")
        if not isinstance(owner, str) or not owner.strip():
            raise AssertionError(f"missing single owner in {row}")

    registry = load_json(root / "REGISTRY-KIND-COMPILER-MATRIX.json")
    kind_ids = [row["unit_kind_id"] for row in registry["rows"]]
    if len(kind_ids) != len(set(kind_ids)):
        raise AssertionError("duplicate registry unit kind")

    ir = load_json(root / "IR-PORTFOLIO.json")
    ir_ids = [row["ir_id"] for row in ir["selected_intermediate_representations"]]
    ir_owners = [row["semantic_owner"] for row in ir["selected_intermediate_representations"]]
    if len(ir_ids) != len(set(ir_ids)):
        raise AssertionError("duplicate Intermediate Representation identity")
    if len(ir_owners) != len(set(ir_owners)):
        raise AssertionError("same owner reused for independent Intermediate Representation meanings")

    csag = load_json(root / "CSAG-OWNERSHIP-AND-COVERAGE.json")
    node_kind_ids = [row["node_kind_id"] for row in csag["node_kinds"]]
    edge_kind_ids = [row["edge_kind_id"] for row in csag["hyperedge_kinds"]]
    if len(node_kind_ids) != len(set(node_kind_ids)) or len(edge_kind_ids) != len(set(edge_kind_ids)):
        raise AssertionError("duplicate semantic graph kind")
    return {
        "universal_fields": len(field_ids),
        "facet_kinds": len(facet_ids),
        "class_projections": len(projection_ids),
        "registry_kinds": len(kind_ids),
        "ir_strata": len(ir_ids),
        "csag_node_kinds": len(node_kind_ids),
        "csag_edge_kinds": len(edge_kind_ids),
    }


def verify_artifact_dag(root: Path) -> dict[str, Any]:
    artifact = load_json(root / "ARTIFACT-AND-FINALITY-DAG.json")
    nodes = [row["artifact_kind"] for row in artifact["nodes"]]
    edges = [(row["from"], row["to"]) for row in artifact["edges"]]
    if nodes != EXPECTED_FINALITY_ORDER:
        raise AssertionError(f"artifact order mismatch: {nodes}")
    order = topological_order(nodes, edges)
    if order != EXPECTED_FINALITY_ORDER:
        raise AssertionError(f"topological order mismatch: {order}")
    if artifact["canonical_topological_order"] != EXPECTED_FINALITY_ORDER:
        raise AssertionError("declared canonical topological order differs")
    if any(not node["must_bind_exact_occurrences"] for node in artifact["nodes"]):
        raise AssertionError("artifact permits value-only binding")
    environment_allowed = {
        row["artifact_kind"] for row in artifact["nodes"] if row["physical_environment_allowed"]
    }
    if environment_allowed != {"EnvironmentBinding", "DeploymentPlan", "BootInput", "BootReport"}:
        raise AssertionError(f"physical-environment boundary mismatch: {environment_allowed}")
    return {"nodes": len(nodes), "edges": len(edges), "order": order}


def verify_seams_and_csag(root: Path) -> dict[str, int]:
    seams = load_json(root / "SEMANTIC-SEAM-HYPERGRAPH.json")
    endpoint_kinds = set(seams["endpoint_kinds"])
    seam_ids = []
    for seam in seams["seam_types"]:
        seam_ids.append(seam["seam_type_id"])
        for endpoint in seam["endpoint_roles"]:
            if endpoint["kind"] not in endpoint_kinds:
                raise AssertionError(
                    f"unknown seam endpoint kind {endpoint['kind']} in {seam['seam_type_id']}"
                )
        if not seam["owner"]:
            raise AssertionError(f"seam lacks owner: {seam['seam_type_id']}")
    if len(seam_ids) != len(set(seam_ids)):
        raise AssertionError("duplicate seam identity")

    csag = load_json(root / "CSAG-OWNERSHIP-AND-COVERAGE.json")
    node_kinds = {row["node_kind_id"] for row in csag["node_kinds"]}
    for edge in csag["hyperedge_kinds"]:
        if edge["arity"] != len(edge["endpoints"]):
            raise AssertionError(f"hyperedge arity mismatch: {edge['edge_kind_id']}")
        unknown = set(edge["endpoints"]) - node_kinds
        if unknown:
            raise AssertionError(f"unknown graph endpoint kinds: {sorted(unknown)}")
    if csag["admitted_type"] != "Csag" or csag["hostile_input_type"] == "Csag":
        raise AssertionError("hostile and admitted graph types are not separated")
    if csag["parallel_verified_alias_permitted"]:
        raise AssertionError("parallel admitted graph alias permitted")
    return {
        "seam_endpoint_kinds": len(endpoint_kinds),
        "seam_types": len(seam_ids),
        "csag_node_kinds": len(node_kinds),
        "csag_hyperedge_kinds": len(csag["hyperedge_kinds"]),
    }


def verify_source_traceability(root: Path) -> dict[str, int]:
    ledger = load_json(root / "SOURCE-AND-CLAIM-LEDGER.json")
    attached = {row["source_id"]: row for row in ledger["attached_source_spans"]}
    public = {row["source_id"]: row for row in ledger["public_primary_sources"]}
    if len(attached) != len(ledger["attached_source_spans"]):
        raise AssertionError("duplicate attached source id")
    if len(public) != len(ledger["public_primary_sources"]):
        raise AssertionError("duplicate public source id")
    all_ids = set(attached) | set(public)
    for source_id, row in attached.items():
        observed = sha256_bytes(row["span_text"].encode("utf-8"))
        if observed != row["span_sha256"]:
            raise AssertionError(f"source span mutation: {source_id}")
        if row["start_line"] < 1 or row["end_line"] < row["start_line"]:
            raise AssertionError(f"invalid source locus: {source_id}")
        if not re.fullmatch(r"[0-9a-f]{64}", row["source_file_sha256"]):
            raise AssertionError(f"invalid source-file hash: {source_id}")
    for source_id, row in public.items():
        if not row["url"].startswith("https://"):
            raise AssertionError(f"non-HTTPS public primary source: {source_id}")
    claim_ids = []
    for claim in ledger["claims"]:
        claim_ids.append(claim["claim_id"])
        for source_ref in claim.get("source_refs", []):
            if source_ref not in all_ids:
                raise AssertionError(f"unknown source ref {source_ref} in {claim['claim_id']}")
        if claim["claim_class"] == "ARCHITECTURAL_INFERENCE" and not claim.get("source_refs"):
            raise AssertionError(f"unsupported architectural inference {claim['claim_id']}")
    if len(claim_ids) != len(set(claim_ids)):
        raise AssertionError("duplicate claim id")
    return {
        "attached_source_spans": len(attached),
        "public_primary_sources": len(public),
        "claims": len(claim_ids),
    }


def verify_bounded_work(root: Path) -> dict[str, int]:
    bounded = load_json(root / "BOUNDED-WORK-AND-CHECKPOINTS.json")
    algorithms = bounded["algorithms"]
    algorithm_ids = [row["algorithm_id"] for row in algorithms]
    if len(algorithm_ids) != len(set(algorithm_ids)):
        raise AssertionError("duplicate bounded algorithm")
    for row in algorithms:
        if not isinstance(row["maximum"], int) or row["maximum"] <= 0:
            raise AssertionError(f"non-finite or non-positive maximum: {row['algorithm_id']}")
        if not row["checkpoint_key"]:
            raise AssertionError(f"missing checkpoint key: {row['algorithm_id']}")
        if not row["semantic_refusals"] or not row["exhaustion"]:
            raise AssertionError(f"refusal/exhaustion not separated: {row['algorithm_id']}")
        if row["exhaustion"] in row["semantic_refusals"]:
            raise AssertionError(f"exhaustion aliases refusal: {row['algorithm_id']}")
    negatives = load_json(root / "NEGATIVE-TWIN-MATRIX.json")
    budget_cases = [
        case
        for case in negatives["cases"]
        if case["expected_outcome"] in {row["exhaustion"] for row in algorithms}
    ]
    if len(budget_cases) != len(algorithms):
        raise AssertionError(
            f"budget maximum-plus-one coverage mismatch {len(budget_cases)} != {len(algorithms)}"
        )
    return {"bounded_algorithms": len(algorithms), "maximum_plus_one_cases": len(budget_cases)}


def verify_manifest(root: Path) -> dict[str, int]:
    manifest = load_json(root / "MANIFEST.json")
    if manifest.get("manifest_exclusions") != ["MANIFEST.json", "PACKAGE-VERIFY.json"]:
        raise AssertionError("manifest exclusions differ")
    rows = manifest["files"]
    row_paths = [row["path"] for row in rows]
    if row_paths != sorted(row_paths) or len(row_paths) != len(set(row_paths)):
        raise AssertionError("manifest path order or uniqueness failure")
    for row in rows:
        path = root / row["path"]
        if not path.is_file():
            raise AssertionError(f"manifest file absent: {row['path']}")
        if path.stat().st_size != row["bytes"]:
            raise AssertionError(f"manifest byte mismatch: {row['path']}")
        if sha256_file(path) != row["sha256"]:
            raise AssertionError(f"manifest hash mismatch: {row['path']}")
    actual = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(part in IGNORED_MANIFEST_PARTS for part in relative.parts):
            continue
        rel = relative.as_posix()
        if rel in {"MANIFEST.json", "PACKAGE-VERIFY.json"}:
            continue
        actual.append(rel)
    if sorted(actual) != row_paths:
        raise AssertionError(
            f"manifest coverage mismatch missing={sorted(set(actual)-set(row_paths))} extra={sorted(set(row_paths)-set(actual))}"
        )
    root_commitment = sha256_bytes(canonical_bytes(rows))
    if manifest["root_commitment_sha256"] != root_commitment:
        raise AssertionError("manifest root commitment mismatch")
    return {"manifested_files": len(rows), "manifested_bytes": sum(row["bytes"] for row in rows)}


def verify_claim_posture(root: Path) -> dict[str, Any]:
    status = load_json(root / "STATUS.json")
    if status["architecture_posture"] != "REVIEW_CANDIDATE" or status["certification"] != "NONE":
        raise AssertionError("status or certification overclaim")
    claims = status["evidence_claims"]
    forbidden_true = [
        "standalone_reference_rust_executed",
        "san_production_source_modified",
        "san_compiler_integration_executed",
        "live_runtime_executed",
        "deployment_executed",
        "boot_executed",
        "ratified",
        "certified",
    ]
    if any(claims[item] for item in forbidden_true):
        raise AssertionError("unsupported execution or certification claim")
    mixed = load_json(root / "MIXED-VERTICAL.json")
    san = mixed["current_san_evidence_vertical"]
    if san["typed_outcome"]["kind"] != "UserInterfaceSourceAbsent":
        raise AssertionError("missing User Interface source not retained")
    if san["application_closure_issued"] or san["app_release_issued"] or san["boot_report_issued"]:
        raise AssertionError("current SAN evidence path overclaims final artifacts")
    return {
        "status": status["architecture_posture"],
        "certification": status["certification"],
        "san_ui_outcome": san["typed_outcome"]["kind"],
    }


def verify_rust_static(root: Path) -> dict[str, Any]:
    workspace = root / "rust-reference"
    crate_manifest = (workspace / "san-composition-reference/Cargo.toml").read_text(encoding="utf-8")
    dependency_match = re.search(r"\[dependencies\](.*?)(?:\n\[|\Z)", crate_manifest, re.S)
    if dependency_match and dependency_match.group(1).strip():
        raise AssertionError("reference crate has external dependencies")
    source_paths = sorted((workspace / "san-composition-reference/src").glob("*.rs"))
    source = "\n".join(path.read_text(encoding="utf-8") for path in source_paths)
    if "unsafe" in re.sub(r"#!\[forbid\(unsafe_code\)\]", "", source):
        raise AssertionError("unsafe token in reference source")
    banned_dependencies = ["san_proto", "san_factory", "san_foundation", "san_chassis", "old_toolkit"]
    if any(item in crate_manifest.lower() for item in banned_dependencies):
        raise AssertionError("deprecated SAN dependency present")
    proof_source = (workspace / "san-composition-reference/src/proof.rs").read_text(encoding="utf-8")
    for proof_name in ["AuthorityWitness", "AdmissionProof"]:
        match = re.search(rf"pub struct {proof_name}\s*\{{(.*?)\n\}}", proof_source, re.S)
        if not match:
            raise AssertionError(f"missing nominal proof type {proof_name}")
        if re.search(r"^\s*pub\s+[A-Za-z_]", match.group(1), re.M):
            raise AssertionError(f"public field on {proof_name}")
    if re.search(r"\bpub\s+fn\s+(?:new|issue|from_raw)\s*\(", proof_source):
        raise AssertionError("public proof constructor or issuer")
    compiler_source = (workspace / "san-composition-reference/src/compiler.rs").read_text(encoding="utf-8")
    branch = static_branch_scan(compiler_source)
    if branch:
        raise AssertionError(branch)
    compile_fail = (workspace / "compile-fail/caller_constructs_proof.rs").read_text(encoding="utf-8")
    if "AdmissionProof {" not in compile_fail:
        raise AssertionError("caller-proof compile-fail fixture missing")
    required_nominal_types = [
        "ContributionEnvelope",
        "SemanticProjection",
        "GovernedDataProjection",
        "DomainOntologyProjection",
        "ExperienceProjection",
        "UserInterfaceProjection",
        "ApplicationBinding",
        "ObligationClosure",
        "Csag",
        "PortableIrPortfolio",
        "TargetCompilationSet",
        "ExecutionBinding",
        "ApplicationClosure",
        "AppRelease",
        "OfflineReplayClosure",
        "EnvironmentBinding",
        "DeploymentPlan",
        "BootInput",
        "BootReport",
    ]
    missing = [name for name in required_nominal_types if not re.search(rf"\b(?:pub\s+)?(?:struct|enum)\s+{name}\b", source)]
    if missing:
        raise AssertionError(f"missing nominal Rust types: {missing}")
    return {
        "source_files": len(source_paths),
        "external_dependencies": 0,
        "private_proof_types_checked": 2,
        "generic_branch_scan": "PASS",
        "compile_fail_fixture": "PRESENT",
    }


def verify_reference_and_mutations(root: Path) -> dict[str, Any]:
    mixed = load_json(root / "MIXED-VERTICAL.json")
    negative = load_json(root / "NEGATIVE-TWIN-MATRIX.json")
    fixture = mixed["reference_architecture_fixture"]
    supplier_roles = fixture["supplier_roles"]
    positive = validate_reference_fixture(fixture, supplier_roles)
    compiler_source = (root / "rust-reference/san-composition-reference/src/compiler.rs").read_text(encoding="utf-8")
    proof_source = (root / "rust-reference/san-composition-reference/src/proof.rs").read_text(encoding="utf-8")
    negative_results = run_negative_cases(fixture, supplier_roles, negative, compiler_source, proof_source)
    if any(result["status"] != "PASS" for result in negative_results):
        raise AssertionError("negative mutation failure")
    expected = {row["case_id"] for row in negative["cases"]}
    observed = {row["case_id"] for row in negative_results}
    if expected != observed:
        raise AssertionError("negative matrix coverage mismatch")
    return {"positive": positive, "negative_case_count": len(negative_results), "negative_results": negative_results}


def verify_deterministic_zip(root: Path) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="san-deterministic-zip-") as temporary:
        first = Path(temporary) / "first.zip"
        second = Path(temporary) / "second.zip"
        build_zip(root, first)
        build_zip(root, second)
        first_bytes = first.read_bytes()
        second_bytes = second.read_bytes()
        if first_bytes != second_bytes:
            raise AssertionError("deterministic ZIP reconstruction differs")
        with zipfile.ZipFile(first) as archive:
            bad = archive.testzip()
            if bad is not None:
                raise AssertionError(f"reconstructed ZIP corruption at {bad}")
        return {
            "sha256": sha256_bytes(first_bytes),
            "bytes": len(first_bytes),
            "byte_identical_reconstructions": 2,
        }


def run_command(command: list[str], cwd: Path, env: dict[str, str] | None = None) -> dict[str, Any]:
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    detail = {
        "command": command,
        "returncode": completed.returncode,
        "stdout_tail": completed.stdout[-4000:],
        "stderr_tail": completed.stderr[-4000:],
    }
    if completed.returncode != 0:
        raise AssertionError(json.dumps(detail, ensure_ascii=False))
    return detail


def verify_rust_execution(root: Path, gate: Gate, require_rust: bool) -> dict[str, Any]:
    cargo = shutil.which("cargo")
    rustc = shutil.which("rustc")
    if cargo is None or rustc is None:
        detail = "cargo and/or rustc unavailable; Rust execution gates were not run"
        if require_rust:
            raise AssertionError(detail)
        gate.blocked("RUST-EXECUTION", detail)
        return {"status": "BLOCKED_TOOLCHAIN_UNAVAILABLE", "cargo": cargo, "rustc": rustc, "commands": []}
    workspace = root / "rust-reference"
    commands = []
    commands.append(run_command([cargo, "fmt", "--all", "--", "--check"], workspace))
    commands.append(run_command([cargo, "check", "--workspace", "--all-targets", "--locked"], workspace))
    commands.append(run_command([cargo, "test", "--workspace", "--locked"], workspace))
    commands.append(
        run_command(
            [cargo, "clippy", "--workspace", "--all-targets", "--locked", "--", "-D", "warnings"],
            workspace,
        )
    )
    doc_env = os.environ.copy()
    doc_env["RUSTDOCFLAGS"] = "-D warnings"
    commands.append(run_command([cargo, "doc", "--workspace", "--no-deps", "--locked"], workspace, doc_env))
    rlibs = sorted((workspace / "target/debug/deps").glob("libsan_composition_reference-*.rlib"))
    if not rlibs:
        raise AssertionError("compiled reference rlib not found for compile-fail gate")
    fixture = workspace / "compile-fail/caller_constructs_proof.rs"
    compile_fail = subprocess.run(
        [
            rustc,
            "--edition=2021",
            "--extern",
            f"san_composition_reference={rlibs[-1]}",
            str(fixture),
            "-L",
            f"dependency={workspace / 'target/debug/deps'}",
        ],
        cwd=workspace,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if compile_fail.returncode == 0:
        raise AssertionError("caller-authored AdmissionProof unexpectedly compiled")
    if "private" not in compile_fail.stderr.lower():
        raise AssertionError(f"compile-fail did not fail for privacy: {compile_fail.stderr[-2000:]}")
    return {
        "status": "PASS",
        "cargo": cargo,
        "rustc": rustc,
        "commands": commands,
        "compile_fail": {
            "returncode": compile_fail.returncode,
            "stderr_tail": compile_fail.stderr[-2000:],
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--json-output", type=Path)
    parser.add_argument("--require-rust", action="store_true")
    args = parser.parse_args()
    root = args.root.resolve()
    gate = Gate()

    gate.run("REQUIRED-PATHS", lambda: verify_required_paths(root))
    gate.run("JSON-CANONICAL", lambda: verify_json_and_canonical(root))
    gate.run("JSON-SCHEMA-2020-12", lambda: verify_schemas(root))
    gate.run("IDENTITIES-AND-OWNERS", lambda: verify_identities_and_owners(root))
    gate.run("ARTIFACT-FINALITY-DAG", lambda: verify_artifact_dag(root))
    gate.run("SEAMS-AND-CSAG", lambda: verify_seams_and_csag(root))
    gate.run("SOURCE-TRACEABILITY", lambda: verify_source_traceability(root))
    gate.run("BOUNDED-WORK", lambda: verify_bounded_work(root))
    gate.run("MANIFEST", lambda: verify_manifest(root))
    gate.run("CLAIM-POSTURE", lambda: verify_claim_posture(root))
    gate.run("RUST-STATIC", lambda: verify_rust_static(root))
    reference_result = gate.run("REFERENCE-VERTICAL-AND-MUTATIONS", lambda: verify_reference_and_mutations(root))
    deterministic_result = gate.run("DETERMINISTIC-ZIP", lambda: verify_deterministic_zip(root))

    rust_result: dict[str, Any]
    try:
        rust_result = verify_rust_execution(root, gate, args.require_rust)
        if rust_result["status"] == "PASS":
            gate.checks.append({"check_id": "RUST-EXECUTION", "status": "PASS", "detail": rust_result})
    except Exception as error:  # noqa: BLE001
        gate.checks.append({"check_id": "RUST-EXECUTION", "status": "FAIL", "detail": str(error)})
        gate.errors.append({"check_id": "RUST-EXECUTION", "error": str(error)})
        rust_result = {"status": "FAIL", "detail": str(error)}

    if gate.errors:
        overall = "FAIL"
    elif rust_result["status"] == "BLOCKED_TOOLCHAIN_UNAVAILABLE":
        overall = "PASS_WITH_RUST_BLOCKED"
    else:
        overall = "PASS"

    report = {
        "artifact_id": "san.cross-registry.package-verification-result",
        "edition": 1,
        "status": "REVIEW_CANDIDATE",
        "certification": "NONE",
        "overall_status": overall,
        "root": root.name,
        "checks": gate.checks,
        "errors": gate.errors,
        "warnings": gate.warnings,
        "reference_result": reference_result,
        "deterministic_zip_result": deterministic_result,
        "rust_execution": rust_result,
        "claim_limits": {
            "san_production_integration": "NOT_EXECUTED",
            "live_runtime": "NOT_EXECUTED",
            "deployment": "NOT_EXECUTED",
            "boot": "NOT_EXECUTED",
            "certification": "NONE",
        },
    }
    rendered = json.dumps(report, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    if args.json_output:
        args.json_output.parent.mkdir(parents=True, exist_ok=True)
        args.json_output.write_text(rendered, encoding="utf-8")
    sys.stdout.write(rendered)
    return 0 if overall != "FAIL" else 1


if __name__ == "__main__":
    raise SystemExit(main())
