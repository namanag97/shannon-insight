//! Operation contracts owned by `SAN-COMPILER-APPLICATION-BINDING`.

pub trait ApplicationBindingContracts {
    /// `application-binding.input.admit`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_link_input(
        &self,
        arg0: crate::catalog_types::application_binding::ApplicationBindingInputMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingInput, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.source.verify`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_link_sources(
        &self,
        arg0: &crate::catalog_types::application_binding::ApplicationBindingInput,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingTrustPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::VerifiedLinkSources, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.surface.bind`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_linker_dispatch_table(
        &self,
        arg0: &crate::catalog_types::application_binding::VerifiedLinkSources,
        arg1: &crate::catalog_types::application_binding::GeneratedDispatchMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingDispatchTable, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.header.index`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn index_contract_headers(
        &self,
        arg0: &crate::catalog_types::application_binding::VerifiedLinkSources,
        arg1: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ContractHeaderRegistry, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.requirement.cluster`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn cluster_requirements(
        &self,
        arg0: &[crate::vertical::ContractRequirementSpec],
        arg1: &crate::catalog_types::application_binding::ContractHeaderRegistry,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::RequirementClusterSet, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.requirement.join-one`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn join_requirement_cluster(
        &self,
        arg0: &crate::catalog_types::application_binding::RequirementCluster,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingDispatchTable,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::JoinedRequirementSet, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.requirement.join-all`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn join_all_requirements(
        &self,
        arg0: &crate::catalog_types::application_binding::RequirementClusterSet,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingDispatchTable,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::JoinedRequirementSet, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.offer.index`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn index_semantic_offers(
        &self,
        arg0: &[crate::vertical::ContractOfferSpec],
        arg1: &crate::catalog_types::application_binding::ContractHeaderRegistry,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::SemanticOfferIndex, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.candidate.structural`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn discover_structural_candidates(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirement,
        arg1: &crate::catalog_types::application_binding::SemanticOfferIndex,
        arg2: &crate::catalog_types::application_binding::ContractHeader,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::StructuralCandidateSet, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.candidate.assess`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn assess_candidate_offer(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirement,
        arg1: &crate::vertical::ContractOfferSpec,
        arg2: &crate::catalog_types::application_binding::ContractHeader,
        arg3: &crate::catalog_types::application_binding::ApplicationBindingDispatchTable,
        arg4: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::CandidateOfferAssessment, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.candidate.discover`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn discover_candidate_offers(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirement,
        arg1: &crate::catalog_types::application_binding::SemanticOfferIndex,
        arg2: &crate::catalog_types::application_binding::ApplicationBindingDispatchTable,
        arg3: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::CandidateOfferSet, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.candidate.discover-all`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn discover_all_candidates(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirementSet,
        arg1: &crate::catalog_types::application_binding::SemanticOfferIndex,
        arg2: &crate::catalog_types::application_binding::ApplicationBindingDispatchTable,
        arg3: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::CandidateOfferSetMap, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.selection.request`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_selection_request(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirement,
        arg1: &crate::catalog_types::application_binding::CandidateOfferSet,
        arg2: &crate::catalog_types::application_binding::ContractHeader,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<Option<crate::catalog_types::application_binding::SelectionRequest>, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.selection.admit`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_selection_directive(
        &self,
        arg0: crate::catalog_types::application_binding::SelectionDirectiveMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::SelectionDirective, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.selection.validate`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn validate_selection_directive(
        &self,
        arg0: &crate::catalog_types::application_binding::SelectionDirective,
        arg1: &crate::catalog_types::application_binding::JoinedRequirement,
        arg2: &crate::catalog_types::application_binding::CandidateOfferSet,
        arg3: &crate::catalog_types::application_binding::ContractHeader,
        arg4: &crate::waist::AuthorityPolicySet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::SelectionProof, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.cardinality.resolve`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_provider_cardinality(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirement,
        arg1: &crate::catalog_types::application_binding::CandidateOfferSet,
        arg2: Option<&crate::catalog_types::application_binding::SelectionDirective>,
        arg3: &crate::catalog_types::application_binding::ContractHeader,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::CardinalityResolution, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.binding.derive`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_resolved_binding(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirement,
        arg1: &crate::catalog_types::application_binding::CandidateOfferSet,
        arg2: &crate::catalog_types::application_binding::CardinalityResolution,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::ResolvedContractBinding, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.binding.resolve-all`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_all_bindings(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirementSet,
        arg1: &crate::catalog_types::application_binding::CandidateOfferSetMap,
        arg2: &crate::catalog_types::application_binding::SelectionDirectiveSet,
        arg3: &crate::waist::AuthorityPolicySet,
        arg4: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::BindingResolution, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.deferred.derive`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_deferred_binding(
        &self,
        arg0: &crate::catalog_types::application_binding::JoinedRequirement,
        arg1: &crate::catalog_types::application_binding::ContractHeader,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::DeferredBindingRequirement, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.extension.resolve`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_extensions(
        &self,
        arg0: &crate::catalog_types::application_binding::ExtensionDeclarationSet,
        arg1: &crate::catalog_types::application_binding::VerifiedLinkSources,
        arg2: &crate::catalog_types::application_binding::ApplicationBindingDispatchTable,
        arg3: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ExtensionBindingSet, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.gap.resolve`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_gap_dispositions(
        &self,
        arg0: &crate::catalog_types::application_binding::GapLedgerSet,
        arg1: &crate::catalog_types::application_binding::GapAcceptanceDirectiveSet,
        arg2: &crate::waist::AuthorityPolicySet,
        arg3: &crate::catalog_types::application_binding::ApplicationBindingPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::GapDispositionSet, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.link`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn link_application(
        &self,
        arg0: &crate::catalog_types::application_binding::ApplicationBindingInput,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingOutcome, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.resume`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_link(
        &self,
        arg0: &crate::catalog_types::application_binding::ApplicationBindingCheckpoint,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingInput,
        arg2: &crate::catalog_types::application_binding::ApplicationBindingExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingOutcome, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.directive.invalidate`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_selection_invalidation(
        &self,
        arg0: &crate::catalog_types::application_binding::SelectionDirective,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingInput,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::SelectionInvalidation, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.explain`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_link_target(
        &self,
        arg0: crate::catalog_types::application_binding::ApplicationBindingExplainTarget,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingOrRefusal,
        arg2: crate::waist::DisclosurePolicyRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingExplanation, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.build`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_application_binding(
        &self,
        arg0: &crate::catalog_types::application_binding::ApplicationBindingStageArtifacts,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingPolicy,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::ApplicationBinding, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.verify`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_application_binding(
        &self,
        arg0: &crate::vertical::ApplicationBinding,
        arg1: &crate::catalog_types::application_binding::ApplicationBindingVerificationContext,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::ApplicationBindingProof, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.canonical.project`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_application_binding(
        &self,
        arg0: &crate::vertical::ApplicationBinding,
        arg1: &crate::catalog_types::application_binding::CanonicalContext,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingCanonicalProjection, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.fingerprint`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn fingerprint_application_binding(
        &self,
        arg0: &crate::catalog_types::application_binding::ApplicationBindingCanonicalProjection,
        arg1: &crate::waist::DigestContext,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingFingerprint, crate::vertical::ApplicationBindingRefusal, crate::waist::CompilerNeedsInput>;

    /// `application-binding.delta.classify`. Owner: `SAN-COMPILER-APPLICATION-BINDING`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_application_binding_delta(
        &self,
        arg0: &crate::vertical::ApplicationBinding,
        arg1: &crate::vertical::ApplicationBinding,
        arg2: crate::catalog_types::application_binding::ApplicationBindingBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_binding::ApplicationBindingDelta, crate::catalog_types::application_binding::ApplicationBindingEvolutionRefusal, crate::waist::CompilerNeedsInput>;

}
