#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Any
from jsonschema import Draft202012Validator

FORBIDDEN = {"metadata", "properties", "attributes", "payload", "extensions", "custom_fields", "notes"}
COMMON = {"schema_version", "id", "kind", "canonical_name", "definition", "aliases", "version", "lifecycle_status", "classification", "applicability", "confidence", "evidence_refs", "created_at", "updated_at"}
EXCLUDED_REF_KEYS = {"owner_reference", "missing_reference_literal", "target_identifier", "locator"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def walk_keys(value: Any, errors: list[str], location: str) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if key in FORBIDDEN:
                errors.append(f"forbidden field {key} at {location}")
            walk_keys(item, errors, f"{location}.{key}")
    elif isinstance(value, list):
        for i, item in enumerate(value):
            walk_keys(item, errors, f"{location}[{i}]")


def collect_refs(value: Any, refs: list[tuple[str, str]], location: str, parent_key: str = "") -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            loc = f"{location}.{key}"
            if key not in EXCLUDED_REF_KEYS and (key == "ref" or key.endswith("_ref") or key.endswith("_refs")):
                vals = item if isinstance(item, list) else [item]
                for ref in vals:
                    if isinstance(ref, str):
                        refs.append((loc, ref))
            collect_refs(item, refs, loc, key)
    elif isinstance(value, list):
        for i, item in enumerate(value):
            collect_refs(item, refs, f"{location}[{i}]", parent_key)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    errors: list[str] = []
    warnings: list[str] = []
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))

    parsed_json_count = 0
    parsed_jsonl_count = 0
    for path in sorted(root.rglob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8"))
            parsed_json_count += 1
        except Exception as exc:
            errors.append(f"JSON parse failure {path.relative_to(root)}: {exc}")
    records: list[dict[str, Any]] = []
    file_records: dict[str, list[dict[str, Any]]] = {}
    for path in sorted(root.rglob("*.jsonl")):
        current = []
        for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                errors.append(f"blank JSONL line {path.relative_to(root)}:{line_no}")
                continue
            try:
                obj = json.loads(line)
            except Exception as exc:
                errors.append(f"JSONL parse failure {path.relative_to(root)}:{line_no}: {exc}")
                continue
            if not isinstance(obj, dict):
                errors.append(f"non-object JSONL record {path.relative_to(root)}:{line_no}")
                continue
            current.append(obj)
            records.append(obj)
        parsed_jsonl_count += 1
        rel = path.relative_to(root).as_posix()
        file_records[rel] = current
        ids = [r.get("id", "") for r in current]
        if ids != sorted(ids):
            errors.append(f"non-deterministic JSONL order: {rel}")

    ids = [r.get("id") for r in records]
    duplicate_ids = [x for x, n in Counter(ids).items() if x is not None and n > 1]
    if duplicate_ids:
        errors.append(f"duplicate ids: {duplicate_ids[:20]}")
    id_set = {x for x in ids if isinstance(x, str)}
    external = set(manifest.get("external_reference_allowlist", []))

    lifecycle = {x["value"] for x in json.loads((root / "vocabularies/lifecycle_statuses.json").read_text())["values"]}
    relation_types = {x["value"] for x in json.loads((root / "vocabularies/relation_types.json").read_text())["values"]}
    roles = {x["value"] for x in json.loads((root / "vocabularies/participant_roles.json").read_text())["values"]}
    dispositions = {x["value"] for x in json.loads((root / "vocabularies/boundary_dispositions.json").read_text())["values"]}

    schema_cache = {}
    for kind, schema_path in manifest["schema_map"].items():
        schema = json.loads((root / schema_path).read_text(encoding="utf-8"))
        try:
            Draft202012Validator.check_schema(schema)
        except Exception as exc:
            errors.append(f"invalid schema {schema_path}: {exc}")
        schema_cache[kind] = Draft202012Validator(schema)

    for record in records:
        rid = record.get("id", "<missing>")
        missing = sorted(COMMON - set(record))
        if missing:
            errors.append(f"{rid}: missing common fields {missing}")
        kind = record.get("kind")
        if kind not in schema_cache:
            errors.append(f"{rid}: unknown kind {kind}")
        else:
            for err in schema_cache[kind].iter_errors(record):
                errors.append(f"{rid}: schema error at {'/'.join(map(str, err.path))}: {err.message}")
        if record.get("lifecycle_status") not in lifecycle:
            errors.append(f"{rid}: uncontrolled lifecycle status")
        if kind == "context" and record.get("disposition") not in dispositions:
            errors.append(f"{rid}: uncontrolled boundary disposition")
        if kind == "relation":
            if record.get("relation_type") not in relation_types:
                errors.append(f"{rid}: uncontrolled relation type")
            participants = record.get("participants", [])
            expected = 2 if record.get("relation_form") == "BINARY" else 3
            if len(participants) < expected or (record.get("relation_form") == "BINARY" and len(participants) != 2):
                errors.append(f"{rid}: participant cardinality invalid")
            for p in participants:
                if p.get("role") not in roles:
                    errors.append(f"{rid}: uncontrolled participant role {p.get('role')}")
        walk_keys(record, errors, rid)
        refs: list[tuple[str, str]] = []
        collect_refs(record, refs, rid)
        for location, ref in refs:
            if ref not in id_set and ref not in external:
                errors.append(f"unresolved reference {ref} at {location}")

    # Exact duplicate fingerprints exclude identity and timestamps but retain semantic content.
    fingerprints: dict[str, list[str]] = {}
    for record in records:
        normalized = {k: v for k, v in record.items() if k not in {"id", "created_at", "updated_at"}}
        fp = hashlib.sha256(json.dumps(normalized, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        fingerprints.setdefault(fp, []).append(record.get("id", ""))
    semantic_exact_duplicates = [v for v in fingerprints.values() if len(v) > 1]
    if semantic_exact_duplicates:
        errors.append(f"exact semantic duplicate fingerprints: {semantic_exact_duplicates[:10]}")

    required = [
        "manifest.json", "VALIDATION.json", "CHECKSUMS.txt", "README.md", "generated/index.json", "generated/SUMMARY.md",
        "coverage/coverage_matrix.json", "coverage/boundary_evaluation.json", "coverage/validation_summary.json",
    ] + list(manifest["record_files"].values()) + list(manifest["schema_map"].values())
    for rel in required:
        if not (root / rel).is_file():
            errors.append(f"missing required file: {rel}")

    checksum_file = root / "CHECKSUMS.txt"
    checksum_count = 0
    if checksum_file.is_file():
        for line in checksum_file.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            digest, rel = line.split("  ", 1)
            target = root / rel
            checksum_count += 1
            if not target.is_file():
                errors.append(f"checksum target missing: {rel}")
            elif sha256(target) != digest:
                errors.append(f"checksum mismatch: {rel}")

    result = {
        "status": "PASS" if not errors else "FAIL",
        "record_count": len(records),
        "counts_by_kind": dict(sorted(Counter(r.get("kind") for r in records).items())),
        "parsed_json_files": parsed_json_count,
        "parsed_jsonl_files": parsed_jsonl_count,
        "checksum_entries_verified": checksum_count,
        "errors": errors,
        "warnings": warnings,
    }
    print(json.dumps(result, sort_keys=True))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
