
# Compile and Test Commands

Run from `04-IMPLEMENTATION/rust` with a stable Rust toolchain:

```bash
cargo fmt --all -- --check
cargo check --workspace --all-targets
cargo test --workspace --all-targets
cargo clippy --workspace --all-targets --all-features -- -D warnings
RUSTDOCFLAGS="-D warnings" cargo doc --workspace --all-features --no-deps
```

The audit environment did not contain `cargo`, `rustc`, `rustfmt`, or `clippy`; these commands are required checkpoints, not claimed results.
