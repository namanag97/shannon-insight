#!/usr/bin/env python3
from __future__ import annotations
import json, re, sys
from pathlib import Path

ID_RE=re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$")

def load(p): return json.loads(p.read_text(encoding="utf-8"))
def fail(msg): print("FAIL",msg); raise SystemExit(1)

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve()
    spec=load(root/"SPEC.json"); ops=load(root/"OPERATIONS.json")["operations"]
    rust=load(root/"RUST-API.json"); laws=load(root/"LAWS.json")["laws"]
    refs=load(root/"REFUSALS.json")["variants"]; decs=load(root/"DECISIONS.json")["decisions"]
    budget=load(root/"BUDGETS.json")["budgets"]; st=load(root/"STATES.json")["state_machine"]
    tx=load(root/"TRANSITIONS.json")["matrix"]
    if not ID_RE.fullmatch(spec["identity"]): fail("invalid stable identity")
    if re.search(r"(?:/v\d+|@v\d+|[-_]v\d+)$",spec["identity"],re.I): fail("edition suffix embedded in identity")
    if spec["edition"]<1 or spec["status"]!="REVIEW_CANDIDATE" or spec["certification"]!="NONE": fail("dishonest status")
    opids={x["identity"] for x in ops}; lawids={x["identity"] for x in laws}; refids={x["identity"] for x in refs}; decids={x["identity"] for x in decs}
    if len(opids)!=len(ops) or len(lawids)!=len(laws) or len(refids)!=len(refs) or len(decids)!=len(decs): fail("duplicate local identity")
    api={x["identity"] for x in rust["operations"]}
    if api!=opids: fail("operation/Rust API drift")
    for op in ops:
        if not op["candidate_signature"].startswith("pub fn ") or "Result<" not in op["candidate_signature"]: fail("placeholder signature")
        if not set(op["law_coverage"])<=lawids: fail("unknown law in operation")
        if not set(op["decision_dependencies"])<=decids: fail("unknown decision in operation")
        if op["side_effect_posture"]!="PURE_NO_IO": fail("I/O leakage")
    for law in laws:
        if not set(law["operations_affected"])<=opids: fail("unknown operation in law")
        if not set(law["refusal_on_violation"])<=refids: fail("unknown refusal in law")
    for d in decs:
        if not d.get("absence_semantics"): fail("decision lacks absence semantics")
    for t in rust["types"]:
        if t["kind"] in {"ADMITTED_VALUE","ADMITTED_ENTITY","PROOF","AUTHORITY"} and (not t["fields_private"] or t["deserialize_constructor"]): fail("forgeable admitted/proof type")
    if len(tx)!=len(st["states"])*len(st["commands"]): fail("incomplete state×command matrix")
    if len({(x["state"],x["command"]) for x in tx})!=len(tx): fail("duplicate state cell")
    for b in budget:
        for key in ["max_input_bytes","max_items","max_depth","max_output_bytes","max_iterations"]:
            if not isinstance(b[key],int) or b[key]<=0: fail("unbounded budget")
        if "allocate" not in b["precharge_order"] or b["precharge_order"].index("allocate") < b["precharge_order"].index("charge allocation") or not b["overflow_behavior"].startswith("REFUSE_"): fail("unsafe budget charging")
    print(json.dumps({"result":"PASS","identity":spec["identity"],"operations":len(ops),"laws":len(laws),"state_cells":len(tx)},sort_keys=True))
if __name__=="__main__": main()
