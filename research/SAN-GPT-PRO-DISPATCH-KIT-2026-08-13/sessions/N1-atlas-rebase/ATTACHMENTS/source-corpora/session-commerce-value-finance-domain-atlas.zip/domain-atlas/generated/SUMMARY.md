# Commerce, Agreements, Value, Accounting, and Financial Exchange Domain Atlas

Generated navigation only. JSON and JSONL files are canonical.

## Package summary

- Total independently addressable records: 4530
- Concepts: 188
- Candidate bounded contexts: 37
- Other boundary hypotheses: 18
- Typed relations: 2324 (1815 binary, 509 n-ary)
- Adversarial scenarios: 14
- Competency questions: 84
- Registry-intake candidates: 62
- Open gaps: 16
- Unresolved boundaries: 13

## Navigation

- `corpus/`: canonical semantic, behavioral, boundary and relationship records
- `scenarios/`: adversarial scenarios, competency questions and examples
- `registry_intake/`: non-mutating crosswalks and intake proposals
- `issues/`: conflicts, gaps and unresolved references
- `coverage/`: generated coverage and boundary evaluations
- `schemas/`: JSON Schema Draft 2020-12 validation contracts
- `vocabularies/`: controlled values used by the corpus
- `tools/validate_corpus.py`: reusable validation utility

## Highest-impact unresolved boundaries

- `candidate.commerce-value-finance.unresolved_boundary.catalogue-publication-kind`: Should catalogue publication be a publication unit, owner-local module or profile?
- `candidate.commerce-value-finance.unresolved_boundary.commercial-availability-owner`: Who owns commercial availability when capacity, inventory, regulation and customer commitments interact?
- `candidate.commerce-value-finance.unresolved_boundary.commitment-family-shape`: Should commitment and obligation remain separate registry units or one coordinated family?
- `candidate.commerce-value-finance.unresolved_boundary.entitlement-eligibility-placement`: Which parts of eligibility are horizontal and which are programme-local?
- `candidate.commerce-value-finance.unresolved_boundary.financial-account-horizontal-scope`: Is Financial Account a horizontal family or a set of banking, brokerage, billing and custody profiles?
- `candidate.commerce-value-finance.unresolved_boundary.financial-reporting-1`: Jurisdictional adoption timing and transition from IAS 1 to IFRS 18 must remain profile-specific.
- `candidate.commerce-value-finance.unresolved_boundary.grant-exchange-boundary`: When does an award cease to be a grant and become procurement or exchange contract?
- `candidate.commerce-value-finance.unresolved_boundary.ledger-family-ratification`: Should Ledger be one family or a split algebra plus accounting application?
- `candidate.commerce-value-finance.unresolved_boundary.management-reporting-placement`: Does management reporting deserve a composition identity in the registry?
- `candidate.commerce-value-finance.unresolved_boundary.position-horizontal-scope`: Can Position survive as a horizontal qualified view across securities, treasury, risk and physical resources?
- `candidate.commerce-value-finance.unresolved_boundary.reconciliation-horizontal-family`: Should reconciliation be a horizontal semantic family or remain owner-local capabilities?
- `candidate.commerce-value-finance.unresolved_boundary.royalty-commission-common-family`: Are royalty and commission one reusable variable-consideration family or only adjacent verticals?
