
# Target Compilation Orchestration

**Coordinate:** `SAN-COMPILER-TARGET-COMPILATION-ORCHESTRATION`  
**CMP coordinate:** `CMP-009`  
**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

This Edition 2 context preserves the Edition 1 scope. Every type row now resolves to one field-complete owner definition or an explicit owner import. Every operation, law, contract, refusal and proof obligation has one owner coordinate. No implementation status is inferred from JSON presence.
