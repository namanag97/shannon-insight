
mod common;

use common::*;
use san_composition_reference::*;

#[test]
fn reference_mixed_vertical_reaches_boot_report() {
    let verifier = CompilerVerifier::new(verifier_id("verifier.cross-registry.reference"));
    let lock = package_lock();

    let contribution_pairs = minimal_contributions(&lock);
    assert_eq!(contribution_pairs.len(), 4);
    for (envelope, projection) in &contribution_pairs {
        let proof = verifier
            .admit_contribution(envelope, projection, &lock, WorkBudget::new(64))
            .expect("reference contribution must admit");
        assert_eq!(proof.contribution_occurrence(), &envelope.occurrence);
        assert!(!proof.admitted_facets().is_empty());
    }

    let supplier_rows = complete_supplier_inventory(&lock);
    let supplier_closure = verifier
        .close_supplier_inventory(
            &lock,
            &supplier_rows,
            WorkBudget::new((lock.selected_releases.len() * ALL_SUPPLIER_ROLE_NAMES.len()) as u64),
        )
        .expect("complete product must close");
    assert_eq!(supplier_closure.disposition_count(), 232);
    assert_eq!(supplier_closure.expected_disposition_count(), 232);

    let requirements = requirements();
    let offers = offers();
    let decisions = decisions();
    let binding = verifier
        .bind_application(
            &lock,
            &supplier_closure,
            &requirements,
            &offers,
            &decisions,
            WorkBudget::new(4),
        )
        .expect("independent offers and decisions must bind");
    assert_eq!(binding.decisions().len(), 2);

    let obligations = obligations();
    let obligation_closure = verifier
        .close_obligations(
            &lock,
            &binding,
            &obligations,
            RuleEdition::parse("rule-edition-1").expect("rule edition"),
            SchemaEdition::parse("schema-edition-1").expect("schema edition"),
            WorkBudget::new(5),
        )
        .expect("non-empty discharged fixed point must close");
    assert_eq!(obligation_closure.obligations().len(), 3);
    assert_eq!(obligation_closure.fixed_point_rounds(), 3);

    let (nodes, edges) = graph();
    let csag = verifier
        .admit_csag(
            &lock,
            &binding,
            &obligation_closure,
            &nodes,
            &edges,
            WorkBudget::new(15),
        )
        .expect("typed non-empty graph must admit");
    assert_eq!(csag.nodes().len(), 5);
    assert_eq!(csag.hyperedges().len(), 3);

    let modules = ir_modules();
    let portfolio = verifier
        .seal_ir_portfolio(&csag, &modules)
        .expect("six applicable strata must seal");
    assert_eq!(portfolio.modules().len(), 6);

    let target_descriptor = target(&modules);
    let required_capability_count = target_descriptor.supported_capabilities.len() as u64;
    let negotiation = verifier
        .negotiate_target(
            &portfolio,
            &target_descriptor,
            WorkBudget::new(required_capability_count),
        )
        .expect("capable target must negotiate");
    let legality = verifier.determine_target_legality(&negotiation, &portfolio);
    let lowered = verifier
        .lower_target(
            &legality,
            &portfolio,
            &target_descriptor,
            WorkBudget::new(6),
        )
        .expect("legal modules must lower");
    let translation = verifier
        .validate_translation(
            &lowered,
            &target_descriptor,
            &target_descriptor.translation_validator,
            WorkBudget::new(6),
        )
        .expect("independent validator must cover every artifact");
    let target_compilation = verifier.close_target_compilation(
        &target_descriptor,
        &negotiation,
        &legality,
        &lowered,
        &translation,
    );

    let implementations = runtime_implementations(&modules);
    let execution = verifier
        .bind_execution(
            &target_compilation,
            &portfolio,
            &implementations,
            WorkBudget::new(36),
        )
        .expect("all portable runtime obligations must bind");
    assert_eq!(execution.implementations().len(), 6);

    let closure = verifier
        .close_application(
            &lock,
            &supplier_closure,
            &binding,
            &obligation_closure,
            &csag,
            &portfolio,
            &target_compilation,
            &execution,
            &[],
            toolchain("toolchain.reference-rust-1"),
        )
        .expect("complete portable closure must seal");

    let dependencies = replay_dependencies(
        &supplier_closure,
        &binding,
        &obligation_closure,
        &csag,
        &portfolio,
        &target_compilation,
        &execution,
        &closure,
    );
    let available = dependency_occurrences(&dependencies);
    let release = verifier
        .package_release(
            occurrence("app-release:customer-risk:1"),
            &lock,
            &closure,
            dependencies,
            vec![verifier.verifier_id().clone(), target_descriptor.translation_validator.clone()],
            toolchain("toolchain.reference-rust-1"),
        )
        .expect("complete replay closure must package");

    let clean_result = commitment("clean-and-incremental-result");
    let replay = verifier
        .reverify_offline(
            &release,
            lock.commitment,
            &available,
            clean_result,
            clean_result,
            WorkBudget::new(8),
        )
        .expect("exact offline dependencies must reverify");
    assert_ne!(replay.commitment(), CanonicalCommitment::from_canonical_bytes(b""));

    let environment = EnvironmentBindingInput {
        environment: EnvironmentId::parse("environment.reference-local")
            .expect("environment identifier"),
        occurrence: occurrence("environment-binding-input:local:1"),
        release_occurrence: release.occurrence().clone(),
        region: "reference-local-region".to_owned(),
        placement: "reference-local-placement".to_owned(),
        endpoint_references: vec!["endpoint-reference:local".to_owned()],
        credential_references: vec!["credential-reference:local".to_owned()],
        capacity_evidence: occurrence("capacity-evidence:local:1"),
    };
    let environment_binding = verifier
        .bind_environment(&release, &environment)
        .expect("environment binds only after release");
    let deployment_plan = verifier
        .plan_deployment(
            occurrence("deployment-plan:customer-risk:1"),
            &environment_binding,
            vec![
                contract("deployment-step:admit:v1"),
                contract("deployment-step:provision:v1"),
                contract("deployment-step:install:v1"),
                contract("deployment-step:start:v1"),
                contract("deployment-step:verify:v1"),
            ],
            WorkBudget::new(5),
        )
        .expect("bounded deployment plan must construct");
    let boot_input = verifier.prepare_boot(
        occurrence("boot-input:customer-risk:1"),
        &deployment_plan,
        &release,
    );
    let report = verifier.record_boot(
        occurrence("boot-report:customer-risk:1"),
        &boot_input,
        occurrence("runtime-evidence:reference-boot:1"),
        BootOutcome::Booted,
    );
    assert_eq!(report.outcome(), &BootOutcome::Booted);
}
