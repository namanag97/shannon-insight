# Executive architecture decision

## Decision

SAN shall use a **heterogeneous governed-unit registry**, not a flat semantic-library inventory. Edition 1 separates stable identity, owner authority, unit kind, source posture, qualification disposition, implementation mapping and fifteen completion axes. It derives five graph views because compile prerequisites, reciprocal semantic collaboration, compilation artifacts, runtime/provider closure and domain context mapping obey different laws.

The registry has four logical layers:

1. **Authority and source ledger**: immutable evidence inventory, digests, trust posture and supersession.
2. **Candidate intake and adjudication**: every candidate receives an explicit accept, merge, split, rename, defer, reject or retire disposition.
3. **Canonical governed records**: stable identities with one owner, typed capabilities, dependencies, seams, compiler disposition, evidence and gaps.
4. **Regenerable projections**: graph, coverage, completeness, query and implementation-order views.

This structure supports thousands of records by namespace partitioning and exact-base-digest patches without turning every enterprise noun into a crate-shaped shrine.

## Governing boundary decisions

- The attached Constitution distinguishes semantic ownership, compiler transformations, portable representation, runtime physics, resource guarantees, provider implementations, chassis assembly, products and proof evidence. Edition 1 preserves these as different kinds.
- A sovereign semantic unit must survive the independent-question, vocabulary, laws, authority, lifecycle, failure-taxonomy and named-consumer tests. A noun list fails.
- A bounded context is a context-map hypothesis until its model and owner boundary are ratified. It is not automatically a library, package, service or crate.
- Portable intermediate representation owns target-neutral representation and legality. A target compiler owns concrete lowering and preservation evidence. Assurance judges evidence and is neither.
- Resource contracts own provider-neutral guarantees. Provider records own implementations and conformance evidence. Chassis owns assembly and boot order. Runtime mechanisms own controlled execution physics.
- Human Work and User Interface candidates are retained only where a residual independent semantic question survives overlap with Party, Role, Work, Process, Rule, Decision, Obligation and domain-command ownership.
- Proof verticals are governed falsification evidence and never semantic libraries.

## Count adjudication

There is no single meaningful SAN “library count.” Edition 1 exposes explicit projections and preserves incompatible historical totals as conflicts.

- Canonical governed records in this package: **269**
- Semantic-library projection: **143**
- Proof verticals: **11**
- Domain hierarchy: **20 domains, 60 subdomains, 129 bounded-context hypotheses**
- Hard dependency graph: **269 nodes, 697 edges, acyclic**
- Source inventory: **39 direct files and 8 nested archives**

### Records by governed-unit kind

| Governed-unit kind | Count |
| --- | --- |
| application_chassis | 1 |
| compiler_stage | 26 |
| composition | 7 |
| constitutional_contract | 13 |
| domain_ontology_metamodel | 3 |
| foundation_algebra | 18 |
| governed_data_semantics | 24 |
| human_work_semantics | 4 |
| ontology_artifact_kind | 3 |
| operator_or_tenant_product | 8 |
| owner_local_module | 7 |
| portable_ir_dialect | 11 |
| profile | 18 |
| proof_vertical | 11 |
| provider_implementation | 11 |
| publication | 2 |
| resource_contract | 2 |
| runtime_mechanism | 3 |
| semantic_family | 87 |
| user_interface_semantics | 10 |

### Records by registry posture

| Registry posture | Count |
| --- | --- |
| CANDIDATE_BOUNDARY_MODEL | 13 |
| CANDIDATE_NOT_RATIFIED | 105 |
| CANDIDATE_NOT_SELECTED | 8 |
| CURRENT_REVIEW_CANDIDATE_NOT_RATIFIED | 12 |
| DEFERRED_IMPLEMENTATION_CANDIDATE | 11 |
| DEFERRED_PRODUCT_CANDIDATE | 8 |
| PROPOSED_VARIANT_NOT_SELECTED | 14 |
| QUALIFICATION_CANDIDATE_NOT_ADMITTED | 33 |
| QUALIFIED_CANDIDATE_NOT_ADMITTED | 34 |
| REQUIRED_NOT_EXECUTED | 9 |
| SELECTED_NOT_RATIFIED | 13 |
| SELECTED_SOURCE_NOT_RATIFIED | 9 |

### Every count conflict

| ID | Subject | Disposition |
| --- | --- | --- |
| COUNT-001 | Global registry health and intended active count | REJECT_CANONICAL_TOTAL |
| COUNT-002 | Semantic coordinates | KEEP_SEPARATE_PROJECTIONS |
| COUNT-003 | Current mixed master registry | HETEROGENEOUS_INTAKE_NOT_LIBRARY_COUNT |
| COUNT-004 | Compiler stages | EXTERNAL_A_B_DECISION_REQUIRED |
| COUNT-005 | Portable targets | 3_SELECTED_SOURCES_11_CANDIDATE_DIALECTS_ASSURANCE_MOVED |
| COUNT-006 | Runtime mechanisms | 3_SELECTED_SOURCES_BROADER_TAXONOMIES_DEFERRED |
| COUNT-007 | Resource contracts | 2_SELECTED_SOURCES_BROADER_GUARANTEE_TAXONOMIES_DEFERRED |
| COUNT-008 | Application chassis | 1_SELECTED_SOURCE_PARTS_REQUIRE_MODULE_RECIPE_TEST |
| COUNT-009 | Governed Data | NON_ADDITIVE_LEVELS_24_SOVEREIGN_QUALIFICATION_10_RECLASSIFIED |
| COUNT-010 | Enterprise Domain Ontology | PRESERVE_HIERARCHY_AND_ARTIFACT_KIND |
| COUNT-011 | Human Work and Experience | 4_RESIDUAL_HUMAN_WORK_10_UI_QUALIFICATION_CANDIDATES_OTHER_ITEMS_RECLASSIFIED |
| COUNT-012 | Providers | KEEP_IMPLEMENTATIONS_AND_CAPABILITY_AXES_SEPARATE |
| COUNT-013 | Proof verticals | GOVERNED_BUT_NEVER_LIBRARY_COUNT |
| COUNT-014 | Registry records versus crates | INDEPENDENT_CARDINALITIES |
| COUNT-015 | Ontology identity | METAMODEL_GOVERNED_ARTIFACTS_NOT_AUTOMATIC_LIBRARIES |
| COUNT-016 | Hard dependencies versus reciprocal seams | SEPARATE_GRAPH_VIEWS |
| COUNT-017 | Status COMPLETE | REPLACE_WITH_15_INDEPENDENT_AXES |

Full reasons and competing claims are machine-readable in `CONFLICT-ADJUDICATION-LEDGER.json`.

## Compiler decision

Edition 1 does **not** select among the current and candidate compiler pipelines. The 12-stage current registry and 14-stage candidate proposal disagree about Stage-0 authority, parse/admission, family closure, application binding, obligation closure, final ApplicationClosure, target/runtime finality, release sealing, migration and environment binding. The proposal is represented as a variant so that evidence is not lost, but all twenty-five A/B dependencies remain external blocking decisions.

## What this edition proves

It proves that the delivered archive was inventoried with matching input digest; the generated registry is closed-schema valid; identities, aliases, owners and owned capabilities are unique; all hard references resolve; the hard graph is acyclic; counts and derived views are reproducible; and representative invalid mutations are rejected.

## What this edition does not prove

It does not prove a signed Stage-0 authority, owner ratification, compiler execution, semantic closure, target lowering, runtime/provider closure, AppRelease sealing, deployment, boot, provider conformance, universal industry coverage, implementation-package mapping or certification. Those absences are explicit in `RESEARCH-GAP-LEDGER.json` and `OPEN-DECISIONS.md` rather than being hidden behind the customary reassuring boolean.
