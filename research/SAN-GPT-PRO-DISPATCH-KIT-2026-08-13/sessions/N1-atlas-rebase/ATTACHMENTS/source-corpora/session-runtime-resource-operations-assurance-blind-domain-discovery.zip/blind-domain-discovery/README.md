# Blind Domain Discovery Package

## Entry points

- [`manifest.json`](manifest.json) — package identity, collection inventory, counts, and method.
- [`VALIDATION.json`](VALIDATION.json) — mechanical validation results.
- [`CHECKSUMS.txt`](CHECKSUMS.txt) — SHA-256 checksums for package files.
- [`coverage/coverage_matrix.json`](coverage/coverage_matrix.json) — topic, boundary-question, and adversarial-scenario coverage.
- [`coverage/maturity_report.json`](coverage/maturity_report.json) — research maturity and highest-impact open boundaries.
- [`vocabularies/evidence_sources.json`](vocabularies/evidence_sources.json) — primary-authority evidence catalog.
- [`vocabularies/controlled_vocabularies.json`](vocabularies/controlled_vocabularies.json) — controlled values used by validation.

## Boundary navigation

- Candidate bounded contexts: **26**
- Split proposals: **6**
- Merge proposals: **3**
- Rejected false boundaries: **12**
- Typed relations: **138**
- Context relationships: **60**

## JSONL collections

| Path | Records | Schema |
|---|---:|---|
| [`boundary_analysis/evaluations.jsonl`](boundary_analysis/evaluations.jsonl) | 86 | [`schemas/boundary-evaluation.schema.json`](schemas/boundary-evaluation.schema.json) |
| [`boundary_analysis/merge_proposals.jsonl`](boundary_analysis/merge_proposals.jsonl) | 3 | [`schemas/boundary-analysis-record.schema.json`](schemas/boundary-analysis-record.schema.json) |
| [`boundary_analysis/rejected_boundaries.jsonl`](boundary_analysis/rejected_boundaries.jsonl) | 12 | [`schemas/boundary-analysis-record.schema.json`](schemas/boundary-analysis-record.schema.json) |
| [`boundary_analysis/split_proposals.jsonl`](boundary_analysis/split_proposals.jsonl) | 6 | [`schemas/boundary-analysis-record.schema.json`](schemas/boundary-analysis-record.schema.json) |
| [`boundary_analysis/unresolved_ownership.jsonl`](boundary_analysis/unresolved_ownership.jsonl) | 18 | [`schemas/boundary-analysis-record.schema.json`](schemas/boundary-analysis-record.schema.json) |
| [`corpus/artifacts.jsonl`](corpus/artifacts.jsonl) | 110 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/bounded_contexts.jsonl`](corpus/bounded_contexts.jsonl) | 86 | [`schemas/bounded-context.schema.json`](schemas/bounded-context.schema.json) |
| [`corpus/capabilities.jsonl`](corpus/capabilities.jsonl) | 81 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/claims.jsonl`](corpus/claims.jsonl) | 26 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/classification_axes.jsonl`](corpus/classification_axes.jsonl) | 20 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/commands.jsonl`](corpus/commands.jsonl) | 179 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/compositions.jsonl`](corpus/compositions.jsonl) | 8 | [`schemas/composition.schema.json`](schemas/composition.schema.json) |
| [`corpus/concepts.jsonl`](corpus/concepts.jsonl) | 181 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/context_relationships.jsonl`](corpus/context_relationships.jsonl) | 60 | [`schemas/context-relationship.schema.json`](schemas/context-relationship.schema.json) |
| [`corpus/contextual_meanings.jsonl`](corpus/contextual_meanings.jsonl) | 111 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/contracts.jsonl`](corpus/contracts.jsonl) | 26 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/coverage_areas.jsonl`](corpus/coverage_areas.jsonl) | 16 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/entities.jsonl`](corpus/entities.jsonl) | 109 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/events.jsonl`](corpus/events.jsonl) | 154 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/external_mappings.jsonl`](corpus/external_mappings.jsonl) | 15 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/failures.jsonl`](corpus/failures.jsonl) | 52 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/identities.jsonl`](corpus/identities.jsonl) | 109 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/invariants.jsonl`](corpus/invariants.jsonl) | 52 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/laws.jsonl`](corpus/laws.jsonl) | 142 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/lifecycles.jsonl`](corpus/lifecycles.jsonl) | 26 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/operators.jsonl`](corpus/operators.jsonl) | 61 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/policies.jsonl`](corpus/policies.jsonl) | 52 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/profiles.jsonl`](corpus/profiles.jsonl) | 12 | [`schemas/profile.schema.json`](schemas/profile.schema.json) |
| [`corpus/queries.jsonl`](corpus/queries.jsonl) | 78 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/refusals.jsonl`](corpus/refusals.jsonl) | 108 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/relations.jsonl`](corpus/relations.jsonl) | 138 | [`schemas/relation.schema.json`](schemas/relation.schema.json) |
| [`corpus/states.jsonl`](corpus/states.jsonl) | 223 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/value_objects.jsonl`](corpus/value_objects.jsonl) | 140 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`corpus/vocabulary.jsonl`](corpus/vocabulary.jsonl) | 181 | [`schemas/record.schema.json`](schemas/record.schema.json) |
| [`issues/conflicts.jsonl`](issues/conflicts.jsonl) | 20 | [`schemas/issue.schema.json`](schemas/issue.schema.json) |
| [`issues/gaps.jsonl`](issues/gaps.jsonl) | 20 | [`schemas/issue.schema.json`](schemas/issue.schema.json) |
| [`issues/unresolved_questions.jsonl`](issues/unresolved_questions.jsonl) | 53 | [`schemas/issue.schema.json`](schemas/issue.schema.json) |
| [`scenarios/boundary_examples.jsonl`](scenarios/boundary_examples.jsonl) | 24 | [`schemas/scenario.schema.json`](schemas/scenario.schema.json) |
| [`scenarios/competency_questions.jsonl`](scenarios/competency_questions.jsonl) | 104 | [`schemas/competency-question.schema.json`](schemas/competency-question.schema.json) |
| [`scenarios/cross_domain_examples.jsonl`](scenarios/cross_domain_examples.jsonl) | 20 | [`schemas/scenario.schema.json`](schemas/scenario.schema.json) |
| [`scenarios/negative_examples.jsonl`](scenarios/negative_examples.jsonl) | 52 | [`schemas/scenario.schema.json`](schemas/scenario.schema.json) |
| [`scenarios/positive_examples.jsonl`](scenarios/positive_examples.jsonl) | 52 | [`schemas/scenario.schema.json`](schemas/scenario.schema.json) |

## Schemas

- [`schemas/boundary-analysis-record.schema.json`](schemas/boundary-analysis-record.schema.json)
- [`schemas/boundary-evaluation.schema.json`](schemas/boundary-evaluation.schema.json)
- [`schemas/bounded-context.schema.json`](schemas/bounded-context.schema.json)
- [`schemas/common.schema.json`](schemas/common.schema.json)
- [`schemas/competency-question.schema.json`](schemas/competency-question.schema.json)
- [`schemas/composition.schema.json`](schemas/composition.schema.json)
- [`schemas/context-relationship.schema.json`](schemas/context-relationship.schema.json)
- [`schemas/controlled-vocabularies.schema.json`](schemas/controlled-vocabularies.schema.json)
- [`schemas/coverage-matrix.schema.json`](schemas/coverage-matrix.schema.json)
- [`schemas/evidence-sources.schema.json`](schemas/evidence-sources.schema.json)
- [`schemas/issue.schema.json`](schemas/issue.schema.json)
- [`schemas/manifest.schema.json`](schemas/manifest.schema.json)
- [`schemas/maturity-report.schema.json`](schemas/maturity-report.schema.json)
- [`schemas/profile.schema.json`](schemas/profile.schema.json)
- [`schemas/record.schema.json`](schemas/record.schema.json)
- [`schemas/relation.schema.json`](schemas/relation.schema.json)
- [`schemas/scenario.schema.json`](schemas/scenario.schema.json)
- [`schemas/term-index.schema.json`](schemas/term-index.schema.json)
- [`schemas/validation-report.schema.json`](schemas/validation-report.schema.json)

## Canonicality

- JSONL records are ordered lexicographically by `id`.
- JSON object keys are ordered lexicographically.
- The ZIP uses lexicographic entry order and a fixed timestamp.
- Markdown is navigation only; JSON and JSONL are canonical.
