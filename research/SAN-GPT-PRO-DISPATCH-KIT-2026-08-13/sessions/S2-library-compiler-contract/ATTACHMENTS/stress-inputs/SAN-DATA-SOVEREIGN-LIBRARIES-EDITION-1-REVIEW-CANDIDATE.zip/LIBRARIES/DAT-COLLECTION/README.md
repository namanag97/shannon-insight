# DAT-COLLECTION · Data Collection Semantics

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

What makes a provider-neutral collection of data members one collection, independent of one cut, representation, service, catalog entry, or storage realization?

## Boundary

Owns:
- provider-neutral collection identity
- membership rule and qualification
- duplicate and ordering posture
- collection boundedness
- membership assessment

Explicitly excludes:
- data cut
- source snapshot
- distribution
- data service
- table
- file
- catalog record
- Schema meaning
- Identity meaning
- provider storage

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- No first-batch Data Sovereign Library dependency.

## Reciprocal semantic seams

- None in this edition.

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
