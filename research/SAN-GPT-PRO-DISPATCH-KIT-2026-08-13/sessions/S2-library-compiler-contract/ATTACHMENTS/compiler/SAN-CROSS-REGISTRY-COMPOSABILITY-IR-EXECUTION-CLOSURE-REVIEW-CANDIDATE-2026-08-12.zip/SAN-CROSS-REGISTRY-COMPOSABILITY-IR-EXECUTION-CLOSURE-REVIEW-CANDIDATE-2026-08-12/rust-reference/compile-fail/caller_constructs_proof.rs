
use san_composition_reference::{AdmissionProof, CanonicalCommitment};

fn main() {
    let _forged = AdmissionProof {
        contribution_occurrence: panic!("caller cannot supply an occurrence field"),
        contribution_commitment: CanonicalCommitment::from_canonical_bytes(b"forged"),
        package_lock_commitment: CanonicalCommitment::from_canonical_bytes(b"forged-lock"),
        admitted_facets: Vec::new(),
        work_receipt: panic!("caller cannot supply a receipt field"),
        seal: panic!("caller cannot supply the private verifier seal"),
    };
}
