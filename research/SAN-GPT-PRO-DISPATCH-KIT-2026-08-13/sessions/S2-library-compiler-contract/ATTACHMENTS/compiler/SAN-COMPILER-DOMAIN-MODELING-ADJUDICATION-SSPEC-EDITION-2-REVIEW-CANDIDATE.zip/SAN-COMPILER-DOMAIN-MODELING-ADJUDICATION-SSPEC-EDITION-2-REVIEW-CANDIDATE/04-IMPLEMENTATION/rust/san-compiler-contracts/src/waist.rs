//! Generic constitutional contract waist shared by the sixteen retained contexts.
//!
//! This module owns representation plumbing, not SEM/ONTOLOGY/DATA/UI/TGT/RUN meaning.

use std::collections::BTreeMap;
use std::fmt;
use std::num::NonZeroU32;

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum IdentityRefusal {
    Empty,
    TooLong { maximum: usize, actual: usize },
    InvalidCharacter { index: usize, character: char },
    LeadingOrTrailingSeparator,
    NonPositiveEdition,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct StableId(String);

impl StableId {
    pub fn admit(value: impl Into<String>) -> Result<Self, IdentityRefusal> {
        let value = value.into();
        if value.is_empty() {
            return Err(IdentityRefusal::Empty);
        }
        if value.len() > 160 {
            return Err(IdentityRefusal::TooLong { maximum: 160, actual: value.len() });
        }
        if matches!(value.chars().next(), Some('.' | '-' | ':'))
            || matches!(value.chars().next_back(), Some('.' | '-' | ':'))
        {
            return Err(IdentityRefusal::LeadingOrTrailingSeparator);
        }
        for (index, character) in value.chars().enumerate() {
            if !(character.is_ascii_lowercase()
                || character.is_ascii_digit()
                || matches!(character, '.' | '-' | ':' | '/'))
            {
                return Err(IdentityRefusal::InvalidCharacter { index, character });
            }
        }
        Ok(Self(value))
    }

    #[must_use]
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for StableId {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(&self.0)
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct Edition(NonZeroU32);

impl Edition {
    pub fn admit(value: u32) -> Result<Self, IdentityRefusal> {
        NonZeroU32::new(value).map(Self).ok_or(IdentityRefusal::NonPositiveEdition)
    }

    #[must_use]
    pub const fn get(self) -> u32 {
        self.0.get()
    }
}

macro_rules! nominal_id {
    ($name:ident) => {
        #[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
        pub struct $name(StableId);

        impl $name {
            pub fn admit(value: impl Into<String>) -> Result<Self, IdentityRefusal> {
                StableId::admit(value).map(Self)
            }


            #[must_use]
            pub fn stable(&self) -> &StableId {
                &self.0
            }
        }
    };
}

nominal_id!(OccurrenceId);
nominal_id!(AuthorityRef);
nominal_id!(PolicyRef);
nominal_id!(ContractRef);
nominal_id!(PackageLockRef);
nominal_id!(ProofRef);
nominal_id!(SupplierRef);
nominal_id!(StageId);
nominal_id!(FieldPath);
nominal_id!(SeparationDomain);

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct SubjectKey {
    pub(crate) application: StableId,
    pub(crate) release: OccurrenceId,
    pub(crate) package_lock: PackageLockRef,
    pub(crate) stage: StageId,
    pub(crate) schema: Edition,
}

impl SubjectKey {
    #[must_use]
    pub fn application(&self) -> &StableId { &self.application }
    #[must_use]
    pub fn release(&self) -> &OccurrenceId { &self.release }
    #[must_use]
    pub fn package_lock(&self) -> &PackageLockRef { &self.package_lock }
    #[must_use]
    pub fn stage(&self) -> &StageId { &self.stage }
    #[must_use]
    pub const fn schema(&self) -> Edition { self.schema }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CarrierScalar {
    Text(String),
    Integer(i128),
    Boolean(bool),
    Identity(String),
    Decimal { coefficient: i128, scale: u32 },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ScalarValue {
    Text(String),
    Integer(i128),
    Boolean(bool),
    Identity(StableId),
    Decimal { coefficient: i128, scale: u32 },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ArtifactRefCarrier {
    pub identity: String,
    pub edition: u32,
    pub occurrence: String,
    pub digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub struct ArtifactRef {
    identity: StableId,
    edition: Edition,
    occurrence: OccurrenceId,
    digest: [u8; 32],
}

impl ArtifactRef {
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub const fn edition(&self) -> Edition { self.edition }
    #[must_use]
    pub fn occurrence(&self) -> &OccurrenceId { &self.occurrence }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
}

pub fn admit_artifact_ref(carrier: ArtifactRefCarrier) -> Result<ArtifactRef, IdentityRefusal> {
    Ok(ArtifactRef {
        identity: StableId::admit(carrier.identity)?,
        edition: Edition::admit(carrier.edition)?,
        occurrence: OccurrenceId::admit(carrier.occurrence)?,
        digest: carrier.digest,
    })
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DigestAlgorithm {
    Sha256,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DigestClaim {
    algorithm: DigestAlgorithm,
    subject: SubjectKey,
    separation_domain: SeparationDomain,
    value: [u8; 32],
}

impl DigestClaim {
    pub(crate) fn sha256(
        subject: SubjectKey,
        separation_domain: SeparationDomain,
        value: [u8; 32],
    ) -> Self {
        Self { algorithm: DigestAlgorithm::Sha256, subject, separation_domain, value }
    }

    #[must_use]
    pub fn algorithm(&self) -> &DigestAlgorithm { &self.algorithm }
    #[must_use]
    pub fn subject(&self) -> &SubjectKey { &self.subject }
    #[must_use]
    pub fn separation_domain(&self) -> &SeparationDomain { &self.separation_domain }
    #[must_use]
    pub const fn value(&self) -> &[u8; 32] { &self.value }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Provenance {
    source: ArtifactRef,
    owner: AuthorityRef,
    derivation: Vec<ArtifactRef>,
}

impl Provenance {
    pub(crate) fn verified(source: ArtifactRef, owner: AuthorityRef, derivation: Vec<ArtifactRef>) -> Self {
        Self { source, owner, derivation }
    }
    #[must_use]
    pub fn source(&self) -> &ArtifactRef { &self.source }
    #[must_use]
    pub fn owner(&self) -> &AuthorityRef { &self.owner }
    #[must_use]
    pub fn derivation(&self) -> &[ArtifactRef] { &self.derivation }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct WorkBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

impl WorkBudget {
    #[must_use]
    pub const fn fixture() -> Self {
        Self {
            max_input_items: 4096,
            max_input_bytes: 4 * 1024 * 1024,
            max_work_units: 8 * 1024 * 1024,
            max_allocation_bytes: 8 * 1024 * 1024,
            max_output_bytes: 8 * 1024 * 1024,
            max_diagnostics: 1024,
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum BudgetDimension {
    InputItems,
    InputBytes,
    WorkUnits,
    AllocationBytes,
    OutputBytes,
    Diagnostics,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Exhaustion {
    pub stage: StageId,
    pub dimension: BudgetDimension,
    pub required: u64,
    pub allowed: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkReceipt {
    pub(crate) stage: StageId,
    pub(crate) input_items: u64,
    pub(crate) input_bytes: u64,
    pub(crate) work_units: u64,
    pub(crate) allocation_bytes: u64,
    pub(crate) output_bytes: u64,
    pub(crate) diagnostics: u64,
}

impl WorkReceipt {
    #[must_use]
    pub fn stage(&self) -> &StageId { &self.stage }
    #[must_use]
    pub const fn input_items(&self) -> u64 { self.input_items }
    #[must_use]
    pub const fn input_bytes(&self) -> u64 { self.input_bytes }
    #[must_use]
    pub const fn work_units(&self) -> u64 { self.work_units }
    #[must_use]
    pub const fn allocation_bytes(&self) -> u64 { self.allocation_bytes }
    #[must_use]
    pub const fn output_bytes(&self) -> u64 { self.output_bytes }
    #[must_use]
    pub const fn diagnostics(&self) -> u64 { self.diagnostics }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum MissingInputKind {
    Authority,
    Decision,
    Offer,
    Verifier,
    Provider,
    Evidence,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompilerNeedsInput {
    pub stage: StageId,
    pub kind: MissingInputKind,
    pub subjects: Vec<StableId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TotalOutcome<T, R, N = CompilerNeedsInput> {
    Produced(T),
    Refused(R),
    Exhausted(Exhaustion),
    NeedsInput(N),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NonEmpty<T> {
    head: T,
    tail: Vec<T>,
}

impl<T> NonEmpty<T> {
    #[must_use]
    pub fn from_head_tail(head: T, tail: Vec<T>) -> Self { Self { head, tail } }
    #[must_use]
    pub fn head(&self) -> &T { &self.head }
    #[must_use]
    pub fn tail(&self) -> &[T] { &self.tail }
    pub fn iter(&self) -> impl Iterator<Item = &T> { std::iter::once(&self.head).chain(self.tail.iter()) }
    #[must_use]
    pub fn len(&self) -> usize { 1 + self.tail.len() }
    #[must_use]
    pub const fn is_empty(&self) -> bool { false }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub enum RegistryKind {
    Semantic,
    Ontology,
    Data,
    Ui,
    Target,
    Runtime,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum AbsenceSemantics {
    Required,
    OptionalExplicit,
    InapplicableWithReason,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum Cardinality {
    ExactlyOne,
    ZeroOrOne,
    OneOrMore,
    Exact(NonZeroU32),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CompatibilityClass {
    Identical,
    BackwardCompatible,
    ForwardCompatible,
    Breaking,
    Unclassified,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RefusalReason {
    Missing,
    Malformed,
    Duplicate,
    Unauthorized,
    Incompatible,
    Drift,
    Overflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CanonicalEntry {
    pub key: StableId,
    pub value: ScalarValue,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticMember {
    pub identity: StableId,
    pub owner: AuthorityRef,
    pub kind: StableId,
    pub values: BTreeMap<StableId, ScalarValue>,
    pub source: ArtifactRef,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
pub struct SourceSpan {
    pub start: u64,
    pub end: u64,
    pub line: u64,
    pub column: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GraphNode {
    pub identity: StableId,
    pub owner: AuthorityRef,
    pub kind: StableId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GraphEdge {
    pub identity: StableId,
    pub source: StableId,
    pub target: StableId,
    pub kind: StableId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PlanStep {
    pub identity: StableId,
    pub stage: StageId,
    pub inputs: Vec<StableId>,
    pub outputs: Vec<StableId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExplanationStep {
    pub law: StableId,
    pub inputs: Vec<ArtifactRef>,
    pub output: ArtifactRef,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompilerContractRefusal {
    pub subject: StableId,
    pub reason: RefusalReason,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DisclosurePolicyRef {
    pub policy: PolicyRef,
    pub maximum_items: u64,
    pub maximum_text_bytes: u64,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AuthorityPolicySet {
    pub authorities: BTreeMap<StableId, AuthorityRef>,
    pub package_lock: PackageLockRef,
    pub commitment: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DigestContext {
    pub subject: SubjectKey,
    pub canonical_domain: SeparationDomain,
    pub digest_domain: SeparationDomain,
    pub budget: WorkBudget,
}
