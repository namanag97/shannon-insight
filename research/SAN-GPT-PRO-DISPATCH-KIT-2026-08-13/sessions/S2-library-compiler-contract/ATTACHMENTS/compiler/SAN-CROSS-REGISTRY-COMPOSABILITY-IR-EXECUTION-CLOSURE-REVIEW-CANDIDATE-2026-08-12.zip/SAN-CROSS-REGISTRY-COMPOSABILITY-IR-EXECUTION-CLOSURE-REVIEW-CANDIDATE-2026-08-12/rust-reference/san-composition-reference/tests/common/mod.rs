
use san_composition_reference::*;
use std::collections::{BTreeSet, BTreeMap};

pub fn coordinate(value: &str) -> StableCoordinate {
    StableCoordinate::parse(value).expect("test coordinate")
}

pub fn occurrence(value: &str) -> OccurrenceId {
    OccurrenceId::parse(value).expect("test occurrence")
}

pub fn edition(value: &str) -> SemanticEdition {
    SemanticEdition::parse(value).expect("test edition")
}

pub fn owner(value: &str) -> SovereignOwner {
    SovereignOwner::parse(value).expect("test owner")
}

pub fn artifact_kind(value: &str) -> ArtifactKindId {
    ArtifactKindId::parse(value).expect("test artifact kind")
}

pub fn authority(value: &str) -> SourceAuthorityId {
    SourceAuthorityId::parse(value).expect("test source authority")
}

pub fn package_lock_id(value: &str) -> PackageLockId {
    PackageLockId::parse(value).expect("test package lock")
}

pub fn verifier_id(value: &str) -> VerifierId {
    VerifierId::parse(value).expect("test verifier")
}

pub fn contract(value: &str) -> ContractId {
    ContractId::parse(value).expect("test contract")
}

pub fn requirement_id(value: &str) -> RequirementId {
    RequirementId::parse(value).expect("test requirement")
}

pub fn offer_id(value: &str) -> OfferId {
    OfferId::parse(value).expect("test offer")
}

pub fn decision_id(value: &str) -> DecisionId {
    DecisionId::parse(value).expect("test decision")
}

pub fn obligation_id(value: &str) -> ObligationId {
    ObligationId::parse(value).expect("test obligation")
}

pub fn capability(value: &str) -> CapabilityId {
    CapabilityId::parse(value).expect("test capability")
}

pub fn runtime_requirement(value: &str) -> RuntimeRequirementId {
    RuntimeRequirementId::parse(value).expect("test runtime requirement")
}

pub fn target_id(value: &str) -> TargetId {
    TargetId::parse(value).expect("test target")
}

pub fn implementation_id(value: &str) -> ImplementationId {
    ImplementationId::parse(value).expect("test implementation")
}

pub fn toolchain(value: &str) -> ToolchainId {
    ToolchainId::parse(value).expect("test toolchain")
}

pub fn commitment(label: &str) -> CanonicalCommitment {
    CanonicalCommitment::from_canonical_bytes(label.as_bytes())
}

pub fn package_lock() -> PackageLock {
    let releases = vec![
        ReleaseOccurrence {
            coordinate: coordinate("reference.semantic.customer-risk"),
            edition: edition("edition-1"),
            occurrence: occurrence("release:semantic-risk:1"),
            content_digest: commitment("semantic-risk-release"),
        },
        ReleaseOccurrence {
            coordinate: coordinate("reference.data.customer-risk-view"),
            edition: edition("edition-1"),
            occurrence: occurrence("release:data-risk-view:1"),
            content_digest: commitment("data-risk-view-release"),
        },
        ReleaseOccurrence {
            coordinate: coordinate("reference.domain.customer-account"),
            edition: edition("edition-1"),
            occurrence: occurrence("release:domain-customer-account:1"),
            content_digest: commitment("domain-customer-account-release"),
        },
        ReleaseOccurrence {
            coordinate: coordinate("reference.client.risk-review"),
            edition: edition("edition-1"),
            occurrence: occurrence("release:client-risk-review:1"),
            content_digest: commitment("client-risk-review-release"),
        },
    ];
    let lock_commitment = commit_parts(&[
        releases[0].content_digest.as_bytes(),
        releases[1].content_digest.as_bytes(),
        releases[2].content_digest.as_bytes(),
        releases[3].content_digest.as_bytes(),
    ]);
    PackageLock {
        id: package_lock_id("reference.lock.customer-risk"),
        occurrence: occurrence("package-lock:customer-risk:1"),
        selected_releases: releases,
        commitment: lock_commitment,
    }
}

pub fn complete_supplier_inventory(lock: &PackageLock) -> Vec<SupplierDisposition> {
    let mut rows = Vec::new();
    for release in &lock.selected_releases {
        for role_name in ALL_SUPPLIER_ROLE_NAMES {
            rows.push(SupplierDisposition {
                release_occurrence: release.occurrence.clone(),
                role: SupplierRole::from_registry_name(role_name).expect("registered role"),
                disposition: SupplierDispositionKind::Available {
                    evidence: occurrence(&format!(
                        "evidence:{}:{}",
                        release.occurrence.as_str(),
                        role_name
                    )),
                },
            });
        }
    }
    rows
}

pub fn requirements() -> Vec<RequirementContribution> {
    vec![
        RequirementContribution {
            occurrence: occurrence("requirement-occurrence:risk-data:1"),
            requirement_id: requirement_id("requirement:risk-data"),
            owner: owner("owner.semantic-risk"),
            contract: contract("contract:governed-risk-data:v1"),
            cardinality: Cardinality::new(1, 1).expect("valid cardinality"),
            authority_required: contract("contract:independent-offer-authority:v1"),
        },
        RequirementContribution {
            occurrence: occurrence("requirement-occurrence:risk-result:1"),
            requirement_id: requirement_id("requirement:risk-result"),
            owner: owner("owner.client-risk-review"),
            contract: contract("contract:risk-result:v1"),
            cardinality: Cardinality::new(1, 1).expect("valid cardinality"),
            authority_required: contract("contract:independent-offer-authority:v1"),
        },
    ]
}

pub fn offers() -> Vec<OfferContribution> {
    vec![
        OfferContribution {
            occurrence: occurrence("offer-occurrence:risk-data:1"),
            offer_id: offer_id("offer:risk-data"),
            owner: owner("owner.data-risk"),
            contract: contract("contract:governed-risk-data:v1"),
            offered_for: requirement_id("requirement:risk-data"),
            authority_contract: contract("contract:independent-offer-authority:v1"),
        },
        OfferContribution {
            occurrence: occurrence("offer-occurrence:risk-result:1"),
            offer_id: offer_id("offer:risk-result"),
            owner: owner("owner.semantic-risk"),
            contract: contract("contract:risk-result:v1"),
            offered_for: requirement_id("requirement:risk-result"),
            authority_contract: contract("contract:independent-offer-authority:v1"),
        },
    ]
}

pub fn decisions() -> Vec<SelectionDecision> {
    vec![
        SelectionDecision {
            occurrence: occurrence("decision-occurrence:risk-data:1"),
            decision_id: decision_id("decision:select-risk-data"),
            authority_owner: owner("owner.application-binding"),
            requirement: requirement_id("requirement:risk-data"),
            considered_offers: vec![offer_id("offer:risk-data")],
            selected_offers: vec![offer_id("offer:risk-data")],
            basis_commitment: commitment("exact contract and independent owner"),
        },
        SelectionDecision {
            occurrence: occurrence("decision-occurrence:risk-result:1"),
            decision_id: decision_id("decision:select-risk-result"),
            authority_owner: owner("owner.application-binding"),
            requirement: requirement_id("requirement:risk-result"),
            considered_offers: vec![offer_id("offer:risk-result")],
            selected_offers: vec![offer_id("offer:risk-result")],
            basis_commitment: commitment("exact contract and independent owner"),
        },
    ]
}

pub fn obligations() -> Vec<ObligationContribution> {
    vec![
        ObligationContribution {
            occurrence: occurrence("obligation-occurrence:lineage:1"),
            obligation_id: obligation_id("obligation:lineage"),
            owner: owner("owner.data-risk"),
            seeded_by: decision_id("decision:select-risk-data"),
            depends_on: vec![],
            discharge_contract: contract("contract:lineage-proof:v1"),
            discharge_evidence: Some(occurrence("evidence:lineage:1")),
        },
        ObligationContribution {
            occurrence: occurrence("obligation-occurrence:explanation:1"),
            obligation_id: obligation_id("obligation:explanation"),
            owner: owner("owner.semantic-risk"),
            seeded_by: decision_id("decision:select-risk-result"),
            depends_on: vec![obligation_id("obligation:lineage")],
            discharge_contract: contract("contract:explanation-proof:v1"),
            discharge_evidence: Some(occurrence("evidence:explanation:1")),
        },
        ObligationContribution {
            occurrence: occurrence("obligation-occurrence:accessibility:1"),
            obligation_id: obligation_id("obligation:accessibility"),
            owner: owner("owner.client-risk-review"),
            seeded_by: decision_id("decision:select-risk-result"),
            depends_on: vec![obligation_id("obligation:explanation")],
            discharge_contract: contract("contract:accessibility-proof:v1"),
            discharge_evidence: Some(occurrence("evidence:accessibility:1")),
        },
    ]
}

pub fn graph() -> (Vec<HostileGraphNode>, Vec<HostileHyperedge>) {
    let nodes = vec![
        HostileGraphNode {
            occurrence: occurrence("node:application:customer-risk"),
            kind: GraphNodeKind::ApplicationAnchor,
            owner: owner("owner.application"),
            source_contribution: occurrence("contribution:application:1"),
            semantic_commitment: commitment("application anchor"),
        },
        HostileGraphNode {
            occurrence: occurrence("node:semantic:risk-evaluation"),
            kind: GraphNodeKind::SemanticDeclaration,
            owner: owner("owner.semantic-risk"),
            source_contribution: occurrence("contribution:semantic-risk:1"),
            semantic_commitment: commitment("risk evaluation"),
        },
        HostileGraphNode {
            occurrence: occurrence("node:data:risk-view"),
            kind: GraphNodeKind::GovernedDataSemantic,
            owner: owner("owner.data-risk"),
            source_contribution: occurrence("contribution:data-risk:1"),
            semantic_commitment: commitment("risk view"),
        },
        HostileGraphNode {
            occurrence: occurrence("node:ontology:customer"),
            kind: GraphNodeKind::OntologyConcept,
            owner: owner("owner.domain-customer"),
            source_contribution: occurrence("contribution:domain-customer:1"),
            semantic_commitment: commitment("customer concept"),
        },
        HostileGraphNode {
            occurrence: occurrence("node:interaction:risk-review"),
            kind: GraphNodeKind::InteractionContract,
            owner: owner("owner.client-risk-review"),
            source_contribution: occurrence("contribution:client-risk-review:1"),
            semantic_commitment: commitment("risk review interaction"),
        },
    ];
    let edges = vec![
        HostileHyperedge {
            occurrence: occurrence("edge:bind-risk-data"),
            kind: HyperedgeKind::BindsContract,
            owner: owner("owner.application-binding"),
            endpoints: vec![
                occurrence("node:semantic:risk-evaluation"),
                occurrence("node:data:risk-view"),
                occurrence("node:application:customer-risk"),
            ],
            source_contribution: occurrence("contribution:application-binding:1"),
            semantic_commitment: commitment("bind risk data"),
        },
        HostileHyperedge {
            occurrence: occurrence("edge:correspond-customer"),
            kind: HyperedgeKind::CorrespondsTo,
            owner: owner("owner.domain-customer"),
            endpoints: vec![
                occurrence("node:data:risk-view"),
                occurrence("node:ontology:customer"),
            ],
            source_contribution: occurrence("contribution:domain-customer:1"),
            semantic_commitment: commitment("customer correspondence"),
        },
        HostileHyperedge {
            occurrence: occurrence("edge:realize-risk-review"),
            kind: HyperedgeKind::RealizesWorkIntent,
            owner: owner("owner.client-risk-review"),
            endpoints: vec![
                occurrence("node:semantic:risk-evaluation"),
                occurrence("node:interaction:risk-review"),
                occurrence("node:application:customer-risk"),
            ],
            source_contribution: occurrence("contribution:client-risk-review:1"),
            semantic_commitment: commitment("realize risk review"),
        },
    ];
    (nodes, edges)
}

pub fn ir_modules() -> Vec<PortableIrContribution> {
    let rows = [
        (
            "ir:data-query:1",
            PortableIrKind::GovernedDataAndQuery,
            "owner.data-query-ir",
            "contribution:data-risk:1",
            ["capability.scan", "capability.filter"].as_slice(),
            ["runtime.query"].as_slice(),
        ),
        (
            "ir:behavior-effect:1",
            PortableIrKind::BehaviorAndEffect,
            "owner.behavior-effect-ir",
            "contribution:semantic-risk:1",
            ["capability.pure-computation", "capability.effect-intent"].as_slice(),
            ["runtime.behavior-effects"].as_slice(),
        ),
        (
            "ir:event-protocol:1",
            PortableIrKind::EventAndProtocol,
            "owner.event-protocol-ir",
            "contribution:data-risk:1",
            ["capability.event-identity", "capability.correlation"].as_slice(),
            ["runtime.event-dispatch"].as_slice(),
        ),
        (
            "ir:workflow-process:1",
            PortableIrKind::WorkflowAndProcess,
            "owner.workflow-process-ir",
            "contribution:domain-customer:1",
            ["capability.human-task", "capability.deadline"].as_slice(),
            ["runtime.workflow"].as_slice(),
        ),
        (
            "ir:policy-decision:1",
            PortableIrKind::PolicyAndDecision,
            "owner.policy-decision-ir",
            "contribution:semantic-risk:1",
            ["capability.decision-table", "capability.explanation"].as_slice(),
            ["runtime.policy"].as_slice(),
        ),
        (
            "ir:interaction-presentation-accessibility:1",
            PortableIrKind::InteractionPresentationAndAccessibility,
            "owner.interaction-ir",
            "contribution:client-risk-review:1",
            ["capability.navigation", "capability.accessible-role-state-name"].as_slice(),
            ["runtime.client-interaction"].as_slice(),
        ),
    ];
    rows.into_iter()
        .map(|(occ, kind, semantic_owner, producer, capabilities, runtime)| {
            let required_capabilities: BTreeSet<_> = capabilities
                .iter()
                .map(|value| capability(value))
                .collect();
            let runtime_obligations: BTreeSet<_> = runtime
                .iter()
                .map(|value| runtime_requirement(value))
                .collect();
            PortableIrContribution {
                occurrence: occurrence(occ),
                kind,
                semantic_owner: owner(semantic_owner),
                producer_contribution: occurrence(producer),
                type_system_edition: SchemaEdition::parse("schema-edition-1")
                    .expect("test schema edition"),
                legality_contract: contract("contract:ir-legality:v1"),
                preserved_laws: vec![contract("contract:semantic-preservation:v1")],
                required_capabilities,
                runtime_obligations,
                canonical_commitment: commitment(occ),
            }
        })
        .collect()
}

pub fn target(modules: &[PortableIrContribution]) -> TargetDescriptor {
    let capabilities = modules
        .iter()
        .flat_map(|module| module.required_capabilities.iter().cloned())
        .collect();
    TargetDescriptor {
        target: target_id("target.reference-portable-host"),
        occurrence: occurrence("target:reference-portable-host:1"),
        supported_capabilities: capabilities,
        lowering_implementation: implementation_id("implementation.reference-lowering"),
        translation_validator: verifier_id("verifier.reference-independent-translation"),
    }
}

pub fn runtime_implementations(modules: &[PortableIrContribution]) -> Vec<RuntimeImplementation> {
    let requirements: BTreeSet<_> = modules
        .iter()
        .flat_map(|module| module.runtime_obligations.iter().cloned())
        .collect();
    requirements
        .into_iter()
        .map(|requirement| RuntimeImplementation {
            implementation: implementation_id(&format!(
                "implementation.portable.{}",
                requirement.as_str()
            )),
            occurrence: occurrence(&format!(
                "runtime-implementation:{}:1",
                requirement.as_str()
            )),
            conformance_evidence: occurrence(&format!(
                "conformance:{}:1",
                requirement.as_str()
            )),
            requirement,
            portable: true,
            declared_environment_fields: BTreeSet::new(),
        })
        .collect()
}

pub fn minimal_contributions(lock: &PackageLock) -> Vec<(ContributionEnvelope, ClassProjection)> {
    let provenance = |source: &str| Provenance {
        source_authority: authority(source),
        source_occurrence: occurrence(&format!("source:{}:1", source)),
        source_digest: commitment(source),
        admitted_by: verifier_id("verifier.cross-registry.reference"),
    };
    let mut facets = BTreeSet::new();
    facets.insert(FacetKind::Contract);
    facets.insert(FacetKind::Graph);
    facets.insert(FacetKind::PortableIntermediateRepresentation);
    facets.insert(FacetKind::RuntimeObligation);

    vec![
        (
            ContributionEnvelope {
                stable_coordinate: coordinate("reference.semantic.customer-risk"),
                occurrence: occurrence("contribution:semantic-risk:1"),
                semantic_edition: edition("edition-1"),
                sovereign_owner: owner("owner.semantic-risk"),
                contribution_class: ContributionClass::Semantic,
                artifact_kind: artifact_kind("artifact-kind.semantic-contribution"),
                source_authority: authority("source-authority.semantic-risk"),
                package_lock: lock.id.clone(),
                package_lock_commitment: lock.commitment,
                provenance: provenance("source-authority.semantic-risk"),
                declared_operations: vec![DeclaredOperation {
                    coordinate: coordinate("operation.evaluate-customer-risk"),
                    input_contracts: vec![contract("contract:governed-risk-data:v1")],
                    output_contracts: vec![contract("contract:risk-result:v1")],
                    refusal_contracts: vec![contract("contract:risk-evaluation-refusal:v1")],
                    effect_requirements: vec![],
                }],
                declared_decisions: vec![],
                facet_kinds: facets.clone(),
                declared_budget_ceiling: 128,
                evolution_posture: EvolutionPosture::Stable,
                canonical_commitment: commitment("contribution:semantic-risk:1"),
            },
            ClassProjection::Semantic(SemanticProjection {
                owned_meanings: vec![coordinate("meaning.customer-risk")],
                semantic_laws: vec![contract("contract:customer-risk-law:v1")],
                pure_operations: vec![],
                required_external_contracts: vec![contract("contract:governed-risk-data:v1")],
            }),
        ),
        (
            ContributionEnvelope {
                stable_coordinate: coordinate("reference.data.customer-risk-view"),
                occurrence: occurrence("contribution:data-risk:1"),
                semantic_edition: edition("edition-1"),
                sovereign_owner: owner("owner.data-risk"),
                contribution_class: ContributionClass::GovernedData,
                artifact_kind: artifact_kind("artifact-kind.governed-data-contribution"),
                source_authority: authority("source-authority.data-risk"),
                package_lock: lock.id.clone(),
                package_lock_commitment: lock.commitment,
                provenance: provenance("source-authority.data-risk"),
                declared_operations: vec![],
                declared_decisions: vec![],
                facet_kinds: facets.clone(),
                declared_budget_ceiling: 128,
                evolution_posture: EvolutionPosture::Stable,
                canonical_commitment: commitment("contribution:data-risk:1"),
            },
            ClassProjection::GovernedData(GovernedDataProjection {
                governed_grains: vec![coordinate("grain.customer-risk-fact")],
                identity_contracts: vec![contract("contract:customer-identity:v1")],
                time_and_order_contracts: vec![contract("contract:risk-fact-time:v1")],
                lineage_contracts: vec![contract("contract:risk-lineage:v1")],
                query_contracts: vec![contract("contract:governed-risk-data:v1")],
                quality_obligations: vec![obligation_id("obligation:lineage")],
            }),
        ),
        (
            ContributionEnvelope {
                stable_coordinate: coordinate("reference.domain.customer-account"),
                occurrence: occurrence("contribution:domain-customer:1"),
                semantic_edition: edition("edition-1"),
                sovereign_owner: owner("owner.domain-customer"),
                contribution_class: ContributionClass::DomainOntology,
                artifact_kind: artifact_kind("artifact-kind.domain-ontology-contribution"),
                source_authority: authority("source-authority.domain-customer"),
                package_lock: lock.id.clone(),
                package_lock_commitment: lock.commitment,
                provenance: provenance("source-authority.domain-customer"),
                declared_operations: vec![],
                declared_decisions: vec![],
                facet_kinds: facets.clone(),
                declared_budget_ceiling: 128,
                evolution_posture: EvolutionPosture::Stable,
                canonical_commitment: commitment("contribution:domain-customer:1"),
            },
            ClassProjection::DomainOntology(DomainOntologyProjection {
                bounded_context: coordinate("bounded-context.customer-account"),
                concepts: vec![coordinate("concept.customer"), coordinate("concept.account")],
                relations: vec![contract("contract:customer-account-relation:v1")],
                invariants: vec![contract("contract:customer-account-invariant:v1")],
                correspondence_seams: vec![contract("contract:risk-customer-correspondence:v1")],
            }),
        ),
        (
            ContributionEnvelope {
                stable_coordinate: coordinate("reference.client.risk-review"),
                occurrence: occurrence("contribution:client-risk-review:1"),
                semantic_edition: edition("edition-1"),
                sovereign_owner: owner("owner.client-risk-review"),
                contribution_class: ContributionClass::UserInterface,
                artifact_kind: artifact_kind("artifact-kind.user-interface-contribution"),
                source_authority: authority("reference-fixture-authority.client-risk-review"),
                package_lock: lock.id.clone(),
                package_lock_commitment: lock.commitment,
                provenance: provenance("reference-fixture-authority.client-risk-review"),
                declared_operations: vec![],
                declared_decisions: vec![],
                facet_kinds: facets,
                declared_budget_ceiling: 128,
                evolution_posture: EvolutionPosture::Stable,
                canonical_commitment: commitment("contribution:client-risk-review:1"),
            },
            ClassProjection::UserInterface(UserInterfaceProjection {
                interaction_contracts: vec![contract("contract:risk-review-interaction:v1")],
                navigation_contracts: vec![contract("contract:risk-review-navigation:v1")],
                presentation_contracts: vec![contract("contract:risk-review-presentation:v1")],
                accessibility_contracts: vec![contract("contract:risk-review-accessibility:v1")],
                input_modality_contracts: vec![contract("contract:risk-review-input:v1")],
                responsive_behavior_contracts: vec![contract("contract:risk-review-responsive:v1")],
                client_state_contracts: vec![contract("contract:risk-review-client-state:v1")],
                localization_contracts: vec![contract("contract:risk-review-localization:v1")],
                rendering_contracts: vec![contract("contract:risk-review-rendering:v1")],
                media_contracts: vec![contract("contract:risk-review-media:v1")],
                design_token_contracts: vec![contract("contract:risk-review-design-token:v1")],
                client_effect_requirements: vec![runtime_requirement("runtime.client-interaction")],
                source_authority: authority("reference-fixture-authority.client-risk-review"),
            }),
        ),
    ]
}

pub fn replay_dependencies(
    supplier: &Stage0SupplierInventoryClosure,
    binding: &ApplicationBinding,
    obligation: &ObligationClosure,
    csag: &Csag,
    portfolio: &PortableIrPortfolio,
    target: &TargetCompilationSet,
    execution: &ExecutionBinding,
    closure: &ApplicationClosure,
) -> Vec<(ArtifactKindId, OccurrenceId, CanonicalCommitment)> {
    vec![
        (artifact_kind("artifact-kind.stage0-supplier-closure"), occurrence("artifact:stage0-supplier-closure:1"), supplier.commitment()),
        (artifact_kind("artifact-kind.application-binding"), occurrence("artifact:application-binding:1"), binding.commitment()),
        (artifact_kind("artifact-kind.obligation-closure"), occurrence("artifact:obligation-closure:1"), obligation.commitment()),
        (artifact_kind("artifact-kind.csag"), occurrence("artifact:csag:1"), csag.commitment()),
        (artifact_kind("artifact-kind.ir-portfolio"), occurrence("artifact:ir-portfolio:1"), portfolio.commitment()),
        (artifact_kind("artifact-kind.target-compilation"), occurrence("artifact:target-compilation:1"), target.commitment()),
        (artifact_kind("artifact-kind.execution-binding"), occurrence("artifact:execution-binding:1"), execution.commitment()),
        (artifact_kind("artifact-kind.application-closure"), occurrence("artifact:application-closure:1"), closure.commitment()),
    ]
}

pub fn dependency_occurrences(
    dependencies: &[(ArtifactKindId, OccurrenceId, CanonicalCommitment)],
) -> BTreeSet<OccurrenceId> {
    dependencies
        .iter()
        .map(|(_, occurrence, _)| occurrence.clone())
        .collect()
}

pub fn dependency_commitment_map(
    dependencies: &[(ArtifactKindId, OccurrenceId, CanonicalCommitment)],
) -> BTreeMap<OccurrenceId, CanonicalCommitment> {
    dependencies
        .iter()
        .map(|(_, occurrence, commitment)| (occurrence.clone(), *commitment))
        .collect()
}
