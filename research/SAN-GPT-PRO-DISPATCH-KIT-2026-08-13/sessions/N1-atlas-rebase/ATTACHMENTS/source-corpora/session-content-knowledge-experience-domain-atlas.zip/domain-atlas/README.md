# SAN Content, Records, Knowledge, Communication and Human Experience Domain Atlas

This package is a research corpus and boundary hypothesis set. It does not build software, mutate the attached SAN registry, ratify a domain, or claim universal completeness.

## Canonical material

JSONL collections contain independently addressable records. JSON contains schemas, controlled vocabularies, coverage assessments and validation evidence. Markdown files are generated navigation only.

Every primary record uses the required common envelope and a kind-specific schema. Important semantics are represented by explicit fields rather than unrestricted metadata bags. Relations are independently identified and distinguish binary from n-ary facts.

## Interpretation

`CANDIDATE_BOUNDED_CONTEXT` is a research proposal. Foundation algebras, semantic families, profiles, compositions, publications, provider implementations and rejected false boundaries are deliberately distinct dispositions. Existing `san.*` identifiers are references to the attached registry or its context-map evidence; all newly created identities use the `candidate.content-knowledge-experience.*` namespace.

The corpus reaches L4 only where adversarial examples and boundary tests are populated. No record claims L5 independent review. Jurisdiction-specific legal effect, external analytics ownership, archival assurance thresholds and provider capability closure remain explicit gaps.

## Integrity

Validate files against the Draft 2020-12 schemas under `schemas/`, then compare every listed digest in `CHECKSUMS.txt`. `VALIDATION.json` records the executed checks. The ZIP uses sorted paths, fixed timestamps, fixed Unix modes and deterministic DEFLATE settings.
