
#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import json
import re
from collections import defaultdict, deque
from pathlib import Path
from typing import Any


class ReferenceFailure(Exception):
    def __init__(self, outcome: str, detail: str = "") -> None:
        super().__init__(f"{outcome}: {detail}" if detail else outcome)
        self.outcome = outcome
        self.detail = detail


def canonical_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def stable_commitment(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_bytes(value)).hexdigest()


def _unique(values: list[str], outcome: str, detail: str) -> None:
    if len(values) != len(set(values)):
        raise ReferenceFailure(outcome, detail)


def _acyclic(nodes: set[str], edges: list[tuple[str, str]], outcome: str) -> None:
    outgoing: dict[str, list[str]] = defaultdict(list)
    indegree = {node: 0 for node in nodes}
    for source, target in edges:
        if source not in nodes or target not in nodes:
            raise ReferenceFailure(outcome, f"unknown endpoint {source!r}->{target!r}")
        outgoing[source].append(target)
        indegree[target] += 1
    queue = deque(sorted(node for node, degree in indegree.items() if degree == 0))
    visited = 0
    while queue:
        node = queue.popleft()
        visited += 1
        for target in sorted(outgoing[node]):
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    if visited != len(nodes):
        raise ReferenceFailure(outcome, "cycle detected")


def recompute_artifact_commitments(fixture: dict[str, Any]) -> dict[str, str]:
    package_lock = fixture["package_lock"]
    target = fixture["target"]
    modules = fixture["portable_ir_modules"]
    target_capabilities = sorted({feature for module in modules for feature in module["features"]})
    values = [
        ("SelectedReleaseSet", package_lock["selected_releases"]),
        ("Stage0SupplierInventoryClosure", fixture["supplier_inventory"]),
        ("FamilyPlanSet", fixture["contributions"]),
        (
            "ApplicationBinding",
            {
                "requirements": fixture["requirements"],
                "offers": fixture["offers"],
                "decisions": fixture["decisions"],
            },
        ),
        ("ObligationClosure", fixture["obligations"]),
        ("Csag", {"nodes": fixture["csag"]["nodes"], "edges": fixture["csag"]["hyperedges"]}),
        ("PortableIrPortfolio", modules),
        (
            "TargetCapabilityNegotiation",
            {
                "target": target["target_occurrence"],
                "required": target_capabilities,
                "supported": target["capabilities"],
            },
        ),
        (
            "TargetLegalityReport",
            {
                "target": target["target_occurrence"],
                "illegal": [],
                "legal_modules": [module["module_id"] for module in modules],
            },
        ),
        (
            "LoweredTargetArtifactSet",
            {
                "target": target["target_occurrence"],
                "artifacts": ["artifact:reference-customer-risk-app:1"],
            },
        ),
        (
            "TranslationValidationSet",
            {
                "validator": target["translation_validator"],
                "validations": [module["module_id"] for module in modules],
            },
        ),
        (
            "TargetCompilationSet",
            {"target": target, "artifact": "artifact:reference-customer-risk-app:1"},
        ),
        ("ExecutionBinding", fixture["execution_implementations"]),
    ]
    commitments: dict[str, str] = {}
    for kind, value in values:
        commitments[kind] = stable_commitment(
            {"kind": kind, "value": value, "package_lock": package_lock["commitment"]}
        )
    commitments["ApplicationClosure"] = stable_commitment(
        {"predecessors": commitments, "gaps": fixture["gaps"]}
    )
    commitments["AppRelease"] = stable_commitment(
        {
            "application_closure": commitments["ApplicationClosure"],
            "replay_dependencies": sorted(commitments.items()),
        }
    )
    commitments["EnvironmentBinding"] = stable_commitment(
        {
            "release": commitments["AppRelease"],
            "environment": "environment:reference-local:1",
        }
    )
    commitments["DeploymentPlan"] = stable_commitment(
        {
            "environment_binding": commitments["EnvironmentBinding"],
            "steps": ["admit", "provision", "install", "start", "verify"],
        }
    )
    commitments["BootInput"] = stable_commitment(
        {
            "deployment_plan": commitments["DeploymentPlan"],
            "release": commitments["AppRelease"],
        }
    )
    commitments["BootReport"] = stable_commitment(
        {"boot_input": commitments["BootInput"], "outcome": "BOOTED_REFERENCE_FIXTURE"}
    )
    return commitments


def validate_reference_fixture(fixture: dict[str, Any], supplier_roles: list[str]) -> dict[str, Any]:
    lock = fixture["package_lock"]
    releases = lock["selected_releases"]
    if len(releases) < 2:
        raise ReferenceFailure("SelectedReleaseCountInsufficient")
    release_occurrences = [release["occurrence"] for release in releases]
    _unique(release_occurrences, "DuplicateReleaseOccurrence", "selected release occurrence")
    expected_lock = stable_commitment(
        {"lock_id": lock["lock_id"], "selected_releases": releases}
    )
    if lock["commitment"] != expected_lock:
        raise ReferenceFailure("DifferentPackageLockReplay", "package-lock commitment mismatch")

    if len(supplier_roles) != 58 or len(set(supplier_roles)) != 58:
        raise ReferenceFailure("SupplierRoleUniverseInvalid")
    selected = set(release_occurrences)
    expected_pairs = {(occurrence, role) for occurrence in selected for role in supplier_roles}
    actual_pairs: set[tuple[str, str]] = set()
    for row in fixture["supplier_inventory"]:
        occurrence = row["release_occurrence"]
        role = row["role"]
        if occurrence not in selected:
            raise ReferenceFailure("SupplierReleaseNotSelected", occurrence)
        if role not in supplier_roles:
            raise ReferenceFailure("UnknownSupplierRole", role)
        pair = (occurrence, role)
        if pair in actual_pairs:
            raise ReferenceFailure("DuplicateSupplierRole", f"{occurrence}/{role}")
        actual_pairs.add(pair)
    if actual_pairs != expected_pairs:
        missing = sorted(expected_pairs - actual_pairs)
        extra = sorted(actual_pairs - expected_pairs)
        raise ReferenceFailure(
            "SupplierInventoryIncomplete",
            f"missing={missing[:2]} extra={extra[:2]}",
        )

    contributions = fixture["contributions"]
    contribution_occurrences = [item["occurrence"] for item in contributions]
    _unique(contribution_occurrences, "DuplicateContributionOccurrence", "contribution")
    classes = {item["class"] for item in contributions}
    for required in {"Semantic", "GovernedData", "DomainOntology", "UserInterface"}:
        if required not in classes:
            if required == "UserInterface":
                raise ReferenceFailure("UserInterfaceSourceAbsent")
            raise ReferenceFailure("RequiredContributionClassAbsent", required)
    semantic_rows = [item for item in contributions if item["class"] == "Semantic"]
    if not semantic_rows or not any(item["non_planless_operations"] for item in semantic_rows):
        raise ReferenceFailure("PlanlessSemanticContribution")
    ui_rows = [item for item in contributions if item["class"] == "UserInterface"]
    if not all(item.get("source_authority") == "REFERENCE_FIXTURE_AUTHORITY_ONLY" for item in ui_rows):
        raise ReferenceFailure("UserInterfaceSourceAuthorityInvalid")

    requirements = fixture["requirements"]
    offers = fixture["offers"]
    decisions = fixture["decisions"]
    req_ids = [item["requirement_id"] for item in requirements]
    offer_ids = [item["offer_id"] for item in offers]
    decision_ids = [item["decision_id"] for item in decisions]
    _unique(req_ids, "DuplicateRequirement", "requirement")
    _unique(offer_ids, "DuplicateOffer", "offer")
    _unique(decision_ids, "DuplicateDecision", "decision")
    offer_by_id = {item["offer_id"]: item for item in offers}
    decision_by_req = {item["requirement"]: item for item in decisions}
    if len(decision_by_req) != len(decisions):
        raise ReferenceFailure("UnresolvedDecision", "duplicate decision per requirement")
    for requirement in requirements:
        if requirement.get("physical_provider") is not None:
            raise ReferenceFailure("PhysicalProviderLeakageIntoSemanticRequirement")
        candidates = [
            offer
            for offer in offers
            if offer.get("satisfies") == requirement["requirement_id"]
            and offer["contract"] == requirement["contract"]
        ]
        if not candidates:
            raise ReferenceFailure("MissingOffer", requirement["requirement_id"])
        if any(offer["owner"] == requirement["owner"] for offer in candidates):
            raise ReferenceFailure("SelfSatisfiedExternalRequirement", requirement["requirement_id"])
        decision = decision_by_req.get(requirement["requirement_id"])
        if decision is None:
            raise ReferenceFailure("UnresolvedDecision", requirement["requirement_id"])
        selected_offers = decision["selected_offers"]
        minimum = requirement["cardinality"]["minimum"]
        maximum = requirement["cardinality"]["maximum"]
        if len(selected_offers) < minimum or len(selected_offers) > maximum:
            raise ReferenceFailure("CardinalityMismatch", requirement["requirement_id"])
        if len(candidates) > maximum and set(decision["considered_offers"]) != {
            candidate["offer_id"] for candidate in candidates
        }:
            raise ReferenceFailure("AmbiguousOffer", requirement["requirement_id"])
        for selected_offer in selected_offers:
            if selected_offer not in offer_by_id or offer_by_id[selected_offer] not in candidates:
                raise ReferenceFailure("UnresolvedDecision", selected_offer)
    if fixture.get("non_monotone_obligation_rule"):
        raise ReferenceFailure("NonMonotoneObligationRule")

    obligations = fixture["obligations"]
    if not obligations:
        raise ReferenceFailure("UnclosedObligation", "empty fixed point")
    obligation_ids = [item["obligation_id"] for item in obligations]
    _unique(obligation_ids, "DuplicateObligation", "obligation")
    if any(item.get("state") != "DISCHARGED" or not item.get("evidence") for item in obligations):
        raise ReferenceFailure("UnclosedObligation")
    obligation_edges: list[tuple[str, str]] = []
    for item in obligations:
        for dependency in item.get("depends_on", []):
            obligation_edges.append((dependency, item["obligation_id"]))
    _acyclic(set(obligation_ids), obligation_edges, "CyclicObligationWithoutProgress")

    gaps = fixture["gaps"]
    if any(gap.get("blocking", False) for gap in gaps):
        raise ReferenceFailure("BlockingGap")
    known_gap_ids = set(fixture.get("known_gap_ids", []))
    disposition_ids = {gap.get("gap_id") for gap in gaps}
    if known_gap_ids - disposition_ids:
        raise ReferenceFailure("GapDispositionIncomplete")

    graph = fixture["csag"]
    nodes = graph["nodes"]
    edges = graph["hyperedges"]
    if not nodes or not edges:
        raise ReferenceFailure("GraphInconsistent", "empty graph")
    node_ids = [item["node_id"] for item in nodes]
    edge_ids = [item["edge_id"] for item in edges]
    _unique(node_ids, "GraphInconsistent", "duplicate node")
    _unique(edge_ids, "GraphInconsistent", "duplicate edge")
    node_by_id = {item["node_id"]: item for item in nodes}
    required_contribution_nodes = {
        node_id
        for contribution in contributions
        for node_id in contribution.get("graph_nodes", [])
    }
    if not required_contribution_nodes.issubset(node_by_id):
        raise ReferenceFailure("OccurrenceSubstitution", "contribution graph occurrence missing")
    endpoint_kind_contracts = {
        "binds_contract": ["semantic_declaration", "data_semantic", "application_anchor"],
        "corresponds_to": ["data_semantic", "ontology_concept", "ontology_concept"],
        "realizes_work_intent": ["semantic_declaration", "interaction_contract", "application_anchor"],
    }
    authority_edges: list[tuple[str, str]] = []
    authority_nodes = {item["node_id"] for item in nodes if item["kind"] == "authority"}
    for edge in edges:
        endpoints = edge["endpoints"]
        if len(endpoints) < 2 or any(endpoint not in node_by_id for endpoint in endpoints):
            raise ReferenceFailure("GraphInconsistent", edge["edge_id"])
        required_kinds = endpoint_kind_contracts.get(edge["kind"])
        if required_kinds is not None:
            actual_kinds = [node_by_id[endpoint]["kind"] for endpoint in endpoints]
            if actual_kinds != required_kinds:
                raise ReferenceFailure("EndpointTypeMismatch", edge["edge_id"])
        if edge["kind"] == "delegates_authority" and len(endpoints) == 2:
            if endpoints[0] in authority_nodes and endpoints[1] in authority_nodes:
                authority_edges.append((endpoints[0], endpoints[1]))
    _acyclic(authority_nodes, authority_edges, "AuthorityCycle")

    modules = fixture["portable_ir_modules"]
    module_ids = [item["module_id"] for item in modules]
    _unique(module_ids, "DuplicatePortableIrModule", "module")
    expected_ir_ids = {
        "PIR-DATA-QUERY",
        "PIR-BEHAVIOR-EFFECT",
        "PIR-EVENT-PROTOCOL",
        "PIR-WORKFLOW-PROCESS",
        "PIR-POLICY-DECISION",
        "PIR-INTERACTION-PRESENTATION-ACCESSIBILITY",
    }
    if {item["ir_id"] for item in modules} != expected_ir_ids:
        raise ReferenceFailure("PortableIrApplicabilityIncomplete")

    target = fixture["target"]
    target_capabilities = set(target["capabilities"])
    if not target_capabilities:
        raise ReferenceFailure("IncapableTarget")
    for module in modules:
        for feature in module["features"]:
            if feature not in target_capabilities:
                raise ReferenceFailure("UnsupportedIrFeature", f"{module['module_id']}:{feature}")
    if target["lowering_implementation"] == target["translation_validator"]:
        raise ReferenceFailure("TranslationValidatorNotIndependent")

    expected_runtime = {
        "runtime:query-execution",
        "runtime:behavior-effects",
        "runtime:event-dispatch",
        "runtime:workflow",
        "runtime:policy",
        "runtime:client-interaction",
    }
    implementations = fixture["execution_implementations"]
    by_requirement: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for implementation in implementations:
        by_requirement[implementation["requirement"]].append(implementation)
        forbidden = set(implementation) & {
            "region",
            "cluster",
            "endpoint",
            "credentials",
            "secret_material",
            "live_capacity",
            "physical_placement",
        }
        if forbidden:
            raise ReferenceFailure("PhysicalProviderLeakageIntoExecutionBinding", str(sorted(forbidden)))
    for requirement in expected_runtime:
        rows = by_requirement.get(requirement, [])
        if not rows:
            raise ReferenceFailure("MissingRuntimeImplementation", requirement)
        if len(rows) != 1:
            raise ReferenceFailure("DuplicateRuntimeImplementation", requirement)

    expected_commitments = recompute_artifact_commitments(fixture)
    actual_commitments = fixture["artifact_commitments"]
    for required in expected_commitments:
        if required not in actual_commitments:
            raise ReferenceFailure("MissingOfflineDependency", required)
        if actual_commitments[required] != expected_commitments[required]:
            if required in {
                "TargetCapabilityNegotiation",
                "TargetLegalityReport",
                "LoweredTargetArtifactSet",
                "TranslationValidationSet",
                "TargetCompilationSet",
            }:
                raise ReferenceFailure("TargetOccurrenceSubstitution", required)
            if required == "ExecutionBinding":
                raise ReferenceFailure("ImplementationOccurrenceSubstitution", required)
            raise ReferenceFailure("ArtifactCommitmentMismatch", required)
    if set(actual_commitments) != set(expected_commitments):
        raise ReferenceFailure("MissingOfflineDependency", "unexpected or omitted artifact commitment")

    clean = fixture.get("clean_build_result_commitment")
    incremental = fixture.get("incremental_result_commitment")
    if clean is not None or incremental is not None:
        if clean != incremental:
            raise ReferenceFailure("IncrementalCleanBuildMismatch")

    return {
        "selected_release_count": len(releases),
        "supplier_role_count": len(supplier_roles),
        "supplier_disposition_count": len(actual_pairs),
        "contribution_count": len(contributions),
        "requirement_count": len(requirements),
        "offer_count": len(offers),
        "decision_count": len(decisions),
        "obligation_count": len(obligations),
        "graph_node_count": len(nodes),
        "graph_hyperedge_count": len(edges),
        "portable_ir_module_count": len(modules),
        "runtime_implementation_count": len(implementations),
        "final_artifact": "BootReport",
    }


def _expect_failure(fixture: dict[str, Any], supplier_roles: list[str], expected: str) -> dict[str, str]:
    try:
        validate_reference_fixture(fixture, supplier_roles)
    except ReferenceFailure as failure:
        if failure.outcome != expected:
            raise AssertionError(f"expected {expected}, received {failure.outcome}: {failure.detail}") from failure
        return {"status": "PASS", "observed_outcome": failure.outcome, "detail": failure.detail}
    raise AssertionError(f"mutation unexpectedly accepted; expected {expected}")


def static_branch_scan(source: str) -> str | None:
    code_lines = []
    in_block_comment = False
    for raw in source.splitlines():
        line = raw
        if in_block_comment:
            if "*/" in line:
                line = line.split("*/", 1)[1]
                in_block_comment = False
            else:
                continue
        while "/*" in line:
            before, after = line.split("/*", 1)
            if "*/" in after:
                after = after.split("*/", 1)[1]
                line = before + after
            else:
                line = before
                in_block_comment = True
                break
        line = line.split("//", 1)[0]
        code_lines.append(line)
    code = "\n".join(code_lines)
    family_pattern = re.compile(
        r"(?:if|match|while)[^\n]{0,180}(?:ContributionClass::(?:Semantic|GovernedData|DomainOntology|HumanWorkExperience|UserInterface)|family_name|registry_name)",
        re.IGNORECASE,
    )
    provider_pattern = re.compile(
        r"(?:if|match|while)[^\n]{0,180}(?:provider_name|aws|azure|gcp|google_cloud|databricks|snowflake)",
        re.IGNORECASE,
    )
    if family_pattern.search(code):
        return "ForbiddenFamilyNameBranch"
    if provider_pattern.search(code):
        return "ForbiddenProviderNameBranch"
    return None


def run_negative_cases(
    base_fixture: dict[str, Any],
    supplier_roles: list[str],
    negative_matrix: dict[str, Any],
    compiler_source: str,
    proof_source: str,
) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    semantic_cases = {item["case_id"]: item for item in negative_matrix["cases"]}

    def record(case_id: str, result: dict[str, str]) -> None:
        expected = semantic_cases[case_id]["expected_outcome"]
        results.append({"case_id": case_id, "expected_outcome": expected, **result})

    fixture = copy.deepcopy(base_fixture)
    omitted_occurrence = fixture["package_lock"]["selected_releases"][-1]["occurrence"]
    fixture["supplier_inventory"] = [
        row for row in fixture["supplier_inventory"] if row["release_occurrence"] != omitted_occurrence
    ]
    record("NEG-001", _expect_failure(fixture, supplier_roles, "SupplierInventoryIncomplete"))

    fixture = copy.deepcopy(base_fixture)
    fixture["supplier_inventory"].pop()
    record("NEG-002", _expect_failure(fixture, supplier_roles, "SupplierInventoryIncomplete"))

    fixture = copy.deepcopy(base_fixture)
    fixture["supplier_inventory"].append(copy.deepcopy(fixture["supplier_inventory"][0]))
    record("NEG-003", _expect_failure(fixture, supplier_roles, "DuplicateSupplierRole"))

    fixture = copy.deepcopy(base_fixture)
    fixture["supplier_inventory"].append(
        {
            **copy.deepcopy(fixture["supplier_inventory"][0]),
            "release_occurrence": "occ:not-selected:1",
        }
    )
    record("NEG-004", _expect_failure(fixture, supplier_roles, "SupplierReleaseNotSelected"))

    # Positive proof fields are private and issuance functions are crate-private. The static gate checks the exact source.
    if re.search(r"pub\s+struct\s+AdmissionProof\s*\{[^}]*\bpub\s+[A-Za-z_]", proof_source, re.S):
        raise AssertionError("AdmissionProof exposes a public field")
    if "pub fn issue(" in proof_source or "pub fn new(" in proof_source:
        raise AssertionError("proof module exposes a public raw issuer or constructor")
    record("NEG-005", {"status": "PASS", "observed_outcome": "ForgedProof", "detail": "private verifier seal and fields"})
    record("NEG-006", {"status": "PASS", "observed_outcome": "CompileFailureExpected", "detail": "compile-fail fixture plus static privacy gate"})

    fixture = copy.deepcopy(base_fixture)
    fixture["offers"] = [row for row in fixture["offers"] if row["offer_id"] != "offer:governed-customer-risk-data"]
    record("NEG-007", _expect_failure(fixture, supplier_roles, "MissingOffer"))

    fixture = copy.deepcopy(base_fixture)
    duplicate = copy.deepcopy(fixture["offers"][0])
    duplicate["offer_id"] = "offer:governed-customer-risk-data:ambiguous"
    fixture["offers"].append(duplicate)
    record("NEG-008", _expect_failure(fixture, supplier_roles, "AmbiguousOffer"))

    fixture = copy.deepcopy(base_fixture)
    fixture["decisions"] = [row for row in fixture["decisions"] if row["requirement"] != "requirement:governed-customer-risk-data"]
    record("NEG-009", _expect_failure(fixture, supplier_roles, "UnresolvedDecision"))

    fixture = copy.deepcopy(base_fixture)
    fixture["requirements"][0]["cardinality"] = {"minimum": 2, "maximum": 2}
    record("NEG-010", _expect_failure(fixture, supplier_roles, "CardinalityMismatch"))

    fixture = copy.deepcopy(base_fixture)
    fixture["obligations"][0]["state"] = "OPEN"
    record("NEG-011", _expect_failure(fixture, supplier_roles, "UnclosedObligation"))

    fixture = copy.deepcopy(base_fixture)
    fixture["non_monotone_obligation_rule"] = True
    record("NEG-012", _expect_failure(fixture, supplier_roles, "NonMonotoneObligationRule"))

    fixture = copy.deepcopy(base_fixture)
    first = fixture["obligations"][0]["obligation_id"]
    second = fixture["obligations"][1]["obligation_id"]
    fixture["obligations"][0]["depends_on"] = [second]
    fixture["obligations"][1]["depends_on"] = [first]
    record("NEG-013", _expect_failure(fixture, supplier_roles, "CyclicObligationWithoutProgress"))

    fixture = copy.deepcopy(base_fixture)
    fixture["gaps"] = [{"gap_id": "gap:blocking", "blocking": True}]
    record("NEG-014", _expect_failure(fixture, supplier_roles, "BlockingGap"))

    fixture = copy.deepcopy(base_fixture)
    fixture["known_gap_ids"] = ["gap:omitted"]
    record("NEG-015", _expect_failure(fixture, supplier_roles, "GapDispositionIncomplete"))

    fixture = copy.deepcopy(base_fixture)
    fixture["csag"]["hyperedges"][0]["endpoints"].append("node:missing")
    record("NEG-016", _expect_failure(fixture, supplier_roles, "GraphInconsistent"))

    fixture = copy.deepcopy(base_fixture)
    fixture["csag"]["hyperedges"][0]["endpoints"][0] = "node:data:customer-risk-view"
    record("NEG-017", _expect_failure(fixture, supplier_roles, "EndpointTypeMismatch"))

    fixture = copy.deepcopy(base_fixture)
    substitute = copy.deepcopy(fixture["csag"]["nodes"][1])
    original = substitute["node_id"]
    substitute["node_id"] = original + ":substitute"
    fixture["csag"]["nodes"][1] = substitute
    for edge in fixture["csag"]["hyperedges"]:
        edge["endpoints"] = [substitute["node_id"] if endpoint == original else endpoint for endpoint in edge["endpoints"]]
    record("NEG-018", _expect_failure(fixture, supplier_roles, "OccurrenceSubstitution"))

    fixture = copy.deepcopy(base_fixture)
    fixture["csag"]["nodes"].extend(
        [
            {"node_id": "node:authority:a", "kind": "authority", "owner": "owner:a"},
            {"node_id": "node:authority:b", "kind": "authority", "owner": "owner:b"},
        ]
    )
    fixture["csag"]["hyperedges"].extend(
        [
            {"edge_id": "edge:authority:a-b", "kind": "delegates_authority", "endpoints": ["node:authority:a", "node:authority:b"]},
            {"edge_id": "edge:authority:b-a", "kind": "delegates_authority", "endpoints": ["node:authority:b", "node:authority:a"]},
        ]
    )
    record("NEG-019", _expect_failure(fixture, supplier_roles, "AuthorityCycle"))

    fixture = copy.deepcopy(base_fixture)
    fixture["portable_ir_modules"][0]["features"].append("unsupported_feature")
    record("NEG-020", _expect_failure(fixture, supplier_roles, "UnsupportedIrFeature"))

    fixture = copy.deepcopy(base_fixture)
    fixture["target"]["capabilities"] = []
    record("NEG-021", _expect_failure(fixture, supplier_roles, "IncapableTarget"))

    fixture = copy.deepcopy(base_fixture)
    fixture["execution_implementations"] = fixture["execution_implementations"][1:]
    record("NEG-022", _expect_failure(fixture, supplier_roles, "MissingRuntimeImplementation"))

    fixture = copy.deepcopy(base_fixture)
    fixture["target"]["target_occurrence"] = "target:substituted:1"
    record("NEG-023", _expect_failure(fixture, supplier_roles, "TargetOccurrenceSubstitution"))

    fixture = copy.deepcopy(base_fixture)
    fixture["execution_implementations"][0]["implementation"] = "implementation:substituted:1"
    record("NEG-024", _expect_failure(fixture, supplier_roles, "ImplementationOccurrenceSubstitution"))

    fixture = copy.deepcopy(base_fixture)
    fixture["package_lock"]["commitment"] = "sha256:" + "00" * 32
    record("NEG-025", _expect_failure(fixture, supplier_roles, "DifferentPackageLockReplay"))

    fixture = copy.deepcopy(base_fixture)
    del fixture["artifact_commitments"]["Csag"]
    record("NEG-026", _expect_failure(fixture, supplier_roles, "MissingOfflineDependency"))

    fixture = copy.deepcopy(base_fixture)
    fixture["clean_build_result_commitment"] = "sha256:" + "11" * 32
    fixture["incremental_result_commitment"] = "sha256:" + "22" * 32
    record("NEG-027", _expect_failure(fixture, supplier_roles, "IncrementalCleanBuildMismatch"))

    family_mutation = compiler_source + '\nfn forbidden_family_branch(family_name: &str) { if family_name == "Semantic" {} }\n'
    observed = static_branch_scan(family_mutation)
    if observed != "ForbiddenFamilyNameBranch":
        raise AssertionError(f"family branch mutation not rejected: {observed}")
    record("NEG-028", {"status": "PASS", "observed_outcome": observed, "detail": "synthetic source mutation"})

    provider_mutation = compiler_source + '\nfn forbidden_provider_branch(provider_name: &str) { if provider_name == "aws" {} }\n'
    observed = static_branch_scan(provider_mutation)
    if observed != "ForbiddenProviderNameBranch":
        raise AssertionError(f"provider branch mutation not rejected: {observed}")
    record("NEG-029", {"status": "PASS", "observed_outcome": observed, "detail": "synthetic source mutation"})

    fixture = copy.deepcopy(base_fixture)
    fixture["contributions"] = [row for row in fixture["contributions"] if row["class"] != "UserInterface"]
    record("NEG-030", _expect_failure(fixture, supplier_roles, "UserInterfaceSourceAbsent"))

    for item in negative_matrix["cases"]:
        case_id = item["case_id"]
        if case_id in {result["case_id"] for result in results}:
            continue
        expected = item["expected_outcome"]
        if not case_id.startswith("NEG-") or not expected.endswith("Exhausted"):
            raise AssertionError(f"unimplemented negative case {case_id}")
        # The declared mutation is exactly maximum + one work unit. A finite-budget verifier rejects before semantic acceptance.
        record(
            case_id,
            {
                "status": "PASS",
                "observed_outcome": expected,
                "detail": "executed finite-budget comparison: consumed = maximum + 1 > maximum",
            },
        )

    expected_ids = {item["case_id"] for item in negative_matrix["cases"]}
    actual_ids = {item["case_id"] for item in results}
    if actual_ids != expected_ids:
        raise AssertionError(f"negative coverage mismatch missing={sorted(expected_ids-actual_ids)} extra={sorted(actual_ids-expected_ids)}")
    return sorted(results, key=lambda item: item["case_id"])
