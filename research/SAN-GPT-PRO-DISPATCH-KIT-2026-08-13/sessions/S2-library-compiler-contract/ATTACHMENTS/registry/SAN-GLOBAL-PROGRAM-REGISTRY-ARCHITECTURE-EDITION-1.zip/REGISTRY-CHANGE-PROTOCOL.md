# Registry change protocol

## Change envelope

Every change is an immutable proposal containing:

```json
{
  "change_id": "globally-unique-stable-id",
  "base_registry_sha256": "64 lowercase hexadecimal characters",
  "base_edition": 1,
  "target_edition": 2,
  "operations": [{"op": "test|add|remove|replace|move|copy", "path": "/..."}],
  "proposer": "named authority",
  "reason": "specific boundary or evidence change",
  "evidence_refs": ["source-or-proof-id"],
  "affected_owners": ["owner-id"],
  "required_reviewers": ["independent-reviewer-id"]
}
```

`operations` use RFC 6902 semantics, but an operation list alone is never authority. The exact base digest prevents accidental application to another registry state.

## Required sequence

1. Verify the base registry against its schema and manifest.
2. Require an exact match of `base_registry_sha256` and `base_edition`.
3. Apply all `test` operations before mutating operations.
4. Re-run namespace, unit-kind, identity, owner, capability and source-authority checks.
5. Rebuild the five graph views, coverage matrices, completeness matrix and implementation order from canonical records.
6. Reject cycles, unknown references, alias collisions, provider leakage, semantic co-ownership, overclaimed completion or unsupported compiler/runtime claims.
7. Run the deliberate-corruption suite.
8. Require affected-owner review; require independent review for sovereign-boundary, compiler-finality, target/runtime or certification changes.
9. Emit a new edition and deterministic package. Never rewrite a published edition in place.

## Identity and edition rules

- Stable identity never embeds its edition and is never recycled.
- Compatible evidence additions may preserve stable identity and increment edition.
- A changed sovereign question, owner or semantic law requires a new stable identity plus explicit supersession or split/merge records.
- Renames preserve the old coordinate as a unique migration alias.
- Removed records become retired evidence; they are not erased from history.
- One logical change may affect many derived files, but those files are regenerated rather than hand-edited.

## Patch conflict rules

Reject a patch when the base digest differs, a path is absent for a required `test`, two patches claim the same new identity or alias, an affected owner is omitted, or the patch changes a derived projection without changing canonical source records. Parallel non-overlapping patches may be rebased only after each is independently revalidated against the new exact digest.

## Certification rule

A registry edition may be structurally verified without being ratified or certified. Ratification and certification require named authorities and evidence external to this package.
