//! Operation contracts owned by `SAN-COMPILER-APPLICATION-CLOSURE`.

pub trait ApplicationClosureContracts {
    /// `verified-closure.input.admit`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_verified_closure_input(
        &self,
        arg0: crate::catalog_types::application_closure::VerifiedClosureInputMaterial,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::VerifiedClosureInput, crate::catalog_types::application_closure::ClosureInputRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.correspondence.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_closure_correspondence(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::ClosureCorrespondenceProof, crate::catalog_types::application_closure::ClosureCorrespondenceRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.semantic.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_semantic_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::SemanticClosureProof, crate::catalog_types::application_closure::SemanticClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.authority.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_authority_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::AuthorityClosureProof, crate::catalog_types::application_closure::AuthorityClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.reference.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_reference_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ReferenceClosureProof, crate::catalog_types::application_closure::ReferenceClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.obligation.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_obligation_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::ObligationCorrespondenceProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.effect.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_effect_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::EffectClosureProof, crate::catalog_types::application_closure::EffectClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.resource.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_resource_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::ResourceClosureProof, crate::catalog_types::application_closure::ResourceClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.evolution.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_evolution_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::EvolutionClosureProof, crate::catalog_types::application_closure::EvolutionClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.assurance.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_assurance_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::AssuranceClosureProof, crate::catalog_types::application_closure::AssuranceClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.build`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_verified_application_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureInput,
        arg1: &crate::catalog_types::application_closure::ClosureProofSet,
        arg2: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::ApplicationClosure, crate::catalog_types::application_closure::ClosureBuildRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.canonical.project`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_verified_application_closure(
        &self,
        arg0: &crate::vertical::ApplicationClosure,
        arg1: &crate::catalog_types::application_closure::ClosureCanonicalContext,
        arg2: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::VerifiedClosureCanonicalProjection, crate::catalog_types::application_closure::ClosureCanonicalRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.fingerprint`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn fingerprint_verified_application_closure(
        &self,
        arg0: &crate::catalog_types::application_closure::VerifiedClosureCanonicalProjection,
        arg1: &crate::waist::DigestContext,
        arg2: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::VerifiedClosureFingerprint, crate::catalog_types::application_closure::ClosureCanonicalRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.verify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_verified_application_closure(
        &self,
        arg0: &crate::vertical::ApplicationClosure,
        arg1: &crate::catalog_types::application_closure::ClosureVerificationContext,
        arg2: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::VerifiedClosureVerificationProof, crate::catalog_types::application_closure::ClosureVerificationRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.explain`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_verified_application_closure(
        &self,
        arg0: &crate::vertical::ApplicationClosure,
        arg1: &crate::catalog_types::application_closure::ClosureExplainQuery,
        arg2: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::VerifiedClosureExplanation, crate::catalog_types::application_closure::ClosureExplainRefusal, crate::waist::CompilerNeedsInput>;

    /// `verified-closure.delta.classify`. Owner: `SAN-COMPILER-APPLICATION-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_verified_closure_delta(
        &self,
        arg0: &crate::vertical::ApplicationClosure,
        arg1: &crate::vertical::ApplicationClosure,
        arg2: &crate::catalog_types::application_closure::ClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::application_closure::VerifiedClosureDelta, crate::catalog_types::application_closure::ClosureEvolutionRefusal, crate::waist::CompilerNeedsInput>;

}
