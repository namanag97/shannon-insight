//! Types owned by `pack_expansion`.

use std::collections::{BTreeMap};

/// Field-complete contract model for `BoundPackInvocation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BoundPackInvocation {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `BoundPackInvocationSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BoundPackInvocationSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ExpandedPackInvocation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExpandedPackInvocation {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `GeneratedSymbolPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeneratedSymbolPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl GeneratedSymbolPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `GeneratedSymbolTemplateSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeneratedSymbolTemplateSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `PackExpansionOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PackExpansionOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::PackExpansionRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `PackExpansionPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PackExpansionPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl PackExpansionPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `PackExpansionProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PackExpansionProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl PackExpansionProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `PackTrustPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PackTrustPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `SelectedPackReleaseSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SelectedPackReleaseSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `VerifiedPackReleaseSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct VerifiedPackReleaseSet {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl VerifiedPackReleaseSet {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}
