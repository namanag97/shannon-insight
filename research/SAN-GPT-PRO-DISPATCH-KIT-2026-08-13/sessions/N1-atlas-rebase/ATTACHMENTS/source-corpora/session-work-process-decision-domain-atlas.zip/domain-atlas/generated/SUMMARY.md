# SAN Work, Process, Decision Domain Atlas

Generated navigation only. JSON and JSONL files are the source of truth.

## Package posture

This package is a research corpus and boundary-hypothesis ledger. It does not mutate or ratify the supplied SAN Global Program Registry and does not define software, runtime, provider, or compiler implementation.

## Counts

- Total independently addressable records: 1897
- Typed relations: 127
- Candidate bounded contexts: 15
- Split proposals: 5
- Merge proposals: 1
- Validation: PASS

## Collections

- `corpus/artifacts.jsonl`: 44 `artifact` records; schema `schemas/records/artifact.schema.json`
- `scenarios/boundary_examples.jsonl`: 12 `boundary_example` records; schema `schemas/records/boundary_example.schema.json`
- `corpus/capabilities.jsonl`: 66 `capability` records; schema `schemas/records/capability.schema.json`
- `corpus/claims.jsonl`: 38 `claim` records; schema `schemas/records/claim.schema.json`
- `corpus/commands.jsonl`: 110 `command` records; schema `schemas/records/command.schema.json`
- `scenarios/competency_questions.jsonl`: 60 `competency_question` records; schema `schemas/records/competency_question.schema.json`
- `corpus/compositions.jsonl`: 10 `composition` records; schema `schemas/records/composition.schema.json`
- `corpus/concepts.jsonl`: 215 `concept` records; schema `schemas/records/concept.schema.json`
- `issues/conflicts.jsonl`: 12 `conflict` records; schema `schemas/issues/conflict.schema.json`
- `corpus/contexts.jsonl`: 34 `context` records; schema `schemas/records/context.schema.json`
- `corpus/context_relationships.jsonl`: 205 `context_relationship` records; schema `schemas/relations/context_relationship.schema.json`
- `corpus/contextual_meanings.jsonl`: 55 `contextual_meaning` records; schema `schemas/records/contextual_meaning.schema.json`
- `corpus/coverage_areas.jsonl`: 16 `coverage_area` records; schema `schemas/records/coverage_area.schema.json`
- `scenarios/cross_domain_examples.jsonl`: 12 `cross_domain_example` records; schema `schemas/records/cross_domain_example.schema.json`
- `registry_intake/disposition_ledger.jsonl`: 34 `disposition_entry` records; schema `schemas/registry_intake/disposition_entry.schema.json`
- `corpus/entities.jsonl`: 44 `entity` records; schema `schemas/records/entity.schema.json`
- `corpus/events.jsonl`: 110 `event` records; schema `schemas/records/event.schema.json`
- `corpus/evidence.jsonl`: 27 `evidence` records; schema `schemas/records/evidence.schema.json`
- `issues/gaps.jsonl`: 12 `gap` records; schema `schemas/issues/gap.schema.json`
- `corpus/laws.jsonl`: 88 `law` records; schema `schemas/records/law.schema.json`
- `corpus/mappings.jsonl`: 25 `mapping` records; schema `schemas/records/mapping.schema.json`
- `registry_intake/merge_split_proposals.jsonl`: 6 `merge_split_proposal` records; schema `schemas/registry_intake/merge_split_proposal.schema.json`
- `scenarios/negative_examples.jsonl`: 12 `negative_example` records; schema `schemas/records/negative_example.schema.json`
- `corpus/policies.jsonl`: 44 `policy` records; schema `schemas/records/policy.schema.json`
- `scenarios/positive_examples.jsonl`: 12 `positive_example` records; schema `schemas/records/positive_example.schema.json`
- `corpus/profiles.jsonl`: 15 `profile` records; schema `schemas/records/profile.schema.json`
- `corpus/queries.jsonl`: 66 `query` records; schema `schemas/records/query.schema.json`
- `corpus/refusals.jsonl`: 88 `refusal` records; schema `schemas/records/refusal.schema.json`
- `registry_intake/candidate_units.jsonl`: 34 `registry_candidate_unit` records; schema `schemas/registry_intake/registry_candidate_unit.schema.json`
- `registry_intake/registry_change_requests.jsonl`: 10 `registry_change_request` records; schema `schemas/registry_intake/registry_change_request.schema.json`
- `registry_intake/existing_record_crosswalk.jsonl`: 67 `registry_crosswalk` records; schema `schemas/registry_intake/registry_crosswalk.schema.json`
- `corpus/relations.jsonl`: 127 `relation` records; schema `schemas/relations/relation.schema.json`
- `corpus/states.jsonl`: 110 `state` records; schema `schemas/records/state.schema.json`
- `issues/unresolved_boundaries.jsonl`: 10 `unresolved_boundary` records; schema `schemas/issues/unresolved_boundary.schema.json`
- `issues/unresolved_references.jsonl`: 1 `unresolved_reference` records; schema `schemas/issues/unresolved_reference.schema.json`
- `corpus/value_objects.jsonl`: 66 `value_object` records; schema `schemas/records/value_object.schema.json`

## Highest-impact open boundaries

- `candidate.work-process-decision.unresolved_boundary.case-reopening-identity`: Case Reopening and Identity
- `candidate.work-process-decision.unresolved_boundary.control-boundary-horizontal`: Horizontal Control Boundary
- `candidate.work-process-decision.unresolved_boundary.investigation-context-or-family`: Investigation: Bounded Context or Semantic Family
- `candidate.work-process-decision.unresolved_boundary.machine-agent-responsibility`: Machine Agent Responsibility
- `candidate.work-process-decision.unresolved_boundary.mental-workload-vs-strain`: Mental Workload, Demand and Strain Boundary
- `candidate.work-process-decision.unresolved_boundary.plan-context-or-composition`: Plan: Context or Composition
- `candidate.work-process-decision.unresolved_boundary.problem-horizontal-stability`: Problem Horizontal Stability
- `candidate.work-process-decision.unresolved_boundary.retrospective-exception`: Retrospective Process Exception
- `candidate.work-process-decision.unresolved_boundary.risk-treatment-owner`: Risk Treatment Ownership
- `candidate.work-process-decision.unresolved_boundary.shared-situation-awareness`: Shared Situation Awareness Boundary
