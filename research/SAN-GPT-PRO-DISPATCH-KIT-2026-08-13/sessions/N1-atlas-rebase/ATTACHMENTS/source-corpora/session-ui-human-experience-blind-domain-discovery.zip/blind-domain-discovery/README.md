# Blind Domain Discovery: User Interaction and Human Experience

- Package: `session-ui-human-experience-blind-domain-discovery`
- Canonical corpus: `corpus/*.jsonl`
- Boundary adjudication: `boundary_analysis/*.jsonl`
- Adversarial and competency scenarios: `scenarios/*.jsonl`
- Conflicts and open research: `issues/*.jsonl`
- Coverage and maturity: `coverage/*.json`
- Schemas: `schemas/*.schema.json` and `schemas/schema-index.json`
- Controlled vocabularies: `vocabularies/controlled_vocabularies.json`
- Entry point and counts: `manifest.json`
- Mechanical results: `VALIDATION.json`
- File integrity: `CHECKSUMS.txt`

## Corpus navigation
- `boundary_analysis/evaluations.jsonl`: 18 evaluations records
- `boundary_analysis/merge_proposals.jsonl`: 6 merge proposals records
- `boundary_analysis/rejected_boundaries.jsonl`: 18 rejected boundaries records
- `boundary_analysis/split_proposals.jsonl`: 8 split proposals records
- `boundary_analysis/unresolved_ownership.jsonl`: 12 unresolved ownership records
- `corpus/artifacts.jsonl`: 45 artifacts records
- `corpus/bounded_contexts.jsonl`: 18 bounded contexts records
- `corpus/capabilities.jsonl`: 43 capabilities records
- `corpus/classification_axes.jsonl`: 16 classification axes records
- `corpus/commands.jsonl`: 75 commands records
- `corpus/compositions.jsonl`: 8 compositions records
- `corpus/concepts.jsonl`: 132 concepts records
- `corpus/context_relationships.jsonl`: 24 context relationships records
- `corpus/contextual_meanings.jsonl`: 42 contextual meanings records
- `corpus/contracts.jsonl`: 24 contracts records
- `corpus/counterexamples.jsonl`: 12 counterexamples records
- `corpus/coverage_areas.jsonl`: 46 coverage areas records
- `corpus/entities.jsonl`: 18 entities records
- `corpus/events.jsonl`: 51 events records
- `corpus/evidence_sources.jsonl`: 30 evidence sources records
- `corpus/examples.jsonl`: 12 examples records
- `corpus/failures.jsonl`: 25 failures records
- `corpus/identities.jsonl`: 18 identities records
- `corpus/invariants.jsonl`: 30 invariants records
- `corpus/laws.jsonl`: 69 laws records
- `corpus/lifecycles.jsonl`: 17 lifecycles records
- `corpus/operators.jsonl`: 25 operators records
- `corpus/policies.jsonl`: 30 policies records
- `corpus/profiles.jsonl`: 13 profiles records
- `corpus/queries.jsonl`: 32 queries records
- `corpus/refusals.jsonl`: 57 refusals records
- `corpus/relations.jsonl`: 59 relations records
- `corpus/states.jsonl`: 133 states records
- `corpus/value_objects.jsonl`: 31 value objects records
- `corpus/vocabulary.jsonl`: 132 vocabulary records
- `issues/conflicts.jsonl`: 12 conflicts records
- `issues/gaps.jsonl`: 18 gaps records
- `issues/unresolved_questions.jsonl`: 18 unresolved questions records
- `scenarios/boundary_examples.jsonl`: 12 boundary examples records
- `scenarios/competency_questions.jsonl`: 60 competency questions records
- `scenarios/cross_domain_examples.jsonl`: 12 cross domain examples records
- `scenarios/negative_examples.jsonl`: 12 negative examples records
- `scenarios/positive_examples.jsonl`: 12 positive examples records

## Boundary navigation
- Candidate boundary records: 18
- Bounded-context candidates: 12
- Foundation algebra candidates: 1
- Semantic family candidates: 3
- Split proposals: 8
- Merge proposals: 6
- Rejected false boundaries: 18

Generated Markdown is navigation only. Canonical meanings and decisions are in JSON and JSONL.
