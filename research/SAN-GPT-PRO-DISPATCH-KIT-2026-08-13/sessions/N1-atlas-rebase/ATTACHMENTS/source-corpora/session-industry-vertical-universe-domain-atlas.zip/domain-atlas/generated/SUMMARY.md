# Generated Navigation Summary

> Navigation only. JSON and JSONL are authoritative.

## Package status

- Validation: **PASS**
- Primary records: **13122**
- General relations: **3673**
- Context relationships: **170**
- Candidate bounded contexts: **290**
- Vertical partitions: **145**
- Profiles: **10**
- Compositions: **12**
- Registry crosswalk records: **209**
- Completeness claim: **NOT CLAIMED**

## Registry-intake dispositions

| Disposition | Count |
|---|---:|
| `CANDIDATE_BOUNDED_CONTEXT` | 284 |
| `COMPOSITION` | 12 |
| `FOUNDATION_ALGEBRA_CANDIDATE` | 1 |
| `MERGE_REQUIRED` | 2 |
| `PROFILE` | 15 |
| `SEMANTIC_FAMILY_CANDIDATE` | 12 |
| `SPLIT_REQUIRED` | 1 |
| `VERTICAL_CONCEPT` | 130 |

## Highest-impact unresolved boundaries

- `candidate.industry-vertical-universe.issue.unresolved-boundary.classification-version-change`: How should an enduring vertical identity survive ISIC, NAICS or NACE revisions and many-to-many code changes?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.clinical-care-public-health`: Which observations and findings cross from individual clinical care into public-health case authority, and under what reporting law and de-identification conditions?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.clinical-research-care`: When does a research intervention become clinical care, and who owns safety, result disclosure and continuing treatment?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.community-data-sovereignty`: Which collective or Indigenous authority may constrain data collection, use, sharing and benefit beyond individual consent?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.energy-market-grid`: Which obligations and events bridge market schedules and physical grid instructions without conflating commercial and operational finality?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.environmental-right-credit`: Who may issue, verify, transfer, retire or invalidate an environmental credit, and how does it relate to physical environmental state?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.financial-infrastructure-versus-participant`: Where do payment, securities and collateral finality reside between participant institutions and infrastructure rulebooks?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.grant-procurement-contract`: When is a transfer a grant, procurement contract, subsidy, prize, benefit or investment, and which selection and performance law applies?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.household-collective-authority`: How should household, family, guardian, caregiver and individual authority interact without erasing autonomy or dependency?
- `candidate.industry-vertical-universe.issue.unresolved-boundary.identity-civil-commercial-clinical`: Which identity correspondence may be reused across civil, commercial, clinical, educational and household contexts without unlawful or unsafe merging?

## Main entry points

- `coverage/coverage_matrix.json`
- `coverage/boundary_evaluation.json`
- `corpus/contexts.jsonl`
- `corpus/relations.jsonl`
- `registry_intake/existing_record_crosswalk.jsonl`
- `registry_intake/merge_split_proposals.jsonl`
- `issues/unresolved_boundaries.jsonl`
- `VALIDATION.json`
