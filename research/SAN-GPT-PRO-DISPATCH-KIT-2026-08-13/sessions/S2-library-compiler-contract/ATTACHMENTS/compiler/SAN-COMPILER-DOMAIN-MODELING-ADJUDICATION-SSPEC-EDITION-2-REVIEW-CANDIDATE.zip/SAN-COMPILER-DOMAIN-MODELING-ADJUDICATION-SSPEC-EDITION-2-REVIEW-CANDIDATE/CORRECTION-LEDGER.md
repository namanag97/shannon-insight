# Correction Ledger

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## 1. TYPE-NAME-CMP008-OBLIGATION-READ-VIEW

- Disposition: `REPLACE`
- Old: `ObligationClosure`
- New: `ObligationClosureReadView`
- Reason: The CSAG consumer must import the one CMP-007 ObligationClosure and may own only a read projection, not a competing closure type.

## 2. ARTIFACT-CMP006

- Disposition: `REPLACE`
- Old: `CMP-006 ApplicationClosure`
- New: `CMP-006 ApplicationBinding`
- Reason: CMP-008 and target/runtime closure can still invalidate the application; CMP-006 is not final closure.

## 3. ARTIFACT-CMP007

- Disposition: `RENAME`
- Old: `ObligationFixedPointClosure`
- New: `ObligationClosure`
- Reason: The fixed-point law remains explicit in proof and invariants; the artifact name is idiomatic and ungenerated.

## 4. ARTIFACT-CMP008

- Disposition: `RETAIN_NAME`
- Old: `VerifiedCsag / VerifiedCSAG proposal`
- New: `Csag`
- Reason: The only public Csag has private fields and owner-only issuance after verification and sealing; a Verified prefix would be redundant.

## 5. ARTIFACT-CMP013

- Disposition: `REPLACE`
- Old: `VerifiedApplicationClosure / VerifiedVerifiedApplicationClosure`
- New: `ApplicationClosure`
- Reason: Final closure is emitted only after CSAG, targets, runtime requirement closure and proof closure; no compatibility alias.

## 6. ARTIFACT-CMP010

- Disposition: `REPLACE`
- Old: `BackendAppRelease / BackendBackendAppRelease`
- New: `AppRelease`
- Reason: The constitutional source defines one portable AppRelease and no lawful BackendAppRelease species.

## 7. STATUS-API

- Disposition: `REPLACE`
- Old: `CURRENT_RUST_CANDIDATE`
- New: `truthful per-symbol implementation evidence`
- Reason: A nonexistent symbol is not current Rust merely because a JSON generator felt optimistic.

## Corpus-wide correction

- 751 type rows now carry complete fields or enum variants, construction visibility, invariants, provenance and budget semantics.
- 394 operations now expose total produced/refused/exhausted/needs-input contracts and truthful per-symbol evidence.
- Every law, contract, refusal and proof obligation records one owner coordinate.
- No Cargo result is claimed.
