# SAN Global Domain-Universe Blind Domain Discovery

This package is a machine-readable research corpus for first-principles discovery of durable problem territories, semantic authorities, candidate bounded contexts, false boundaries, profiles, compositions, artifact flows, and registry-intake proposals.

## Use

1. Read `manifest.json` and `coverage/coverage_matrix.json`.
2. Treat JSON and JSONL as the source of truth.
3. Validate with `python tools/validate_package.py .` from the `blind-domain-discovery` directory.
4. Review `corpus/bounded_contexts.jsonl` together with `boundary_analysis/evaluations.jsonl`, not by name alone.
5. Use `registry_intake/existing_record_crosswalk.jsonl` only as a review queue. It does not mutate or ratify the supplied SAN registry.

## Package-contract reconciliation

The assignment supplied both `domain-atlas/` and `blind-domain-discovery/` layouts. The more specific final work-package contract is used as the archive root: `blind-domain-discovery/`. Collections required only by the broader atlas contract are retained. Canonical candidate context records are in `corpus/bounded_contexts.jsonl`; `corpus/contexts.jsonl` contains a compatibility pointer rather than duplicate records.

## Interpretation limits

A populated record is not proof of completeness, correctness, implementation, execution, admission, ratification, or certification. Boundary dispositions are research proposals. Evidence records support claims but do not substitute for accountable semantic ownership. Similar names across the registry and corpus are not treated as identity.

## Integrity

`CHECKSUMS.txt` contains SHA-256 digests for every package file except itself. ZIP integrity and checksum verification are reported in `VALIDATION.json` and are independently rechecked during deterministic packaging.
