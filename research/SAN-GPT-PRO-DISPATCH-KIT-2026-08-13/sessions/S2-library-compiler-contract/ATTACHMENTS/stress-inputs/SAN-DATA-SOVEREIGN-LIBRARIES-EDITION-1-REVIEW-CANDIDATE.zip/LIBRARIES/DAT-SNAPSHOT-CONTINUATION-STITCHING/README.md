# DAT-SNAPSHOT-CONTINUATION-STITCHING · Snapshot–Continuation Stitching

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

How are a finite source snapshot and subsequent source changes composed into one history without omission, double application, scope mismatch, or transaction incoherence?

## Boundary

Owns:
- snapshot/continuation overlap semantics
- gap-free reconstruction law
- duplicate/conflict handling
- transaction-preserving stitching
- pure reference stitching semantics
- stitch proof obligations

Explicitly excludes:
- connector execution
- checkpoint storage
- source I/O
- provider implementation
- application fact mutation
- generic migration execution
- Data Cut admission authority
- Schema meaning

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- DAT-DATA-CUT
- DAT-SOURCE-SNAPSHOT
- DAT-SOURCE-CONTINUATION
- DAT-SOURCE-CHANGE-STREAM

## Reciprocal semantic seams

- None in this edition.

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
