//! Deterministic, budgeted implementation of the non-vacuous reference vertical.

use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::num::NonZeroU32;

use sha2::{Digest, Sha256};

use crate::stage0::{
    require_available_supplier, verify_stage0_offline, CompilerSupplierRole, PinnedStage0TrustAnchor,
    ReleaseCoordinate, Stage0PackageAuthority,
};
use crate::waist::{
    admit_artifact_ref, AbsenceSemantics, ArtifactRef, AuthorityRef, BudgetDimension, Cardinality,
    CompilerNeedsInput, DigestClaim, Edition, Exhaustion, IdentityRefusal, MissingInputKind,
    PackageLockRef, RegistryKind, SeparationDomain, StableId, StageId, SubjectKey, TotalOutcome,
    WorkBudget, WorkReceipt,
};

use super::model::*;

const APPLICATION_ANCHOR_KIND: &str = "san.csag.application-anchor";
const CSAG_CANONICAL_DOMAIN: &str = "san.csag.canonical.edition-2";
const CSAG_DIGEST_DOMAIN: &str = "san.csag.digest.sha256.edition-2";
const CLOSURE_CANONICAL_DOMAIN: &str = "san.application-closure.canonical.edition-2";
const CLOSURE_DIGEST_DOMAIN: &str = "san.application-closure.digest.sha256.edition-2";
const APP_RELEASE_DOMAIN: &str = "san.app-release.digest.sha256.edition-2";
const DEPLOYMENT_DOMAIN: &str = "san.deployment-plan.digest.sha256.edition-2";

fn checked_add(left: u64, right: u64) -> Option<u64> { left.checked_add(right) }
fn checked_mul(left: u64, right: u64) -> Option<u64> { left.checked_mul(right) }

fn precharge(
    stage: &str,
    input_items: u64,
    input_bytes: u64,
    work_units: u64,
    allocation_bytes: u64,
    output_bytes: u64,
    diagnostics: u64,
    budget: WorkBudget,
) -> Result<WorkReceipt, Exhaustion> {
    let stage_id = StageId::admit(stage).expect("static stage identity");
    for (dimension, required, allowed) in [
        (BudgetDimension::InputItems, input_items, budget.max_input_items),
        (BudgetDimension::InputBytes, input_bytes, budget.max_input_bytes),
        (BudgetDimension::WorkUnits, work_units, budget.max_work_units),
        (BudgetDimension::AllocationBytes, allocation_bytes, budget.max_allocation_bytes),
        (BudgetDimension::OutputBytes, output_bytes, budget.max_output_bytes),
        (BudgetDimension::Diagnostics, diagnostics, budget.max_diagnostics),
    ] {
        if required > allowed {
            return Err(Exhaustion { stage: stage_id, dimension, required, allowed });
        }
    }
    Ok(WorkReceipt {
        stage: stage_id,
        input_items,
        input_bytes,
        work_units,
        allocation_bytes,
        output_bytes,
        diagnostics,
    })
}

fn usize_u64(value: usize) -> Option<u64> { u64::try_from(value).ok() }

fn charge_for_strings<'a>(values: impl IntoIterator<Item = &'a str>) -> Option<u64> {
    values.into_iter().try_fold(0_u64, |sum, value| {
        checked_add(sum, usize_u64(value.len())?)
    })
}

fn encode_u64(output: &mut Vec<u8>, value: u64) { output.extend_from_slice(&value.to_be_bytes()); }
fn encode_u32(output: &mut Vec<u8>, value: u32) { output.extend_from_slice(&value.to_be_bytes()); }
fn encode_bool(output: &mut Vec<u8>, value: bool) { output.push(u8::from(value)); }
fn encode_bytes(output: &mut Vec<u8>, value: &[u8]) {
    encode_u64(output, u64::try_from(value.len()).unwrap_or(u64::MAX));
    output.extend_from_slice(value);
}
fn encode_id(output: &mut Vec<u8>, value: &StableId) { encode_bytes(output, value.as_str().as_bytes()); }
fn encode_release(output: &mut Vec<u8>, value: &ReleaseCoordinate) {
    output.push(match value.kind() {
        RegistryKind::Semantic => 1,
        RegistryKind::Ontology => 2,
        RegistryKind::Data => 3,
        RegistryKind::Ui => 4,
        RegistryKind::Target => 5,
        RegistryKind::Runtime => 6,
    });
    encode_id(output, value.identity());
    encode_u32(output, value.edition().get());
    encode_id(output, value.occurrence().stable());
}
fn encode_artifact(output: &mut Vec<u8>, value: &ArtifactRef) {
    encode_id(output, value.identity());
    encode_u32(output, value.edition().get());
    encode_id(output, value.occurrence().stable());
    output.extend_from_slice(value.digest());
}
fn sha256(value: &[u8]) -> [u8; 32] { Sha256::digest(value).into() }

fn first_owner(owners: &[ReleaseCoordinate]) -> &ReleaseCoordinate {
    owners.first().expect("every proof-bearing stage has at least one selected owner")
}

fn subject_key(
    application: StableId,
    owner: &ReleaseCoordinate,
    package_lock: PackageLockRef,
    stage: StageId,
) -> SubjectKey {
    SubjectKey {
        application,
        release: owner.occurrence().clone(),
        package_lock,
        stage,
        schema: Edition::admit(2).expect("positive static edition"),
    }
}

fn issue_stage_proof(
    stage0: &Stage0PackageAuthority,
    owners: &[ReleaseCoordinate],
    role: CompilerSupplierRole,
    stage: &str,
    application: &StableId,
    canonical: Vec<u8>,
    work: WorkReceipt,
) -> Result<StageProof, CompilerNeedsInput> {
    let mut sorted = if owners.is_empty() {
        all_package_owners(stage0)
    } else {
        owners.to_vec()
    };
    sorted.sort();
    sorted.dedup();
    if sorted.is_empty() {
        return Err(needs_input(
            stage,
            MissingInputKind::Authority,
            vec![application.clone()],
        ));
    }
    let mut witnesses = Vec::with_capacity(sorted.len());
    for owner in &sorted {
        let supplier = require_available_supplier(stage0, owner, role, stage)?;
        let disposition = stage0.disposition(owner, role).ok_or_else(|| {
            needs_input(stage, MissingInputKind::Verifier, vec![owner.identity().clone()])
        })?;
        witnesses.push(StageRoleWitness {
            owner: owner.clone(),
            supplier: supplier.clone(),
            role,
            evidence: disposition.evidence().clone(),
        });
    }
    let stage_id = StageId::admit(stage).expect("static stage identity");
    let digest = sha256(&canonical);
    let subject = subject_key(
        application.clone(),
        first_owner(&sorted),
        stage0.package_lock().reference().clone(),
        stage_id.clone(),
    );
    Ok(StageProof {
        stage: stage_id,
        package_lock: stage0.package_lock().reference().clone(),
        subject,
        canonical,
        digest,
        witnesses,
        work,
    })
}

fn proof_ledger_canonical(proofs: &[StageProof]) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, b"san.proof-ledger.edition-2");
    encode_u64(&mut output, u64::try_from(proofs.len()).unwrap_or(u64::MAX));
    for proof in proofs {
        encode_id(&mut output, proof.stage().stable());
        output.extend_from_slice(proof.digest());
        encode_id(&mut output, proof.subject().application());
        encode_id(&mut output, proof.package_lock().stable());
        encode_u64(&mut output, u64::try_from(proof.witnesses().len()).unwrap_or(u64::MAX));
        for witness in proof.witnesses() {
            encode_release(&mut output, witness.owner());
            encode_release(&mut output, witness.supplier());
            output.extend_from_slice(&(witness.role() as u16).to_be_bytes());
            encode_artifact(&mut output, witness.evidence());
        }
    }
    output
}

fn build_proof_ledger(mut proofs: Vec<StageProof>) -> Result<ProofLedger, ()> {
    proofs.sort_by(|left, right| {
        left.stage().stable().cmp(right.stage().stable())
            .then_with(|| left.digest().cmp(right.digest()))
            .then_with(|| left.subject().release().cmp(right.subject().release()))
    });
    for pair in proofs.windows(2) {
        if pair[0].stage() == pair[1].stage()
            && pair[0].digest() == pair[1].digest()
            && pair[0].subject() == pair[1].subject()
        {
            return Err(());
        }
    }
    let commitment = sha256(&proof_ledger_canonical(&proofs));
    Ok(ProofLedger { proofs, commitment })
}

fn all_package_owners(stage0: &Stage0PackageAuthority) -> Vec<ReleaseCoordinate> {
    stage0.package_lock().releases().cloned().collect()
}

fn semantic_owners(stage0: &Stage0PackageAuthority) -> Vec<ReleaseCoordinate> {
    stage0.package_lock().releases()
        .filter(|release| release.kind() == RegistryKind::Semantic)
        .cloned()
        .collect()
}

fn source_digest(bytes: &[u8]) -> [u8; 32] {
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"san.application-source.edition-2");
    encode_bytes(&mut canonical, bytes);
    sha256(&canonical)
}

#[must_use]
pub fn application_source_digest(bytes: &[u8]) -> [u8; 32] { source_digest(bytes) }

fn constitution_digest(coordinate: &str, edition: u32, bytes: &[u8]) -> [u8; 32] {
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"san.constitution-source.edition-2");
    encode_bytes(&mut canonical, coordinate.as_bytes());
    encode_u32(&mut canonical, edition);
    encode_bytes(&mut canonical, bytes);
    sha256(&canonical)
}

#[must_use]
pub fn admitted_constitution_digest(coordinate: &str, edition: u32, bytes: &[u8]) -> [u8; 32] {
    constitution_digest(coordinate, edition, bytes)
}

pub fn admit_application_source(
    stage0: &Stage0PackageAuthority,
    carrier: ApplicationSourceCarrier,
    budget: WorkBudget,
) -> ExecutableSourceAdmissionOutcome {
    let source_reference_bytes = usize_u64(carrier.source.identity.len())
        .and_then(|identity| checked_add(identity, usize_u64(carrier.source.occurrence.len())?))
        .unwrap_or(u64::MAX);
    let input_bytes = match checked_add(
        usize_u64(carrier.bytes.len()).unwrap_or(u64::MAX),
        source_reference_bytes,
    ) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp001.source-admission", 1, input_bytes, input_bytes, input_bytes, input_bytes, 1, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    if carrier.bytes.is_empty() {
        return TotalOutcome::Refused(ApplicationSourceParsingRefusal::EmptySource);
    }
    let actual = source_digest(&carrier.bytes);
    if actual != carrier.claimed_digest {
        return TotalOutcome::Refused(ApplicationSourceParsingRefusal::SourceDigestMismatch);
    }
    let source = match admit_artifact_ref(carrier.source) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
    };
    let owners = semantic_owners(stage0);
    if owners.is_empty() {
        return TotalOutcome::Refused(ApplicationSourceParsingRefusal::EmptySemanticSelection);
    }
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp001.admitted-source.edition-2");
    encode_artifact(&mut canonical, &source);
    canonical.extend_from_slice(&actual);
    encode_bytes(&mut canonical, &carrier.bytes);
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::SourceDigestVerification,
        "cmp001.source-admission", source.identity(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(AdmittedApplicationSource {
        source,
        bytes: carrier.bytes,
        digest: actual,
        proof,
    })
}

pub fn admit_constitution(
    stage0: &Stage0PackageAuthority,
    carrier: ConstitutionCarrier,
    budget: WorkBudget,
) -> ExecutableConstitutionAdmissionOutcome {
    let input_bytes = usize_u64(carrier.bytes.len())
        .and_then(|value| checked_add(value, usize_u64(carrier.coordinate.len())?));
    let Some(input_bytes) = input_bytes else {
        return TotalOutcome::Refused(DeclarationAdmissionRefusal::ChargeOverflow);
    };
    let work = match precharge(
        "cmp002.constitution-admission", 1, input_bytes, input_bytes, 512, 256, 1, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let actual = constitution_digest(&carrier.coordinate, carrier.edition, &carrier.bytes);
    if actual != carrier.claimed_digest {
        return TotalOutcome::Refused(DeclarationAdmissionRefusal::ConstitutionMismatch);
    }
    let coordinate = match StableId::admit(carrier.coordinate) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(DeclarationAdmissionRefusal::InvalidIdentity(refusal)),
    };
    let edition = match Edition::admit(carrier.edition) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(DeclarationAdmissionRefusal::InvalidIdentity(refusal)),
    };
    let source = match admit_artifact_ref(carrier.source) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(DeclarationAdmissionRefusal::InvalidIdentity(refusal)),
    };
    let owners = all_package_owners(stage0);
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp002.admitted-constitution.edition-2");
    encode_id(&mut canonical, &coordinate);
    encode_u32(&mut canonical, edition.get());
    encode_artifact(&mut canonical, &source);
    canonical.extend_from_slice(&actual);
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::ConstitutionVerification,
        "cmp002.constitution-admission", &coordinate, canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(AdmittedConstitution { source, coordinate, edition, digest: actual, proof })
}

fn parse_registry_kind(value: &str) -> Option<RegistryKind> {
    match value {
        "semantic" => Some(RegistryKind::Semantic),
        "ontology" => Some(RegistryKind::Ontology),
        "data" => Some(RegistryKind::Data),
        "ui" => Some(RegistryKind::Ui),
        "target" => Some(RegistryKind::Target),
        "runtime" => Some(RegistryKind::Runtime),
        _ => None,
    }
}

fn parsed_source_canonical(
    application: &StableId,
    selections: &[ParsedSelection],
    packs: &[StableId],
    decisions: &[ParsedDecisionDirective],
    targets: &[StableId],
    source: &AdmittedApplicationSource,
) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, b"cmp001.parsed-source-set.edition-2");
    encode_id(&mut output, application);
    encode_artifact(&mut output, source.source());
    output.extend_from_slice(source.digest());
    encode_u64(&mut output, u64::try_from(selections.len()).unwrap_or(u64::MAX));
    for selection in selections {
        output.push(match selection.kind {
            RegistryKind::Semantic => 1,
            RegistryKind::Ontology => 2,
            RegistryKind::Data => 3,
            RegistryKind::Ui => 4,
            RegistryKind::Target => 5,
            RegistryKind::Runtime => 6,
        });
        encode_id(&mut output, &selection.identity);
        encode_u32(&mut output, selection.edition.get());
        encode_id(&mut output, selection.occurrence.stable());
    }
    encode_u64(&mut output, u64::try_from(packs.len()).unwrap_or(u64::MAX));
    for pack in packs { encode_id(&mut output, pack); }
    encode_u64(&mut output, u64::try_from(decisions.len()).unwrap_or(u64::MAX));
    for decision in decisions {
        encode_id(&mut output, &decision.decision);
        encode_id(&mut output, &decision.alternative);
    }
    encode_u64(&mut output, u64::try_from(targets.len()).unwrap_or(u64::MAX));
    for target in targets { encode_id(&mut output, target); }
    output
}

pub fn parse_application_source(
    stage0: &Stage0PackageAuthority,
    source: AdmittedApplicationSource,
    budget: WorkBudget,
) -> ExecutableParseOutcome {
    let text = match std::str::from_utf8(source.bytes()) {
        Ok(value) => value,
        Err(_) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidUtf8),
    };
    let line_count = text.lines().count();
    let input_items = match usize_u64(line_count) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::ChargeOverflow),
    };
    let input_bytes = match usize_u64(source.bytes().len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::ChargeOverflow),
    };
    let work_units = match checked_mul(input_bytes, 3) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp001.parse", input_items, input_bytes, work_units,
        input_bytes.saturating_mul(2), input_bytes.saturating_mul(2), input_items, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };

    let mut application: Option<StableId> = None;
    let mut selections = Vec::new();
    let mut packs = Vec::new();
    let mut decisions = Vec::new();
    let mut targets = Vec::new();
    let mut selection_ids = BTreeSet::new();
    let mut pack_ids = BTreeSet::new();
    let mut decision_ids = BTreeSet::new();
    let mut target_ids = BTreeSet::new();

    for (zero_index, raw_line) in text.lines().enumerate() {
        let line_number = u64::try_from(zero_index + 1).unwrap_or(u64::MAX);
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        let parts: Vec<&str> = line.split_whitespace().collect();
        let malformed = || ApplicationSourceParsingRefusal::MalformedStatement {
            line: line_number,
            statement: line.chars().take(160).collect(),
        };
        match parts.as_slice() {
            ["application", identity] => {
                if application.is_some() {
                    return TotalOutcome::Refused(ApplicationSourceParsingRefusal::DuplicateApplication);
                }
                application = Some(match StableId::admit(*identity) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                });
            }
            ["select", kind, identity, edition, occurrence] => {
                let Some(kind) = parse_registry_kind(kind) else {
                    return TotalOutcome::Refused(malformed());
                };
                let identity = match StableId::admit(*identity) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                };
                if !selection_ids.insert((kind, identity.clone())) {
                    return TotalOutcome::Refused(ApplicationSourceParsingRefusal::DuplicateSelection { release: identity });
                }
                let edition_number = match edition.parse::<u32>() {
                    Ok(value) => value,
                    Err(_) => return TotalOutcome::Refused(malformed()),
                };
                let edition = match Edition::admit(edition_number) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                };
                let occurrence = match crate::waist::OccurrenceId::admit(*occurrence) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                };
                selections.push(ParsedSelection { kind, identity, edition, occurrence });
            }
            ["pack", pack] => {
                let pack = match StableId::admit(*pack) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                };
                if !pack_ids.insert(pack.clone()) {
                    return TotalOutcome::Refused(ApplicationSourceParsingRefusal::DuplicatePack { pack });
                }
                packs.push(pack);
            }
            ["decision", decision, alternative] => {
                let decision = match StableId::admit(*decision) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                };
                if !decision_ids.insert(decision.clone()) {
                    return TotalOutcome::Refused(ApplicationSourceParsingRefusal::DuplicateDecision { decision });
                }
                let alternative = match StableId::admit(*alternative) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                };
                decisions.push(ParsedDecisionDirective { decision, alternative });
            }
            ["target", target] => {
                let target = match StableId::admit(*target) {
                    Ok(value) => value,
                    Err(refusal) => return TotalOutcome::Refused(ApplicationSourceParsingRefusal::InvalidIdentity(refusal)),
                };
                if !target_ids.insert(target.clone()) {
                    return TotalOutcome::Refused(ApplicationSourceParsingRefusal::DuplicateTarget { target });
                }
                targets.push(target);
            }
            _ => return TotalOutcome::Refused(malformed()),
        }
    }
    let Some(application) = application else {
        return TotalOutcome::Refused(ApplicationSourceParsingRefusal::MissingApplication);
    };
    if selections.iter().all(|selection| selection.kind != RegistryKind::Semantic) {
        return TotalOutcome::Refused(ApplicationSourceParsingRefusal::EmptySemanticSelection);
    }
    selections.sort_by(|left, right| (left.kind, &left.identity, left.edition, &left.occurrence)
        .cmp(&(right.kind, &right.identity, right.edition, &right.occurrence)));
    packs.sort();
    decisions.sort_by(|left, right| left.decision.cmp(&right.decision));
    targets.sort();
    let canonical = parsed_source_canonical(&application, &selections, &packs, &decisions, &targets, &source);
    let owners = semantic_owners(stage0);
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::NameDeclarationProjection,
        "cmp001.parse", &application, canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(ParsedSourceSet {
        application,
        selections,
        packs,
        decisions,
        targets,
        source,
        proof,
    })
}

pub fn admit_application_declarations(
    stage0: &Stage0PackageAuthority,
    constitution: &AdmittedConstitution,
    parsed: ParsedSourceSet,
    budget: WorkBudget,
) -> ExecutableDeclarationAdmissionOutcome {
    let item_count = match usize_u64(parsed.selections().len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DeclarationAdmissionRefusal::ChargeOverflow),
    };
    let work_units = match checked_mul(item_count, 58) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DeclarationAdmissionRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp002.declaration-admission", item_count, item_count.saturating_mul(96), work_units,
        item_count.saturating_mul(192), item_count.saturating_mul(128), item_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    if constitution.coordinate().as_str() != "san.pure-library-constitution" {
        return TotalOutcome::Refused(DeclarationAdmissionRefusal::ConstitutionMismatch);
    }
    let mut selected_semantic_families = Vec::new();
    let mut selected_targets = Vec::new();
    for selection in parsed.selections() {
        let Some(selected) = stage0.package_lock().selected(&selection.identity, selection.kind) else {
            return TotalOutcome::Refused(DeclarationAdmissionRefusal::UnselectedRelease {
                release: selection.identity.clone(),
            });
        };
        if selected.edition() != selection.edition || selected.occurrence() != &selection.occurrence {
            return TotalOutcome::Refused(DeclarationAdmissionRefusal::EditionOrOccurrenceMismatch {
                release: selection.identity.clone(),
            });
        }
        match selection.kind {
            RegistryKind::Semantic => selected_semantic_families.push(selected.clone()),
            RegistryKind::Target => selected_targets.push(selection.identity.clone()),
            _ => {
                return TotalOutcome::Refused(DeclarationAdmissionRefusal::NonSemanticFamilySelected {
                    release: selection.identity.clone(),
                });
            }
        }
    }
    selected_semantic_families.sort();
    selected_semantic_families.dedup();
    if selected_semantic_families.len() < 2 {
        return TotalOutcome::Refused(DeclarationAdmissionRefusal::FewerThanTwoSemanticFamilies);
    }
    selected_targets.sort();
    selected_targets.dedup();
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp002.admitted-declarations.edition-2");
    encode_id(&mut canonical, parsed.application());
    encode_id(&mut canonical, constitution.coordinate());
    canonical.extend_from_slice(constitution.digest());
    for release in &selected_semantic_families { encode_release(&mut canonical, release); }
    for target in &selected_targets { encode_id(&mut canonical, target); }
    let proof = match issue_stage_proof(
        stage0, &selected_semantic_families, CompilerSupplierRole::OwnerAdmission,
        "cmp002.declaration-admission", parsed.application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(AdmittedDeclarationSet {
        parsed,
        selected_semantic_families,
        selected_targets,
        proof,
    })
}

pub fn bind_application_names(
    stage0: &Stage0PackageAuthority,
    declarations: AdmittedDeclarationSet,
    budget: WorkBudget,
) -> ExecutableNameBindingOutcome {
    let count = match usize_u64(declarations.selected_semantic_families().len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(NameBindingRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp003.name-binding", count, count.saturating_mul(96), count.saturating_mul(8),
        count.saturating_mul(160), count.saturating_mul(128), count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut release_bindings = BTreeMap::new();
    for release in declarations.selected_semantic_families() {
        if release_bindings.insert(release.identity().clone(), release.clone()).is_some() {
            return TotalOutcome::Refused(NameBindingRefusal::AmbiguousRelease {
                release: release.identity().clone(),
            });
        }
        if !stage0.package_lock().contains(release) {
            return TotalOutcome::Refused(NameBindingRefusal::UnknownRelease {
                release: release.identity().clone(),
            });
        }
    }
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp003.bound-declaration-graph.edition-2");
    encode_id(&mut canonical, declarations.parsed().application());
    for (identity, release) in &release_bindings {
        encode_id(&mut canonical, identity);
        encode_release(&mut canonical, release);
    }
    let owners: Vec<_> = release_bindings.values().cloned().collect();
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::NameDeclarationProjection,
        "cmp003.name-binding", declarations.parsed().application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(BoundDeclarationGraph { declarations, release_bindings, proof })
}

fn cardinality_from_carrier(value: &CardinalityCarrier) -> Result<Cardinality, IdentityRefusal> {
    match value {
        CardinalityCarrier::ExactlyOne => Ok(Cardinality::ExactlyOne),
        CardinalityCarrier::ZeroOrOne => Ok(Cardinality::ZeroOrOne),
        CardinalityCarrier::OneOrMore => Ok(Cardinality::OneOrMore),
        CardinalityCarrier::Exact(value) => NonZeroU32::new(*value)
            .map(Cardinality::Exact)
            .ok_or(IdentityRefusal::NonPositiveEdition),
    }
}

fn encode_cardinality(output: &mut Vec<u8>, value: &CardinalityCarrier) {
    match value {
        CardinalityCarrier::ExactlyOne => output.push(1),
        CardinalityCarrier::ZeroOrOne => output.push(2),
        CardinalityCarrier::OneOrMore => output.push(3),
        CardinalityCarrier::Exact(value) => {
            output.push(4);
            encode_u32(output, *value);
        }
    }
}

fn encode_string_map(output: &mut Vec<u8>, values: &BTreeMap<String, String>) {
    encode_u64(output, u64::try_from(values.len()).unwrap_or(u64::MAX));
    for (key, value) in values {
        encode_bytes(output, key.as_bytes());
        encode_bytes(output, value.as_bytes());
    }
}

fn family_descriptor_carrier_canonical(carrier: &FamilyDescriptorCarrier) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, b"san.family-descriptor.edition-2");
    encode_bytes(&mut output, carrier.release_identity.as_bytes());
    encode_bytes(&mut output, carrier.owner_authority.as_bytes());
    encode_bytes(&mut output, carrier.descriptor_artifact.identity.as_bytes());
    encode_u32(&mut output, carrier.descriptor_artifact.edition);
    encode_bytes(&mut output, carrier.descriptor_artifact.occurrence.as_bytes());
    output.extend_from_slice(&carrier.descriptor_artifact.digest);
    encode_u64(&mut output, u64::try_from(carrier.packs.len()).unwrap_or(u64::MAX));
    for pack in &carrier.packs {
        encode_bytes(&mut output, pack.pack.as_bytes());
        encode_u64(&mut output, u64::try_from(pack.requirements.len()).unwrap_or(u64::MAX));
        for requirement in &pack.requirements {
            encode_bytes(&mut output, requirement.identity.as_bytes());
            encode_bytes(&mut output, requirement.contract.as_bytes());
            encode_cardinality(&mut output, &requirement.cardinality);
            encode_string_map(&mut output, &requirement.constraints);
        }
        encode_u64(&mut output, u64::try_from(pack.offers.len()).unwrap_or(u64::MAX));
        for offer in &pack.offers {
            encode_bytes(&mut output, offer.identity.as_bytes());
            encode_bytes(&mut output, offer.contract.as_bytes());
            encode_u32(&mut output, offer.capacity);
            encode_string_map(&mut output, &offer.constraints);
            encode_u64(&mut output, u64::try_from(offer.provided_facts.len()).unwrap_or(u64::MAX));
            for fact in &offer.provided_facts { encode_bytes(&mut output, fact.as_bytes()); }
        }
        encode_u64(&mut output, u64::try_from(pack.decisions.len()).unwrap_or(u64::MAX));
        for decision in &pack.decisions {
            encode_bytes(&mut output, decision.identity.as_bytes());
            encode_bool(&mut output, decision.required);
            encode_u64(&mut output, u64::try_from(decision.alternatives.len()).unwrap_or(u64::MAX));
            for alternative in &decision.alternatives { encode_bytes(&mut output, alternative.as_bytes()); }
        }
        encode_u64(&mut output, u64::try_from(pack.obligations.len()).unwrap_or(u64::MAX));
        for obligation in &pack.obligations {
            encode_bytes(&mut output, obligation.identity.as_bytes());
            encode_bytes(&mut output, obligation.owner.as_bytes());
            encode_bytes(&mut output, obligation.required_fact.as_bytes());
        }
        encode_u64(&mut output, u64::try_from(pack.obligation_rules.len()).unwrap_or(u64::MAX));
        for rule in &pack.obligation_rules {
            encode_bytes(&mut output, rule.identity.as_bytes());
            encode_u64(&mut output, u64::try_from(rule.premises.len()).unwrap_or(u64::MAX));
            for premise in &rule.premises { encode_bytes(&mut output, premise.as_bytes()); }
            encode_bytes(&mut output, rule.conclusion.as_bytes());
        }
        encode_u64(&mut output, u64::try_from(pack.runtime_requirements.len()).unwrap_or(u64::MAX));
        for requirement in &pack.runtime_requirements {
            encode_bytes(&mut output, requirement.identity.as_bytes());
            encode_bytes(&mut output, requirement.capability.as_bytes());
            encode_cardinality(&mut output, &requirement.cardinality);
            output.push(match requirement.absence {
                AbsenceSemantics::Required => 1,
                AbsenceSemantics::OptionalExplicit => 2,
                AbsenceSemantics::InapplicableWithReason => 3,
            });
        }
        encode_u64(&mut output, u64::try_from(pack.initial_facts.len()).unwrap_or(u64::MAX));
        for fact in &pack.initial_facts { encode_bytes(&mut output, fact.as_bytes()); }
    }
    encode_u64(&mut output, u64::try_from(carrier.authority_dependencies.len()).unwrap_or(u64::MAX));
    for dependency in &carrier.authority_dependencies {
        encode_bytes(&mut output, dependency.from.as_bytes());
        encode_bytes(&mut output, dependency.to.as_bytes());
    }
    output
}

#[must_use]
pub fn family_descriptor_digest(carrier: &FamilyDescriptorCarrier) -> [u8; 32] {
    sha256(&family_descriptor_carrier_canonical(carrier))
}

fn admit_id_map(values: BTreeMap<String, String>) -> Result<BTreeMap<StableId, StableId>, IdentityRefusal> {
    let mut result = BTreeMap::new();
    for (key, value) in values {
        result.insert(StableId::admit(key)?, StableId::admit(value)?);
    }
    Ok(result)
}

fn admit_pack(
    carrier: PackContributionCarrier,
    owner: &ReleaseCoordinate,
) -> Result<PackContribution, IdentityRefusal> {
    let pack = StableId::admit(carrier.pack)?;
    let mut requirements = Vec::with_capacity(carrier.requirements.len());
    let mut requirement_ids = BTreeSet::new();
    for value in carrier.requirements {
        let identity = StableId::admit(value.identity)?;
        if !requirement_ids.insert(identity.clone()) { return Err(IdentityRefusal::Empty); }
        requirements.push(ContractRequirementSpec {
            identity,
            contract: StableId::admit(value.contract)?,
            cardinality: cardinality_from_carrier(&value.cardinality)?,
            constraints: admit_id_map(value.constraints)?,
            owner: owner.clone(),
        });
    }
    let mut offers = Vec::with_capacity(carrier.offers.len());
    let mut offer_ids = BTreeSet::new();
    for value in carrier.offers {
        let identity = StableId::admit(value.identity)?;
        if value.capacity == 0 || !offer_ids.insert(identity.clone()) { return Err(IdentityRefusal::Empty); }
        let provided_facts = value.provided_facts.into_iter()
            .map(StableId::admit)
            .collect::<Result<BTreeSet<_>, _>>()?;
        offers.push(ContractOfferSpec {
            identity,
            contract: StableId::admit(value.contract)?,
            capacity: value.capacity,
            constraints: admit_id_map(value.constraints)?,
            provided_facts,
            owner: owner.clone(),
        });
    }
    let mut decisions = Vec::with_capacity(carrier.decisions.len());
    let mut decision_ids = BTreeSet::new();
    for value in carrier.decisions {
        let identity = StableId::admit(value.identity)?;
        if !decision_ids.insert(identity.clone()) { return Err(IdentityRefusal::Empty); }
        let alternatives = value.alternatives.into_iter()
            .map(StableId::admit)
            .collect::<Result<BTreeSet<_>, _>>()?;
        if alternatives.is_empty() { return Err(IdentityRefusal::Empty); }
        decisions.push(DecisionSpec { identity, alternatives, required: value.required, owner: owner.clone() });
    }
    let mut obligations = Vec::with_capacity(carrier.obligations.len());
    let mut obligation_ids = BTreeSet::new();
    for value in carrier.obligations {
        let identity = StableId::admit(value.identity)?;
        if !obligation_ids.insert(identity.clone()) { return Err(IdentityRefusal::Empty); }
        obligations.push(ObligationSpec {
            identity,
            owner_identity: AuthorityRef::admit(value.owner)?,
            required_fact: StableId::admit(value.required_fact)?,
            release_owner: owner.clone(),
        });
    }
    let mut obligation_rules = Vec::with_capacity(carrier.obligation_rules.len());
    let mut rule_ids = BTreeSet::new();
    for value in carrier.obligation_rules {
        let identity = StableId::admit(value.identity)?;
        if !rule_ids.insert(identity.clone()) { return Err(IdentityRefusal::Empty); }
        let premises = value.premises.into_iter()
            .map(StableId::admit)
            .collect::<Result<BTreeSet<_>, _>>()?;
        if premises.is_empty() { return Err(IdentityRefusal::Empty); }
        obligation_rules.push(ObligationRuleSpec {
            identity,
            premises,
            conclusion: StableId::admit(value.conclusion)?,
            owner: owner.clone(),
        });
    }
    let mut runtime_requirements = Vec::with_capacity(carrier.runtime_requirements.len());
    let mut runtime_ids = BTreeSet::new();
    for value in carrier.runtime_requirements {
        let identity = StableId::admit(value.identity)?;
        if !runtime_ids.insert(identity.clone()) { return Err(IdentityRefusal::Empty); }
        runtime_requirements.push(RuntimeRequirementSpec {
            identity,
            capability: StableId::admit(value.capability)?,
            cardinality: cardinality_from_carrier(&value.cardinality)?,
            absence: value.absence,
            owner: owner.clone(),
        });
    }
    let initial_facts = carrier.initial_facts.into_iter()
        .map(StableId::admit)
        .collect::<Result<BTreeSet<_>, _>>()?;
    Ok(PackContribution {
        pack,
        owner: owner.clone(),
        requirements,
        offers,
        decisions,
        obligations,
        obligation_rules,
        runtime_requirements,
        initial_facts,
    })
}

pub fn admit_family_descriptors(
    stage0: &Stage0PackageAuthority,
    carriers: Vec<FamilyDescriptorCarrier>,
    application: &StableId,
    budget: WorkBudget,
) -> ExecutableFamilyDescriptorOutcome {
    let item_count = match usize_u64(carriers.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(FamilyCompilationRefusal::ChargeOverflow),
    };
    let input_bytes = match carriers.iter().try_fold(0_u64, |sum, carrier| {
        checked_add(sum, usize_u64(family_descriptor_carrier_canonical(carrier).len())?)
    }) {
        Some(value) => value,
        None => return TotalOutcome::Refused(FamilyCompilationRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp005.family-descriptor-admission", item_count, input_bytes,
        input_bytes.saturating_mul(2), input_bytes, input_bytes, item_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut descriptors = BTreeMap::new();
    let mut owners = Vec::new();
    for carrier in carriers {
        let release_identity = match StableId::admit(carrier.release_identity.clone()) {
            Ok(value) => value,
            Err(_) => return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing {
                release: StableId::admit("invalid.release").expect("static identity"),
            }),
        };
        let Some(release) = stage0.package_lock().selected(&release_identity, RegistryKind::Semantic).cloned() else {
            return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing { release: release_identity });
        };
        let actual = family_descriptor_digest(&carrier);
        if actual != carrier.claimed_digest
            || stage0.package_lock().descriptor_digest(&release).copied() != Some(actual)
        {
            return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorDigestDrift {
                release: release.identity().clone(),
            });
        }
        let owner_authority = match AuthorityRef::admit(carrier.owner_authority) {
            Ok(value) => value,
            Err(_) => return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing {
                release: release.identity().clone(),
            }),
        };
        let artifact = match admit_artifact_ref(carrier.descriptor_artifact) {
            Ok(value) => value,
            Err(_) => return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing {
                release: release.identity().clone(),
            }),
        };
        let mut packs = BTreeMap::new();
        for pack_carrier in carrier.packs {
            let pack = match admit_pack(pack_carrier, &release) {
                Ok(value) => value,
                Err(_) => return TotalOutcome::Refused(FamilyCompilationRefusal::CrossOwnerContribution {
                    pack: StableId::admit("invalid.pack").expect("static identity"),
                }),
            };
            let identity = pack.pack.clone();
            if packs.insert(identity.clone(), pack).is_some() {
                return TotalOutcome::Refused(FamilyCompilationRefusal::CrossOwnerContribution { pack: identity });
            }
        }
        let mut authority_dependencies = Vec::new();
        for dependency in carrier.authority_dependencies {
            authority_dependencies.push(AuthorityDependency {
                from: match AuthorityRef::admit(dependency.from) {
                    Ok(value) => value,
                    Err(_) => return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing {
                        release: release.identity().clone(),
                    }),
                },
                to: match AuthorityRef::admit(dependency.to) {
                    Ok(value) => value,
                    Err(_) => return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing {
                        release: release.identity().clone(),
                    }),
                },
                owner: release.clone(),
            });
        }
        owners.push(release.clone());
        if descriptors.insert(release.identity().clone(), FamilyDescriptor {
            release,
            owner_authority,
            descriptor_artifact: artifact,
            packs,
            authority_dependencies,
            digest: actual,
        }).is_some() {
            return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing { release: release_identity });
        }
    }
    if descriptors.len() < 2 {
        return TotalOutcome::Refused(FamilyCompilationRefusal::NoSemanticFamilySelected);
    }
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp005.family-descriptor-set.edition-2");
    encode_id(&mut canonical, application);
    for descriptor in descriptors.values() {
        encode_release(&mut canonical, &descriptor.release);
        encode_artifact(&mut canonical, &descriptor.descriptor_artifact);
        canonical.extend_from_slice(&descriptor.digest);
    }
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::CompilerFamilySurfaceVerification,
        "cmp005.family-descriptor-admission", application, canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(FamilyDescriptorSet { descriptors, proof })
}

pub fn expand_application_packs(
    stage0: &Stage0PackageAuthority,
    bound: BoundDeclarationGraph,
    descriptors: FamilyDescriptorSet,
    budget: WorkBudget,
) -> ExecutablePackExpansionOutcome {
    let requested = bound.declarations.parsed().packs().to_vec();
    let pack_count = match usize_u64(requested.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(PackExpansionRefusal::ChargeOverflow),
    };
    let descriptor_count = match usize_u64(descriptors.descriptors().len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(PackExpansionRefusal::ChargeOverflow),
    };
    let work_units = match checked_mul(pack_count, descriptor_count.saturating_add(1)) {
        Some(value) => value,
        None => return TotalOutcome::Refused(PackExpansionRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp004.pack-expansion", pack_count.saturating_add(descriptor_count),
        pack_count.saturating_mul(96), work_units, pack_count.saturating_mul(1024),
        pack_count.saturating_mul(1024), pack_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut contributions = Vec::new();
    let mut owner_pack_counts: BTreeMap<StableId, u64> = BTreeMap::new();
    for requested_pack in requested {
        let matches: Vec<&PackContribution> = descriptors.descriptors().values()
            .filter_map(|descriptor| descriptor.packs.get(&requested_pack))
            .collect();
        match matches.as_slice() {
            [] => return TotalOutcome::Refused(PackExpansionRefusal::UnknownPack { pack: requested_pack }),
            [pack] => {
                if !bound.release_bindings().values().any(|release| release == &pack.owner) {
                    return TotalOutcome::Refused(PackExpansionRefusal::PackOwnedByUnselectedRelease {
                        pack: requested_pack,
                    });
                }
                *owner_pack_counts.entry(pack.owner.identity().clone()).or_default() += 1;
                contributions.push((*pack).clone());
            }
            _ => return TotalOutcome::Refused(PackExpansionRefusal::DuplicatePack { pack: requested_pack }),
        }
    }
    for release in bound.release_bindings().values() {
        if owner_pack_counts.get(release.identity()).copied().unwrap_or(0) == 0 {
            return TotalOutcome::Refused(PackExpansionRefusal::UnknownPack {
                pack: release.identity().clone(),
            });
        }
    }
    contributions.sort_by(|left, right| left.pack.cmp(&right.pack));
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp004.expanded-contribution-set.edition-2");
    encode_id(&mut canonical, bound.declarations.parsed().application());
    for contribution in &contributions {
        encode_id(&mut canonical, &contribution.pack);
        encode_release(&mut canonical, &contribution.owner);
        encode_u64(&mut canonical, u64::try_from(contribution.requirements.len()).unwrap_or(u64::MAX));
        encode_u64(&mut canonical, u64::try_from(contribution.offers.len()).unwrap_or(u64::MAX));
        encode_u64(&mut canonical, u64::try_from(contribution.decisions.len()).unwrap_or(u64::MAX));
        encode_u64(&mut canonical, u64::try_from(contribution.obligations.len()).unwrap_or(u64::MAX));
    }
    let owners: Vec<_> = contributions.iter().map(|value| value.owner.clone()).collect();
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::PackVerification,
        "cmp004.pack-expansion", bound.declarations.parsed().application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(ExpandedContributionSet { bound, descriptors, contributions, proof })
}

pub fn resolve_application_decisions(
    stage0: &Stage0PackageAuthority,
    expanded: ExpandedContributionSet,
    budget: WorkBudget,
) -> ExecutableDecisionResolutionOutcome {
    let declaration_count: usize = expanded.contributions().iter()
        .map(|contribution| contribution.decisions.len())
        .sum();
    let directive_count = expanded.bound().declarations.parsed().decisions().len();
    let total = match declaration_count.checked_add(directive_count).and_then(usize_u64) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DecisionResolutionRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp004.decision-resolution", total, total.saturating_mul(96), total.saturating_mul(8),
        total.saturating_mul(256), total.saturating_mul(128), total, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut declarations: BTreeMap<StableId, DecisionSpec> = BTreeMap::new();
    for contribution in expanded.contributions() {
        for decision in &contribution.decisions {
            if declarations.insert(decision.identity.clone(), decision.clone()).is_some() {
                return TotalOutcome::Refused(DecisionResolutionRefusal::DuplicateDecisionDeclaration {
                    decision: decision.identity.clone(),
                });
            }
        }
    }
    let mut directives = BTreeMap::new();
    for directive in expanded.bound().declarations.parsed().decisions() {
        if !declarations.contains_key(&directive.decision) {
            return TotalOutcome::Refused(DecisionResolutionRefusal::UnknownDecisionDirective {
                decision: directive.decision.clone(),
            });
        }
        if directives.insert(directive.decision.clone(), directive.alternative.clone()).is_some() {
            return TotalOutcome::Refused(DecisionResolutionRefusal::ConflictingDirective {
                decision: directive.decision.clone(),
            });
        }
    }
    let mut decisions = BTreeMap::new();
    for (identity, declaration) in declarations {
        let Some(alternative) = directives.get(&identity).cloned() else {
            if declaration.required {
                return TotalOutcome::NeedsInput(needs_input(
                    "cmp004.decision-resolution", MissingInputKind::Decision, vec![identity],
                ));
            }
            continue;
        };
        if !declaration.alternatives.contains(&alternative) {
            return TotalOutcome::Refused(DecisionResolutionRefusal::InvalidAlternative {
                decision: identity,
                alternative,
            });
        }
        decisions.insert(identity.clone(), ResolvedDecision {
            identity,
            alternative,
            owner: declaration.owner,
        });
    }
    if decisions.is_empty() {
        return TotalOutcome::Refused(DecisionResolutionRefusal::NoResolvedDecision);
    }
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp004.resolved-decision-set.edition-2");
    encode_id(&mut canonical, expanded.bound().declarations.parsed().application());
    for decision in decisions.values() {
        encode_id(&mut canonical, &decision.identity);
        encode_id(&mut canonical, &decision.alternative);
        encode_release(&mut canonical, &decision.owner);
    }
    let owners: Vec<_> = decisions.values().map(|decision| decision.owner.clone()).collect();
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::DecisionAlgebra,
        "cmp004.decision-resolution", expanded.bound().declarations.parsed().application(),
        canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(ResolvedDecisionSet { expanded, decisions, proof })
}

pub fn compile_family_plans(
    stage0: &Stage0PackageAuthority,
    decisions: ResolvedDecisionSet,
    budget: WorkBudget,
) -> ExecutableFamilyPlanOutcome {
    let family_count = decisions.expanded.bound().release_bindings().len();
    let contribution_count = decisions.expanded.contributions().len();
    let total = match family_count.checked_add(contribution_count).and_then(usize_u64) {
        Some(value) => value,
        None => return TotalOutcome::Refused(FamilyCompilationRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp005.family-compilation", total, total.saturating_mul(256), total.saturating_mul(16),
        total.saturating_mul(2048), total.saturating_mul(2048), total, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut plans = Vec::new();
    for release in decisions.expanded.bound().release_bindings().values() {
        let Some(descriptor) = decisions.expanded.descriptors().descriptors().get(release.identity()) else {
            return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorMissing {
                release: release.identity().clone(),
            });
        };
        if decisions.expanded.descriptors().descriptors().get(release.identity())
            .map(|value| value.digest)
            != stage0.package_lock().descriptor_digest(release).copied()
        {
            return TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorDigestDrift {
                release: release.identity().clone(),
            });
        }
        let contributions: Vec<&PackContribution> = decisions.expanded.contributions().iter()
            .filter(|contribution| contribution.owner == *release)
            .collect();
        if contributions.is_empty() {
            return TotalOutcome::Refused(FamilyCompilationRefusal::PlanlessFamilyForbidden {
                release: release.identity().clone(),
            });
        }
        let mut packs = Vec::new();
        let mut requirements = Vec::new();
        let mut offers = Vec::new();
        let mut obligations = Vec::new();
        let mut obligation_rules = Vec::new();
        let mut runtime_requirements = Vec::new();
        let mut initial_facts = BTreeSet::new();
        for contribution in contributions {
            packs.push(contribution.pack.clone());
            requirements.extend(contribution.requirements.clone());
            offers.extend(contribution.offers.clone());
            obligations.extend(contribution.obligations.clone());
            obligation_rules.extend(contribution.obligation_rules.clone());
            runtime_requirements.extend(contribution.runtime_requirements.clone());
            initial_facts.extend(contribution.initial_facts.clone());
        }
        packs.sort();
        requirements.sort_by(|left, right| left.identity.cmp(&right.identity));
        offers.sort_by(|left, right| left.identity.cmp(&right.identity));
        obligations.sort_by(|left, right| left.identity.cmp(&right.identity));
        obligation_rules.sort_by(|left, right| left.identity.cmp(&right.identity));
        runtime_requirements.sort_by(|left, right| left.identity.cmp(&right.identity));
        let mut canonical = Vec::new();
        encode_bytes(&mut canonical, b"cmp005.family-plan.edition-2");
        encode_release(&mut canonical, release);
        for pack in &packs { encode_id(&mut canonical, pack); }
        for requirement in &requirements {
            encode_id(&mut canonical, &requirement.identity);
            encode_id(&mut canonical, &requirement.contract);
        }
        for offer in &offers {
            encode_id(&mut canonical, &offer.identity);
            encode_id(&mut canonical, &offer.contract);
        }
        for obligation in &obligations {
            encode_id(&mut canonical, &obligation.identity);
            encode_id(&mut canonical, &obligation.required_fact);
        }
        let proof = match issue_stage_proof(
            stage0, std::slice::from_ref(release), CompilerSupplierRole::FamilyCompilation,
            "cmp005.family-compilation", decisions.expanded.bound().declarations.parsed().application(),
            canonical, work.clone(),
        ) {
            Ok(value) => value,
            Err(needs) => return TotalOutcome::NeedsInput(needs),
        };
        plans.push(FamilyPlan {
            release: release.clone(),
            semantic_owner: descriptor.owner_authority.clone(),
            packs,
            requirements,
            offers,
            obligations,
            obligation_rules,
            runtime_requirements,
            initial_facts,
            authority_dependencies: descriptor.authority_dependencies.clone(),
            proof,
        });
    }
    plans.sort_by(|left, right| left.release.cmp(&right.release));
    if plans.iter().any(|plan| plan.packs.is_empty()) {
        let release = plans.iter().find(|plan| plan.packs.is_empty()).expect("checked").release.identity().clone();
        return TotalOutcome::Refused(FamilyCompilationRefusal::PlanlessFamilyForbidden { release });
    }
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp005.family-plan-set.edition-2");
    encode_id(&mut canonical, decisions.expanded.bound().declarations.parsed().application());
    for plan in &plans {
        encode_release(&mut canonical, &plan.release);
        canonical.extend_from_slice(plan.proof.digest());
    }
    let owners: Vec<_> = plans.iter().map(|plan| plan.release.clone()).collect();
    let proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::FamilyCompilation,
        "cmp005.family-plan-set", decisions.expanded.bound().declarations.parsed().application(),
        canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(FamilyPlanSet {
        application: decisions.expanded.bound().declarations.parsed().application().clone(),
        decisions,
        plans,
        proof,
    })
}

fn constraints_compatible(
    requirement: &BTreeMap<StableId, StableId>,
    offer: &BTreeMap<StableId, StableId>,
) -> bool {
    requirement.iter().all(|(key, value)| offer.get(key) == Some(value))
}

fn cardinality_bounds(value: Cardinality) -> (u64, Option<u64>) {
    match value {
        Cardinality::ExactlyOne => (1, Some(1)),
        Cardinality::ZeroOrOne => (0, Some(1)),
        Cardinality::OneOrMore => (1, None),
        Cardinality::Exact(value) => {
            let count = u64::from(value.get());
            (count, Some(count))
        }
    }
}

pub fn build_application_binding(
    stage0: &Stage0PackageAuthority,
    family_plans: FamilyPlanSet,
    budget: WorkBudget,
) -> ExecutableApplicationBindingOutcome {
    let requirements: Vec<ContractRequirementSpec> = family_plans.plans().iter()
        .flat_map(|plan| plan.requirements.clone())
        .collect();
    let offers: Vec<ContractOfferSpec> = family_plans.plans().iter()
        .flat_map(|plan| plan.offers.clone())
        .collect();
    if requirements.is_empty() {
        return TotalOutcome::Refused(ApplicationBindingRefusal::NoRealRequirement);
    }
    if offers.is_empty() {
        return TotalOutcome::Refused(ApplicationBindingRefusal::NoRealOffer);
    }
    let requirement_count = match usize_u64(requirements.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationBindingRefusal::ChargeOverflow),
    };
    let offer_count = match usize_u64(offers.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationBindingRefusal::ChargeOverflow),
    };
    let comparisons = match checked_mul(requirement_count, offer_count) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationBindingRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp006.application-binding", requirement_count.saturating_add(offer_count),
        comparisons.saturating_mul(128), comparisons.saturating_mul(4),
        comparisons.saturating_mul(256), comparisons.saturating_mul(192),
        requirement_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut usage: BTreeMap<StableId, u64> = BTreeMap::new();
    let mut bindings = Vec::with_capacity(requirements.len());
    let mut selection_proofs = Vec::with_capacity(requirements.len());
    for requirement in requirements {
        let mut candidates: Vec<ContractOfferSpec> = offers.iter()
            .filter(|offer| {
                offer.contract == requirement.contract
                    && constraints_compatible(&requirement.constraints, &offer.constraints)
                    && usage.get(&offer.identity).copied().unwrap_or(0) < u64::from(offer.capacity)
            })
            .cloned()
            .collect();
        candidates.sort_by(|left, right| left.identity.cmp(&right.identity));
        let (minimum, maximum) = cardinality_bounds(requirement.cardinality);
        let selected_count = match maximum {
            Some(maximum) => usize::try_from(maximum).unwrap_or(usize::MAX).min(candidates.len()),
            None => candidates.len(),
        };
        if u64::try_from(selected_count).unwrap_or(u64::MAX) < minimum {
            if candidates.is_empty() {
                return TotalOutcome::Refused(ApplicationBindingRefusal::MissingCompatibleOffer {
                    requirement: requirement.identity.clone(),
                });
            }
            return TotalOutcome::Refused(ApplicationBindingRefusal::CardinalityUnsatisfied {
                requirement: requirement.identity.clone(),
                expected: requirement.cardinality,
                actual: u64::try_from(candidates.len()).unwrap_or(u64::MAX),
            });
        }
        if matches!(requirement.cardinality, Cardinality::ExactlyOne | Cardinality::ZeroOrOne)
            && candidates.len() > 1
        {
            return TotalOutcome::Refused(ApplicationBindingRefusal::AmbiguousOfferSelection {
                requirement: requirement.identity.clone(),
                candidates: candidates.iter().map(|offer| offer.identity.clone()).collect(),
            });
        }
        candidates.truncate(selected_count);
        for offer in &candidates {
            let selected = usage.entry(offer.identity.clone()).or_default();
            *selected = selected.saturating_add(1);
            if *selected > u64::from(offer.capacity) {
                return TotalOutcome::Refused(ApplicationBindingRefusal::OfferCapacityExceeded {
                    offer: offer.identity.clone(),
                    capacity: offer.capacity,
                    selected: *selected,
                });
            }
        }
        let mut basis = requirement.constraints.clone();
        for decision in family_plans.decisions().decisions().values() {
            basis.insert(decision.identity.clone(), decision.alternative.clone());
        }
        let mut canonical = Vec::new();
        encode_bytes(&mut canonical, b"cmp006.resolved-contract-binding.edition-2");
        encode_id(&mut canonical, &requirement.identity);
        encode_id(&mut canonical, &requirement.contract);
        for offer in &candidates {
            encode_id(&mut canonical, &offer.identity);
            encode_release(&mut canonical, &offer.owner);
        }
        for (key, value) in &basis {
            encode_id(&mut canonical, key);
            encode_id(&mut canonical, value);
        }
        let mut owners = vec![requirement.owner.clone()];
        owners.extend(candidates.iter().map(|offer| offer.owner.clone()));
        let selection_proof = match issue_stage_proof(
            stage0, &owners, CompilerSupplierRole::SelectionAuthorityVerification,
            "cmp006.selection", family_plans.application(), canonical, work.clone(),
        ) {
            Ok(value) => value,
            Err(needs) => return TotalOutcome::NeedsInput(needs),
        };
        selection_proofs.push(selection_proof);
        bindings.push(ResolvedContractBinding {
            requirement,
            offers: candidates,
            selection_basis: basis,
        });
    }
    if bindings.is_empty() {
        return TotalOutcome::Refused(ApplicationBindingRefusal::NoRealRequirement);
    }
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp006.application-binding.edition-2");
    encode_id(&mut canonical, family_plans.application());
    encode_id(&mut canonical, stage0.package_lock().reference().stable());
    for binding in &bindings {
        encode_id(&mut canonical, binding.requirement.identity());
        for offer in binding.offers() { encode_id(&mut canonical, offer.identity()); }
    }
    let owners: Vec<_> = family_plans.plans().iter().map(|plan| plan.release.clone()).collect();
    let stage_proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::CentralLinkerBindingVerification,
        "cmp006.application-binding", family_plans.application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    let proof = ApplicationBindingProof {
        stage: stage_proof,
        requirement_count,
        offer_count,
        binding_count: u64::try_from(bindings.len()).unwrap_or(u64::MAX),
    };
    TotalOutcome::Produced(ApplicationBinding {
        application: family_plans.application().clone(),
        package_lock: stage0.package_lock().reference().clone(),
        resolved_decisions: family_plans.decisions().clone(),
        family_plans,
        bindings,
        selection_proofs,
        proof,
    })
}

fn obligation_inputs(binding: &ApplicationBinding) -> (
    Vec<ObligationSpec>,
    Vec<ObligationRuleSpec>,
    Vec<RuntimeRequirementSpec>,
    BTreeSet<StableId>,
) {
    let mut obligations = Vec::new();
    let mut rules = Vec::new();
    let mut runtime = Vec::new();
    let mut facts = BTreeSet::new();
    for plan in binding.family_plans().plans() {
        obligations.extend(plan.obligations.clone());
        rules.extend(plan.obligation_rules.clone());
        runtime.extend(plan.runtime_requirements.clone());
        facts.extend(plan.initial_facts.clone());
    }
    for resolved in binding.bindings() {
        for offer in resolved.offers() { facts.extend(offer.provided_facts.clone()); }
    }
    (obligations, rules, runtime, facts)
}

pub fn close_application_obligations(
    stage0: &Stage0PackageAuthority,
    binding: ApplicationBinding,
    budget: WorkBudget,
) -> ExecutableObligationClosureOutcome {
    if binding.package_lock() != stage0.package_lock().reference() {
        return TotalOutcome::Refused(ObligationClosureRefusal::PackageLockMismatch);
    }
    let (mut obligations, mut rules, runtime_requirements, mut facts) = obligation_inputs(&binding);
    if obligations.is_empty() {
        return TotalOutcome::Refused(ObligationClosureRefusal::NoRealObligation);
    }
    obligations.sort_by(|left, right| left.identity.cmp(&right.identity));
    rules.sort_by(|left, right| left.identity.cmp(&right.identity));
    for pair in obligations.windows(2) {
        if pair[0].identity == pair[1].identity {
            return TotalOutcome::Refused(ObligationClosureRefusal::DuplicateObligation {
                obligation: pair[0].identity.clone(),
            });
        }
    }
    for pair in rules.windows(2) {
        if pair[0].identity == pair[1].identity {
            return TotalOutcome::Refused(ObligationClosureRefusal::DuplicateRule {
                rule: pair[0].identity.clone(),
            });
        }
        if pair[0].conclusion == pair[0].identity {
            return TotalOutcome::Refused(ObligationClosureRefusal::NonMonotoneRule {
                rule: pair[0].identity.clone(),
            });
        }
    }
    let item_count = obligations.len()
        .checked_add(rules.len())
        .and_then(|value| value.checked_add(facts.len()))
        .and_then(usize_u64);
    let Some(item_count) = item_count else {
        return TotalOutcome::Refused(ObligationClosureRefusal::ChargeOverflow);
    };
    let iteration_bound = item_count.saturating_add(1);
    let work_units = match checked_mul(item_count, iteration_bound) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ObligationClosureRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp007.obligation-closure", item_count, item_count.saturating_mul(128), work_units,
        item_count.saturating_mul(512), item_count.saturating_mul(512), item_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut fact_iteration: BTreeMap<StableId, u64> = facts.iter().cloned().map(|fact| (fact, 0)).collect();
    let mut iterations = 0_u64;
    loop {
        if iterations >= iteration_bound {
            return TotalOutcome::Refused(ObligationClosureRefusal::IterationLimitExceeded {
                required: iterations.saturating_add(1),
                allowed: iteration_bound,
            });
        }
        iterations = iterations.saturating_add(1);
        let mut additions = Vec::new();
        for rule in &rules {
            if rule.premises.iter().all(|premise| facts.contains(premise))
                && !facts.contains(&rule.conclusion)
            {
                additions.push(rule.conclusion.clone());
            }
        }
        additions.sort();
        additions.dedup();
        if additions.is_empty() { break; }
        for fact in additions {
            facts.insert(fact.clone());
            fact_iteration.insert(fact, iterations);
        }
    }
    let missing: Vec<StableId> = obligations.iter()
        .filter(|obligation| !facts.contains(&obligation.required_fact))
        .map(|obligation| obligation.identity.clone())
        .collect();
    if !missing.is_empty() {
        return TotalOutcome::Refused(ObligationClosureRefusal::IncompleteFixedPoint { missing });
    }
    let closed: Vec<ClosedObligation> = obligations.iter().map(|obligation| ClosedObligation {
        identity: obligation.identity.clone(),
        owner: obligation.owner_identity.clone(),
        required_fact: obligation.required_fact.clone(),
        discharged_by: obligation.required_fact.clone(),
        iteration: fact_iteration.get(&obligation.required_fact).copied().unwrap_or(0),
    }).collect();

    let mut dispositions = Vec::new();
    for resolved in binding.bindings() {
        dispositions.push(GapDisposition {
            subject: resolved.requirement.identity.clone(),
            kind: GapKind::ContractRequirement,
            resolution: GapResolution::BoundContract {
                offers: resolved.offers.iter().map(|offer| offer.identity.clone()).collect(),
            },
            owner: resolved.requirement.owner.clone(),
        });
    }
    for (obligation, closed_obligation) in obligations.iter().zip(&closed) {
        dispositions.push(GapDisposition {
            subject: obligation.identity.clone(),
            kind: GapKind::Obligation,
            resolution: GapResolution::DischargedObligation {
                fact: closed_obligation.required_fact.clone(),
                iteration: closed_obligation.iteration,
            },
            owner: obligation.release_owner.clone(),
        });
    }
    for requirement in runtime_requirements {
        dispositions.push(GapDisposition {
            subject: requirement.identity.clone(),
            kind: GapKind::RuntimeProvider,
            resolution: GapResolution::DeferredToDeployment {
                requirement: requirement.capability,
                absence: requirement.absence,
            },
            owner: requirement.owner,
        });
    }
    dispositions.sort_by(|left, right| left.subject.cmp(&right.subject));
    let owners: Vec<_> = binding.family_plans().plans().iter().map(|plan| plan.release.clone()).collect();
    let mut gap_canonical = Vec::new();
    encode_bytes(&mut gap_canonical, b"cmp007.gap-disposition-set.edition-2");
    for disposition in &dispositions {
        encode_id(&mut gap_canonical, &disposition.subject);
        encode_release(&mut gap_canonical, &disposition.owner);
    }
    let gap_proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::RequirementResolutionKernel,
        "cmp007.gap-disposition", binding.application(), gap_canonical, work.clone(),
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    let gap_dispositions = GapDispositionSet {
        dispositions,
        unresolved_count: 0,
        proof: gap_proof,
    };
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp007.obligation-closure.edition-2");
    encode_id(&mut canonical, binding.application());
    canonical.extend_from_slice(binding.proof().stage().digest());
    encode_u64(&mut canonical, iterations);
    for obligation in &closed {
        encode_id(&mut canonical, &obligation.identity);
        encode_id(&mut canonical, &obligation.required_fact);
        encode_u64(&mut canonical, obligation.iteration);
    }
    for fact in &facts { encode_id(&mut canonical, fact); }
    canonical.extend_from_slice(gap_dispositions.proof().digest());
    let stage_proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::ObligationLattice,
        "cmp007.obligation-closure", binding.application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(ObligationClosure {
        binding,
        obligations: closed,
        iterations,
        derived_facts: facts,
        gap_dispositions,
        proof: ObligationClosureProof {
            stage: stage_proof,
            least_fixed_point: true,
            monotone: true,
            complete: true,
        },
    })
}

fn authority_node_id(authority: &AuthorityRef) -> StableId {
    StableId::admit(format!("csag.authority/{}", authority.stable().as_str()))
        .expect("admitted authority yields admitted prefixed identity")
}

fn find_authority_cycle(dependencies: &[AuthorityDependency]) -> Option<Vec<AuthorityRef>> {
    let mut adjacency: BTreeMap<AuthorityRef, BTreeSet<AuthorityRef>> = BTreeMap::new();
    for dependency in dependencies {
        adjacency.entry(dependency.from.clone()).or_default().insert(dependency.to.clone());
        adjacency.entry(dependency.to.clone()).or_default();
    }
    let mut state: BTreeMap<AuthorityRef, u8> = BTreeMap::new();
    let mut stack: Vec<AuthorityRef> = Vec::new();

    fn visit(
        node: &AuthorityRef,
        adjacency: &BTreeMap<AuthorityRef, BTreeSet<AuthorityRef>>,
        state: &mut BTreeMap<AuthorityRef, u8>,
        stack: &mut Vec<AuthorityRef>,
    ) -> Option<Vec<AuthorityRef>> {
        state.insert(node.clone(), 1);
        stack.push(node.clone());
        if let Some(neighbors) = adjacency.get(node) {
            for neighbor in neighbors {
                match state.get(neighbor).copied().unwrap_or(0) {
                    0 => {
                        if let Some(cycle) = visit(neighbor, adjacency, state, stack) {
                            return Some(cycle);
                        }
                    }
                    1 => {
                        let start = stack.iter().position(|value| value == neighbor).unwrap_or(0);
                        let mut cycle = stack[start..].to_vec();
                        cycle.push(neighbor.clone());
                        return Some(cycle);
                    }
                    _ => {}
                }
            }
        }
        stack.pop();
        state.insert(node.clone(), 2);
        None
    }

    for node in adjacency.keys() {
        if state.get(node).copied().unwrap_or(0) == 0 {
            if let Some(cycle) = visit(node, &adjacency, &mut state, &mut stack) {
                return Some(cycle);
            }
        }
    }
    None
}

fn csag_canonical_bytes(
    application: &StableId,
    package_lock: &PackageLockRef,
    schema: Edition,
    anchor: &StableId,
    nodes: &[CsagNode],
    relations: &[CsagRelation],
    requested_targets: &[StableId],
) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, CSAG_CANONICAL_DOMAIN.as_bytes());
    encode_id(&mut output, application);
    encode_id(&mut output, package_lock.stable());
    encode_u32(&mut output, schema.get());
    encode_id(&mut output, anchor);
    encode_u64(&mut output, u64::try_from(nodes.len()).unwrap_or(u64::MAX));
    for node in nodes {
        encode_id(&mut output, &node.identity);
        output.push(match node.kind {
            CsagNodeKind::ApplicationAnchor => 1,
            CsagNodeKind::Authority => 2,
            CsagNodeKind::FamilyPlan => 3,
            CsagNodeKind::ContractBinding => 4,
            CsagNodeKind::ClosedObligation => 5,
            CsagNodeKind::RuntimeRequirement => 6,
        });
        encode_id(&mut output, node.owner.stable());
        encode_release(&mut output, &node.provenance_release);
        encode_id(&mut output, &node.source_subject);
    }
    encode_u64(&mut output, u64::try_from(requested_targets.len()).unwrap_or(u64::MAX));
    for target in requested_targets { encode_id(&mut output, target); }
    encode_u64(&mut output, u64::try_from(relations.len()).unwrap_or(u64::MAX));
    for relation in relations {
        encode_id(&mut output, &relation.identity);
        encode_id(&mut output, &relation.source);
        encode_id(&mut output, &relation.target);
        output.push(match relation.kind {
            CsagRelationKind::ApplicationContains => 1,
            CsagRelationKind::FamilyRequires => 2,
            CsagRelationKind::RequirementBoundToOffer => 3,
            CsagRelationKind::ObligationClosedByFact => 4,
            CsagRelationKind::RuntimeCapabilityRequired => 5,
            CsagRelationKind::AuthorityDependsOn => 6,
        });
        encode_release(&mut output, &relation.owner);
    }
    output
}

pub fn build_csag(
    stage0: &Stage0PackageAuthority,
    obligations: ObligationClosure,
    budget: WorkBudget,
) -> ExecutableCsagOutcome {
    if obligations.binding().package_lock() != stage0.package_lock().reference() {
        return TotalOutcome::Refused(CsagRefusal::PackageLockMismatch);
    }
    if obligations.gap_dispositions().unresolved_count() != 0 {
        return TotalOutcome::Refused(CsagRefusal::GapDispositionIncomplete);
    }
    let application = obligations.binding().application().clone();
    let plans = obligations.binding().family_plans().plans();
    if plans.is_empty() {
        return TotalOutcome::Refused(CsagRefusal::EmptyGraph);
    }
    let node_estimate = 1_usize
        .checked_add(plans.len())
        .and_then(|value| value.checked_add(obligations.binding().bindings().len()))
        .and_then(|value| value.checked_add(obligations.obligations().len()))
        .and_then(|value| value.checked_add(
            plans.iter().map(|plan| plan.runtime_requirements.len()).sum::<usize>(),
        ));
    let Some(node_estimate) = node_estimate.and_then(usize_u64) else {
        return TotalOutcome::Refused(CsagRefusal::ChargeOverflow);
    };
    let work = match precharge(
        "cmp008.csag", node_estimate, node_estimate.saturating_mul(192),
        node_estimate.saturating_mul(node_estimate.max(1)), node_estimate.saturating_mul(512),
        node_estimate.saturating_mul(512), node_estimate, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let schema = Edition::admit(2).expect("positive static edition");
    let anchor = StableId::admit(format!("{}/application-anchor", application.as_str()))
        .expect("admitted application yields admitted anchor identity");
    let anchor_release = plans[0].release.clone();
    let mut nodes = Vec::new();
    let mut relations = Vec::new();
    nodes.push(CsagNode {
        identity: anchor.clone(),
        kind: CsagNodeKind::ApplicationAnchor,
        owner: stage0.proof().issuer().clone(),
        provenance_release: anchor_release.clone(),
        source_subject: application.clone(),
    });
    let mut plan_nodes: BTreeMap<StableId, StableId> = BTreeMap::new();
    for plan in plans {
        let node_id = StableId::admit(format!("csag.family/{}", plan.release.identity().as_str()))
            .expect("selected release identity yields graph identity");
        plan_nodes.insert(plan.release.identity().clone(), node_id.clone());
        nodes.push(CsagNode {
            identity: node_id.clone(),
            kind: CsagNodeKind::FamilyPlan,
            owner: plan.semantic_owner.clone(),
            provenance_release: plan.release.clone(),
            source_subject: plan.release.identity().clone(),
        });
        relations.push(CsagRelation {
            identity: StableId::admit(format!("csag.rel/application-family/{}", plan.release.identity().as_str()))
                .expect("static prefix"),
            source: anchor.clone(),
            target: node_id,
            kind: CsagRelationKind::ApplicationContains,
            owner: plan.release.clone(),
        });
    }
    for resolved in obligations.binding().bindings() {
        let node_id = StableId::admit(format!("csag.binding/{}", resolved.requirement.identity().as_str()))
            .expect("admitted requirement yields graph identity");
        nodes.push(CsagNode {
            identity: node_id.clone(),
            kind: CsagNodeKind::ContractBinding,
            owner: plans.iter()
                .find(|plan| plan.release == resolved.offers()[0].owner)
                .map(|plan| plan.semantic_owner.clone())
                .expect("every retained offer belongs to a retained family plan"),
            provenance_release: resolved.requirement.owner.clone(),
            source_subject: resolved.requirement.identity.clone(),
        });
        let source = plan_nodes.get(resolved.requirement.owner.identity()).cloned().unwrap_or_else(|| anchor.clone());
        relations.push(CsagRelation {
            identity: StableId::admit(format!("csag.rel/family-binding/{}", resolved.requirement.identity().as_str()))
                .expect("static prefix"),
            source,
            target: node_id,
            kind: CsagRelationKind::RequirementBoundToOffer,
            owner: resolved.requirement.owner.clone(),
        });
    }
    for closed in obligations.obligations() {
        let source_spec = plans.iter()
            .flat_map(|plan| plan.obligations.iter())
            .find(|spec| spec.identity == closed.identity)
            .expect("closed obligation comes from retained plan");
        let node_id = StableId::admit(format!("csag.obligation/{}", closed.identity.as_str()))
            .expect("admitted obligation yields graph identity");
        nodes.push(CsagNode {
            identity: node_id.clone(),
            kind: CsagNodeKind::ClosedObligation,
            owner: closed.owner.clone(),
            provenance_release: source_spec.release_owner.clone(),
            source_subject: closed.identity.clone(),
        });
        relations.push(CsagRelation {
            identity: StableId::admit(format!("csag.rel/application-obligation/{}", closed.identity.as_str()))
                .expect("static prefix"),
            source: anchor.clone(),
            target: node_id,
            kind: CsagRelationKind::ObligationClosedByFact,
            owner: source_spec.release_owner.clone(),
        });
    }
    for plan in plans {
        for requirement in &plan.runtime_requirements {
            let node_id = StableId::admit(format!("csag.runtime/{}", requirement.identity.as_str()))
                .expect("admitted runtime requirement yields graph identity");
            nodes.push(CsagNode {
                identity: node_id.clone(),
                kind: CsagNodeKind::RuntimeRequirement,
                owner: plan.semantic_owner.clone(),
                provenance_release: plan.release.clone(),
                source_subject: requirement.identity.clone(),
            });
            relations.push(CsagRelation {
                identity: StableId::admit(format!("csag.rel/application-runtime/{}", requirement.identity.as_str()))
                    .expect("static prefix"),
                source: anchor.clone(),
                target: node_id,
                kind: CsagRelationKind::RuntimeCapabilityRequired,
                owner: plan.release.clone(),
            });
        }
    }
    let dependencies: Vec<AuthorityDependency> = plans.iter()
        .flat_map(|plan| plan.authority_dependencies.clone())
        .collect();
    let mut authority_nodes = BTreeSet::new();
    for dependency in &dependencies {
        for authority in [&dependency.from, &dependency.to] {
            if authority_nodes.insert(authority.clone()) {
                nodes.push(CsagNode {
                    identity: authority_node_id(authority),
                    kind: CsagNodeKind::Authority,
                    owner: authority.clone(),
                    provenance_release: dependency.owner.clone(),
                    source_subject: authority.stable().clone(),
                });
            }
        }
        relations.push(CsagRelation {
            identity: StableId::admit(format!(
                "csag.rel/authority/{}/{}",
                dependency.from.stable().as_str(), dependency.to.stable().as_str(),
            )).expect("admitted authority identities yield relation identity"),
            source: authority_node_id(&dependency.from),
            target: authority_node_id(&dependency.to),
            kind: CsagRelationKind::AuthorityDependsOn,
            owner: dependency.owner.clone(),
        });
    }
    nodes.sort_by(|left, right| left.identity.cmp(&right.identity));
    relations.sort_by(|left, right| left.identity.cmp(&right.identity));
    for pair in nodes.windows(2) {
        if pair[0].identity == pair[1].identity {
            return TotalOutcome::Refused(CsagRefusal::DuplicateNode { node: pair[0].identity.clone() });
        }
    }
    for pair in relations.windows(2) {
        if pair[0].identity == pair[1].identity {
            return TotalOutcome::Refused(CsagRefusal::DuplicateRelation { relation: pair[0].identity.clone() });
        }
    }
    let node_ids: BTreeSet<StableId> = nodes.iter().map(|node| node.identity.clone()).collect();
    for relation in &relations {
        if !node_ids.contains(&relation.source) || !node_ids.contains(&relation.target) {
            return TotalOutcome::Refused(CsagRefusal::DanglingRelation { relation: relation.identity.clone() });
        }
    }
    let cycle = find_authority_cycle(&dependencies);
    let authority_cycle_proof = if let Some(cycle) = cycle {
        let cycle_ids: Vec<StableId> = cycle.iter().map(|authority| authority.stable().clone()).collect();
        let cycle_owners: Vec<ReleaseCoordinate> = dependencies.iter()
            .filter(|dependency| cycle.contains(&dependency.from) || cycle.contains(&dependency.to))
            .map(|dependency| dependency.owner.clone())
            .collect();
        let mut canonical = Vec::new();
        encode_bytes(&mut canonical, b"cmp008.authority-cycle.edition-2");
        for authority in &cycle { encode_id(&mut canonical, authority.stable()); }
        match issue_stage_proof(
            stage0, &cycle_owners, CompilerSupplierRole::AuthorityCycleVerification,
            "cmp008.authority-cycle", &application, canonical, work.clone(),
        ) {
            Ok(value) => Some(value),
            Err(_) => return TotalOutcome::NeedsInput(needs_input(
                "cmp008.authority-cycle", MissingInputKind::Verifier, cycle_ids,
            )),
        }
    } else {
        None
    };
    let requested_targets = obligations.binding.family_plans.decisions.expanded.bound.declarations.parsed.targets.clone();
    let canonical = csag_canonical_bytes(
        &application, stage0.package_lock().reference(), schema, &anchor, &nodes, &relations,
        &requested_targets,
    );
    let owners: Vec<_> = plans.iter().map(|plan| plan.release.clone()).collect();
    let stage_proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::CsagCommitment,
        "cmp008.csag", &application, canonical.clone(), work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    let digest = sha256(&canonical);
    let subject = subject_key(
        application.clone(), first_owner(&owners), stage0.package_lock().reference().clone(),
        StageId::admit("cmp008.csag").expect("static stage identity"),
    );
    let commitment = DigestClaim::sha256(
        subject,
        SeparationDomain::admit(CSAG_DIGEST_DOMAIN).expect("static separation domain"),
        digest,
    );
    TotalOutcome::Produced(Csag {
        application,
        schema,
        nodes,
        relations,
        requested_targets,
        application_anchor: anchor,
        commitment,
        proof: CsagProof {
            stage: stage_proof,
            authority_cycle_proof,
            non_empty: true,
            anchor_law: true,
            no_dangling_relations: true,
            authority_cycles_verified: true,
            canonical_subject_bound: true,
        },
    })
}

fn encode_node_kind(output: &mut Vec<u8>, kind: &CsagNodeKind) {
    output.push(match kind {
        CsagNodeKind::ApplicationAnchor => 1,
        CsagNodeKind::Authority => 2,
        CsagNodeKind::FamilyPlan => 3,
        CsagNodeKind::ContractBinding => 4,
        CsagNodeKind::ClosedObligation => 5,
        CsagNodeKind::RuntimeRequirement => 6,
    });
}

fn target_descriptor_carrier_canonical(carrier: &TargetDescriptorCarrier) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, b"san.target-descriptor.edition-2");
    encode_bytes(&mut output, carrier.release_identity.as_bytes());
    encode_artifact_carrier(&mut output, &carrier.descriptor_artifact);
    encode_bytes(&mut output, carrier.target_kind.as_bytes());
    let mut kinds = carrier.supported_node_kinds.clone();
    kinds.sort();
    kinds.dedup();
    encode_u64(&mut output, u64::try_from(kinds.len()).unwrap_or(u64::MAX));
    for kind in &kinds { encode_node_kind(&mut output, kind); }
    output
}

fn encode_artifact_carrier(output: &mut Vec<u8>, value: &crate::waist::ArtifactRefCarrier) {
    encode_bytes(output, value.identity.as_bytes());
    encode_u32(output, value.edition);
    encode_bytes(output, value.occurrence.as_bytes());
    output.extend_from_slice(&value.digest);
}

#[must_use]
pub fn target_descriptor_digest(carrier: &TargetDescriptorCarrier) -> [u8; 32] {
    sha256(&target_descriptor_carrier_canonical(carrier))
}

fn admit_target_descriptor(
    stage0: &Stage0PackageAuthority,
    carrier: TargetDescriptorCarrier,
) -> Result<TargetDescriptor, TargetCompilationRefusal> {
    let release_identity = StableId::admit(carrier.release_identity)
        .map_err(TargetCompilationRefusal::InvalidIdentity)?;
    let release = stage0.package_lock().selected(&release_identity, RegistryKind::Target)
        .cloned()
        .ok_or_else(|| TargetCompilationRefusal::TargetDescriptorNotSelected {
            target: release_identity.clone(),
        })?;
    let actual = target_descriptor_digest(&carrier);
    if actual != carrier.claimed_digest
        || stage0.package_lock().descriptor_digest(&release).copied() != Some(actual)
    {
        return Err(TargetCompilationRefusal::TargetDescriptorDigestDrift {
            target: release_identity,
        });
    }
    let descriptor_artifact = admit_artifact_ref(carrier.descriptor_artifact)
        .map_err(TargetCompilationRefusal::InvalidIdentity)?;
    let target_kind = StableId::admit(carrier.target_kind)
        .map_err(TargetCompilationRefusal::InvalidIdentity)?;
    let supported_node_kinds = carrier.supported_node_kinds.into_iter().collect();
    Ok(TargetDescriptor {
        release,
        descriptor_artifact,
        target_kind,
        supported_node_kinds,
        digest: actual,
    })
}

fn target_artifact_bytes(csag: &Csag, descriptor: &TargetDescriptor) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, b"san.portable-target-artifact.edition-2");
    encode_id(&mut output, csag.application());
    encode_id(&mut output, &descriptor.target_kind);
    output.extend_from_slice(csag.commitment().value());
    encode_u64(&mut output, u64::try_from(csag.nodes().len()).unwrap_or(u64::MAX));
    for node in csag.nodes() {
        encode_id(&mut output, node.identity());
        encode_node_kind(&mut output, node.kind());
    }
    encode_u64(&mut output, u64::try_from(csag.relations().len()).unwrap_or(u64::MAX));
    for relation in csag.relations() {
        encode_id(&mut output, &relation.identity);
        encode_id(&mut output, &relation.source);
        encode_id(&mut output, &relation.target);
    }
    output
}

pub fn compile_targets(
    stage0: &Stage0PackageAuthority,
    csag: Csag,
    carriers: Vec<TargetDescriptorCarrier>,
    budget: WorkBudget,
) -> ExecutableTargetCompilationOutcome {
    if csag.commitment().subject().package_lock() != stage0.package_lock().reference() {
        return TotalOutcome::Refused(TargetCompilationRefusal::PackageLockMismatch);
    }
    let descriptor_count = match usize_u64(carriers.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(TargetCompilationRefusal::ChargeOverflow),
    };
    let node_count = match usize_u64(csag.nodes().len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(TargetCompilationRefusal::ChargeOverflow),
    };
    let work_units = match checked_mul(descriptor_count.max(1), node_count.max(1)) {
        Some(value) => value,
        None => return TotalOutcome::Refused(TargetCompilationRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp009.target-compilation", descriptor_count.saturating_add(node_count),
        node_count.saturating_mul(256), work_units.saturating_mul(4),
        node_count.saturating_mul(1024), node_count.saturating_mul(1024),
        descriptor_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    if carriers.is_empty() {
        return TotalOutcome::Refused(TargetCompilationRefusal::NoTargetRequested);
    }
    let mut descriptors = Vec::with_capacity(carriers.len());
    for carrier in carriers {
        match admit_target_descriptor(stage0, carrier) {
            Ok(value) => descriptors.push(value),
            Err(refusal) => return TotalOutcome::Refused(refusal),
        }
    }
    descriptors.sort_by(|left, right| left.target_kind.cmp(&right.target_kind));
    for pair in descriptors.windows(2) {
        if pair[0].target_kind == pair[1].target_kind {
            return TotalOutcome::Refused(TargetCompilationRefusal::UnsupportedTarget {
                target: pair[0].target_kind.clone(),
            });
        }
    }
    if csag.requested_targets().is_empty() {
        return TotalOutcome::Refused(TargetCompilationRefusal::NoTargetRequested);
    }
    let descriptor_kinds: BTreeSet<StableId> = descriptors.iter()
        .map(|descriptor| descriptor.target_kind.clone())
        .collect();
    for requested in csag.requested_targets() {
        if !descriptor_kinds.contains(requested) {
            return TotalOutcome::Refused(TargetCompilationRefusal::UnsupportedTarget {
                target: requested.clone(),
            });
        }
    }
    if descriptor_kinds.len() != csag.requested_targets().len() {
        let extra = descriptor_kinds.iter()
            .find(|kind| !csag.requested_targets().contains(kind))
            .cloned()
            .unwrap_or_else(|| StableId::admit("target.portfolio-mismatch").expect("static identity"));
        return TotalOutcome::Refused(TargetCompilationRefusal::UnsupportedTarget { target: extra });
    }
    let mut compilations = Vec::new();
    let mut portfolio = BTreeSet::new();
    for descriptor in descriptors {
        for node in csag.nodes() {
            if !descriptor.supported_node_kinds.contains(node.kind()) {
                return TotalOutcome::Refused(TargetCompilationRefusal::UnsupportedNodeKind {
                    target: descriptor.target_kind.clone(),
                    kind: node.kind().clone(),
                });
            }
        }
        let bytes = target_artifact_bytes(&csag, &descriptor);
        let digest = sha256(&bytes);
        let identity = StableId::admit(format!("target.artifact/{}", descriptor.target_kind.as_str()))
            .expect("admitted target kind yields target artifact identity");
        let artifact = TargetArtifact {
            identity,
            target_kind: descriptor.target_kind.clone(),
            bytes: bytes.clone(),
            digest,
            compiler_release: descriptor.release.clone(),
        };
        let mut canonical = Vec::new();
        encode_bytes(&mut canonical, b"cmp009.target-preservation.edition-2");
        encode_id(&mut canonical, &descriptor.target_kind);
        canonical.extend_from_slice(csag.commitment().value());
        canonical.extend_from_slice(&digest);
        let preservation_proof = match issue_stage_proof(
            stage0, std::slice::from_ref(&descriptor.release),
            CompilerSupplierRole::TranslationValidation,
            "cmp009.target-preservation", csag.application(), canonical, work.clone(),
        ) {
            Ok(value) => value,
            Err(needs) => return TotalOutcome::NeedsInput(needs),
        };
        portfolio.insert(descriptor.target_kind.clone());
        compilations.push(TargetCompilation { target: descriptor, artifact, preservation_proof });
    }
    if compilations.is_empty() {
        return TotalOutcome::Refused(TargetCompilationRefusal::TargetPortfolioIncomplete);
    }
    let owners: Vec<_> = compilations.iter().map(|value| value.target.release.clone()).collect();
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"cmp009.target-compilation-set.edition-2");
    encode_id(&mut canonical, csag.application());
    canonical.extend_from_slice(csag.commitment().value());
    for compilation in &compilations {
        encode_id(&mut canonical, &compilation.target.target_kind);
        canonical.extend_from_slice(&compilation.artifact.digest);
        canonical.extend_from_slice(compilation.preservation_proof.digest());
    }
    let stage_proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::TargetCompilation,
        "cmp009.target-compilation", csag.application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(TargetCompilationSet {
        csag,
        compilations,
        portfolio,
        proof: TargetCompilationProof {
            stage: stage_proof,
            all_nodes_supported: true,
            portfolio_complete: true,
        },
    })
}

fn runtime_descriptor_carrier_canonical(carrier: &RuntimeCapabilityDescriptorCarrier) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, b"san.runtime-capability-descriptor.edition-2");
    encode_bytes(&mut output, carrier.release_identity.as_bytes());
    encode_artifact_carrier(&mut output, &carrier.descriptor_artifact);
    let mut capabilities = carrier.capabilities.clone();
    capabilities.sort();
    capabilities.dedup();
    encode_u64(&mut output, u64::try_from(capabilities.len()).unwrap_or(u64::MAX));
    for capability in capabilities { encode_bytes(&mut output, capability.as_bytes()); }
    output
}

#[must_use]
pub fn runtime_descriptor_digest(carrier: &RuntimeCapabilityDescriptorCarrier) -> [u8; 32] {
    sha256(&runtime_descriptor_carrier_canonical(carrier))
}

fn admit_runtime_descriptor(
    stage0: &Stage0PackageAuthority,
    carrier: RuntimeCapabilityDescriptorCarrier,
) -> Result<RuntimeCapabilityDescriptor, RuntimeRequirementClosureRefusal> {
    let release_identity = StableId::admit(carrier.release_identity)
        .map_err(RuntimeRequirementClosureRefusal::InvalidIdentity)?;
    let release = stage0.package_lock().selected(&release_identity, RegistryKind::Runtime)
        .cloned()
        .ok_or_else(|| RuntimeRequirementClosureRefusal::RuntimeDescriptorNotSelected {
            release: release_identity.clone(),
        })?;
    let actual = runtime_descriptor_digest(&carrier);
    if actual != carrier.claimed_digest
        || stage0.package_lock().descriptor_digest(&release).copied() != Some(actual)
    {
        return Err(RuntimeRequirementClosureRefusal::RuntimeDescriptorDigestDrift {
            release: release_identity,
        });
    }
    let descriptor_artifact = admit_artifact_ref(carrier.descriptor_artifact)
        .map_err(RuntimeRequirementClosureRefusal::InvalidIdentity)?;
    let capabilities = carrier.capabilities.into_iter()
        .map(StableId::admit)
        .collect::<Result<BTreeSet<_>, _>>()
        .map_err(RuntimeRequirementClosureRefusal::InvalidIdentity)?;
    Ok(RuntimeCapabilityDescriptor {
        release,
        descriptor_artifact,
        capabilities,
        digest: actual,
    })
}

pub fn close_runtime_requirements(
    stage0: &Stage0PackageAuthority,
    obligations: &ObligationClosure,
    targets: TargetCompilationSet,
    carriers: Vec<RuntimeCapabilityDescriptorCarrier>,
    budget: WorkBudget,
) -> ExecutableRuntimeRequirementClosureOutcome {
    if targets.csag().application() != obligations.binding().application()
        || targets.csag().commitment().subject().package_lock() != stage0.package_lock().reference()
        || obligations.binding().package_lock() != stage0.package_lock().reference()
    {
        return TotalOutcome::Refused(RuntimeRequirementClosureRefusal::PackageLockMismatch);
    }
    let source_requirements: Vec<RuntimeRequirementSpec> = obligations.binding().family_plans().plans().iter()
        .flat_map(|plan| plan.runtime_requirements.clone())
        .collect();
    if source_requirements.is_empty() {
        return TotalOutcome::Refused(RuntimeRequirementClosureRefusal::NoRuntimeRequirement);
    }
    let requirement_count = match usize_u64(source_requirements.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(RuntimeRequirementClosureRefusal::ChargeOverflow),
    };
    let descriptor_count = match usize_u64(carriers.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(RuntimeRequirementClosureRefusal::ChargeOverflow),
    };
    let comparisons = match checked_mul(requirement_count, descriptor_count.max(1)) {
        Some(value) => value,
        None => return TotalOutcome::Refused(RuntimeRequirementClosureRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "run.requirement-closure", requirement_count.saturating_add(descriptor_count),
        comparisons.saturating_mul(128), comparisons.saturating_mul(4),
        comparisons.saturating_mul(256), comparisons.saturating_mul(192), requirement_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut descriptors = Vec::with_capacity(carriers.len());
    for carrier in carriers {
        match admit_runtime_descriptor(stage0, carrier) {
            Ok(value) => descriptors.push(value),
            Err(refusal) => return TotalOutcome::Refused(refusal),
        }
    }
    descriptors.sort_by(|left, right| left.release.cmp(&right.release));
    let mut requirements = Vec::with_capacity(source_requirements.len());
    for source in source_requirements {
        let matches: Vec<&RuntimeCapabilityDescriptor> = descriptors.iter()
            .filter(|descriptor| descriptor.capabilities.contains(&source.capability))
            .collect();
        let descriptor = match matches.as_slice() {
            [] => return TotalOutcome::Refused(RuntimeRequirementClosureRefusal::UnsupportedRuntimeCapability {
                capability: source.capability,
            }),
            [descriptor] => *descriptor,
            _ => return TotalOutcome::Refused(RuntimeRequirementClosureRefusal::AmbiguousRuntimeCapability {
                capability: source.capability,
                releases: matches.iter().map(|descriptor| descriptor.release.identity().clone()).collect(),
            }),
        };
        requirements.push(ProviderBindingRequirement {
            identity: StableId::admit(format!("provider.requirement/{}", source.identity.as_str()))
                .expect("admitted requirement yields provider requirement identity"),
            capability: source.capability,
            cardinality: source.cardinality,
            absence: source.absence,
            runtime_release: descriptor.release.clone(),
            source_requirement: source.identity,
        });
    }
    requirements.sort_by(|left, right| left.identity.cmp(&right.identity));
    let owners: Vec<_> = descriptors.iter().map(|descriptor| descriptor.release.clone()).collect();
    let mut canonical = Vec::new();
    encode_bytes(&mut canonical, b"run.runtime-requirement-closure.edition-2");
    encode_id(&mut canonical, targets.csag().application());
    canonical.extend_from_slice(targets.proof.stage.digest());
    for requirement in &requirements {
        encode_id(&mut canonical, &requirement.identity);
        encode_id(&mut canonical, &requirement.capability);
        encode_release(&mut canonical, &requirement.runtime_release);
    }
    let stage_proof = match issue_stage_proof(
        stage0, &owners, CompilerSupplierRole::DeploymentRequirementProjection,
        "run.requirement-closure", targets.csag().application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    TotalOutcome::Produced(RuntimeRequirementClosure {
        targets,
        requirements,
        runtime_descriptors: descriptors,
        proof: RuntimeRequirementClosureProof {
            stage: stage_proof,
            every_requirement_supported: true,
            portable_only: true,
        },
    })
}

fn collect_upstream_proofs(
    constitution: &AdmittedConstitution,
    source: &AdmittedApplicationSource,
    plans: &FamilyPlanSet,
    binding: &ApplicationBinding,
    obligations: &ObligationClosure,
    csag: &Csag,
    targets: &TargetCompilationSet,
    runtime: &RuntimeRequirementClosure,
) -> Vec<StageProof> {
    let parsed = &plans.decisions.expanded.bound.declarations.parsed;
    let declarations = &plans.decisions.expanded.bound.declarations;
    let bound = &plans.decisions.expanded.bound;
    let descriptors = &plans.decisions.expanded.descriptors;
    let expanded = &plans.decisions.expanded;
    let decisions = &plans.decisions;
    let mut proofs = vec![
        constitution.proof().clone(),
        source.proof().clone(),
        parsed.proof().clone(),
        declarations.proof().clone(),
        bound.proof().clone(),
        descriptors.proof().clone(),
        expanded.proof().clone(),
        decisions.proof().clone(),
    ];
    proofs.extend(plans.plans().iter().map(|plan| plan.proof.clone()));
    proofs.push(plans.proof().clone());
    proofs.extend(binding.selection_proofs.iter().cloned());
    proofs.push(binding.proof().stage().clone());
    proofs.push(obligations.gap_dispositions().proof().clone());
    proofs.push(obligations.proof().stage().clone());
    if let Some(proof) = csag.proof().authority_cycle_proof() { proofs.push(proof.clone()); }
    proofs.push(csag.proof().stage().clone());
    for compilation in targets.compilations() {
        proofs.push(compilation.preservation_proof.clone());
    }
    proofs.push(targets.proof.stage.clone());
    proofs.push(runtime.proof.stage.clone());
    proofs
}

fn has_stage(ledger: &ProofLedger, stage: &str) -> bool {
    ledger.proofs().iter().any(|proof| proof.stage().stable().as_str() == stage)
}

fn required_upstream_stage_ids() -> &'static [&'static str] {
    &[
        "cmp001.source-admission",
        "cmp002.constitution-admission",
        "cmp001.parse",
        "cmp002.declaration-admission",
        "cmp003.name-binding",
        "cmp005.family-descriptor-admission",
        "cmp004.pack-expansion",
        "cmp004.decision-resolution",
        "cmp005.family-compilation",
        "cmp005.family-plan-set",
        "cmp006.selection",
        "cmp006.application-binding",
        "cmp007.gap-disposition",
        "cmp007.obligation-closure",
        "cmp008.csag",
        "cmp009.target-preservation",
        "cmp009.target-compilation",
        "run.requirement-closure",
    ]
}

fn application_closure_canonical(
    stage0: &Stage0PackageAuthority,
    constitution: &AdmittedConstitution,
    source: &AdmittedApplicationSource,
    plans: &FamilyPlanSet,
    binding: &ApplicationBinding,
    obligations: &ObligationClosure,
    csag: &Csag,
    targets: &TargetCompilationSet,
    runtime: &RuntimeRequirementClosure,
    upstream_ledger: &ProofLedger,
) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, CLOSURE_CANONICAL_DOMAIN.as_bytes());
    encode_id(&mut output, plans.application());
    encode_id(&mut output, stage0.package_lock().reference().stable());
    output.extend_from_slice(stage0.package_lock().digest());
    encode_id(&mut output, constitution.coordinate());
    encode_u32(&mut output, constitution.edition().get());
    output.extend_from_slice(constitution.digest());
    encode_artifact(&mut output, source.source());
    output.extend_from_slice(source.digest());
    output.extend_from_slice(plans.proof().digest());
    output.extend_from_slice(binding.proof().stage().digest());
    output.extend_from_slice(obligations.proof().stage().digest());
    output.extend_from_slice(csag.commitment().value());
    output.extend_from_slice(targets.proof.stage.digest());
    output.extend_from_slice(runtime.proof.stage.digest());
    output.extend_from_slice(upstream_ledger.commitment());
    encode_u64(&mut output, u64::try_from(targets.compilations().len()).unwrap_or(u64::MAX));
    for compilation in targets.compilations() {
        encode_id(&mut output, compilation.artifact.identity());
        output.extend_from_slice(compilation.artifact.digest());
    }
    encode_u64(&mut output, u64::try_from(runtime.requirements().len()).unwrap_or(u64::MAX));
    for requirement in runtime.requirements() {
        encode_id(&mut output, requirement.identity());
        encode_id(&mut output, requirement.capability());
    }
    output
}

pub fn seal_application_closure(
    stage0: Stage0PackageAuthority,
    constitution: AdmittedConstitution,
    source: AdmittedApplicationSource,
    family_plans: FamilyPlanSet,
    binding: ApplicationBinding,
    obligations: ObligationClosure,
    csag: Csag,
    targets: TargetCompilationSet,
    runtime: RuntimeRequirementClosure,
    budget: WorkBudget,
) -> ExecutableApplicationClosureOutcome {
    let application = family_plans.application().clone();
    let mismatch_stage = |stage: &str| ApplicationClosureRefusal::ArtifactThreadMismatch {
        stage: StageId::admit(stage).expect("static stage identity"),
    };
    if binding.family_plans() != &family_plans {
        return TotalOutcome::Refused(mismatch_stage("cmp006.application-binding"));
    }
    if obligations.binding() != &binding {
        return TotalOutcome::Refused(mismatch_stage("cmp007.obligation-closure"));
    }
    if targets.csag() != &csag {
        return TotalOutcome::Refused(mismatch_stage("cmp009.target-compilation"));
    }
    if runtime.targets() != &targets {
        return TotalOutcome::Refused(mismatch_stage("run.requirement-closure"));
    }
    let retained_source = &family_plans.decisions.expanded.bound.declarations.parsed.source;
    if retained_source != &source {
        return TotalOutcome::Refused(mismatch_stage("cmp001.source-admission"));
    }
    if binding.package_lock() != stage0.package_lock().reference()
        || csag.commitment().subject().package_lock() != stage0.package_lock().reference()
    {
        return TotalOutcome::Refused(ApplicationClosureRefusal::PackageLockMismatch);
    }
    if obligations.gap_dispositions().unresolved_count() != 0 {
        let subject = obligations.gap_dispositions().dispositions().first()
            .map(|value| value.subject.clone())
            .unwrap_or_else(|| application.clone());
        return TotalOutcome::Refused(ApplicationClosureRefusal::UnclosedGap { subject });
    }
    if !csag.proof().is_valid() || csag.nodes().is_empty() {
        return TotalOutcome::Refused(ApplicationClosureRefusal::InvalidCsag);
    }
    if targets.compilations().is_empty() || targets.portfolio().is_empty() {
        return TotalOutcome::Refused(ApplicationClosureRefusal::EmptyTargetPortfolio);
    }
    if runtime.requirements().is_empty()
        || !runtime.proof.every_requirement_supported
        || !runtime.proof.portable_only
    {
        return TotalOutcome::Refused(ApplicationClosureRefusal::RuntimeRequirementsNotClosed);
    }
    let item_count = collect_upstream_proofs(
        &constitution, &source, &family_plans, &binding, &obligations, &csag, &targets, &runtime,
    ).len();
    let item_count = match usize_u64(item_count) {
        Some(value) => value,
        None => return TotalOutcome::Refused(ApplicationClosureRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp013.application-closure", item_count, item_count.saturating_mul(512),
        item_count.saturating_mul(8), item_count.saturating_mul(512),
        item_count.saturating_mul(512), item_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let upstream_proofs = collect_upstream_proofs(
        &constitution, &source, &family_plans, &binding, &obligations, &csag, &targets, &runtime,
    );
    let upstream_proof_ledger = match build_proof_ledger(upstream_proofs) {
        Ok(value) => value,
        Err(()) => return TotalOutcome::Refused(ApplicationClosureRefusal::ProofLedgerInconsistent),
    };
    for stage in required_upstream_stage_ids() {
        if !has_stage(&upstream_proof_ledger, stage) {
            return TotalOutcome::Refused(ApplicationClosureRefusal::UpstreamProofMissing {
                stage: StageId::admit(*stage).expect("static stage identity"),
            });
        }
    }
    let canonical = application_closure_canonical(
        &stage0, &constitution, &source, &family_plans, &binding, &obligations,
        &csag, &targets, &runtime, &upstream_proof_ledger,
    );
    let owners = all_package_owners(&stage0);
    let final_proof = match issue_stage_proof(
        &stage0, &owners, CompilerSupplierRole::ApplicationClosureCommitmentVerification,
        "cmp013.application-closure", &application, canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    let mut all_proofs = upstream_proof_ledger.proofs().to_vec();
    all_proofs.push(final_proof.clone());
    let proof_ledger = match build_proof_ledger(all_proofs) {
        Ok(value) => value,
        Err(()) => return TotalOutcome::Refused(ApplicationClosureRefusal::ProofLedgerInconsistent),
    };
    let seal = ApplicationClosureSeal {
        subject: final_proof.subject().clone(),
        canonical_domain: SeparationDomain::admit(CLOSURE_CANONICAL_DOMAIN)
            .expect("static separation domain"),
        digest_domain: SeparationDomain::admit(CLOSURE_DIGEST_DOMAIN)
            .expect("static separation domain"),
        digest: *final_proof.digest(),
        proof: final_proof,
    };
    TotalOutcome::Produced(ApplicationClosure {
        stage0,
        constitution,
        source,
        family_plans,
        binding,
        obligations,
        csag,
        targets,
        runtime,
        upstream_proof_ledger,
        proof_ledger,
        seal,
    })
}

fn release_manifest_canonical(manifest: &ReleaseManifest) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, b"san.release-manifest.edition-2");
    encode_id(&mut output, &manifest.application);
    encode_id(&mut output, manifest.package_lock.stable());
    output.extend_from_slice(&manifest.application_closure_digest);
    encode_u32(&mut output, manifest.format_edition.get());
    encode_u64(&mut output, u64::try_from(manifest.target_artifacts.len()).unwrap_or(u64::MAX));
    for (identity, digest) in &manifest.target_artifacts {
        encode_id(&mut output, identity);
        output.extend_from_slice(digest);
    }
    encode_u64(&mut output, u64::try_from(manifest.provider_requirements.len()).unwrap_or(u64::MAX));
    for requirement in &manifest.provider_requirements { encode_id(&mut output, requirement); }
    output
}

fn app_release_canonical(
    closure: &ApplicationClosure,
    manifest: &ReleaseManifest,
    target_artifacts: &[TargetArtifact],
    provider_requirements: &[ProviderBindingRequirement],
) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, APP_RELEASE_DOMAIN.as_bytes());
    output.extend_from_slice(closure.seal().digest());
    let manifest_bytes = release_manifest_canonical(manifest);
    encode_bytes(&mut output, &manifest_bytes);
    for artifact in target_artifacts {
        encode_id(&mut output, artifact.identity());
        output.extend_from_slice(artifact.digest());
    }
    for requirement in provider_requirements {
        encode_id(&mut output, requirement.identity());
        encode_id(&mut output, requirement.capability());
    }
    output
}

pub fn build_app_release(
    closure: ApplicationClosure,
    budget: WorkBudget,
) -> ExecutableAppReleaseOutcome {
    if closure.seal().proof().stage().stable().as_str() != "cmp013.application-closure"
        || closure.seal().digest() != closure.seal().proof().digest()
    {
        return TotalOutcome::Refused(AppReleaseAssemblyRefusal::ApplicationClosureUnsealed);
    }
    if closure.targets().compilations().is_empty() {
        return TotalOutcome::Refused(AppReleaseAssemblyRefusal::TargetPortfolioIncomplete);
    }
    let target_artifacts: Vec<TargetArtifact> = closure.targets().compilations().iter()
        .map(|compilation| compilation.artifact.clone())
        .collect();
    for artifact in &target_artifacts {
        if sha256(artifact.bytes()) != *artifact.digest() {
            return TotalOutcome::Refused(AppReleaseAssemblyRefusal::TargetArtifactDigestMismatch {
                artifact: artifact.identity().clone(),
            });
        }
    }
    let provider_requirements = closure.runtime().requirements().to_vec();
    let item_count = target_artifacts.len()
        .checked_add(provider_requirements.len())
        .and_then(usize_u64);
    let Some(item_count) = item_count else {
        return TotalOutcome::Refused(AppReleaseAssemblyRefusal::ChargeOverflow);
    };
    let work = match precharge(
        "cmp010.app-release", item_count, item_count.saturating_mul(512),
        item_count.saturating_mul(8), item_count.saturating_mul(1024),
        item_count.saturating_mul(1024), item_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let target_manifest: BTreeMap<StableId, [u8; 32]> = target_artifacts.iter()
        .map(|artifact| (artifact.identity().clone(), *artifact.digest()))
        .collect();
    let manifest = ReleaseManifest {
        application: closure.family_plans().application().clone(),
        package_lock: closure.stage0().package_lock().reference().clone(),
        application_closure_digest: *closure.seal().digest(),
        target_artifacts: target_manifest,
        provider_requirements: provider_requirements.iter()
            .map(|requirement| requirement.identity().clone())
            .collect(),
        format_edition: Edition::admit(2).expect("positive static edition"),
    };
    let canonical = app_release_canonical(&closure, &manifest, &target_artifacts, &provider_requirements);
    let owners = all_package_owners(closure.stage0());
    let release_proof = match issue_stage_proof(
        closure.stage0(), &owners, CompilerSupplierRole::ReleasePackaging,
        "cmp010.app-release", closure.family_plans().application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    let mut proofs = closure.proof_ledger().proofs().to_vec();
    proofs.push(release_proof.clone());
    let proof_ledger = match build_proof_ledger(proofs) {
        Ok(value) => value,
        Err(()) => return TotalOutcome::Refused(AppReleaseAssemblyRefusal::OfflineProofInventoryIncomplete {
            stage: StageId::admit("cmp010.app-release").expect("static stage identity"),
        }),
    };
    let seal = AppReleaseSeal {
        subject: release_proof.subject().clone(),
        separation_domain: SeparationDomain::admit(APP_RELEASE_DOMAIN)
            .expect("static separation domain"),
        digest: *release_proof.digest(),
        proof: release_proof,
    };
    TotalOutcome::Produced(AppRelease {
        application_closure: closure,
        manifest,
        target_artifacts,
        unbound_provider_requirements: provider_requirements,
        proof_ledger,
        seal,
    })
}

fn deployment_canonical(
    app_release: &AppRelease,
    bindings: &[ProviderBinding],
) -> Vec<u8> {
    let mut output = Vec::new();
    encode_bytes(&mut output, DEPLOYMENT_DOMAIN.as_bytes());
    output.extend_from_slice(app_release.seal().digest());
    encode_u64(&mut output, u64::try_from(bindings.len()).unwrap_or(u64::MAX));
    for binding in bindings {
        encode_id(&mut output, binding.requirement.identity());
        encode_id(&mut output, binding.requirement.capability());
        encode_id(&mut output, &binding.provider);
        encode_bytes(&mut output, binding.endpoint.as_bytes());
        encode_artifact(&mut output, &binding.evidence);
    }
    output
}

pub fn bind_deployment_plan(
    app_release: AppRelease,
    offers: Vec<ProviderOfferCarrier>,
    budget: WorkBudget,
) -> ExecutableDeploymentPlanOutcome {
    let offer_count = match usize_u64(offers.len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DeploymentPlanningRefusal::ChargeOverflow),
    };
    let requirement_count = match usize_u64(app_release.provider_requirements().len()) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DeploymentPlanningRefusal::ChargeOverflow),
    };
    let input_bytes = match offers.iter().try_fold(0_u64, |sum, offer| {
        let size = offer.provider.len()
            .checked_add(offer.capability.len())?
            .checked_add(offer.endpoint.len())?
            .checked_add(offer.evidence.identity.len())?
            .checked_add(offer.evidence.occurrence.len())?;
        checked_add(sum, usize_u64(size)?)
    }) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DeploymentPlanningRefusal::ChargeOverflow),
    };
    let comparisons = match checked_mul(requirement_count, offer_count.max(1)) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DeploymentPlanningRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "cmp011.deployment-plan", requirement_count.saturating_add(offer_count), input_bytes,
        comparisons.saturating_mul(4), comparisons.saturating_mul(256),
        comparisons.saturating_mul(256), requirement_count, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let mut admitted_offers = Vec::with_capacity(offers.len());
    for offer in offers {
        if offer.endpoint.is_empty() || offer.endpoint.len() > 2048 {
            return TotalOutcome::Refused(DeploymentPlanningRefusal::ProviderEvidenceInvalid {
                provider: StableId::admit("provider.invalid-endpoint").expect("static identity"),
            });
        }
        let provider = match StableId::admit(offer.provider) {
            Ok(value) => value,
            Err(refusal) => return TotalOutcome::Refused(DeploymentPlanningRefusal::InvalidIdentity(refusal)),
        };
        let capability = match StableId::admit(offer.capability) {
            Ok(value) => value,
            Err(refusal) => return TotalOutcome::Refused(DeploymentPlanningRefusal::InvalidIdentity(refusal)),
        };
        let evidence = match admit_artifact_ref(offer.evidence) {
            Ok(value) => value,
            Err(_) => return TotalOutcome::Refused(DeploymentPlanningRefusal::ProviderEvidenceInvalid { provider }),
        };
        admitted_offers.push((provider, capability, offer.endpoint, evidence));
    }
    admitted_offers.sort_by(|left, right| (&left.1, &left.0).cmp(&(&right.1, &right.0)));
    let mut bindings = Vec::new();
    for requirement in app_release.provider_requirements() {
        let candidates: Vec<_> = admitted_offers.iter()
            .filter(|(_, capability, _, _)| capability == requirement.capability())
            .collect();
        let (minimum, maximum) = cardinality_bounds(requirement.cardinality());
        if candidates.is_empty() {
            match requirement.absence() {
                AbsenceSemantics::Required => {
                    return TotalOutcome::NeedsInput(needs_input(
                        "cmp011.deployment-plan", MissingInputKind::Provider,
                        vec![requirement.capability().clone()],
                    ));
                }
                AbsenceSemantics::OptionalExplicit | AbsenceSemantics::InapplicableWithReason => continue,
            }
        }
        if u64::try_from(candidates.len()).unwrap_or(u64::MAX) < minimum {
            return TotalOutcome::Refused(DeploymentPlanningRefusal::CardinalityUnsatisfied {
                requirement: requirement.identity().clone(),
            });
        }
        if let Some(maximum) = maximum {
            if u64::try_from(candidates.len()).unwrap_or(u64::MAX) > maximum {
                return TotalOutcome::Refused(DeploymentPlanningRefusal::AmbiguousProvider {
                    capability: requirement.capability().clone(),
                    providers: candidates.iter().map(|(provider, _, _, _)| (*provider).clone()).collect(),
                });
            }
        }
        for (provider, _, endpoint, evidence) in candidates {
            bindings.push(ProviderBinding {
                requirement: requirement.clone(),
                provider: provider.clone(),
                endpoint: endpoint.clone(),
                evidence: evidence.clone(),
            });
        }
    }
    if bindings.is_empty() && app_release.provider_requirements().iter()
        .any(|requirement| requirement.absence() == AbsenceSemantics::Required)
    {
        return TotalOutcome::NeedsInput(needs_input(
            "cmp011.deployment-plan", MissingInputKind::Provider,
            app_release.provider_requirements().iter().map(|value| value.capability().clone()).collect(),
        ));
    }
    bindings.sort_by(|left, right| {
        (&left.requirement.identity, &left.provider).cmp(&(&right.requirement.identity, &right.provider))
    });
    let owners: Vec<ReleaseCoordinate> = app_release.provider_requirements().iter()
        .map(|requirement| requirement.runtime_release.clone())
        .collect();
    let canonical = deployment_canonical(&app_release, &bindings);
    let proof = match issue_stage_proof(
        app_release.application_closure().stage0(), &owners,
        CompilerSupplierRole::ProviderPlanAdaptation, "cmp011.deployment-plan",
        app_release.manifest().application(), canonical, work,
    ) {
        Ok(value) => value,
        Err(needs) => return TotalOutcome::NeedsInput(needs),
    };
    let seal = DeploymentPlanSeal {
        separation_domain: SeparationDomain::admit(DEPLOYMENT_DOMAIN)
            .expect("static separation domain"),
        digest: *proof.digest(),
        proof,
    };
    TotalOutcome::Produced(DeploymentPlan { app_release, provider_bindings: bindings, seal })
}

pub fn build_boot_input(
    deployment: DeploymentPlan,
    budget: WorkBudget,
) -> ExecutableBootInputOutcome {
    let item_count = match usize_u64(deployment.provider_bindings().len().saturating_add(1)) {
        Some(value) => value,
        None => return TotalOutcome::Refused(DeploymentPlanningRefusal::ChargeOverflow),
    };
    if let Err(exhaustion) = precharge(
        "cmp011.boot-input", item_count, item_count.saturating_mul(128), item_count.saturating_mul(2),
        512, 512, 0, budget,
    ) {
        return TotalOutcome::Exhausted(exhaustion);
    }
    let mut startup_contract = BTreeMap::new();
    startup_contract.insert(
        StableId::admit("boot.application").expect("static identity"),
        deployment.app_release().manifest().application().clone(),
    );
    startup_contract.insert(
        StableId::admit("boot.provider-binding-count").expect("static identity"),
        StableId::admit(format!("count.{}", deployment.provider_bindings().len()))
            .expect("numeric count prefixed into nominal identity"),
    );
    TotalOutcome::Produced(BootInput {
        release_digest: *deployment.app_release().seal().digest(),
        deployment_digest: *deployment.seal.digest(),
        deployment,
        startup_contract,
    })
}

fn verify_proof_ledger(
    stage0: &Stage0PackageAuthority,
    ledger: &ProofLedger,
) -> Result<BTreeSet<StageId>, OfflineVerificationRefusal> {
    let actual_commitment = sha256(&proof_ledger_canonical(ledger.proofs()));
    if actual_commitment != *ledger.commitment() {
        return Err(OfflineVerificationRefusal::ProofLedgerCommitmentMismatch);
    }
    let mut exact = BTreeSet::new();
    let mut stages = BTreeSet::new();
    for proof in ledger.proofs() {
        if sha256(proof.canonical_bytes()) != *proof.digest() {
            return Err(OfflineVerificationRefusal::ProofDigestMismatch { stage: proof.stage().clone() });
        }
        if proof.package_lock() != stage0.package_lock().reference()
            || proof.subject().package_lock() != stage0.package_lock().reference()
            || proof.subject().stage() != proof.stage()
            || &proof.work().stage != proof.stage()
        {
            return Err(OfflineVerificationRefusal::PackageLockMismatch);
        }
        let key = (
            proof.stage().clone(),
            *proof.digest(),
            proof.subject().release().clone(),
        );
        if !exact.insert(key) {
            return Err(OfflineVerificationRefusal::DuplicateProof { stage: proof.stage().clone() });
        }
        if proof.witnesses().is_empty() {
            return Err(OfflineVerificationRefusal::ProofWitnessMismatch { stage: proof.stage().clone() });
        }
        for witness in proof.witnesses() {
            let Some(disposition) = stage0.disposition(witness.owner(), witness.role()) else {
                return Err(OfflineVerificationRefusal::ProofWitnessMismatch { stage: proof.stage().clone() });
            };
            if disposition.available_supplier() != Some(witness.supplier())
                || disposition.evidence() != witness.evidence()
            {
                return Err(OfflineVerificationRefusal::ProofWitnessMismatch { stage: proof.stage().clone() });
            }
        }
        stages.insert(proof.stage().clone());
    }
    Ok(stages)
}

fn required_final_stage_ids(csag: &Csag) -> Vec<&'static str> {
    let mut required = required_upstream_stage_ids().to_vec();
    if csag.proof().authority_cycle_proof().is_some() {
        required.push("cmp008.authority-cycle");
    }
    required.push("cmp013.application-closure");
    required.push("cmp010.app-release");
    required
}

pub fn verify_boot_input_offline(
    boot: &BootInput,
    anchor: &PinnedStage0TrustAnchor,
    budget: WorkBudget,
) -> ExecutableOfflineVerificationOutcome {
    let deployment = boot.deployment();
    let release = deployment.app_release();
    let closure = release.application_closure();
    let proof_count = release.proof_ledger().proofs().len().saturating_add(1);
    let proof_count_u64 = match usize_u64(proof_count) {
        Some(value) => value,
        None => return TotalOutcome::Refused(OfflineVerificationRefusal::ChargeOverflow),
    };
    let work = match precharge(
        "offline.reverification", proof_count_u64, proof_count_u64.saturating_mul(1024),
        proof_count_u64.saturating_mul(16), proof_count_u64.saturating_mul(256),
        proof_count_u64.saturating_mul(128), proof_count_u64, budget,
    ) {
        Ok(value) => value,
        Err(exhaustion) => return TotalOutcome::Exhausted(exhaustion),
    };
    let _ = work;
    if let Err(refusal) = verify_stage0_offline(closure.stage0(), anchor) {
        return TotalOutcome::Refused(OfflineVerificationRefusal::Stage0(refusal));
    }
    let mut checked_stages = match verify_proof_ledger(closure.stage0(), release.proof_ledger()) {
        Ok(value) => value,
        Err(refusal) => return TotalOutcome::Refused(refusal),
    };
    for stage in required_final_stage_ids(closure.csag()) {
        let stage_id = StageId::admit(stage).expect("static stage identity");
        if !checked_stages.contains(&stage_id) {
            return TotalOutcome::Refused(OfflineVerificationRefusal::MissingProof { stage: stage_id });
        }
    }
    let closure_canonical = application_closure_canonical(
        closure.stage0(), closure.constitution(), closure.source(), closure.family_plans(),
        closure.binding(), closure.obligations(), closure.csag(), closure.targets(),
        closure.runtime(), &closure.upstream_proof_ledger,
    );
    let closure_digest = sha256(&closure_canonical);
    if closure_digest != *closure.seal().digest()
        || closure_digest != *closure.seal().proof().digest()
    {
        return TotalOutcome::Refused(OfflineVerificationRefusal::ApplicationClosureDigestMismatch);
    }
    for artifact in release.target_artifacts() {
        if sha256(artifact.bytes()) != *artifact.digest() {
            return TotalOutcome::Refused(OfflineVerificationRefusal::AppReleaseDigestMismatch);
        }
    }
    let release_canonical = app_release_canonical(
        closure,
        release.manifest(),
        release.target_artifacts(),
        release.provider_requirements(),
    );
    let release_digest = sha256(&release_canonical);
    if release_digest != *release.seal().digest()
        || release_digest != *release.seal().proof().digest()
    {
        return TotalOutcome::Refused(OfflineVerificationRefusal::AppReleaseDigestMismatch);
    }
    let deployment_canonical = deployment_canonical(release, deployment.provider_bindings());
    let deployment_digest = sha256(&deployment_canonical);
    if deployment_digest != *deployment.seal.digest()
        || deployment_digest != *deployment.seal.proof.digest()
    {
        return TotalOutcome::Refused(OfflineVerificationRefusal::DeploymentDigestMismatch);
    }
    let deployment_ledger = match build_proof_ledger(vec![deployment.seal.proof.clone()]) {
        Ok(value) => value,
        Err(()) => return TotalOutcome::Refused(OfflineVerificationRefusal::DeploymentDigestMismatch),
    };
    match verify_proof_ledger(closure.stage0(), &deployment_ledger) {
        Ok(stages) => checked_stages.extend(stages),
        Err(refusal) => return TotalOutcome::Refused(refusal),
    }
    if boot.release_digest() != release.seal().digest()
        || boot.deployment_digest() != deployment.seal.digest()
    {
        return TotalOutcome::Refused(OfflineVerificationRefusal::BootInputMismatch);
    }
    TotalOutcome::Produced(OfflineVerificationReport {
        package_lock: closure.stage0().package_lock().reference().clone(),
        checked_stages,
        proof_count: proof_count_u64,
        application_closure_digest: closure_digest,
        app_release_digest: release_digest,
        deployment_digest,
    })
}
