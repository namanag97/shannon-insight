
mod common;

use common::*;
use san_composition_reference::*;
use std::collections::BTreeSet;

#[test]
fn omitted_selected_release_inventory_is_rejected() {
    let verifier = CompilerVerifier::new(verifier_id("verifier.reference"));
    let lock = package_lock();
    let omitted = lock.selected_releases[3].occurrence.clone();
    let rows: Vec<_> = complete_supplier_inventory(&lock)
        .into_iter()
        .filter(|row| row.release_occurrence != omitted)
        .collect();
    let result = verifier.close_supplier_inventory(&lock, &rows, WorkBudget::new(232));
    assert!(matches!(
        result,
        Err(CompileFailure::Refused(Refusal::SupplierInventoryIncomplete { .. }))
    ));
}

#[test]
fn supplier_budget_maximum_plus_one_is_exhaustion_not_refusal() {
    let verifier = CompilerVerifier::new(verifier_id("verifier.reference"));
    let lock = package_lock();
    let rows = complete_supplier_inventory(&lock);
    let result = verifier.close_supplier_inventory(&lock, &rows, WorkBudget::new(231));
    assert_eq!(
        result,
        Err(CompileFailure::Exhausted(
            Exhaustion::SupplierInventoryBudgetExhausted
        ))
    );
}

#[test]
fn missing_offer_is_rejected_before_application_binding() {
    let verifier = CompilerVerifier::new(verifier_id("verifier.reference"));
    let lock = package_lock();
    let rows = complete_supplier_inventory(&lock);
    let supplier = verifier
        .close_supplier_inventory(&lock, &rows, WorkBudget::new(232))
        .expect("supplier closure");
    let mut offers = offers();
    offers.retain(|offer| offer.offer_id != offer_id("offer:risk-data"));
    let result = verifier.bind_application(
        &lock,
        &supplier,
        &requirements(),
        &offers,
        &decisions(),
        WorkBudget::new(4),
    );
    assert!(matches!(
        result,
        Err(CompileFailure::Refused(Refusal::MissingOffer { .. }))
    ));
}

#[test]
fn unclosed_obligation_is_rejected() {
    let verifier = CompilerVerifier::new(verifier_id("verifier.reference"));
    let lock = package_lock();
    let rows = complete_supplier_inventory(&lock);
    let supplier = verifier
        .close_supplier_inventory(&lock, &rows, WorkBudget::new(232))
        .expect("supplier closure");
    let binding = verifier
        .bind_application(
            &lock,
            &supplier,
            &requirements(),
            &offers(),
            &decisions(),
            WorkBudget::new(4),
        )
        .expect("binding");
    let mut obligations = obligations();
    obligations[1].discharge_evidence = None;
    let result = verifier.close_obligations(
        &lock,
        &binding,
        &obligations,
        RuleEdition::parse("rule-edition-1").expect("rule edition"),
        SchemaEdition::parse("schema-edition-1").expect("schema edition"),
        WorkBudget::new(5),
    );
    assert!(matches!(
        result,
        Err(CompileFailure::Refused(Refusal::UnclosedObligation { .. }))
    ));
}

#[test]
fn incapable_target_is_rejected_before_lowering() {
    let verifier = CompilerVerifier::new(verifier_id("verifier.reference"));
    let lock = package_lock();
    let rows = complete_supplier_inventory(&lock);
    let supplier = verifier
        .close_supplier_inventory(&lock, &rows, WorkBudget::new(232))
        .expect("supplier closure");
    let binding = verifier
        .bind_application(
            &lock,
            &supplier,
            &requirements(),
            &offers(),
            &decisions(),
            WorkBudget::new(4),
        )
        .expect("binding");
    let obligation = verifier
        .close_obligations(
            &lock,
            &binding,
            &obligations(),
            RuleEdition::parse("rule-edition-1").expect("rule edition"),
            SchemaEdition::parse("schema-edition-1").expect("schema edition"),
            WorkBudget::new(5),
        )
        .expect("obligations");
    let (nodes, edges) = graph();
    let csag = verifier
        .admit_csag(
            &lock,
            &binding,
            &obligation,
            &nodes,
            &edges,
            WorkBudget::new(15),
        )
        .expect("csag");
    let modules = ir_modules();
    let portfolio = verifier
        .seal_ir_portfolio(&csag, &modules)
        .expect("portfolio");
    let mut incapable = target(&modules);
    incapable.supported_capabilities.remove(&capability("capability.navigation"));
    let result = verifier.negotiate_target(&portfolio, &incapable, WorkBudget::new(12));
    assert!(matches!(
        result,
        Err(CompileFailure::Refused(Refusal::UnsupportedIrFeature { .. }))
    ));
}

#[test]
fn environment_fields_cannot_leak_into_execution_binding() {
    let modules = ir_modules();
    let mut implementations = runtime_implementations(&modules);
    implementations[0]
        .declared_environment_fields
        .insert("region".to_owned());
    assert!(!implementations[0].declared_environment_fields.is_empty());
}

#[test]
fn different_package_lock_replay_is_rejected() {
    let expected = commitment("expected-lock");
    let supplied = commitment("different-lock");
    assert_ne!(expected, supplied);
}

#[test]
fn incremental_and_clean_build_must_match() {
    assert_ne!(commitment("clean"), commitment("incremental-mismatch"));
}

#[test]
fn dependency_occurrences_are_exact_not_value_aliases() {
    let dependencies = vec![
        (
            artifact_kind("artifact-kind.test"),
            occurrence("dependency:one:1"),
            commitment("same-looking-value"),
        ),
        (
            artifact_kind("artifact-kind.test"),
            occurrence("dependency:two:1"),
            commitment("same-looking-value"),
        ),
    ];
    let occurrences: BTreeSet<_> = dependency_occurrences(&dependencies);
    assert_eq!(occurrences.len(), 2);
}
