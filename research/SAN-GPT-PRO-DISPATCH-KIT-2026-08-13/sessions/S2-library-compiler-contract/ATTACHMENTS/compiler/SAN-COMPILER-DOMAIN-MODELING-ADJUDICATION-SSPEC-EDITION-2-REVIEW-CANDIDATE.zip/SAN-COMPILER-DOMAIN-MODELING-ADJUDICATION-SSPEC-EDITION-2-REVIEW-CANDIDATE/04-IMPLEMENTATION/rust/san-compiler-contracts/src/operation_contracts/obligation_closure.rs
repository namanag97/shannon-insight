//! Operation contracts owned by `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`.

pub trait ObligationClosureContracts {
    /// `obligation-fixed-point.input.admit`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_obligation_closure_input(
        &self,
        arg0: crate::catalog_types::obligation_closure::ObligationClosureInputMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureInput, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.program.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_obligation_program(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationClosureInput,
        arg1: &crate::catalog_types::obligation_closure::ObligationTrustPolicy,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::VerifiedObligationProgram, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.dispatch.bind`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn bind_obligation_dispatch_table(
        &self,
        arg0: &crate::catalog_types::obligation_closure::VerifiedObligationProgram,
        arg1: &crate::catalog_types::obligation_closure::GeneratedRulePlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationDispatchTable, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.universe.close`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_obligation_universe(
        &self,
        arg0: &crate::catalog_types::obligation_closure::VerifiedObligationProgram,
        arg1: &crate::catalog_types::obligation_closure::FiniteParameterSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationUniverse, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.key.intern`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn intern_obligation_key(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationUniverse,
        arg1: &crate::catalog_types::obligation_closure::StableObligationKey,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationKeyIndex, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.plan.graph`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_rule_dependency_graph(
        &self,
        arg0: &crate::catalog_types::obligation_closure::VerifiedObligationProgram,
        arg1: &crate::catalog_types::obligation_closure::ObligationUniverse,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::RuleDependencyGraph, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.plan.scc`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_scc_plan(
        &self,
        arg0: &crate::catalog_types::obligation_closure::RuleDependencyGraph,
        arg1: &crate::catalog_types::obligation_closure::VerifiedObligationProgram,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::SccExecutionPlan, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.plan.seminaive`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_semi_naive_variants(
        &self,
        arg0: &crate::catalog_types::obligation_closure::SccExecutionPlan,
        arg1: &crate::catalog_types::obligation_closure::VerifiedObligationProgram,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::SemiNaivePlan, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.plan.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_execution_plan(
        &self,
        arg0: &crate::catalog_types::obligation_closure::GeneratedRulePlan,
        arg1: &crate::catalog_types::obligation_closure::VerifiedObligationProgram,
        arg2: &crate::catalog_types::obligation_closure::ObligationUniverse,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ExecutionPlanProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.seed.collect`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn collect_obligation_seeds(
        &self,
        arg0: &crate::vertical::ResolvedDecisionSet,
        arg1: &crate::catalog_types::application_binding::BindingResolution,
        arg2: &crate::catalog_types::application_binding::ExtensionBindingSet,
        arg3: &crate::vertical::GapDispositionSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationSeedSet, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.seed.admit`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_obligation_seeds(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationSeedSet,
        arg1: &crate::catalog_types::obligation_closure::ObligationUniverse,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::AdmittedObligationSeedSet, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.store.initialize`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn initialize_obligation_store(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationUniverse,
        arg1: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationStore, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.store.seed`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_seed_batch(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::AdmittedObligationSeedSet,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::CommitReceipt, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.subscriber.activate`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn activate_subscribed_rules(
        &self,
        arg0: &crate::catalog_types::obligation_closure::DeltaFrontier,
        arg1: &crate::catalog_types::obligation_closure::RuleSubscriberIndex,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::DirtyRuleSet, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.rule.evaluate`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn evaluate_rule(
        &self,
        arg0: &crate::catalog_types::obligation_closure::CompiledObligationRule,
        arg1: &crate::catalog_types::obligation_closure::ObligationReadView,
        arg2: &crate::catalog_types::obligation_closure::RecentDeltaView,
        arg3: crate::catalog_types::obligation_closure::RuleBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::RuleEvaluation, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.rule.evaluate-scc`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn evaluate_scc_round(
        &self,
        arg0: &crate::catalog_types::obligation_closure::SccExecutionPlan,
        arg1: &crate::catalog_types::obligation_closure::ObligationStore,
        arg2: &crate::catalog_types::obligation_closure::DeltaFrontier,
        arg3: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg4: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::SccProposalBatch, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.proposal.validate`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn validate_rule_proposal(
        &self,
        arg0: &crate::catalog_types::obligation_closure::RuleProposal,
        arg1: &crate::catalog_types::obligation_closure::ObligationUniverse,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: &crate::waist::AuthorityPolicySet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ValidatedProposal, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.proposal.canonicalize`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn canonicalize_proposals(
        &self,
        arg0: Vec<crate::catalog_types::obligation_closure::ValidatedProposal>,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::target_compilation::CanonicalProposalBatch, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.proposal.commit`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_proposal_batch(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::target_compilation::CanonicalProposalBatch,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::CommitReceipt, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.frontier.advance`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn advance_delta_frontier(
        &self,
        arg0: crate::catalog_types::obligation_closure::CommitReceipt,
        arg1: &crate::catalog_types::obligation_closure::SccExecutionPlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::DeltaFrontier, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.scc.close`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_scc(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: crate::catalog_types::obligation_closure::SccId,
        arg2: &crate::catalog_types::obligation_closure::SccExecutionPlan,
        arg3: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg4: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::SccClosureProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.program.close`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_rule_program(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::SccExecutionPlan,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::RuleProgramClosure, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.requirement.collect`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn collect_derived_requirements(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::DerivationFrontier,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::DerivedRequirementSet, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.requirement.resolve`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_derived_requirements(
        &self,
        arg0: &crate::catalog_types::obligation_closure::DerivedRequirementSet,
        arg1: &crate::catalog_types::obligation_closure::ApplicationLinkerKernel,
        arg2: &crate::catalog_types::application_binding::SelectionDirectiveSet,
        arg3: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::DerivedRequirementOutcome, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.binding.commit`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_derived_binding_facts(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::DerivedRequirementResolution,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::CommitReceipt, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.selection.request`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn derive_obligation_selection_requests(
        &self,
        arg0: &crate::catalog_types::obligation_closure::DerivedRequirementResolution,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::SelectionRequestSet, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.selection.checkpoint`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn checkpoint_for_selection(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationEvaluationState,
        arg1: &crate::catalog_types::obligation_closure::SelectionRequestSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureCheckpoint, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.selection.resume`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_after_selection(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationClosureCheckpoint,
        arg1: &crate::catalog_types::application_binding::SelectionDirectiveSet,
        arg2: &crate::catalog_types::obligation_closure::ObligationClosureInput,
        arg3: &crate::catalog_types::obligation_closure::ObligationExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureOutcome, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.discharge.admit`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn admit_discharge_evidence(
        &self,
        arg0: crate::catalog_types::obligation_closure::DischargeEvidenceMaterial,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::AdmittedDischargeEvidence, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.discharge.validate`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn validate_discharge(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationFact,
        arg1: &crate::catalog_types::obligation_closure::AdmittedDischargeEvidence,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: crate::catalog_types::obligation_closure::DischargeBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::DischargeProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.discharge.commit`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_discharge_disposition(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::DischargeProof,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::CommitReceipt, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.discharge.revalidate`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn revalidate_stale_discharges(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::CommitReceipt,
        arg2: &crate::catalog_types::obligation_closure::DischargeEvidenceSet,
        arg3: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::CommitReceipt, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.fixed-point.step`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn advance_fixed_point(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationEvaluationState,
        arg1: &crate::catalog_types::obligation_closure::ObligationExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationProgress, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.fixed-point.close`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_obligation_fixed_point(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationClosureInput,
        arg1: &crate::catalog_types::obligation_closure::ObligationExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureOutcome, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.quiescence.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_quiescence(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::DeltaFrontier,
        arg2: &crate::catalog_types::obligation_closure::DirtyRuleSet,
        arg3: &crate::catalog_types::obligation_closure::DerivedRequirementState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::QuiescenceProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.leastness.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_least_fixed_point(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::VerifiedObligationProgram,
        arg2: &crate::catalog_types::obligation_closure::ObligationProofContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::LeastFixedPointProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.termination.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_termination(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationStore,
        arg1: &crate::catalog_types::obligation_closure::SccExecutionPlan,
        arg2: &crate::catalog_types::obligation_closure::ProgressLedger,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::TerminationProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.no-drop.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_no_dropped_obligations(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationSeedSet,
        arg1: &crate::catalog_types::obligation_closure::ObligationStore,
        arg2: &crate::catalog_types::obligation_closure::ObligationProofGraph,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::NoDroppedObligationProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.proof.build`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_obligation_proof_manifest(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationEvaluationState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureProofManifest, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.explanation.build`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_obligation_explanation_graph(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationEvaluationState,
        arg1: crate::waist::DisclosurePolicyRef,
        arg2: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureExplanationGraph, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.canonical.project`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn project_obligation_closure(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationEvaluationState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureCanonicalProjection, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.closure.build`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_obligation_fixed_point_closure(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationEvaluationState,
        arg1: &crate::catalog_types::obligation_closure::ObligationClosureCanonicalProjection,
        arg2: &crate::catalog_types::obligation_closure::ObligationClosureProofManifest,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::ObligationClosure, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.closure.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_obligation_fixed_point_closure(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: &crate::catalog_types::obligation_closure::ObligationVerificationContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureVerificationProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.checkpoint.create`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_obligation_checkpoint(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationEvaluationState,
        arg1: crate::catalog_types::obligation_closure::ResumableStage,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureCheckpoint, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.checkpoint.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_obligation_checkpoint(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationClosureCheckpoint,
        arg1: &crate::catalog_types::obligation_closure::ObligationClosureInput,
        arg2: &crate::catalog_types::obligation_closure::ObligationExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::CheckpointResumeProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.delta.classify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_obligation_closure_delta(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: &crate::vertical::ObligationClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureDelta, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.recompute.plan`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn plan_affected_scc_recompute(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationClosureDelta,
        arg1: &crate::catalog_types::obligation_closure::SccExecutionPlan,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::AffectedSccRecomputePlan, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.recompute.execute`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn recompute_affected_sccs(
        &self,
        arg0: &crate::catalog_types::obligation_closure::AffectedSccRecomputePlan,
        arg1: &crate::catalog_types::obligation_closure::ObligationClosureInput,
        arg2: &crate::catalog_types::obligation_closure::ObligationExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationClosureOutcome, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.reference.close-naive`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn close_reference_naive(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ObligationClosureInput,
        arg1: &crate::catalog_types::obligation_closure::ReferenceExecutionContext,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ReferenceClosureResult, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.parity.verify`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_optimized_reference_parity(
        &self,
        arg0: &crate::vertical::ObligationClosure,
        arg1: &crate::catalog_types::obligation_closure::ReferenceClosureResult,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::OptimizationParityProof, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.parallel.propose`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn evaluate_parallel_proposals(
        &self,
        arg0: &crate::catalog_types::obligation_closure::ParallelSccLayer,
        arg1: &crate::catalog_types::obligation_closure::ObligationReadView,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: crate::catalog_types::obligation_closure::ParallelBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<Vec<crate::catalog_types::obligation_closure::WorkerProposalBuffer>, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.parallel.commit`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn commit_parallel_barrier(
        &self,
        arg0: &mut crate::catalog_types::obligation_closure::ObligationStore,
        arg1: Vec<crate::catalog_types::obligation_closure::WorkerProposalBuffer>,
        arg2: &crate::catalog_types::obligation_closure::ObligationDispatchTable,
        arg3: crate::catalog_types::obligation_closure::ObligationClosureBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::CommitReceipt, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

    /// `obligation-fixed-point.explain`. Owner: `SAN-COMPILER-OBLIGATION-FIXED-POINT-CLOSURE`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_obligation_target(
        &self,
        arg0: crate::catalog_types::obligation_closure::ObligationExplainTarget,
        arg1: &crate::catalog_types::obligation_closure::ObligationClosureOutcome,
        arg2: crate::waist::DisclosurePolicyRef,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::obligation_closure::ObligationExplanation, crate::vertical::ObligationClosureRefusal, crate::waist::CompilerNeedsInput>;

}
