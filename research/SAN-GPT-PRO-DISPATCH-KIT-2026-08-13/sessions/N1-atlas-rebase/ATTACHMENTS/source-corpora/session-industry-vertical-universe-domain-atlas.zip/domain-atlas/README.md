# SAN Industry and Public-Domain Vertical Universe Atlas

This package is a machine-readable research corpus for the work package **INDUSTRY AND PUBLIC-DOMAIN VERTICAL UNIVERSE**.

JSON and JSONL are the source of truth. `generated/SUMMARY.md` is navigation only.

## What this package does

- represents 21 independent coverage families, 145 vertical partitions and 290 candidate bounded contexts;
- separates industries, public functions, household activities, scientific domains, organizational functions, profiles and compositions;
- crosswalks every node in the supplied SAN registry context map without mutating it;
- tests horizontal semantics against twelve structurally different adversarial verticals;
- records conflicts, gaps and unresolved boundaries instead of hiding uncertainty in generic fields.

## What this package does not do

It does not build a compiler, application, service, data platform, deployment or Rust library. It does not ratify registry identities, semantic owners or bounded contexts.

## Validation

Run from the package root:

```bash
python tools/validate_corpus.py .
```

The deterministic package validation result is also recorded in `VALIDATION.json` and `coverage/validation_summary.json`.

## Checksum convention

`CHECKSUMS.txt` contains SHA-256 hashes for every package file except `CHECKSUMS.txt` itself. `manifest.json` inventories every file except `manifest.json` and `CHECKSUMS.txt` to avoid self-referential hashes.
