# Open decisions and unproven claims

Every item below is open in Edition 1. No default was inferred from archive size, recency, file count or verifier success.

## Compiler A/B external decision dependencies

1. **AB-001 — Stage-0 trust root and constitution compiler.** Whether signed Stage-0 authority is an input artifact only or is compiled by a registered pure Constitution Compiler.
2. **AB-002 — Constitution compilation as registered stage.** Whether Constitution compilation is CCP-001, CMP-000, or outside the application compiler stage count.
3. **AB-003 — Parse and admission split.** Whether restricted parsing and semantic/source admission are distinct stages and which poison-recovery guarantees cross the seam.
4. **AB-004 — Package, module and edition resolution owner.** Which stage resolves package locks, family/module editions, profiles and source authority before name binding.
5. **AB-005 — Name and coordinate binding boundary.** Whether names, stable coordinates, aliases and cross-edition references bind in one stage or separate symbol/edition resolvers.
6. **AB-006 — Contribution, join and decision resolution boundary.** Which stage owns contribution collection, joins, cardinality, defaults, conflicts and explicit decisions.
7. **AB-007 — Family closure content.** Whether family closure emits plans, requirements, offers, obligation seeds and family proofs, and what must be non-empty.
8. **AB-008 — ApplicationClosure versus ApplicationBinding at CMP-006.** Whether CMP-006 is an intermediate binding or a final application closure; the two meanings cannot share one finality claim.
9. **AB-009 — Obligation orchestration ownership.** Division of contract binding, obligation fixed-point iteration, refusal precedence and closure proof between CMP-006 and CMP-007.
10. **AB-010 — Graph inputs and assurance projection.** Exact inputs to the verified semantic application graph and whether assurance is embedded, projected, or independently judged.
11. **AB-011 — Final closure issuer.** Whether final verified ApplicationClosure is issued by CMP-006, proposed CMP-013, or another stage after graph, target and runtime checks.
12. **AB-012 — Finality relative to target and runtime feasibility.** Whether semantic closure may be called final before target feasibility, resource/provider closure and boot feasibility are proven.
13. **AB-013 — Portable IR dialect versus target compiler contract.** Stable ownership split among portable IR meaning, dialect validators, target compilers and translation/preservation proofs.
14. **AB-014 — Target compiler dispatch.** Descriptor/query contract for generic target selection without TGT-name branches and who selects target compiler implementations.
15. **AB-015 — AppRelease identity.** Relationship among AppRelease, BackendAppRelease, target compilation set, product release and deployment input.
16. **AB-016 — Product Release Composer.** Whether a CMP-014 or separate product assembler combines backend, experience, data and operational release parts.
17. **AB-017 — Migration planner order.** Whether semantic diff/migration precedes sealing, follows sealing, or is a side pipeline keyed by exact releases.
18. **AB-018 — Environment binder input and ownership.** Whether environment binding consumes AppRelease, BackendAppRelease, resource requirements, provider offers, or a final closure artifact.
19. **AB-019 — Deployment, boot and catalog projection.** Exact artifact chain from environment binding through deployment plan, boot input, BootReport and published release/catalog evidence.
20. **AB-020 — Incremental, cache and checkpoint equivalence.** Required dependency fingerprints, invalidation laws and proof that cached/resumed compilation equals clean compilation.
21. **AB-021 — Release signatures, SBOM, provenance and attestations.** Which stage or independent assurance authority emits signatures, SBOM/provenance and conformance attestations.
22. **AB-022 — Owner authority handoff.** How owner selections, authority witnesses and independent assurance are pinned into immutable compiler snapshots.
23. **AB-023 — Coordinate and alias migration.** How breaking coordinate changes, aliases, supersession and edition coexistence are consumed by the compiler.
24. **AB-024 — Assurance representation.** Whether assurance is a portable IR, a proof/evidence graph, a compiler query family, an independent stage, or several typed artifacts.
25. **AB-025 — Canonical compiler stage count.** Selection among current 12-stage, 13-stage and 14-stage proposals, including treatment of Constitution and final closure stages.

## Everything not proven

1. **NP-001.** No cryptographically signed Stage-0 authority package is present in the handoff.
2. **NP-002.** No owner-ratified global registry edition is present.
3. **NP-003.** No constitutional contract is certified; attached contract packages identify certification as NONE.
4. **NP-004.** No canonical compiler A/B pipeline, stage count or finality model has been selected.
5. **NP-005.** No non-vacuous end-to-end compilation of two or more selected semantic releases is evidenced.
6. **NP-006.** No real requirement/offer selection, decision/cardinality resolution and resolved binding vertical is evidenced.
7. **NP-007.** No closed obligation fixed point with complete gap disposition is execution-proven.
8. **NP-008.** No non-empty verified semantic application graph is execution-proven.
9. **NP-009.** No portable-IR-to-concrete-target lowering or preservation proof is execution-proven.
10. **NP-010.** No runtime/resource/provider closure is execution-proven.
11. **NP-011.** No final sealed ApplicationClosure, AppRelease and deployment/boot-input chain is execution-proven.
12. **NP-012.** No generic descriptor/query dispatch implementation has been inspected in the private repository.
13. **NP-013.** No provider implementation has current conformance evidence against the selected resource contracts.
14. **NP-014.** No mixed Semantic/Data/Domain/Human-Work/User-Interface/Target/Runtime boot vertical is proven.
15. **NP-015.** The 34 governed-data candidates are not owner-ratified; ten are reclassified here and twenty-four remain qualification candidates.
16. **NP-016.** The 20 domains, 60 subdomains and 129 bounded-context hypotheses lack named owner ratification; 48 contexts are explicitly research-incomplete.
17. **NP-017.** The Human Work and Experience corpus has no admitted global owner boundary; only qualification dispositions are issued here.
18. **NP-018.** No admitted User Interface registry, target-independent presentation compiler or accessible multi-device runtime conformance vertical exists.
19. **NP-019.** No authoritative one-record-to-one-or-many-package implementation map has been approved.
20. **NP-020.** No independent human review, ratification vote or certification signature covers this generated registry architecture.
21. **NP-021.** The stale private-repository global audit/generator has not been repaired or executed by this package.
22. **NP-022.** The historical intended count of 135 active coordinates is not proven and is not adopted.
23. **NP-023.** No complete migration proof exists for legacy coordinates whose architectural kind changes.
24. **NP-024.** No software-supply-chain attestation binds this registry package to a private-repository commit or build environment.
25. **NP-025.** Representative industry cases falsify obvious omissions but do not prove universal enterprise coverage.

## Additional research and implementation gaps

See `RESEARCH-GAP-LEDGER.json` for User Interface intermediate representation, reference publication authority, management/repair boundaries, assurance independence, provider-offer lifecycle, cross-edition migration and registry performance evidence.
