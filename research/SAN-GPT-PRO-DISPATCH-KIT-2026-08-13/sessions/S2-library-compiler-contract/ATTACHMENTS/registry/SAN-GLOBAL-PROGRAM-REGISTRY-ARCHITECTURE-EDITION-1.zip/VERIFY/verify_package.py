#!/usr/bin/env python3
from __future__ import annotations

import copy
import datetime as dt
import hashlib
import io
import json
import re
import sys
import tempfile
import zipfile
from collections import Counter, defaultdict, deque
from pathlib import Path
from typing import Any

REQUIRED_FILES = [
    'CODEX-START-HERE.md',
    'EXECUTIVE-ARCHITECTURE-DECISION.md',
    'REGISTRY-METAMODEL.json',
    'REGISTRY-METAMODEL.schema.json',
    'NAMESPACE-REGISTRY.json',
    'UNIT-KIND-REGISTRY.json',
    'IDENTITY-AND-EDITION-RULES.json',
    'GLOBAL-PROGRAM-REGISTRY.json',
    'GLOBAL-PROGRAM-REGISTRY.schema.json',
    'SOURCE-AUTHORITY-LEDGER.json',
    'OWNERSHIP-MATRIX.json',
    'COORDINATE-ALIAS-AND-MIGRATION.json',
    'CONFLICT-ADJUDICATION-LEDGER.json',
    'HARD-DEPENDENCY-DAG.json',
    'SEMANTIC-SEAM-HYPERGRAPH.json',
    'COMPILATION-ARTIFACT-DAG.json',
    'RUNTIME-RESOURCE-PROVIDER-DAG.json',
    'DOMAIN-ONTOLOGY-CONTEXT-MAP.json',
    'CAPABILITY-COVERAGE-MATRIX.json',
    'INDUSTRY-COVERAGE-EVIDENCE.json',
    'COMPLETENESS-EVIDENCE-MATRIX.json',
    'RESEARCH-SOURCE-LEDGER.json',
    'RESEARCH-GAP-LEDGER.json',
    'IMPLEMENTATION-ORDER.json',
    'REGISTRY-CHANGE-PROTOCOL.md',
    'REGISTRY-INTAKE-PROTOCOL.md',
    'REGISTRY-QUERY-CONTRACTS.json',
    'OPEN-DECISIONS.md',
    'PACKAGE-VERIFY.json',
    'MANIFEST.json',
    'VERIFY/verify_package.py',
]
FIXED_TIMESTAMP = (1980, 1, 1, 0, 0, 0)
EXPECTED_INPUT_SHA256 = '33fc202efba3630343b1e83a7934ade096e3ebe1816798070fb7a1696b92a02e'
SEMANTIC_PROVIDER_MARKERS = ('aws', 'azure', 'gcp', 'google cloud', 'databricks', 'snowflake', 'oracle cloud', 'kubernetes')
CANDIDATE_MARKERS = ('CANDIDATE', 'EXTERNALLY_GENERATED')


class VerifyError(Exception):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerifyError(message)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_bytes(value: Any) -> bytes:
    def visit(node: Any, path: str = '$') -> None:
        if isinstance(node, float):
            raise VerifyError(f'floating point is outside canonical generated subset at {path}')
        if isinstance(node, dict):
            for key, item in node.items():
                require(isinstance(key, str), f'non-string JSON key at {path}')
                require(all(ord(ch) < 128 for ch in key), f'non-ASCII JSON key outside canonical subset at {path}.{key}')
                visit(item, path + '.' + key)
        elif isinstance(node, list):
            for index, item in enumerate(node):
                visit(item, f'{path}[{index}]')
        elif node is not None and not isinstance(node, (str, int, bool)):
            raise VerifyError(f'unsupported JSON value at {path}: {type(node).__name__}')
    visit(value)
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')) + '\n').encode('utf-8')


def parse_json(data: bytes, name: str) -> Any:
    def pairs_hook(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise VerifyError(f'duplicate JSON key {key!r} in {name}')
            result[key] = value
        return result
    try:
        value = json.loads(data.decode('utf-8'), object_pairs_hook=pairs_hook)
    except VerifyError:
        raise
    except Exception as exc:
        raise VerifyError(f'invalid JSON in {name}: {exc}') from exc
    expected = canonical_bytes(value)
    require(data == expected, f'non-canonical JSON serialization: {name}')
    return value


def json_type_matches(value: Any, expected: str) -> bool:
    if expected == 'object':
        return isinstance(value, dict)
    if expected == 'array':
        return isinstance(value, list)
    if expected == 'string':
        return isinstance(value, str)
    if expected == 'integer':
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == 'boolean':
        return isinstance(value, bool)
    if expected == 'null':
        return value is None
    if expected == 'number':
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    raise VerifyError(f'unsupported schema type in verifier: {expected}')


def validate_schema_instance(value: Any, schema: dict[str, Any], path: str = '$') -> None:
    if 'const' in schema:
        require(value == schema['const'], f'{path}: const mismatch')
    if 'enum' in schema:
        require(value in schema['enum'], f'{path}: value not in enum')
    if 'type' in schema:
        types = schema['type'] if isinstance(schema['type'], list) else [schema['type']]
        require(any(json_type_matches(value, t) for t in types), f'{path}: expected type {types}, got {type(value).__name__}')
    if isinstance(value, dict):
        required = schema.get('required', [])
        for key in required:
            require(key in value, f'{path}: missing required property {key}')
        props = schema.get('properties', {})
        additional = schema.get('additionalProperties', True)
        for key, item in value.items():
            if key in props:
                validate_schema_instance(item, props[key], path + '.' + key)
            elif additional is False:
                raise VerifyError(f'{path}: unknown property {key}')
            elif isinstance(additional, dict):
                validate_schema_instance(item, additional, path + '.' + key)
    if isinstance(value, list):
        if 'minItems' in schema:
            require(len(value) >= schema['minItems'], f'{path}: fewer than minItems')
        if 'maxItems' in schema:
            require(len(value) <= schema['maxItems'], f'{path}: more than maxItems')
        if schema.get('uniqueItems'):
            encoded = [canonical_bytes(item) for item in value]
            require(len(encoded) == len(set(encoded)), f'{path}: duplicate array item')
        if 'items' in schema:
            for index, item in enumerate(value):
                validate_schema_instance(item, schema['items'], f'{path}[{index}]')
    if isinstance(value, str):
        if 'minLength' in schema:
            require(len(value) >= schema['minLength'], f'{path}: shorter than minLength')
        if 'pattern' in schema:
            require(re.search(schema['pattern'], value) is not None, f'{path}: pattern mismatch')
        if schema.get('format') == 'date':
            try:
                dt.date.fromisoformat(value)
            except ValueError as exc:
                raise VerifyError(f'{path}: invalid date') from exc
    if isinstance(value, int) and not isinstance(value, bool) and 'minimum' in schema:
        require(value >= schema['minimum'], f'{path}: below minimum')


def topological_order(nodes: list[str] | set[str], edges: list[tuple[str, str]]) -> list[str]:
    node_set = set(nodes)
    adjacency: dict[str, set[str]] = {n: set() for n in node_set}
    indegree = {n: 0 for n in node_set}
    for source, target in edges:
        require(source in node_set and target in node_set, f'unknown graph endpoint: {source} -> {target}')
        if target not in adjacency[source]:
            adjacency[source].add(target)
            indegree[target] += 1
    queue = deque(sorted(n for n, degree in indegree.items() if degree == 0))
    result: list[str] = []
    while queue:
        current = queue.popleft()
        result.append(current)
        for target in sorted(adjacency[current]):
            indegree[target] -= 1
            if indegree[target] == 0:
                queue.append(target)
    require(len(result) == len(node_set), 'directed graph contains a cycle')
    return result


def combined_digest(digests: list[str]) -> str:
    h = hashlib.sha256()
    for digest in sorted(set(digests)):
        require(re.fullmatch(r'[0-9a-f]{64}', digest) is not None, 'invalid source digest')
        h.update(bytes.fromhex(digest))
    return h.hexdigest()


def load_package(target: Path) -> tuple[dict[str, bytes], bytes | None]:
    expected = set(REQUIRED_FILES)
    if target.is_file():
        require(target.suffix.lower() == '.zip', 'file input must be the package ZIP')
        raw_zip = target.read_bytes()
        with zipfile.ZipFile(io.BytesIO(raw_zip)) as archive:
            require(archive.testzip() is None, 'ZIP CRC/integrity failure')
            infos = [x for x in archive.infolist() if not x.is_dir()]
            names = [x.filename for x in infos]
            require(names == sorted(names), 'ZIP entries are not in canonical path order')
            require(set(names) == expected, f'ZIP file set mismatch: missing={sorted(expected-set(names))}, extra={sorted(set(names)-expected)}')
            for info in infos:
                require(info.date_time == FIXED_TIMESTAMP, f'non-deterministic ZIP timestamp: {info.filename}')
                require(info.create_system == 3, f'ZIP creator system must be Unix: {info.filename}')
                require((info.external_attr >> 16) == 0o100644, f'ZIP mode must be 100644: {info.filename}')
                require(info.compress_type == zipfile.ZIP_DEFLATED, f'ZIP compression must be DEFLATED: {info.filename}')
            return {name: archive.read(name) for name in names}, raw_zip
    require(target.is_dir(), f'package path does not exist: {target}')
    actual = {str(path.relative_to(target)).replace('\\', '/') for path in target.rglob('*') if path.is_file()}
    require(actual == expected, f'directory file set mismatch: missing={sorted(expected-actual)}, extra={sorted(actual-expected)}')
    return {name: (target / name).read_bytes() for name in sorted(expected)}, None


def deterministic_zip_bytes(files: dict[str, bytes]) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        for name in sorted(files):
            info = zipfile.ZipInfo(name, FIXED_TIMESTAMP)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, files[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return buffer.getvalue()


def verify_manifest(files: dict[str, bytes], parsed: dict[str, Any]) -> None:
    manifest = parsed['MANIFEST.json']
    require(manifest['identity'] == 'san.global-program-registry-package-manifest', 'manifest identity mismatch')
    require(manifest['package_name'] == 'SAN-GLOBAL-PROGRAM-REGISTRY-ARCHITECTURE-EDITION-1.zip', 'manifest package name mismatch')
    entries = manifest['files']
    paths = [x['path'] for x in entries]
    expected = sorted(set(REQUIRED_FILES) - {'MANIFEST.json'})
    require(paths == expected, 'manifest paths are not exact canonical set')
    for entry in entries:
        data = files[entry['path']]
        require(entry['size'] == len(data), f'manifest size mismatch: {entry["path"]}')
        require(entry['sha256'] == sha256_bytes(data), f'manifest digest mismatch: {entry["path"]}')
    require(manifest['aggregate_sha256'] == sha256_bytes(canonical_bytes(entries)), 'manifest aggregate digest mismatch')
    require(manifest['self_hash_exclusion'] is True, 'manifest must declare self-hash exclusion')


def scan_for_complete_boolean(value: Any, path: str = '$') -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if key.lower() in {'complete', 'completed', 'is_complete', 'is_completed'} and isinstance(item, bool):
                raise VerifyError(f'forbidden aggregate completion boolean at {path}.{key}')
            scan_for_complete_boolean(item, path + '.' + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            scan_for_complete_boolean(item, f'{path}[{index}]')


def verify_registry_core(parsed: dict[str, Any]) -> dict[str, Any]:
    registry = parsed['GLOBAL-PROGRAM-REGISTRY.json']
    registry_schema = parsed['GLOBAL-PROGRAM-REGISTRY.schema.json']
    metamodel = parsed['REGISTRY-METAMODEL.json']
    metamodel_schema = parsed['REGISTRY-METAMODEL.schema.json']
    validate_schema_instance(registry, registry_schema)
    validate_schema_instance(metamodel, metamodel_schema)
    scan_for_complete_boolean(registry)
    scan_for_complete_boolean(metamodel)

    namespaces = parsed['NAMESPACE-REGISTRY.json']['namespaces']
    namespace_by_id = {x['namespace_id']: x for x in namespaces}
    require(len(namespace_by_id) == len(namespaces), 'duplicate namespace identity')
    owner_ids = {x['owner_id'] for x in namespaces}
    require(len(owner_ids) == len(namespaces), 'duplicate namespace owner')

    kinds = parsed['UNIT-KIND-REGISTRY.json']['unit_kinds']
    kind_by_id = {x['unit_kind_id']: x for x in kinds}
    require(len(kind_by_id) == len(kinds), 'duplicate governed-unit kind')

    records = registry['records']
    require(records == sorted(records, key=lambda r: (r['stable_id'], r['edition'])), 'records are not canonically ordered')
    stable_ids = [r['stable_id'] for r in records]
    require(len(stable_ids) == len(set(stable_ids)), 'duplicate stable identity')
    stable_set = set(stable_ids)
    alias_owner: dict[str, str] = {}
    owned_capability: dict[str, str] = {}
    source_ledger = parsed['SOURCE-AUTHORITY-LEDGER.json']
    require(source_ledger['input_sha256_verified'] is True, 'input hash was not verified')
    source_groups = {x['source_id']: x for x in source_ledger['source_groups']}
    require(source_groups['source.input.handoff']['sha256'] == EXPECTED_INPUT_SHA256, 'authorized input SHA-256 mismatch')
    require(not source_ledger['unreadable_or_missing_inputs'], 'source ledger reports unreadable or missing inputs')

    for record in records:
        sid = record['stable_id']
        require(re.fullmatch(r'san\.[a-z0-9][a-z0-9.-]*', sid) is not None, f'invalid stable identity: {sid}')
        require(not re.search(r'(?:^|[./-])(?:v|edition)[.-]?\d+$', sid), f'edition embedded in stable identity: {sid}')
        require(record['edition'] > 0, f'non-positive edition: {sid}')
        require(record['namespace_id'] in namespace_by_id, f'unknown namespace: {sid}')
        ns = namespace_by_id[record['namespace_id']]
        require(record['ownership']['owner_id'] == ns['owner_id'], f'unknown or mismatched owner: {sid}')
        require(record['ownership']['owner_id'] in owner_ids, f'unknown owner: {sid}')
        require(record['unit_kind_id'] in kind_by_id, f'unknown unit kind: {sid}')
        require(record['unit_kind_id'] in ns['allowed_unit_kinds'], f'unit kind not allowed in namespace: {sid}')
        require(record['compiler']['family_name_branch_required'] is False, f'family-name compiler branch required: {sid}')
        require(record['compiler']['dispatch_key'] == record['unit_kind_id'], f'compiler dispatch key is not governed-unit kind: {sid}')
        require(record['implementation_mapping']['one_crate_required'] is False, f'one-crate assumption: {sid}')
        require(record['aliases'] == sorted(record['aliases']), f'aliases not sorted: {sid}')
        require(record['hard_dependencies'] == sorted(record['hard_dependencies']), f'dependencies not sorted: {sid}')
        require(record['open_gaps'] == sorted(record['open_gaps']), f'gaps not sorted: {sid}')
        for alias in record['aliases']:
            require(alias not in stable_set, f'alias collides with stable identity: {alias}')
            require(alias not in alias_owner, f'duplicate alias: {alias}')
            alias_owner[alias] = sid
        for capability in record['capabilities']['owned']:
            require(capability not in owned_capability, f'capability has two sovereign owners: {capability}')
            owned_capability[capability] = sid
        source_ids = record['source']['source_ids']
        require(source_ids == sorted(source_ids), f'source IDs not sorted: {sid}')
        require(all(x in source_groups for x in source_ids), f'unknown source reference: {sid}')
        expected_source_digest = source_groups[source_ids[0]]['sha256'] if len(source_ids) == 1 else combined_digest([source_groups[x]['sha256'] for x in source_ids])
        require(record['source']['source_digest'] == expected_source_digest, f'source digest mismatch: {sid}')
        require(record['source']['authority_posture'] == record['admission']['source_posture'], f'source posture mismatch: {sid}')
        candidate_only = all(any(marker in source_groups[x]['authority'] for marker in CANDIDATE_MARKERS) for x in source_ids)
        ratified_state = next(x['state'] for x in record['completion'] if x['axis'] == 'ratified')
        if candidate_only:
            require(ratified_state != 'PROVEN', f'candidate source silently treated as ratified authority: {sid}')
            posture = record['admission']['registry_posture']
            require(not ('RATIFIED' in posture and 'NOT_RATIFIED' not in posture), f'candidate promoted to authority: {sid}')
        completion_axes = [x['axis'] for x in record['completion']]
        require(completion_axes == [x['axis'] for x in metamodel['completion_axes']], f'completion axes/order mismatch: {sid}')
        for axis in record['completion']:
            if axis['state'] == 'PROVEN':
                require(axis['evidence_refs'], f'proven completion axis lacks evidence: {sid}/{axis["axis"]}')
        require(record['evidence']['refs'], f'missing evidence references: {sid}')
        require(record['evidence']['confidence'] in {'HIGH', 'MEDIUM', 'LOW'}, f'missing confidence posture: {sid}')
        for relation in ('supersedes', 'superseded_by'):
            require(all(x in stable_set for x in record['source'][relation]), f'unknown supersession reference: {sid}')
        if kind_by_id[record['unit_kind_id']]['counts_as_semantic_library']:
            provider_deps = [x for x in record['hard_dependencies'] if next((r for r in records if r['stable_id'] == x and r['unit_kind_id'] == 'provider_implementation'), None)]
            require(not provider_deps, f'provider implementation leaked into semantic dependency: {sid}')
            semantic_text = json.dumps({
                'question': record['ownership']['sovereign_question'],
                'positive_scope': record['ownership']['positive_scope'],
                'artifacts': record['artifacts'],
                'capabilities': record['capabilities'],
            }).lower()
            require(not any(marker in semantic_text for marker in SEMANTIC_PROVIDER_MARKERS), f'physical provider identity leaked into semantic requirement: {sid}')
        if record['unit_kind_id'] == 'proof_vertical':
            require(record['architectural_class'] == 'PROOF_VERTICAL', f'proof vertical misclassified: {sid}')

    for record in records:
        require(all(dep in stable_set for dep in record['hard_dependencies']), f'unknown hard dependency: {record["stable_id"]}')
    hard_edges = sorted((dep, record['stable_id']) for record in records for dep in record['hard_dependencies'])
    computed_topology = topological_order(stable_set, hard_edges)
    require(registry['records_digest'] == sha256_bytes(canonical_bytes(records)), 'records digest mismatch')

    semantic_kinds = {x['unit_kind_id'] for x in kinds if x['counts_as_semantic_library']}
    expected_counts = {
        'record_count': len(records),
        'by_unit_kind': dict(sorted(Counter(r['unit_kind_id'] for r in records).items())),
        'by_namespace': dict(sorted(Counter(r['namespace_id'] for r in records).items())),
        'by_registry_posture': dict(sorted(Counter(r['admission']['registry_posture'] for r in records).items())),
        'by_disposition': dict(sorted(Counter(r['admission']['qualification_disposition'] for r in records).items())),
        'semantic_library_count': sum(1 for r in records if r['unit_kind_id'] in semantic_kinds),
        'proof_vertical_count': sum(1 for r in records if r['unit_kind_id'] == 'proof_vertical'),
        'bounded_context_count': parsed['DOMAIN-ONTOLOGY-CONTEXT-MAP.json']['counts']['bounded_context_hypotheses'],
    }
    require(registry['counts'] == expected_counts, 'registry count projection mismatch')
    require(not any(r['unit_kind_id'] == 'proof_vertical' and r['unit_kind_id'] in semantic_kinds for r in records), 'proof vertical counted as semantic library')

    hard = parsed['HARD-DEPENDENCY-DAG.json']
    require(hard['acyclic'] is True, 'hard DAG not declared acyclic')
    graph_nodes = [x['unit_id'] for x in hard['nodes']]
    require(graph_nodes == stable_ids, 'hard DAG node projection mismatch')
    graph_edges = sorted((x['from'], x['to']) for x in hard['edges'])
    require(graph_edges == hard_edges, 'hard DAG edge projection mismatch')
    require(hard['topological_order'] == computed_topology, 'hard DAG topological order mismatch')
    require(hard['node_count'] == len(stable_ids) and hard['edge_count'] == len(hard_edges), 'hard DAG counts mismatch')

    seam = parsed['SEMANTIC-SEAM-HYPERGRAPH.json']
    namespaces_set = set(namespace_by_id)
    require(seam['hyperedge_count'] == len(seam['hyperedges']), 'seam hyperedge count mismatch')
    hard_pairs = set(hard_edges)
    for edge in seam['hyperedges']:
        require(len(edge['participants']) >= 2, f'seam has fewer than two participants: {edge["seam_id"]}')
        require(all(x in stable_set or x in namespaces_set for x in edge['participants']), f'unknown seam participant: {edge["seam_id"]}')
        require(edge['payload_owner'] in stable_set or edge['payload_owner'] in namespaces_set or edge['payload_owner'].startswith('SEM-'), f'unknown seam payload owner: {edge["seam_id"]}')
        require(edge['hard_dependency_projection_forbidden'] is True, f'seam permits hard-cycle projection: {edge["seam_id"]}')
        participants = edge['participants']
        for a in participants:
            for b in participants:
                if a != b:
                    require(not ((a, b) in hard_pairs and (b, a) in hard_pairs), f'reciprocal seam encoded as hard dependency cycle: {edge["seam_id"]}')

    artifact = parsed['COMPILATION-ARTIFACT-DAG.json']
    artifact_ids = [x['artifact_id'] for x in artifact['artifacts']]
    artifact_edges = [(x['from'], x['to']) for x in artifact['edges']]
    require(artifact['topological_order'] == topological_order(artifact_ids, artifact_edges), 'compilation artifact DAG mismatch')
    required_artifacts = {'SignedStage0AuthorityPackage', 'ApplicationBinding', 'ObligationClosure', 'VerifiedSemanticApplicationGraph', 'VerifiedApplicationClosure', 'AppRelease', 'BackendAppRelease', 'DeploymentPlan', 'BootInput', 'BootReport'}
    require(required_artifacts.issubset({x['artifact_kind'] for x in artifact['artifacts']}), 'compilation artifact ladder is incomplete')
    require(artifact['canonical_pipeline_status'] == 'BLOCKED_BY_COMPILER_A_B_ADJUDICATION', 'compiler A/B status overclaimed')
    for occurrence in artifact['artifacts']:
        require(all(producer in stable_set for producer in occurrence['producer_candidates']), f'unknown compiler/artifact producer: {occurrence["artifact_id"]}')
    pipeline_by_id = {x['variant_id']: x for x in artifact['pipeline_variants']}
    require(set(pipeline_by_id) == {'current-master-12-stage', 'compiler-proposal-14-stage-2026-08-12'}, 'compiler pipeline variants missing')
    require(len(pipeline_by_id['current-master-12-stage']['stage_unit_ids']) == 12, 'current compiler variant is not 12 stages')
    require(len(pipeline_by_id['compiler-proposal-14-stage-2026-08-12']['stage_unit_ids']) == 14, 'proposed compiler variant is not 14 stages')
    record_by_id = {r['stable_id']: r for r in records}
    for variant_id, pipeline in pipeline_by_id.items():
        for stage_id in pipeline['stage_unit_ids']:
            require(stage_id in stable_set, f'unknown stage in pipeline variant: {stage_id}')
            require(record_by_id[stage_id]['variant_id'] == variant_id, f'pipeline variant/stage mismatch: {stage_id}')
    require(alias_owner.get('CMP-006') == 'san.compiler.variant.current-12-stage.central-application-linker', 'legacy CMP-006 no longer resolves to current owner-local evidence')
    require(alias_owner.get('COMPILER-SSPEC-CANDIDATE::CMP-006') == 'san.compiler.variant.proposed-14-stage.application-binding', 'proposed CMP-006 source-qualified alias missing')

    runtime = parsed['RUNTIME-RESOURCE-PROVIDER-DAG.json']
    runtime_ids = [x['node_id'] for x in runtime['nodes']]
    runtime_edges = [(x['from'], x['to']) for x in runtime['edges']]
    require(runtime['topological_order'] == topological_order(runtime_ids, runtime_edges), 'runtime/resource/provider DAG mismatch')
    require(runtime['execution_proven'] is False, 'runtime execution overclaimed')

    domain = parsed['DOMAIN-ONTOLOGY-CONTEXT-MAP.json']
    domain_ids = {x['node_id'] for x in domain['nodes']}
    require(len(domain_ids) == len(domain['nodes']), 'duplicate domain context-map node')
    require(all(x['from'] in domain_ids and x['to'] in domain_ids for x in domain['edges']), 'unknown domain context-map endpoint')
    require(domain['counts']['bounded_context_hypotheses'] == sum(1 for x in domain['nodes'] if x['kind'] == 'BOUNDED_CONTEXT_HYPOTHESIS'), 'bounded-context count mismatch')

    ownership = parsed['OWNERSHIP-MATRIX.json']
    require(ownership['collision_count'] == 0, 'ownership matrix reports collisions')
    capability_rows = ownership['capability_ownership']
    require(len(capability_rows) == len(owned_capability), 'ownership matrix capability count mismatch')
    require({x['capability_id']: x['unit_id'] for x in capability_rows} == owned_capability, 'ownership matrix projection mismatch')

    aliases = parsed['COORDINATE-ALIAS-AND-MIGRATION.json']['aliases']
    require(len(aliases) == len(alias_owner), 'alias migration projection count mismatch')
    require({x['alias']: x['stable_id'] for x in aliases} == alias_owner, 'alias migration projection mismatch')

    completeness = parsed['COMPLETENESS-EVIDENCE-MATRIX.json']
    require(completeness['single_complete_boolean_forbidden'] is True, 'completion matrix permits aggregate complete boolean')
    require(len(completeness['rows']) == len(records), 'completion matrix row count mismatch')
    completion_by_id = {x['unit_id']: x for x in completeness['rows']}
    for record in records:
        row = completion_by_id[record['stable_id']]
        require(row['axes'] == {x['axis']: x['state'] for x in record['completion']}, f'completion projection mismatch: {record["stable_id"]}')
        require(row['open_gaps'] == record['open_gaps'], f'gap projection mismatch: {record["stable_id"]}')

    conflict = parsed['CONFLICT-ADJUDICATION-LEDGER.json']
    require(conflict['adjudication_count'] == len(conflict['candidate_dispositions']), 'conflict adjudication count mismatch')
    adjudication_ids = [x['adjudication_id'] for x in conflict['candidate_dispositions']]
    require(len(adjudication_ids) == len(set(adjudication_ids)), 'duplicate adjudication identity')
    require(len(conflict['count_conflicts']) >= 17, 'count conflicts missing')

    research = parsed['RESEARCH-SOURCE-LEDGER.json']
    require(len(research['sources']) >= 35, 'insufficient primary/official research ledger')
    for source in research['sources']:
        require(source['source_type'] == 'PRIMARY_OR_OFFICIAL', f'non-primary research source: {source["source_id"]}')
        require(source['url'].startswith('https://'), f'non-HTTPS research source: {source["source_id"]}')
        require(source['exact_locus'] and source['concepts_adopted'] and source['adaptation'] and source['rejected_universalization'], f'incomplete source traceability: {source["source_id"]}')
        require('github.com/san' not in source['url'].lower(), 'public SAN GitHub source used')

    gaps = parsed['RESEARCH-GAP-LEDGER.json']
    gap_ids = {x['gap_id'] for x in gaps['gaps']}
    require({f'AB-{i:03d}' for i in range(1, 26)}.issubset(gap_ids), 'compiler A/B dependency missing')
    require({f'NP-{i:03d}' for i in range(1, 26)}.issubset(gap_ids), 'not-proven claim missing')
    require(all(x['status'] == 'OPEN' for x in gaps['gaps']), 'gap silently closed')

    package_verify = parsed['PACKAGE-VERIFY.json']
    require(package_verify['result'] == 'PASS', 'package verification declaration is not PASS')
    require(package_verify['input_sha256'] == EXPECTED_INPUT_SHA256, 'package verification input digest mismatch')
    require(package_verify['mutation_summary']['failed'] == 0, 'declared mutation test failure')

    return {
        'records': len(records),
        'aliases': len(alias_owner),
        'hard_edges': len(hard_edges),
        'semantic_library_count': expected_counts['semantic_library_count'],
        'proof_vertical_count': expected_counts['proof_vertical_count'],
        'bounded_context_count': expected_counts['bounded_context_count'],
    }


def run_mutation_suite(parsed: dict[str, Any]) -> list[dict[str, Any]]:
    tests: list[tuple[str, str, Any]] = []

    def mutate_registry(action: Any) -> dict[str, Any]:
        clone = copy.deepcopy(parsed)
        action(clone['GLOBAL-PROGRAM-REGISTRY.json'])
        return clone

    tests.append(('MUT-001', 'unknown registry property', lambda: mutate_registry(lambda r: r.__setitem__('surprise', True))))
    tests.append(('MUT-002', 'duplicate stable identity', lambda: mutate_registry(lambda r: r['records'].__setitem__(1, copy.deepcopy(r['records'][0])))))
    tests.append(('MUT-003', 'duplicate alias', lambda: mutate_registry(lambda r: r['records'][1]['aliases'].append(r['records'][0]['aliases'][0]))))
    tests.append(('MUT-004', 'edition embedded in stable identity', lambda: mutate_registry(lambda r: r['records'][0].__setitem__('stable_id', r['records'][0]['stable_id'] + '-edition-2'))))
    tests.append(('MUT-005', 'unknown sovereign owner', lambda: mutate_registry(lambda r: r['records'][0]['ownership'].__setitem__('owner_id', 'owner.unknown'))))
    tests.append(('MUT-006', 'unknown hard dependency', lambda: mutate_registry(lambda r: r['records'][0]['hard_dependencies'].append('san.unknown.missing'))))

    def add_cycle(registry: dict[str, Any]) -> None:
        first, second = registry['records'][0], registry['records'][1]
        first['hard_dependencies'] = sorted(set(first['hard_dependencies'] + [second['stable_id']]))
        second['hard_dependencies'] = sorted(set(second['hard_dependencies'] + [first['stable_id']]))
    tests.append(('MUT-007', 'hard dependency cycle', lambda: mutate_registry(add_cycle)))

    def duplicate_capability(registry: dict[str, Any]) -> None:
        registry['records'][1]['capabilities']['owned'] = [registry['records'][0]['capabilities']['owned'][0]]
    tests.append(('MUT-008', 'two sovereign owners for one capability', lambda: mutate_registry(duplicate_capability)))
    tests.append(('MUT-009', 'aggregate complete boolean', lambda: mutate_registry(lambda r: r['records'][0].__setitem__('complete', True))))
    tests.append(('MUT-010', 'family-name compiler branch', lambda: mutate_registry(lambda r: r['records'][0]['compiler'].__setitem__('family_name_branch_required', True))))
    tests.append(('MUT-011', 'proof vertical inflated semantic count', lambda: mutate_registry(lambda r: r['counts'].__setitem__('semantic_library_count', r['counts']['semantic_library_count'] + 1))))

    def promote_candidate(registry: dict[str, Any]) -> None:
        item = next(x for x in registry['records'] if x['admission']['source_posture'] == 'CANDIDATE_INPUT')
        next(axis for axis in item['completion'] if axis['axis'] == 'ratified')['state'] = 'PROVEN'
        next(axis for axis in item['completion'] if axis['axis'] == 'ratified')['evidence_refs'] = item['source']['source_ids']
    tests.append(('MUT-012', 'candidate silently promoted to ratified authority', lambda: mutate_registry(promote_candidate)))

    def provider_leak(registry: dict[str, Any]) -> None:
        provider = next(x for x in registry['records'] if x['unit_kind_id'] == 'provider_implementation')
        semantic = next(x for x in registry['records'] if x['unit_kind_id'] == 'semantic_family')
        semantic['hard_dependencies'] = sorted(set(semantic['hard_dependencies'] + [provider['stable_id']]))
    tests.append(('MUT-013', 'provider implementation in semantic dependency', lambda: mutate_registry(provider_leak)))
    tests.append(('MUT-014', 'records digest tamper', lambda: mutate_registry(lambda r: r.__setitem__('records_digest', '0' * 64))))
    tests.append(('MUT-015', 'missing confidence', lambda: mutate_registry(lambda r: r['records'][0]['evidence'].__setitem__('confidence', 'UNKNOWN'))))
    tests.append(('MUT-016', 'unknown supersession target', lambda: mutate_registry(lambda r: r['records'][0]['source']['superseded_by'].append('san.unknown.future'))))
    tests.append(('MUT-017', 'alias collides with stable identity', lambda: mutate_registry(lambda r: r['records'][0]['aliases'].append(r['records'][1]['stable_id']))))
    tests.append(('MUT-018', 'one-crate-per-record assumption', lambda: mutate_registry(lambda r: r['records'][0]['implementation_mapping'].__setitem__('one_crate_required', True))))
    tests.append(('MUT-019', 'proof vertical architectural misclassification', lambda: mutate_registry(lambda r: next(x for x in r['records'] if x['unit_kind_id'] == 'proof_vertical').__setitem__('architectural_class', 'SEMANTIC_LIBRARY'))))
    tests.append(('MUT-020', 'unknown governed-unit kind', lambda: mutate_registry(lambda r: r['records'][0].__setitem__('unit_kind_id', 'invented_kind'))))

    results = []
    for test_id, description, factory in tests:
        rejected = False
        error = ''
        try:
            verify_registry_core(factory())
        except Exception as exc:
            rejected = True
            error = str(exc)
        require(rejected, f'mutation was incorrectly accepted: {test_id} {description}')
        results.append({'test_id': test_id, 'description': description, 'expected': 'REJECT', 'observed': 'REJECT', 'passed': True, 'rejection': error})
    return results


def verify(target: Path) -> dict[str, Any]:
    files, raw_zip = load_package(target)
    parsed: dict[str, Any] = {}
    for name in sorted(files):
        if name.endswith('.json'):
            parsed[name] = parse_json(files[name], name)
    verify_manifest(files, parsed)
    core = verify_registry_core(parsed)
    mutations = run_mutation_suite(parsed)
    if raw_zip is not None:
        rebuilt = deterministic_zip_bytes(files)
        require(raw_zip == rebuilt, 'archive bytes differ from deterministic repack')
    return {
        'result': 'PASS',
        'target': str(target),
        'archive_sha256': sha256_bytes(raw_zip) if raw_zip is not None else None,
        'archive_size': len(raw_zip) if raw_zip is not None else None,
        'files': len(files),
        'core': core,
        'mutation_tests': len(mutations),
        'mutation_failures': 0,
        'deterministic_archive_repack_equal': raw_zip is not None,
    }


def main() -> int:
    target = Path(sys.argv[1] if len(sys.argv) > 1 else '.')
    try:
        result = verify(target)
    except Exception as exc:
        print(json.dumps({'result': 'FAIL', 'error': str(exc)}, sort_keys=True))
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
