//! Non-vacuous executable fixture and meaningful negative twins.

use std::collections::BTreeMap;

use ed25519_dalek::{Signer, SigningKey};
use sha2::{Digest, Sha256};

use crate::stage0::{
    derive_package_lock_digest, install_pinned_stage0_anchor, prepare_stage0_package_authority,
    stage0_attestation_signing_bytes, verify_stage0_package_authority, CompilerSupplierRole,
    PackageLockCarrier, PinnedStage0TrustAnchor, PinnedStage0TrustAnchorCarrier,
    ReleaseCoordinateCarrier, SelectedReleaseCarrier, Stage0PackageAttestationCarrier,
    Stage0PackageAuthority, SupplierDispositionCarrier, SupplierDispositionStateCarrier,
};
use crate::waist::{
    AbsenceSemantics, ArtifactRefCarrier, RegistryKind, TotalOutcome, WorkBudget,
};

use super::*;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FixtureOptions {
    pub omit_offer: bool,
    pub omit_decision_directive: bool,
    pub omit_obligation_rule: bool,
    pub unsupported_target_node: bool,
    pub omit_provider: bool,
    pub authority_cycle: bool,
    pub block_authority_cycle_verifier: bool,
}

impl Default for FixtureOptions {
    fn default() -> Self {
        Self {
            omit_offer: false,
            omit_decision_directive: false,
            omit_obligation_rule: false,
            unsupported_target_node: false,
            omit_provider: false,
            authority_cycle: false,
            block_authority_cycle_verifier: false,
        }
    }
}

#[derive(Clone, Debug)]
pub struct FixtureInputs {
    pub anchor: PinnedStage0TrustAnchor,
    pub stage0: Stage0PackageAuthority,
    pub source: ApplicationSourceCarrier,
    pub constitution: ConstitutionCarrier,
    pub family_descriptors: Vec<FamilyDescriptorCarrier>,
    pub target_descriptors: Vec<TargetDescriptorCarrier>,
    pub runtime_descriptors: Vec<RuntimeCapabilityDescriptorCarrier>,
    pub providers: Vec<ProviderOfferCarrier>,
}

#[derive(Clone, Debug)]
pub struct PositiveVertical {
    pub boot: BootInput,
    pub report: OfflineVerificationReport,
    pub anchor: PinnedStage0TrustAnchor,
}

fn digest(label: &str) -> [u8; 32] { Sha256::digest(label.as_bytes()).into() }

fn artifact(identity: &str, occurrence: &str) -> ArtifactRefCarrier {
    ArtifactRefCarrier {
        identity: identity.to_owned(),
        edition: 2,
        occurrence: occurrence.to_owned(),
        digest: digest(&format!("artifact:{identity}:{occurrence}")),
    }
}

fn release(kind: RegistryKind, identity: &str, occurrence: &str) -> ReleaseCoordinateCarrier {
    ReleaseCoordinateCarrier {
        kind,
        identity: identity.to_owned(),
        edition: 1,
        occurrence: occurrence.to_owned(),
    }
}

fn checkout_descriptor(options: FixtureOptions) -> FamilyDescriptorCarrier {
    let mut constraints = BTreeMap::new();
    constraints.insert("mode".to_owned(), "card".to_owned());
    let rules = if options.omit_obligation_rule {
        Vec::new()
    } else {
        vec![ObligationRuleCarrier {
            identity: "checkout.record-audit".to_owned(),
            premises: vec!["fact.payment-authorized".to_owned()],
            conclusion: "fact.audit-recorded".to_owned(),
        }]
    };
    let dependencies = vec![AuthorityDependencyCarrier {
        from: "authority.checkout".to_owned(),
        to: "authority.payments".to_owned(),
    }];
    let mut carrier = FamilyDescriptorCarrier {
        release_identity: "sem.checkout".to_owned(),
        owner_authority: "authority.checkout".to_owned(),
        descriptor_artifact: artifact("descriptor.sem.checkout", "occ.descriptor.checkout"),
        packs: vec![PackContributionCarrier {
            pack: "checkout.default".to_owned(),
            requirements: vec![ContractRequirementCarrier {
                identity: "checkout.payment-authorizer.required".to_owned(),
                contract: "contract.payment-authorizer".to_owned(),
                cardinality: CardinalityCarrier::ExactlyOne,
                constraints,
            }],
            offers: Vec::new(),
            decisions: vec![DecisionCarrier {
                identity: "checkout.payment-mode".to_owned(),
                alternatives: vec!["bank".to_owned(), "card".to_owned()],
                required: true,
            }],
            obligations: vec![ObligationCarrier {
                identity: "checkout.audit-obligation".to_owned(),
                owner: "authority.checkout".to_owned(),
                required_fact: "fact.audit-recorded".to_owned(),
            }],
            obligation_rules: rules,
            runtime_requirements: vec![RuntimeRequirementCarrier {
                identity: "checkout.command-journal".to_owned(),
                capability: "runtime.command-journal".to_owned(),
                cardinality: CardinalityCarrier::ExactlyOne,
                absence: AbsenceSemantics::Required,
            }],
            initial_facts: Vec::new(),
        }],
        authority_dependencies: dependencies,
        claimed_digest: [0_u8; 32],
    };
    carrier.claimed_digest = family_descriptor_digest(&carrier);
    carrier
}

fn payments_descriptor(options: FixtureOptions) -> FamilyDescriptorCarrier {
    let mut constraints = BTreeMap::new();
    constraints.insert("mode".to_owned(), "card".to_owned());
    let offers = if options.omit_offer {
        vec![ContractOfferCarrier {
            identity: "payments.unrelated.offer".to_owned(),
            contract: "contract.unrelated".to_owned(),
            capacity: 1,
            constraints,
            provided_facts: Vec::new(),
        }]
    } else {
        vec![ContractOfferCarrier {
            identity: "payments.authorizer.offer".to_owned(),
            contract: "contract.payment-authorizer".to_owned(),
            capacity: 1,
            constraints,
            provided_facts: vec!["fact.payment-authorized".to_owned()],
        }]
    };
    let dependencies = if options.authority_cycle {
        vec![AuthorityDependencyCarrier {
            from: "authority.payments".to_owned(),
            to: "authority.checkout".to_owned(),
        }]
    } else {
        Vec::new()
    };
    let mut carrier = FamilyDescriptorCarrier {
        release_identity: "sem.payments".to_owned(),
        owner_authority: "authority.payments".to_owned(),
        descriptor_artifact: artifact("descriptor.sem.payments", "occ.descriptor.payments"),
        packs: vec![PackContributionCarrier {
            pack: "payments.default".to_owned(),
            requirements: Vec::new(),
            offers,
            decisions: Vec::new(),
            obligations: Vec::new(),
            obligation_rules: Vec::new(),
            runtime_requirements: Vec::new(),
            initial_facts: Vec::new(),
        }],
        authority_dependencies: dependencies,
        claimed_digest: [0_u8; 32],
    };
    carrier.claimed_digest = family_descriptor_digest(&carrier);
    carrier
}

fn target_descriptor(options: FixtureOptions) -> TargetDescriptorCarrier {
    let mut supported = vec![
        CsagNodeKind::ApplicationAnchor,
        CsagNodeKind::Authority,
        CsagNodeKind::FamilyPlan,
        CsagNodeKind::ContractBinding,
        CsagNodeKind::ClosedObligation,
        CsagNodeKind::RuntimeRequirement,
    ];
    if options.unsupported_target_node {
        supported.retain(|kind| *kind != CsagNodeKind::ClosedObligation);
    }
    let mut carrier = TargetDescriptorCarrier {
        release_identity: "tgt.portable-json".to_owned(),
        descriptor_artifact: artifact("descriptor.tgt.portable-json", "occ.descriptor.target"),
        target_kind: "tgt.portable-json".to_owned(),
        supported_node_kinds: supported,
        claimed_digest: [0_u8; 32],
    };
    carrier.claimed_digest = target_descriptor_digest(&carrier);
    carrier
}

fn runtime_descriptor() -> RuntimeCapabilityDescriptorCarrier {
    let mut carrier = RuntimeCapabilityDescriptorCarrier {
        release_identity: "run.command-journal".to_owned(),
        descriptor_artifact: artifact("descriptor.run.command-journal", "occ.descriptor.runtime"),
        capabilities: vec!["runtime.command-journal".to_owned()],
        claimed_digest: [0_u8; 32],
    };
    carrier.claimed_digest = runtime_descriptor_digest(&carrier);
    carrier
}

fn selected_release(
    coordinate: ReleaseCoordinateCarrier,
    descriptor_digest: [u8; 32],
    source_identity: &str,
    source_occurrence: &str,
) -> SelectedReleaseCarrier {
    SelectedReleaseCarrier {
        coordinate,
        source: artifact(source_identity, source_occurrence),
        descriptor_digest,
        surface_digest: digest(&format!("surface:{source_identity}")),
    }
}

fn package_components(
    options: FixtureOptions,
) -> (
    PackageLockCarrier,
    Vec<SupplierDispositionCarrier>,
    Vec<FamilyDescriptorCarrier>,
    Vec<TargetDescriptorCarrier>,
    Vec<RuntimeCapabilityDescriptorCarrier>,
) {
    let family_descriptors = vec![checkout_descriptor(options), payments_descriptor(options)];
    let target_descriptors = vec![target_descriptor(options)];
    let runtime_descriptors = vec![runtime_descriptor()];
    let releases = vec![
        selected_release(
            release(RegistryKind::Semantic, "sem.checkout", "occ.checkout"),
            family_descriptors[0].claimed_digest,
            "source.sem.checkout",
            "occ.source.checkout",
        ),
        selected_release(
            release(RegistryKind::Semantic, "sem.payments", "occ.payments"),
            family_descriptors[1].claimed_digest,
            "source.sem.payments",
            "occ.source.payments",
        ),
        selected_release(
            release(RegistryKind::Target, "tgt.portable-json", "occ.target"),
            target_descriptors[0].claimed_digest,
            "source.tgt.portable-json",
            "occ.source.target",
        ),
        selected_release(
            release(RegistryKind::Runtime, "run.command-journal", "occ.runtime"),
            runtime_descriptors[0].claimed_digest,
            "source.run.command-journal",
            "occ.source.runtime",
        ),
    ];
    let mut lock = PackageLockCarrier { releases, claimed_digest: [0_u8; 32] };
    lock.claimed_digest = derive_package_lock_digest(&lock).expect("fixture lock is well formed");
    let mut dispositions = Vec::new();
    for selected in &lock.releases {
        for role in CompilerSupplierRole::ALL {
            let state = if options.block_authority_cycle_verifier
                && role == CompilerSupplierRole::AuthorityCycleVerification
                && selected.coordinate.kind == RegistryKind::Semantic
            {
                SupplierDispositionStateCarrier::Blocked {
                    gap: artifact(
                        &format!("gap.{}.authority-cycle", selected.coordinate.identity),
                        &format!("occ.gap.{}", selected.coordinate.identity),
                    ),
                }
            } else {
                SupplierDispositionStateCarrier::Available {
                    supplier: selected.coordinate.clone(),
                    artifact: artifact(
                        &format!("evidence.{}.role.{}", selected.coordinate.identity, role as u16),
                        &format!("occ.evidence.{}.{}", selected.coordinate.identity, role as u16),
                    ),
                }
            };
            dispositions.push(SupplierDispositionCarrier {
                owner: selected.coordinate.clone(),
                role,
                state,
            });
        }
    }
    (lock, dispositions, family_descriptors, target_descriptors, runtime_descriptors)
}

fn stage0_from_components(
    lock: PackageLockCarrier,
    dispositions: Vec<SupplierDispositionCarrier>,
) -> (PinnedStage0TrustAnchor, Stage0PackageAuthority) {
    let candidate = match prepare_stage0_package_authority(lock, dispositions, WorkBudget::fixture()) {
        TotalOutcome::Produced(value) => value,
        other => panic!("fixture Stage-0 preparation failed: {other:?}"),
    };
    let signing_key = SigningKey::from_bytes(&[7_u8; 32]);
    let anchor = install_pinned_stage0_anchor(PinnedStage0TrustAnchorCarrier {
        authority: "authority.stage0.package".to_owned(),
        key_id: "key.stage0.fixture".to_owned(),
        verifying_key: signing_key.verifying_key().to_bytes(),
        installation: artifact("trust-anchor.stage0.fixture", "occ.trust-anchor.fixture"),
    }).expect("fixture trust anchor is valid");
    let evidence = artifact("attestation.stage0.fixture", "occ.attestation.fixture");
    let admitted_evidence = crate::waist::admit_artifact_ref(evidence.clone())
        .expect("fixture evidence identity is valid");
    let signing_bytes = stage0_attestation_signing_bytes(&candidate, &anchor, &admitted_evidence);
    let signature = signing_key.sign(&signing_bytes).to_bytes();
    let authority = match verify_stage0_package_authority(
        candidate,
        &anchor,
        Stage0PackageAttestationCarrier {
            issuer: "authority.stage0.package".to_owned(),
            key_id: "key.stage0.fixture".to_owned(),
            evidence,
            signature,
            verification_work_units: 128,
        },
        WorkBudget::fixture(),
    ) {
        TotalOutcome::Produced(value) => value,
        other => panic!("fixture Stage-0 verification failed: {other:?}"),
    };
    (anchor, authority)
}

pub fn fixture_inputs(options: FixtureOptions) -> FixtureInputs {
    let (lock, dispositions, family_descriptors, target_descriptors, runtime_descriptors) =
        package_components(options);
    let (anchor, stage0) = stage0_from_components(lock, dispositions);
    let mut source_text = String::from(
        "application demo.checkout\n\
         select semantic sem.checkout 1 occ.checkout\n\
         select semantic sem.payments 1 occ.payments\n\
         pack checkout.default\n\
         pack payments.default\n",
    );
    if !options.omit_decision_directive {
        source_text.push_str("decision checkout.payment-mode card\n");
    }
    source_text.push_str("target tgt.portable-json\n");
    let source_bytes = source_text.into_bytes();
    let source = ApplicationSourceCarrier {
        source: artifact("application-source.demo.checkout", "occ.application-source.demo"),
        claimed_digest: application_source_digest(&source_bytes),
        bytes: source_bytes,
    };
    let constitution_bytes = b"SAN pure-library constitution edition 2; target lowering precedes final sealing.".to_vec();
    let constitution = ConstitutionCarrier {
        source: artifact("constitution.san.pure-library", "occ.constitution.edition-2"),
        coordinate: "san.pure-library-constitution".to_owned(),
        edition: 2,
        claimed_digest: admitted_constitution_digest(
            "san.pure-library-constitution", 2, &constitution_bytes,
        ),
        bytes: constitution_bytes,
    };
    let providers = if options.omit_provider {
        Vec::new()
    } else {
        vec![ProviderOfferCarrier {
            provider: "provider.fixture.command-journal".to_owned(),
            capability: "runtime.command-journal".to_owned(),
            endpoint: "https://fixture.invalid/command-journal".to_owned(),
            evidence: artifact("provider-evidence.fixture.command-journal", "occ.provider-evidence.fixture"),
        }]
    };
    FixtureInputs {
        anchor,
        stage0,
        source,
        constitution,
        family_descriptors,
        target_descriptors,
        runtime_descriptors,
        providers,
    }
}

fn produced<T: std::fmt::Debug, R: std::fmt::Debug>(
    outcome: TotalOutcome<T, R>,
    stage: &str,
) -> T {
    match outcome {
        TotalOutcome::Produced(value) => value,
        other => panic!("fixture stage {stage} did not produce: {other:?}"),
    }
}

#[derive(Clone, Debug)]
pub struct CompilationArtifacts {
    pub constitution: AdmittedConstitution,
    pub source: AdmittedApplicationSource,
    pub plans: FamilyPlanSet,
    pub binding: ApplicationBinding,
    pub obligations: ObligationClosure,
    pub csag: Csag,
    pub targets: TargetCompilationSet,
    pub runtime: RuntimeRequirementClosure,
}

fn through_bound(inputs: &FixtureInputs) -> (
    AdmittedConstitution,
    AdmittedApplicationSource,
    BoundDeclarationGraph,
) {
    let source = produced(
        admit_application_source(&inputs.stage0, inputs.source.clone(), WorkBudget::fixture()),
        "source-admission",
    );
    let constitution = produced(
        admit_constitution(&inputs.stage0, inputs.constitution.clone(), WorkBudget::fixture()),
        "constitution-admission",
    );
    let parsed = produced(
        parse_application_source(&inputs.stage0, source.clone(), WorkBudget::fixture()),
        "parse",
    );
    let declarations = produced(
        admit_application_declarations(
            &inputs.stage0,
            &constitution,
            parsed,
            WorkBudget::fixture(),
        ),
        "declaration-admission",
    );
    let bound = produced(
        bind_application_names(&inputs.stage0, declarations, WorkBudget::fixture()),
        "name-binding",
    );
    (constitution, source, bound)
}

fn through_expanded(inputs: &FixtureInputs) -> (
    AdmittedConstitution,
    AdmittedApplicationSource,
    ExpandedContributionSet,
) {
    let (constitution, source, bound) = through_bound(inputs);
    let application = bound.declarations.parsed().application().clone();
    let descriptors = produced(
        admit_family_descriptors(
            &inputs.stage0,
            inputs.family_descriptors.clone(),
            &application,
            WorkBudget::fixture(),
        ),
        "family-descriptor-admission",
    );
    let expanded = produced(
        expand_application_packs(&inputs.stage0, bound, descriptors, WorkBudget::fixture()),
        "pack-expansion",
    );
    (constitution, source, expanded)
}

fn through_plans(inputs: &FixtureInputs) -> (
    AdmittedConstitution,
    AdmittedApplicationSource,
    FamilyPlanSet,
) {
    let (constitution, source, expanded) = through_expanded(inputs);
    let decisions = produced(
        resolve_application_decisions(&inputs.stage0, expanded, WorkBudget::fixture()),
        "decision-resolution",
    );
    let plans = produced(
        compile_family_plans(&inputs.stage0, decisions, WorkBudget::fixture()),
        "family-compilation",
    );
    (constitution, source, plans)
}

fn through_binding(inputs: &FixtureInputs) -> (
    AdmittedConstitution,
    AdmittedApplicationSource,
    FamilyPlanSet,
    ApplicationBinding,
) {
    let (constitution, source, plans) = through_plans(inputs);
    let binding = produced(
        build_application_binding(&inputs.stage0, plans.clone(), WorkBudget::fixture()),
        "application-binding",
    );
    (constitution, source, plans, binding)
}

fn through_obligations(inputs: &FixtureInputs) -> (
    AdmittedConstitution,
    AdmittedApplicationSource,
    FamilyPlanSet,
    ApplicationBinding,
    ObligationClosure,
) {
    let (constitution, source, plans, binding) = through_binding(inputs);
    let obligations = produced(
        close_application_obligations(&inputs.stage0, binding.clone(), WorkBudget::fixture()),
        "obligation-closure",
    );
    (constitution, source, plans, binding, obligations)
}

fn through_csag(inputs: &FixtureInputs) -> (
    AdmittedConstitution,
    AdmittedApplicationSource,
    FamilyPlanSet,
    ApplicationBinding,
    ObligationClosure,
    Csag,
) {
    let (constitution, source, plans, binding, obligations) = through_obligations(inputs);
    let csag = produced(
        build_csag(&inputs.stage0, obligations.clone(), WorkBudget::fixture()),
        "csag",
    );
    (constitution, source, plans, binding, obligations, csag)
}

fn through_targets(inputs: &FixtureInputs) -> (
    AdmittedConstitution,
    AdmittedApplicationSource,
    FamilyPlanSet,
    ApplicationBinding,
    ObligationClosure,
    Csag,
    TargetCompilationSet,
) {
    let (constitution, source, plans, binding, obligations, csag) = through_csag(inputs);
    let targets = produced(
        compile_targets(
            &inputs.stage0,
            csag.clone(),
            inputs.target_descriptors.clone(),
            WorkBudget::fixture(),
        ),
        "target-compilation",
    );
    (constitution, source, plans, binding, obligations, csag, targets)
}

pub fn compile_to_runtime(inputs: &FixtureInputs) -> CompilationArtifacts {
    let (constitution, source, plans, binding, obligations, csag, targets) =
        through_targets(inputs);
    let runtime = produced(
        close_runtime_requirements(
            &inputs.stage0,
            &obligations,
            targets.clone(),
            inputs.runtime_descriptors.clone(),
            WorkBudget::fixture(),
        ),
        "runtime-requirement-closure",
    );
    CompilationArtifacts {
        constitution,
        source,
        plans,
        binding,
        obligations,
        csag,
        targets,
        runtime,
    }
}

pub fn compile_to_release(inputs: &FixtureInputs) -> AppRelease {
    let artifacts = compile_to_runtime(inputs);
    let closure = produced(
        seal_application_closure(
            inputs.stage0.clone(),
            artifacts.constitution,
            artifacts.source,
            artifacts.plans,
            artifacts.binding,
            artifacts.obligations,
            artifacts.csag,
            artifacts.targets,
            artifacts.runtime,
            WorkBudget::fixture(),
        ),
        "application-closure",
    );
    produced(build_app_release(closure, WorkBudget::fixture()), "app-release")
}

pub fn execute_positive_vertical() -> PositiveVertical {
    let inputs = fixture_inputs(FixtureOptions::default());
    let release = compile_to_release(&inputs);
    let deployment = produced(
        bind_deployment_plan(release, inputs.providers.clone(), WorkBudget::fixture()),
        "deployment-plan",
    );
    let boot = produced(build_boot_input(deployment, WorkBudget::fixture()), "boot-input");
    let report = produced(
        verify_boot_input_offline(&boot, &inputs.anchor, WorkBudget::fixture()),
        "offline-reverification",
    );
    PositiveVertical { boot, report, anchor: inputs.anchor }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::stage0::Stage0PackageAuthorityRefusal;
    use crate::waist::{BudgetDimension, MissingInputKind};

    #[test]
    fn non_vacuous_vertical_reaches_offline_reverification() {
        let vertical = execute_positive_vertical();
        let release = vertical.boot.deployment().app_release();
        let closure = release.application_closure();
        assert!(closure.stage0().package_lock().releases().count() >= 4);
        assert_eq!(closure.family_plans().plans().len(), 2);
        assert!(closure.family_plans().plans().iter().all(|plan| !plan.packs().is_empty()));
        assert_eq!(closure.binding().bindings().len(), 1);
        assert_eq!(closure.obligations().obligations().len(), 1);
        assert!(closure.obligations().iterations() >= 2);
        assert!(closure.csag().nodes().len() > 1);
        assert_eq!(closure.targets().compilations().len(), 1);
        assert_eq!(closure.runtime().requirements().len(), 1);
        assert_eq!(release.provider_requirements().len(), 1);
        assert_eq!(vertical.boot.deployment().provider_bindings().len(), 1);
        assert!(vertical.report.proof_count() >= 20);
        assert!(vertical.report.checked_stages().iter()
            .any(|stage| stage.stable().as_str() == "cmp013.application-closure"));
        assert!(vertical.report.checked_stages().iter()
            .any(|stage| stage.stable().as_str() == "cmp010.app-release"));
    }

    #[test]
    fn stage0_rejects_incomplete_selected_release_by_58_role_matrix() {
        let (lock, mut dispositions, _, _, _) = package_components(FixtureOptions::default());
        dispositions.pop();
        match prepare_stage0_package_authority(lock, dispositions, WorkBudget::fixture()) {
            TotalOutcome::Refused(Stage0PackageAuthorityRefusal::RoleMatrixCardinalityMismatch {
                expected,
                actual,
            }) => {
                assert_eq!(expected, 4 * 58);
                assert_eq!(actual, expected - 1);
            }
            other => panic!("expected matrix-cardinality refusal, got {other:?}"),
        }
    }

    #[test]
    fn missing_compatible_offer_is_a_semantic_refusal() {
        let inputs = fixture_inputs(FixtureOptions {
            omit_offer: true,
            ..FixtureOptions::default()
        });
        let (_, _, plans) = through_plans(&inputs);
        match build_application_binding(&inputs.stage0, plans, WorkBudget::fixture()) {
            TotalOutcome::Refused(ApplicationBindingRefusal::MissingCompatibleOffer { requirement }) => {
                assert_eq!(requirement.as_str(), "checkout.payment-authorizer.required");
            }
            other => panic!("expected missing-offer refusal, got {other:?}"),
        }
    }

    #[test]
    fn unresolved_required_decision_is_needs_input() {
        let inputs = fixture_inputs(FixtureOptions {
            omit_decision_directive: true,
            ..FixtureOptions::default()
        });
        let (_, _, expanded) = through_expanded(&inputs);
        match resolve_application_decisions(&inputs.stage0, expanded, WorkBudget::fixture()) {
            TotalOutcome::NeedsInput(needs) => {
                assert_eq!(needs.kind, MissingInputKind::Decision);
                assert_eq!(needs.subjects[0].as_str(), "checkout.payment-mode");
            }
            other => panic!("expected decision needs-input, got {other:?}"),
        }
    }

    #[test]
    fn incomplete_obligation_fixed_point_refuses() {
        let inputs = fixture_inputs(FixtureOptions {
            omit_obligation_rule: true,
            ..FixtureOptions::default()
        });
        let (_, _, _, binding) = through_binding(&inputs);
        match close_application_obligations(&inputs.stage0, binding, WorkBudget::fixture()) {
            TotalOutcome::Refused(ObligationClosureRefusal::IncompleteFixedPoint { missing }) => {
                assert_eq!(missing[0].as_str(), "checkout.audit-obligation");
            }
            other => panic!("expected incomplete-obligation refusal, got {other:?}"),
        }
    }

    #[test]
    fn unsupported_target_node_kind_refuses_before_final_closure() {
        let inputs = fixture_inputs(FixtureOptions {
            unsupported_target_node: true,
            ..FixtureOptions::default()
        });
        let (_, _, _, _, _, csag) = through_csag(&inputs);
        match compile_targets(
            &inputs.stage0,
            csag,
            inputs.target_descriptors.clone(),
            WorkBudget::fixture(),
        ) {
            TotalOutcome::Refused(TargetCompilationRefusal::UnsupportedNodeKind { kind, .. }) => {
                assert_eq!(kind, CsagNodeKind::ClosedObligation);
            }
            other => panic!("expected unsupported-target refusal, got {other:?}"),
        }
    }

    #[test]
    fn absent_provider_is_needs_input_after_portable_app_release() {
        let inputs = fixture_inputs(FixtureOptions {
            omit_provider: true,
            ..FixtureOptions::default()
        });
        let release = compile_to_release(&inputs);
        assert_eq!(release.provider_requirements().len(), 1);
        match bind_deployment_plan(release, Vec::new(), WorkBudget::fixture()) {
            TotalOutcome::NeedsInput(needs) => {
                assert_eq!(needs.kind, MissingInputKind::Provider);
                assert_eq!(needs.subjects[0].as_str(), "runtime.command-journal");
            }
            other => panic!("expected provider needs-input, got {other:?}"),
        }
    }

    #[test]
    fn absent_cycle_verifier_is_lawful_only_for_acyclic_graph() {
        let acyclic = fixture_inputs(FixtureOptions {
            block_authority_cycle_verifier: true,
            ..FixtureOptions::default()
        });
        let (_, _, _, _, _, csag) = through_csag(&acyclic);
        assert!(csag.proof().authority_cycle_proof().is_none());

        let cyclic = fixture_inputs(FixtureOptions {
            authority_cycle: true,
            block_authority_cycle_verifier: true,
            ..FixtureOptions::default()
        });
        let (_, _, _, _, obligations) = through_obligations(&cyclic);
        match build_csag(&cyclic.stage0, obligations, WorkBudget::fixture()) {
            TotalOutcome::NeedsInput(needs) => {
                assert_eq!(needs.kind, MissingInputKind::Verifier);
                assert!(needs.subjects.iter().any(|value| value.as_str() == "authority.checkout"));
            }
            other => panic!("expected cycle-verifier needs-input, got {other:?}"),
        }
    }

    #[test]
    fn descriptor_substitution_is_detected_against_stage0_lock() {
        let inputs = fixture_inputs(FixtureOptions::default());
        let (_, _, bound) = through_bound(&inputs);
        let application = bound.declarations.parsed().application().clone();
        let mut descriptors = inputs.family_descriptors.clone();
        descriptors[0].packs[0].requirements[0].contract = "contract.substituted".to_owned();
        match admit_family_descriptors(
            &inputs.stage0,
            descriptors,
            &application,
            WorkBudget::fixture(),
        ) {
            TotalOutcome::Refused(FamilyCompilationRefusal::DescriptorDigestDrift { release }) => {
                assert_eq!(release.as_str(), "sem.checkout");
            }
            other => panic!("expected descriptor drift, got {other:?}"),
        }
    }

    #[test]
    fn occurrence_substitution_is_rejected_during_name_admission() {
        let mut inputs = fixture_inputs(FixtureOptions::default());
        let text = std::str::from_utf8(&inputs.source.bytes).expect("fixture utf8")
            .replace("occ.payments", "occ.payments.substituted");
        inputs.source.bytes = text.into_bytes();
        inputs.source.claimed_digest = application_source_digest(&inputs.source.bytes);
        let source = produced(
            admit_application_source(&inputs.stage0, inputs.source.clone(), WorkBudget::fixture()),
            "source-admission",
        );
        let constitution = produced(
            admit_constitution(&inputs.stage0, inputs.constitution.clone(), WorkBudget::fixture()),
            "constitution-admission",
        );
        let parsed = produced(
            parse_application_source(&inputs.stage0, source, WorkBudget::fixture()),
            "parse",
        );
        match admit_application_declarations(
            &inputs.stage0,
            &constitution,
            parsed,
            WorkBudget::fixture(),
        ) {
            TotalOutcome::Refused(DeclarationAdmissionRefusal::EditionOrOccurrenceMismatch { release }) => {
                assert_eq!(release.as_str(), "sem.payments");
            }
            other => panic!("expected occurrence mismatch, got {other:?}"),
        }
    }

    #[test]
    fn budget_boundary_is_exact_and_exhaustion_is_not_refusal() {
        let inputs = fixture_inputs(FixtureOptions::default());
        let required = u64::try_from(
            inputs.source.bytes.len()
                + inputs.source.source.identity.len()
                + inputs.source.source.occurrence.len(),
        ).expect("fixture size");
        let mut exact = WorkBudget::fixture();
        exact.max_input_bytes = required;
        assert!(matches!(
            admit_application_source(&inputs.stage0, inputs.source.clone(), exact),
            TotalOutcome::Produced(_)
        ));
        let mut too_small = exact;
        too_small.max_input_bytes = required - 1;
        match admit_application_source(&inputs.stage0, inputs.source.clone(), too_small) {
            TotalOutcome::Exhausted(exhaustion) => {
                assert_eq!(exhaustion.dimension, BudgetDimension::InputBytes);
                assert_eq!(exhaustion.required, required);
                assert_eq!(exhaustion.allowed, required - 1);
            }
            other => panic!("expected exhaustion, got {other:?}"),
        }
    }

    #[test]
    fn retained_proof_tamper_fails_offline_reverification() {
        let mut vertical = execute_positive_vertical();
        vertical.boot.deployment.app_release.proof_ledger.proofs[0].canonical.push(0);
        match verify_boot_input_offline(&vertical.boot, &vertical.anchor, WorkBudget::fixture()) {
            TotalOutcome::Refused(OfflineVerificationRefusal::ProofLedgerCommitmentMismatch)
            | TotalOutcome::Refused(OfflineVerificationRefusal::ProofDigestMismatch { .. }) => {}
            other => panic!("expected offline proof failure, got {other:?}"),
        }
    }

    #[test]
    fn package_lock_substitution_fails_offline_reverification() {
        let mut vertical = execute_positive_vertical();
        let substitute = fixture_inputs(FixtureOptions {
            omit_offer: true,
            ..FixtureOptions::default()
        });
        vertical.boot.deployment.app_release.application_closure.stage0 = substitute.stage0;
        match verify_boot_input_offline(&vertical.boot, &substitute.anchor, WorkBudget::fixture()) {
            TotalOutcome::Refused(OfflineVerificationRefusal::PackageLockMismatch)
            | TotalOutcome::Refused(OfflineVerificationRefusal::ProofWitnessMismatch { .. }) => {}
            other => panic!("expected package substitution failure, got {other:?}"),
        }
    }
}
