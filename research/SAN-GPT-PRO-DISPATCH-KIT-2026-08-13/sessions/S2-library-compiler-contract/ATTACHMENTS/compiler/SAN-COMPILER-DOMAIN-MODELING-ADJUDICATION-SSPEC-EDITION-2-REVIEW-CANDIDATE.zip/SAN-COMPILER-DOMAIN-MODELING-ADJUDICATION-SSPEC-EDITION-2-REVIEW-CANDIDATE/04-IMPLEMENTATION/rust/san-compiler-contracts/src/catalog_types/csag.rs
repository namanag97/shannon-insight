//! Types owned by `csag`.

use std::collections::{BTreeMap, BTreeSet};

/// Field-complete contract model for `ApplicationSemanticProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationSemanticProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl ApplicationSemanticProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `AuthorityProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AuthorityProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl AuthorityProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `BindingCoverageProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BindingCoverageProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl BindingCoverageProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `CompileProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CompileProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl CompileProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `CsagBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `CsagBuildCheckpoint`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagBuildCheckpoint {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: Vec<crate::waist::ArtifactRef>,
    work_spent: u64,
    remaining_budget: crate::waist::WorkBudget,
}

impl CsagBuildCheckpoint {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.completed
    }
    #[must_use]
    pub fn work_spent(&self) -> u64 {
        self.work_spent
    }
    #[must_use]
    pub fn remaining_budget(&self) -> &crate::waist::WorkBudget {
        &self.remaining_budget
    }
}

/// Field-complete contract model for `CsagBuildInput`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagBuildInput {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `CsagBuildInputMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagBuildInputMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `CsagBuildOutcome`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CsagBuildOutcome {
    Produced {
        artifact: crate::waist::ArtifactRef,
        proof: crate::waist::ProofRef,
    },
    Refused {
        refusal: crate::vertical::CsagRefusal,
    },
    Exhausted {
        exhaustion: crate::waist::Exhaustion,
    },
    NeedsInput {
        request: crate::waist::CompilerNeedsInput,
    },
}

/// Field-complete contract model for `CsagBuilderState`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagBuilderState {
    stage: crate::waist::StageId,
    input: crate::waist::DigestClaim,
    completed: BTreeSet<crate::waist::StableId>,
    pending: BTreeSet<crate::waist::StableId>,
    work: crate::waist::WorkReceipt,
}

impl CsagBuilderState {
    #[must_use]
    pub fn stage(&self) -> &crate::waist::StageId {
        &self.stage
    }
    #[must_use]
    pub fn input(&self) -> &crate::waist::DigestClaim {
        &self.input
    }
    #[must_use]
    pub fn completed(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.completed
    }
    #[must_use]
    pub fn pending(&self) -> &BTreeSet<crate::waist::StableId> {
        &self.pending
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `CsagCanonicalProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagCanonicalProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl CsagCanonicalProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `CsagClosureProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagClosureProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl CsagClosureProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `CsagDelta`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagDelta {
    before: crate::waist::DigestClaim,
    after: crate::waist::DigestClaim,
    classification: crate::waist::CompatibilityClass,
    changed_subjects: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
}

impl CsagDelta {
    #[must_use]
    pub fn before(&self) -> &crate::waist::DigestClaim {
        &self.before
    }
    #[must_use]
    pub fn after(&self) -> &crate::waist::DigestClaim {
        &self.after
    }
    #[must_use]
    pub fn classification(&self) -> &crate::waist::CompatibilityClass {
        &self.classification
    }
    #[must_use]
    pub fn changed_subjects(&self) -> &Vec<crate::waist::StableId> {
        &self.changed_subjects
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
}

/// Field-complete contract model for `CsagExecutionContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagExecutionContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CsagExplainQuery`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagExplainQuery {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CsagExplanation`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagExplanation {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl CsagExplanation {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CsagExplanationGraph`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagExplanationGraph {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl CsagExplanationGraph {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CsagExplanationPathSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagExplanationPathSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CsagInputs`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagInputs {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CsagNodeId`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagNodeId {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `CsagParityReport`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagParityReport {
    target: crate::waist::SubjectKey,
    steps: Vec<crate::waist::ExplanationStep>,
    disclosure: crate::waist::DisclosurePolicyRef,
    evidence: Vec<crate::waist::ArtifactRef>,
    commitment: crate::waist::DigestClaim,
}

impl CsagParityReport {
    #[must_use]
    pub fn target(&self) -> &crate::waist::SubjectKey {
        &self.target
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::ExplanationStep> {
        &self.steps
    }
    #[must_use]
    pub fn disclosure(&self) -> &crate::waist::DisclosurePolicyRef {
        &self.disclosure
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CsagProjectionSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagProjectionSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CsagSchemaRegistry`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagSchemaRegistry {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl CsagSchemaRegistry {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CsagSeal`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagSeal {
    identity: crate::waist::StableId,
    owner: crate::waist::AuthorityRef,
    edition: crate::waist::Edition,
    kind: crate::waist::StableId,
    members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl CsagSeal {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn edition(&self) -> &crate::waist::Edition {
        &self.edition
    }
    #[must_use]
    pub fn kind(&self) -> &crate::waist::StableId {
        &self.kind
    }
    #[must_use]
    pub fn members(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::ScalarValue> {
        &self.members
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `CsagSlice`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagSlice {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CsagSliceContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagSliceContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CsagSliceProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagSliceProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl CsagSliceProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `CsagTrustPolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagTrustPolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CsagVectorCorpus`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagVectorCorpus {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `CsagVerificationContext`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagVerificationContext {
    pub package_lock: crate::waist::PackageLockRef,
    pub required_supplier_role: crate::stage0::CompilerSupplierRole,
    pub canonical_domain: crate::waist::SeparationDomain,
    pub digest_domain: crate::waist::SeparationDomain,
    pub policy: crate::waist::PolicyRef,
    pub budget: crate::waist::WorkBudget,
}

/// Field-complete contract model for `CsagVerificationProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagVerificationProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl CsagVerificationProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `DecisionCoverageProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DecisionCoverageProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl DecisionCoverageProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `DeploymentRequirementProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeploymentRequirementProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl DeploymentRequirementProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `EndpointSchemaProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EndpointSchemaProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl EndpointSchemaProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `EpistemicClosureProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EpistemicClosureProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl EpistemicClosureProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `EpistemicPolicySet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EpistemicPolicySet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `EvolutionProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EvolutionProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl EvolutionProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `FamilyGraphFragment`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyGraphFragment {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl FamilyGraphFragment {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `FamilyGraphFragmentSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyGraphFragmentSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `FamilyPlanRef`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPlanRef {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub occurrence: crate::waist::OccurrenceId,
}

/// Field-complete contract model for `FamilySlicePolicy`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilySlicePolicy {
    pub identity: crate::waist::StableId,
    pub edition: crate::waist::Edition,
    pub authority: crate::waist::AuthorityRef,
    pub rules: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub absence: crate::waist::AbsenceSemantics,
    pub limits: crate::waist::WorkBudget,
}

/// Field-complete contract model for `FragmentVerificationProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FragmentVerificationProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl FragmentVerificationProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `FragmentVerificationSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FragmentVerificationSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `GapCoverageProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GapCoverageProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl GapCoverageProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `GeneratedGraphDispatchMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GeneratedGraphDispatchMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `GraphFragment`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GraphFragment {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl GraphFragment {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `GraphFragmentSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GraphFragmentSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `GraphProjectionDispatchTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GraphProjectionDispatchTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl GraphProjectionDispatchTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `HyperedgeCommitResult`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HyperedgeCommitResult {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `HyperedgeProposalSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct HyperedgeProposalSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `IncidenceIndexSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IncidenceIndexSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `IncrementalCsagBuildPlan`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct IncrementalCsagBuildPlan {
    identity: crate::waist::StableId,
    basis: Vec<crate::waist::ArtifactRef>,
    steps: Vec<crate::waist::PlanStep>,
    requirements: Vec<crate::waist::StableId>,
    proof: crate::waist::ProofRef,
    commitment: crate::waist::DigestClaim,
}

impl IncrementalCsagBuildPlan {
    #[must_use]
    pub fn identity(&self) -> &crate::waist::StableId {
        &self.identity
    }
    #[must_use]
    pub fn basis(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.basis
    }
    #[must_use]
    pub fn steps(&self) -> &Vec<crate::waist::PlanStep> {
        &self.steps
    }
    #[must_use]
    pub fn requirements(&self) -> &Vec<crate::waist::StableId> {
        &self.requirements
    }
    #[must_use]
    pub fn proof(&self) -> &crate::waist::ProofRef {
        &self.proof
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `LinkerGraphFragment`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LinkerGraphFragment {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl LinkerGraphFragment {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `NodeCommitResult`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeCommitResult {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `NodeProposalSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeProposalSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationClosureReadView`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureReadView {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub edition: crate::waist::Edition,
    pub kind: crate::waist::StableId,
    pub members: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ObligationCoverageProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationCoverageProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl ObligationCoverageProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ObligationGraphFragment`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationGraphFragment {
    owner: crate::waist::AuthorityRef,
    nodes: Vec<crate::waist::GraphNode>,
    edges: Vec<crate::waist::GraphEdge>,
    provenance: crate::waist::Provenance,
    commitment: crate::waist::DigestClaim,
}

impl ObligationGraphFragment {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn nodes(&self) -> &Vec<crate::waist::GraphNode> {
        &self.nodes
    }
    #[must_use]
    pub fn edges(&self) -> &Vec<crate::waist::GraphEdge> {
        &self.edges
    }
    #[must_use]
    pub fn provenance(&self) -> &crate::waist::Provenance {
        &self.provenance
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `OrphanDispositionProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OrphanDispositionProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl OrphanDispositionProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `OwnerUniquenessProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OwnerUniquenessProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl OwnerUniquenessProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `PhaseCompatibilityProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PhaseCompatibilityProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl PhaseCompatibilityProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ProjectionBudget`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProjectionBudget {
    pub max_input_items: u64,
    pub max_input_bytes: u64,
    pub max_work_units: u64,
    pub max_allocation_bytes: u64,
    pub max_output_bytes: u64,
    pub max_diagnostics: u64,
}

/// Field-complete contract model for `ProjectionProofSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProjectionProofSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `ProvenanceIndex`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProvenanceIndex {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl ProvenanceIndex {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `ProviderFreeProof`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProviderFreeProof {
    subject: crate::waist::SubjectKey,
    issuer: crate::waist::SupplierRef,
    package_lock: crate::waist::PackageLockRef,
    separation_domain: crate::waist::SeparationDomain,
    commitment: crate::waist::DigestClaim,
    evidence: Vec<crate::waist::ArtifactRef>,
    work: crate::waist::WorkReceipt,
}

impl ProviderFreeProof {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn issuer(&self) -> &crate::waist::SupplierRef {
        &self.issuer
    }
    #[must_use]
    pub fn package_lock(&self) -> &crate::waist::PackageLockRef {
        &self.package_lock
    }
    #[must_use]
    pub fn separation_domain(&self) -> &crate::waist::SeparationDomain {
        &self.separation_domain
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
    #[must_use]
    pub fn evidence(&self) -> &Vec<crate::waist::ArtifactRef> {
        &self.evidence
    }
    #[must_use]
    pub fn work(&self) -> &crate::waist::WorkReceipt {
        &self.work
    }
}

/// Field-complete contract model for `ReferenceResolutionTable`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReferenceResolutionTable {
    owner: crate::waist::AuthorityRef,
    entries: BTreeMap<crate::waist::StableId, crate::waist::SemanticMember>,
    source: crate::waist::ArtifactRef,
    commitment: crate::waist::DigestClaim,
}

impl ReferenceResolutionTable {
    #[must_use]
    pub fn owner(&self) -> &crate::waist::AuthorityRef {
        &self.owner
    }
    #[must_use]
    pub fn entries(&self) -> &BTreeMap<crate::waist::StableId, crate::waist::SemanticMember> {
        &self.entries
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
    #[must_use]
    pub fn commitment(&self) -> &crate::waist::DigestClaim {
        &self.commitment
    }
}

/// Field-complete contract model for `RuntimeInteractionProjection`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeInteractionProjection {
    subject: crate::waist::SubjectKey,
    domain: crate::waist::SeparationDomain,
    entries: Vec<crate::waist::CanonicalEntry>,
    encoded_len: u64,
    source: crate::waist::ArtifactRef,
}

impl RuntimeInteractionProjection {
    #[must_use]
    pub fn subject(&self) -> &crate::waist::SubjectKey {
        &self.subject
    }
    #[must_use]
    pub fn domain(&self) -> &crate::waist::SeparationDomain {
        &self.domain
    }
    #[must_use]
    pub fn entries(&self) -> &Vec<crate::waist::CanonicalEntry> {
        &self.entries
    }
    #[must_use]
    pub fn encoded_len(&self) -> u64 {
        self.encoded_len
    }
    #[must_use]
    pub fn source(&self) -> &crate::waist::ArtifactRef {
        &self.source
    }
}

/// Field-complete contract model for `SemanticIndexSet`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SemanticIndexSet {
    pub owner: crate::waist::AuthorityRef,
    pub items: Vec<crate::waist::SemanticMember>,
    pub provenance: crate::waist::Provenance,
    pub commitment: crate::waist::DigestClaim,
}

/// Field-complete contract model for `SliceRequirement`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SliceRequirement {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub contract: crate::waist::ContractRef,
    pub cardinality: crate::waist::Cardinality,
    pub constraints: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
}

/// Field-complete contract model for `SliceRequirementMaterial`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SliceRequirementMaterial {
    pub claimed_identity: String,
    pub claimed_edition: u32,
    pub source_occurrence: crate::waist::ArtifactRefCarrier,
    pub properties: BTreeMap<String, crate::waist::CarrierScalar>,
    pub declared_order: Vec<String>,
}

/// Field-complete contract model for `TargetSliceRequirement`.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetSliceRequirement {
    pub identity: crate::waist::StableId,
    pub owner: crate::waist::AuthorityRef,
    pub contract: crate::waist::ContractRef,
    pub cardinality: crate::waist::Cardinality,
    pub constraints: BTreeMap<crate::waist::StableId, crate::waist::ScalarValue>,
    pub provenance: crate::waist::Provenance,
}
