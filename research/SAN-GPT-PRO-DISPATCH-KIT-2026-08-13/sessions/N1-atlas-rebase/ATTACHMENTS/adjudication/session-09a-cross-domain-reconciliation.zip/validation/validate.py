#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, pathlib, re, sys
from jsonschema import Draft202012Validator

ROOT=pathlib.Path(__file__).resolve().parents[1]

def sha256(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def main():
    errors=[]
    manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    for rel,schema_rel in manifest['schema_map'].items():
        p=ROOT/rel; sp=ROOT/schema_rel
        if not p.exists(): errors.append({'path':rel,'error':'missing data file'}); continue
        if not sp.exists(): errors.append({'path':schema_rel,'error':'missing schema'}); continue
        try:
            schema=json.loads(sp.read_text(encoding='utf-8')); Draft202012Validator.check_schema(schema); validator=Draft202012Validator(schema)
        except Exception as e:
            errors.append({'path':schema_rel,'error':str(e)}); continue
        rows=[]
        try:
            if p.suffix=='.jsonl':
                rows=[(n,json.loads(line)) for n,line in enumerate(p.read_text(encoding='utf-8').splitlines(),1) if line.strip()]
            else: rows=[(None,json.loads(p.read_text(encoding='utf-8')))]
        except Exception as e:
            errors.append({'path':rel,'error':str(e)}); continue
        for line,obj in rows:
            for err in validator.iter_errors(obj):
                errors.append({'path':rel,'line':line,'json_path':'/'.join(map(str,err.path)),'error':err.message})
                if len(errors)>=1000: break
    checks=ROOT/'CHECKSUMS.txt'
    if not checks.exists(): errors.append({'path':'CHECKSUMS.txt','error':'missing checksums'})
    else:
        for n,line in enumerate(checks.read_text(encoding='utf-8').splitlines(),1):
            if not line.strip() or line.startswith('#'): continue
            m=re.match(r'^([0-9a-f]{64})\s+\*?(.+)$',line.strip())
            if not m: errors.append({'path':'CHECKSUMS.txt','line':n,'error':'unparseable'}); continue
            expected,rel=m.group(1),m.group(2); p=ROOT/rel
            if not p.exists(): errors.append({'path':rel,'error':'checksum target missing'})
            elif sha256(p)!=expected: errors.append({'path':rel,'error':'checksum mismatch'})
    report={'status':'PASS' if not errors else 'FAIL','error_count':len(errors),'errors':errors[:1000]}
    print(json.dumps(report,indent=2,sort_keys=True))
    return 0 if not errors else 1
if __name__=='__main__': raise SystemExit(main())
