# DAT-SOURCE-OBSERVATION · Source-Qualified Observation Semantics

**Status:** `REVIEW_CANDIDATE`  
**Certification:** `NONE`

## Sovereign question

What did a foreign source expose under which authority, interface, principal, time, visibility, and uncertainty scope, without elevating the observation into application truth?

## Boundary

Owns:
- source-qualified observation
- complete observation scope
- source absence qualification
- source structural observation
- source claim conflict

Explicitly excludes:
- application fact
- Schema
- Identity
- Authorization
- provider connector
- source I/O
- source truth elevation
- business correspondence

## Implementation posture

This directory is an implementation-ready specification candidate, not SAN Rust production code. `RUST-API.json` contains candidate signatures only. Provider offers, runtime execution, target lowerers, independent assurance, ratification and certification remain external and unproved.

## Hard dependencies

- No first-batch Data Sovereign Library dependency.

## Reciprocal semantic seams

- None in this edition.

## Verification

Run `python VERIFY/verify.py` from this directory, or run the package root verifier.
