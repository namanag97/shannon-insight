//! Operation contracts owned by `SAN-COMPILER-DECISION-RESOLUTION`.

pub trait DecisionResolutionContracts {
    /// `decision-resolution.contributions.collect`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn collect_decision_contributions(
        &self,
        arg0: &crate::vertical::BoundDeclarationGraph,
        arg1: &crate::vertical::ExpandedContributionSet,
        arg2: &crate::catalog_types::decision_resolution::DecisionDescriptorSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::DecisionContributionSet, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.contributions.authorize`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn authorize_decision_contributions(
        &self,
        arg0: &crate::catalog_types::decision_resolution::DecisionContributionSet,
        arg1: &crate::waist::AuthorityPolicySet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::AuthorizedDecisionContributionSet, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.decision-graph.build`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn build_decision_dependency_graph(
        &self,
        arg0: &crate::catalog_types::decision_resolution::DecisionDescriptorSet,
        arg1: &crate::catalog_types::decision_resolution::AuthorizedDecisionContributionSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::DecisionDependencyGraph, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.decision.resolve-one`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_decision(
        &self,
        arg0: crate::catalog_types::decision_resolution::DecisionKey,
        arg1: &crate::catalog_types::decision_resolution::AuthorizedDecisionContributionSet,
        arg2: &crate::vertical::ResolvedDecisionSet,
        arg3: &crate::catalog_types::decision_resolution::DecisionAlgebraDispatch,
        arg4: crate::catalog_types::decision_resolution::PackDecisionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::vertical::ResolvedDecision, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.decision.resolve-all`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resolve_all_decisions(
        &self,
        arg0: &crate::catalog_types::decision_resolution::AuthorizedDecisionContributionSet,
        arg1: &crate::catalog_types::decision_resolution::DecisionDependencyGraph,
        arg2: &crate::catalog_types::decision_resolution::DecisionAlgebraDispatch,
        arg3: crate::catalog_types::decision_resolution::PackDecisionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::DecisionResolutionOutcome, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.decision.verify`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn verify_resolved_decisions(
        &self,
        arg0: &crate::vertical::ResolvedDecisionSet,
        arg1: &crate::catalog_types::decision_resolution::DecisionDescriptorSet,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::DecisionResolutionProof, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.checkpoint.create`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn create_pack_decision_checkpoint(
        &self,
        arg0: &crate::catalog_types::decision_resolution::PackDecisionState,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionCheckpoint, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.checkpoint.resume`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn resume_pack_decision(
        &self,
        arg0: &crate::catalog_types::decision_resolution::PackDecisionCheckpoint,
        arg1: &crate::catalog_types::decision_resolution::PackDecisionInput,
        arg2: crate::catalog_types::decision_resolution::PackDecisionBudget,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionOutcome, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.delta.classify`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn classify_pack_decision_delta(
        &self,
        arg0: &crate::catalog_types::decision_resolution::PackDecisionClosure,
        arg1: &crate::catalog_types::decision_resolution::PackDecisionClosure,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionDelta, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

    /// `decision-resolution.explain`. Owner: `SAN-COMPILER-DECISION-RESOLUTION`. Status: REVIEW_CANDIDATE; certification: NONE.
    fn explain_pack_decision(
        &self,
        arg0: crate::catalog_types::decision_resolution::PackDecisionExplainTarget,
        arg1: &crate::catalog_types::decision_resolution::PackDecisionOutcome,
        total_budget: crate::waist::WorkBudget,
    ) -> crate::waist::TotalOutcome<crate::catalog_types::decision_resolution::PackDecisionExplanation, crate::vertical::DecisionResolutionRefusal, crate::waist::CompilerNeedsInput>;

}
