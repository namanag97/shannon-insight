# session-party-authority-governance-domain-atlas

This package is a machine-readable research candidate for the SAN domain-atlas work package covering parties, authority, governance, trust, security, and privacy.

## Authority posture

The package does not mutate or ratify the attached SAN Global Program Registry. Existing `san.*` identities are referenced only in the registry crosswalk and intake proposals. New records use the `candidate.party-authority-governance.*` namespace.

## Canonical sources

JSONL files contain independently addressable primary records. JSON files contain schemas, vocabularies, manifests, coverage, indexes, and validation reports. Markdown is generated navigation only.

## Validation

From this directory:

```text
python tools/validate_corpus.py .
```

The validator requires Python 3 and the `jsonschema` package. It parses every JSON and JSONL file listed in the manifest, validates each record against its Draft 2020-12 schema, verifies unique identifiers, local references, ordering, banned field names, controlled values through schemas, and checksums.

Mechanical PASS does not establish semantic ratification, legal applicability, implementation correctness, compiler closure, or jurisdictional completeness.
