# SAN Universal Non-Data Domain Atlas v0.1.0

- Horizontal contexts: 275
- Vertical contexts: 26
- Context relationships: 3942
- Competency questions: 180
- Adversarial scenarios: 30

## Entry points
- `constitution/corpus_metamodel.json`
- `contexts/bounded_contexts.jsonl`
- `verticals/vertical_contexts.jsonl`
- `decisions/boundary_decisions.jsonl`
- `issues/conflicts.jsonl`
- `validation/VALIDATION.json`
