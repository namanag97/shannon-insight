# SAN Domain Atlas: Work, Process, Case, Decision, Risk, Control, and Human Factors

This archive contains a populated machine-readable research corpus for the assigned coverage region. JSONL collections are independently addressable records. JSON files contain controlled vocabularies, coverage assessments, validation results, and package navigation. Markdown is generated navigation only.

The supplied SAN Global Program Registry was audited and cross-referenced as candidate evidence. This archive does not mutate it, treat it as complete, infer ratification, or convert every registry record into a bounded context, package, or implementation unit.

Key interpretation rules:

1. Concept, contextual meaning, claim, relation, law, application, implementation, evidence, and coverage remain distinct layers.
2. Context and registry dispositions are research proposals, not admissions.
3. Case coordinates work, evidence, decisions, communication, and milestones while preserving their owners.
4. Risk describes and evaluates uncertainty; treatment selection and acceptance are authorized decisions.
5. Workflow, meetings, and several cross-owner groupings are compositions rather than sovereign owners.
6. Queues, timers, retries, tokens, persistence, user-interface states, and provider objects are not treated as domain truth without explicit translation.
7. Open legal, clinical, safety, privacy, and organizational authority questions remain machine-readable gaps or unresolved boundaries.

Start with `manifest.json`, `generated/index.json`, `coverage/coverage_matrix.json`, `coverage/boundary_evaluation.json`, and `VALIDATION.json`.
