//! Field-complete nominal models for the executable vertical.

use std::collections::{BTreeMap, BTreeSet};

use crate::stage0::{CompilerSupplierRole, ReleaseCoordinate, Stage0PackageAuthority};
use crate::waist::{
    AbsenceSemantics, ArtifactRef, ArtifactRefCarrier, AuthorityRef, Cardinality,
    CompilerNeedsInput, DigestClaim, Edition, Exhaustion, IdentityRefusal, OccurrenceId,
    PackageLockRef, RegistryKind, SeparationDomain, StableId, StageId, SubjectKey, TotalOutcome, WorkBudget,
    WorkReceipt,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StageRoleWitness {
    pub(crate) owner: ReleaseCoordinate,
    pub(crate) supplier: ReleaseCoordinate,
    pub(crate) role: CompilerSupplierRole,
    pub(crate) evidence: ArtifactRef,
}

impl StageRoleWitness {
    #[must_use]
    pub fn owner(&self) -> &ReleaseCoordinate { &self.owner }
    #[must_use]
    pub fn supplier(&self) -> &ReleaseCoordinate { &self.supplier }
    #[must_use]
    pub const fn role(&self) -> CompilerSupplierRole { self.role }
    #[must_use]
    pub fn evidence(&self) -> &ArtifactRef { &self.evidence }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct StageProof {
    pub(crate) stage: StageId,
    pub(crate) package_lock: PackageLockRef,
    pub(crate) subject: SubjectKey,
    pub(crate) canonical: Vec<u8>,
    pub(crate) digest: [u8; 32],
    pub(crate) witnesses: Vec<StageRoleWitness>,
    pub(crate) work: WorkReceipt,
}

impl StageProof {
    #[must_use]
    pub fn stage(&self) -> &StageId { &self.stage }
    #[must_use]
    pub fn package_lock(&self) -> &PackageLockRef { &self.package_lock }
    #[must_use]
    pub fn subject(&self) -> &SubjectKey { &self.subject }
    #[must_use]
    pub fn canonical_bytes(&self) -> &[u8] { &self.canonical }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
    #[must_use]
    pub fn witnesses(&self) -> &[StageRoleWitness] { &self.witnesses }
    #[must_use]
    pub fn work(&self) -> &WorkReceipt { &self.work }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProofLedger {
    pub(crate) proofs: Vec<StageProof>,
    pub(crate) commitment: [u8; 32],
}

impl ProofLedger {
    #[must_use]
    pub fn proofs(&self) -> &[StageProof] { &self.proofs }
    #[must_use]
    pub const fn commitment(&self) -> &[u8; 32] { &self.commitment }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationSourceCarrier {
    pub source: ArtifactRefCarrier,
    pub bytes: Vec<u8>,
    pub claimed_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ConstitutionCarrier {
    pub source: ArtifactRefCarrier,
    pub coordinate: String,
    pub edition: u32,
    pub bytes: Vec<u8>,
    pub claimed_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedApplicationSource {
    pub(crate) source: ArtifactRef,
    pub(crate) bytes: Vec<u8>,
    pub(crate) digest: [u8; 32],
    pub(crate) proof: StageProof,
}

impl AdmittedApplicationSource {
    #[must_use]
    pub fn source(&self) -> &ArtifactRef { &self.source }
    #[must_use]
    pub fn bytes(&self) -> &[u8] { &self.bytes }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedConstitution {
    pub(crate) source: ArtifactRef,
    pub(crate) coordinate: StableId,
    pub(crate) edition: Edition,
    pub(crate) digest: [u8; 32],
    pub(crate) proof: StageProof,
}

impl AdmittedConstitution {
    #[must_use]
    pub fn source(&self) -> &ArtifactRef { &self.source }
    #[must_use]
    pub fn coordinate(&self) -> &StableId { &self.coordinate }
    #[must_use]
    pub const fn edition(&self) -> Edition { self.edition }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ParsedSelection {
    pub kind: RegistryKind,
    pub identity: StableId,
    pub edition: Edition,
    pub occurrence: OccurrenceId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ParsedDecisionDirective {
    pub decision: StableId,
    pub alternative: StableId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ParsedSourceSet {
    pub(crate) application: StableId,
    pub(crate) selections: Vec<ParsedSelection>,
    pub(crate) packs: Vec<StableId>,
    pub(crate) decisions: Vec<ParsedDecisionDirective>,
    pub(crate) targets: Vec<StableId>,
    pub(crate) source: AdmittedApplicationSource,
    pub(crate) proof: StageProof,
}

impl ParsedSourceSet {
    #[must_use]
    pub fn application(&self) -> &StableId { &self.application }
    #[must_use]
    pub fn selections(&self) -> &[ParsedSelection] { &self.selections }
    #[must_use]
    pub fn packs(&self) -> &[StableId] { &self.packs }
    #[must_use]
    pub fn decisions(&self) -> &[ParsedDecisionDirective] { &self.decisions }
    #[must_use]
    pub fn targets(&self) -> &[StableId] { &self.targets }
    #[must_use]
    pub fn source(&self) -> &AdmittedApplicationSource { &self.source }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AdmittedDeclarationSet {
    pub(crate) parsed: ParsedSourceSet,
    pub(crate) selected_semantic_families: Vec<ReleaseCoordinate>,
    pub(crate) selected_targets: Vec<StableId>,
    pub(crate) proof: StageProof,
}

impl AdmittedDeclarationSet {
    #[must_use]
    pub fn parsed(&self) -> &ParsedSourceSet { &self.parsed }
    #[must_use]
    pub fn selected_semantic_families(&self) -> &[ReleaseCoordinate] {
        &self.selected_semantic_families
    }
    #[must_use]
    pub fn selected_targets(&self) -> &[StableId] { &self.selected_targets }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BoundDeclarationGraph {
    pub(crate) declarations: AdmittedDeclarationSet,
    pub(crate) release_bindings: BTreeMap<StableId, ReleaseCoordinate>,
    pub(crate) proof: StageProof,
}

impl BoundDeclarationGraph {
    #[must_use]
    pub fn declarations(&self) -> &AdmittedDeclarationSet { &self.declarations }
    #[must_use]
    pub fn release_bindings(&self) -> &BTreeMap<StableId, ReleaseCoordinate> {
        &self.release_bindings
    }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationSourceParsingRefusal {
    InvalidIdentity(IdentityRefusal),
    InvalidUtf8,
    EmptySource,
    SourceDigestMismatch,
    MalformedStatement { line: u64, statement: String },
    DuplicateApplication,
    MissingApplication,
    DuplicateSelection { release: StableId },
    EmptySemanticSelection,
    DuplicatePack { pack: StableId },
    DuplicateDecision { decision: StableId },
    DuplicateTarget { target: StableId },
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DeclarationAdmissionRefusal {
    InvalidIdentity(IdentityRefusal),
    PackageLockMismatch,
    UnselectedRelease { release: StableId },
    EditionOrOccurrenceMismatch { release: StableId },
    NonSemanticFamilySelected { release: StableId },
    FewerThanTwoSemanticFamilies,
    ConstitutionMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum NameBindingRefusal {
    UnknownRelease { release: StableId },
    AmbiguousRelease { release: StableId },
    DescriptorDigestDrift { release: StableId },
    PackageLockMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractRequirementCarrier {
    pub identity: String,
    pub contract: String,
    pub cardinality: CardinalityCarrier,
    pub constraints: BTreeMap<String, String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractOfferCarrier {
    pub identity: String,
    pub contract: String,
    pub capacity: u32,
    pub constraints: BTreeMap<String, String>,
    pub provided_facts: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CardinalityCarrier {
    ExactlyOne,
    ZeroOrOne,
    OneOrMore,
    Exact(u32),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DecisionCarrier {
    pub identity: String,
    pub alternatives: Vec<String>,
    pub required: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationRuleCarrier {
    pub identity: String,
    pub premises: Vec<String>,
    pub conclusion: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationCarrier {
    pub identity: String,
    pub owner: String,
    pub required_fact: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeRequirementCarrier {
    pub identity: String,
    pub capability: String,
    pub cardinality: CardinalityCarrier,
    pub absence: AbsenceSemantics,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PackContributionCarrier {
    pub pack: String,
    pub requirements: Vec<ContractRequirementCarrier>,
    pub offers: Vec<ContractOfferCarrier>,
    pub decisions: Vec<DecisionCarrier>,
    pub obligations: Vec<ObligationCarrier>,
    pub obligation_rules: Vec<ObligationRuleCarrier>,
    pub runtime_requirements: Vec<RuntimeRequirementCarrier>,
    pub initial_facts: Vec<String>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AuthorityDependencyCarrier {
    pub from: String,
    pub to: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyDescriptorCarrier {
    pub release_identity: String,
    pub owner_authority: String,
    pub descriptor_artifact: ArtifactRefCarrier,
    pub packs: Vec<PackContributionCarrier>,
    pub authority_dependencies: Vec<AuthorityDependencyCarrier>,
    pub claimed_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractRequirementSpec {
    pub(crate) identity: StableId,
    pub(crate) contract: StableId,
    pub(crate) cardinality: Cardinality,
    pub(crate) constraints: BTreeMap<StableId, StableId>,
    pub(crate) owner: ReleaseCoordinate,
}

impl ContractRequirementSpec {
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub fn contract(&self) -> &StableId { &self.contract }
    #[must_use]
    pub const fn cardinality(&self) -> Cardinality { self.cardinality }
    #[must_use]
    pub fn constraints(&self) -> &BTreeMap<StableId, StableId> { &self.constraints }
    #[must_use]
    pub fn owner(&self) -> &ReleaseCoordinate { &self.owner }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ContractOfferSpec {
    pub(crate) identity: StableId,
    pub(crate) contract: StableId,
    pub(crate) capacity: u32,
    pub(crate) constraints: BTreeMap<StableId, StableId>,
    pub(crate) provided_facts: BTreeSet<StableId>,
    pub(crate) owner: ReleaseCoordinate,
}

impl ContractOfferSpec {
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub fn contract(&self) -> &StableId { &self.contract }
    #[must_use]
    pub const fn capacity(&self) -> u32 { self.capacity }
    #[must_use]
    pub fn constraints(&self) -> &BTreeMap<StableId, StableId> { &self.constraints }
    #[must_use]
    pub fn provided_facts(&self) -> &BTreeSet<StableId> { &self.provided_facts }
    #[must_use]
    pub fn owner(&self) -> &ReleaseCoordinate { &self.owner }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DecisionSpec {
    pub(crate) identity: StableId,
    pub(crate) alternatives: BTreeSet<StableId>,
    pub(crate) required: bool,
    pub(crate) owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationRuleSpec {
    pub(crate) identity: StableId,
    pub(crate) premises: BTreeSet<StableId>,
    pub(crate) conclusion: StableId,
    pub(crate) owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationSpec {
    pub(crate) identity: StableId,
    pub(crate) owner_identity: AuthorityRef,
    pub(crate) required_fact: StableId,
    pub(crate) release_owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeRequirementSpec {
    pub(crate) identity: StableId,
    pub(crate) capability: StableId,
    pub(crate) cardinality: Cardinality,
    pub(crate) absence: AbsenceSemantics,
    pub(crate) owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct PackContribution {
    pub(crate) pack: StableId,
    pub(crate) owner: ReleaseCoordinate,
    pub(crate) requirements: Vec<ContractRequirementSpec>,
    pub(crate) offers: Vec<ContractOfferSpec>,
    pub(crate) decisions: Vec<DecisionSpec>,
    pub(crate) obligations: Vec<ObligationSpec>,
    pub(crate) obligation_rules: Vec<ObligationRuleSpec>,
    pub(crate) runtime_requirements: Vec<RuntimeRequirementSpec>,
    pub(crate) initial_facts: BTreeSet<StableId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AuthorityDependency {
    pub(crate) from: AuthorityRef,
    pub(crate) to: AuthorityRef,
    pub(crate) owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyDescriptor {
    pub(crate) release: ReleaseCoordinate,
    pub(crate) owner_authority: AuthorityRef,
    pub(crate) descriptor_artifact: ArtifactRef,
    pub(crate) packs: BTreeMap<StableId, PackContribution>,
    pub(crate) authority_dependencies: Vec<AuthorityDependency>,
    pub(crate) digest: [u8; 32],
}

impl FamilyDescriptor {
    #[must_use]
    pub fn release(&self) -> &ReleaseCoordinate { &self.release }
    #[must_use]
    pub fn semantic_owner(&self) -> &AuthorityRef { &self.semantic_owner }
    #[must_use]
    pub fn packs(&self) -> &BTreeMap<StableId, PackContribution> { &self.packs }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyDescriptorSet {
    pub(crate) descriptors: BTreeMap<StableId, FamilyDescriptor>,
    pub(crate) proof: StageProof,
}

impl FamilyDescriptorSet {
    #[must_use]
    pub fn descriptors(&self) -> &BTreeMap<StableId, FamilyDescriptor> { &self.descriptors }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExpandedContributionSet {
    pub(crate) bound: BoundDeclarationGraph,
    pub(crate) descriptors: FamilyDescriptorSet,
    pub(crate) contributions: Vec<PackContribution>,
    pub(crate) proof: StageProof,
}

impl ExpandedContributionSet {
    #[must_use]
    pub fn bound(&self) -> &BoundDeclarationGraph { &self.bound }
    #[must_use]
    pub fn descriptors(&self) -> &FamilyDescriptorSet { &self.descriptors }
    #[must_use]
    pub fn contributions(&self) -> &[PackContribution] { &self.contributions }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedDecision {
    pub(crate) identity: StableId,
    pub(crate) alternative: StableId,
    pub(crate) owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedDecisionSet {
    pub(crate) expanded: ExpandedContributionSet,
    pub(crate) decisions: BTreeMap<StableId, ResolvedDecision>,
    pub(crate) proof: StageProof,
}

impl ResolvedDecisionSet {
    #[must_use]
    pub fn decisions(&self) -> &BTreeMap<StableId, ResolvedDecision> { &self.decisions }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPlan {
    pub(crate) release: ReleaseCoordinate,
    pub(crate) semantic_owner: AuthorityRef,
    pub(crate) packs: Vec<StableId>,
    pub(crate) requirements: Vec<ContractRequirementSpec>,
    pub(crate) offers: Vec<ContractOfferSpec>,
    pub(crate) obligations: Vec<ObligationSpec>,
    pub(crate) obligation_rules: Vec<ObligationRuleSpec>,
    pub(crate) runtime_requirements: Vec<RuntimeRequirementSpec>,
    pub(crate) initial_facts: BTreeSet<StableId>,
    pub(crate) authority_dependencies: Vec<AuthorityDependency>,
    pub(crate) proof: StageProof,
}

impl FamilyPlan {
    #[must_use]
    pub fn release(&self) -> &ReleaseCoordinate { &self.release }
    #[must_use]
    pub fn packs(&self) -> &[StableId] { &self.packs }
    #[must_use]
    pub fn requirements(&self) -> &[ContractRequirementSpec] { &self.requirements }
    #[must_use]
    pub fn offers(&self) -> &[ContractOfferSpec] { &self.offers }
    #[must_use]
    pub fn obligations(&self) -> &[ObligationSpec] { &self.obligations }
    #[must_use]
    pub fn runtime_requirements(&self) -> &[RuntimeRequirementSpec] {
        &self.runtime_requirements
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FamilyPlanSet {
    pub(crate) application: StableId,
    pub(crate) decisions: ResolvedDecisionSet,
    pub(crate) plans: Vec<FamilyPlan>,
    pub(crate) proof: StageProof,
}

impl FamilyPlanSet {
    #[must_use]
    pub fn application(&self) -> &StableId { &self.application }
    #[must_use]
    pub fn plans(&self) -> &[FamilyPlan] { &self.plans }
    #[must_use]
    pub fn decisions(&self) -> &ResolvedDecisionSet { &self.decisions }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum PackExpansionRefusal {
    InvalidIdentity(IdentityRefusal),
    UnknownPack { pack: StableId },
    DuplicatePack { pack: StableId },
    PackOwnedByUnselectedRelease { pack: StableId },
    ExpansionCycle { cycle: Vec<StableId> },
    DescriptorDrift { release: StableId },
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DecisionResolutionRefusal {
    NoResolvedDecision,
    InvalidIdentity(IdentityRefusal),
    DuplicateDecisionDeclaration { decision: StableId },
    UnknownDecisionDirective { decision: StableId },
    InvalidAlternative { decision: StableId, alternative: StableId },
    ConflictingDirective { decision: StableId },
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum FamilyCompilationRefusal {
    NoSemanticFamilySelected,
    PlanlessFamilyForbidden { release: StableId },
    DescriptorMissing { release: StableId },
    DescriptorDigestDrift { release: StableId },
    CrossOwnerContribution { pack: StableId },
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ResolvedContractBinding {
    pub(crate) requirement: ContractRequirementSpec,
    pub(crate) offers: Vec<ContractOfferSpec>,
    pub(crate) selection_basis: BTreeMap<StableId, StableId>,
}

impl ResolvedContractBinding {
    #[must_use]
    pub fn requirement(&self) -> &ContractRequirementSpec { &self.requirement }
    #[must_use]
    pub fn offers(&self) -> &[ContractOfferSpec] { &self.offers }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBindingProof {
    pub(crate) stage: StageProof,
    pub(crate) requirement_count: u64,
    pub(crate) offer_count: u64,
    pub(crate) binding_count: u64,
}

impl ApplicationBindingProof {
    #[must_use]
    pub fn stage(&self) -> &StageProof { &self.stage }
    #[must_use]
    pub const fn requirement_count(&self) -> u64 { self.requirement_count }
    #[must_use]
    pub const fn binding_count(&self) -> u64 { self.binding_count }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationBinding {
    pub(crate) application: StableId,
    pub(crate) package_lock: PackageLockRef,
    pub(crate) family_plans: FamilyPlanSet,
    pub(crate) resolved_decisions: ResolvedDecisionSet,
    pub(crate) bindings: Vec<ResolvedContractBinding>,
    pub(crate) selection_proofs: Vec<StageProof>,
    pub(crate) proof: ApplicationBindingProof,
}

impl ApplicationBinding {
    #[must_use]
    pub fn application(&self) -> &StableId { &self.application }
    #[must_use]
    pub fn package_lock(&self) -> &PackageLockRef { &self.package_lock }
    #[must_use]
    pub fn family_plans(&self) -> &FamilyPlanSet { &self.family_plans }
    #[must_use]
    pub fn bindings(&self) -> &[ResolvedContractBinding] { &self.bindings }
    #[must_use]
    pub fn proof(&self) -> &ApplicationBindingProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationBindingRefusal {
    NoRealRequirement,
    NoRealOffer,
    MissingCompatibleOffer { requirement: StableId },
    AmbiguousOfferSelection { requirement: StableId, candidates: Vec<StableId> },
    CardinalityUnsatisfied { requirement: StableId, expected: Cardinality, actual: u64 },
    OfferCapacityExceeded { offer: StableId, capacity: u32, selected: u64 },
    ContractOwnerMismatch { contract: StableId },
    PackageLockMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ClosedObligation {
    pub(crate) identity: StableId,
    pub(crate) owner: AuthorityRef,
    pub(crate) required_fact: StableId,
    pub(crate) discharged_by: StableId,
    pub(crate) iteration: u64,
}

impl ClosedObligation {
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub fn required_fact(&self) -> &StableId { &self.required_fact }
    #[must_use]
    pub const fn iteration(&self) -> u64 { self.iteration }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum GapKind {
    ContractRequirement,
    Obligation,
    RuntimeProvider,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum GapResolution {
    BoundContract { offers: Vec<StableId> },
    DischargedObligation { fact: StableId, iteration: u64 },
    DeferredToDeployment { requirement: StableId, absence: AbsenceSemantics },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GapDisposition {
    pub(crate) subject: StableId,
    pub(crate) kind: GapKind,
    pub(crate) resolution: GapResolution,
    pub(crate) owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GapDispositionSet {
    pub(crate) dispositions: Vec<GapDisposition>,
    pub(crate) unresolved_count: u64,
    pub(crate) proof: StageProof,
}

impl GapDispositionSet {
    #[must_use]
    pub fn dispositions(&self) -> &[GapDisposition] { &self.dispositions }
    #[must_use]
    pub const fn unresolved_count(&self) -> u64 { self.unresolved_count }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosureProof {
    pub(crate) stage: StageProof,
    pub(crate) least_fixed_point: bool,
    pub(crate) monotone: bool,
    pub(crate) complete: bool,
}

impl ObligationClosureProof {
    #[must_use]
    pub fn stage(&self) -> &StageProof { &self.stage }
    #[must_use]
    pub const fn is_complete(&self) -> bool {
        self.least_fixed_point && self.monotone && self.complete
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ObligationClosure {
    pub(crate) binding: ApplicationBinding,
    pub(crate) obligations: Vec<ClosedObligation>,
    pub(crate) iterations: u64,
    pub(crate) derived_facts: BTreeSet<StableId>,
    pub(crate) gap_dispositions: GapDispositionSet,
    pub(crate) proof: ObligationClosureProof,
}

impl ObligationClosure {
    #[must_use]
    pub fn binding(&self) -> &ApplicationBinding { &self.binding }
    #[must_use]
    pub fn obligations(&self) -> &[ClosedObligation] { &self.obligations }
    #[must_use]
    pub const fn iterations(&self) -> u64 { self.iterations }
    #[must_use]
    pub fn derived_facts(&self) -> &BTreeSet<StableId> { &self.derived_facts }
    #[must_use]
    pub fn gap_dispositions(&self) -> &GapDispositionSet { &self.gap_dispositions }
    #[must_use]
    pub fn proof(&self) -> &ObligationClosureProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ObligationClosureRefusal {
    NoRealObligation,
    IncompleteFixedPoint { missing: Vec<StableId> },
    NonMonotoneRule { rule: StableId },
    DuplicateObligation { obligation: StableId },
    DuplicateRule { rule: StableId },
    GapDispositionIncomplete { gaps: Vec<StableId> },
    IterationLimitExceeded { required: u64, allowed: u64 },
    PackageLockMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub enum CsagNodeKind {
    ApplicationAnchor,
    Authority,
    FamilyPlan,
    ContractBinding,
    ClosedObligation,
    RuntimeRequirement,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagNode {
    pub(crate) identity: StableId,
    pub(crate) kind: CsagNodeKind,
    pub(crate) owner: AuthorityRef,
    pub(crate) provenance_release: ReleaseCoordinate,
    pub(crate) source_subject: StableId,
}

impl CsagNode {
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub fn kind(&self) -> &CsagNodeKind { &self.kind }
    #[must_use]
    pub fn owner(&self) -> &AuthorityRef { &self.owner }
}

#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd, Hash)]
pub enum CsagRelationKind {
    ApplicationContains,
    FamilyRequires,
    RequirementBoundToOffer,
    ObligationClosedByFact,
    RuntimeCapabilityRequired,
    AuthorityDependsOn,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagRelation {
    pub(crate) identity: StableId,
    pub(crate) source: StableId,
    pub(crate) target: StableId,
    pub(crate) kind: CsagRelationKind,
    pub(crate) owner: ReleaseCoordinate,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CsagProof {
    pub(crate) stage: StageProof,
    pub(crate) authority_cycle_proof: Option<StageProof>,
    pub(crate) non_empty: bool,
    pub(crate) anchor_law: bool,
    pub(crate) no_dangling_relations: bool,
    pub(crate) authority_cycles_verified: bool,
    pub(crate) canonical_subject_bound: bool,
}

impl CsagProof {
    #[must_use]
    pub fn stage(&self) -> &StageProof { &self.stage }
    #[must_use]
    pub fn authority_cycle_proof(&self) -> Option<&StageProof> { self.authority_cycle_proof.as_ref() }
    #[must_use]
    pub const fn is_valid(&self) -> bool {
        self.non_empty
            && self.anchor_law
            && self.no_dangling_relations
            && self.authority_cycles_verified
            && self.canonical_subject_bound
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Csag {
    pub(crate) application: StableId,
    pub(crate) schema: Edition,
    pub(crate) nodes: Vec<CsagNode>,
    pub(crate) relations: Vec<CsagRelation>,
    pub(crate) requested_targets: Vec<StableId>,
    pub(crate) application_anchor: StableId,
    pub(crate) commitment: DigestClaim,
    pub(crate) proof: CsagProof,
}

impl Csag {
    #[must_use]
    pub fn application(&self) -> &StableId { &self.application }
    #[must_use]
    pub const fn schema(&self) -> Edition { self.schema }
    #[must_use]
    pub fn nodes(&self) -> &[CsagNode] { &self.nodes }
    #[must_use]
    pub fn relations(&self) -> &[CsagRelation] { &self.relations }
    #[must_use]
    pub fn requested_targets(&self) -> &[StableId] { &self.requested_targets }
    #[must_use]
    pub fn application_anchor(&self) -> &StableId { &self.application_anchor }
    #[must_use]
    pub fn commitment(&self) -> &DigestClaim { &self.commitment }
    #[must_use]
    pub fn proof(&self) -> &CsagProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum CsagRefusal {
    EmptyGraph,
    IllegalApplicationAnchor,
    FabricatedFamilySemantic { node: StableId },
    DanglingRelation { relation: StableId },
    DuplicateNode { node: StableId },
    DuplicateRelation { relation: StableId },
    AuthorityCycleVerifierMissing { cycle: Vec<StableId> },
    AuthorityCycleVerificationFailed { cycle: Vec<StableId> },
    CanonicalSubjectMismatch,
    DigestCommitmentMismatch,
    GapDispositionIncomplete,
    PackageLockMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetDescriptorCarrier {
    pub release_identity: String,
    pub descriptor_artifact: ArtifactRefCarrier,
    pub target_kind: String,
    pub supported_node_kinds: Vec<CsagNodeKind>,
    pub claimed_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetDescriptor {
    pub(crate) release: ReleaseCoordinate,
    pub(crate) descriptor_artifact: ArtifactRef,
    pub(crate) target_kind: StableId,
    pub(crate) supported_node_kinds: BTreeSet<CsagNodeKind>,
    pub(crate) digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetArtifact {
    pub(crate) identity: StableId,
    pub(crate) target_kind: StableId,
    pub(crate) bytes: Vec<u8>,
    pub(crate) digest: [u8; 32],
    pub(crate) compiler_release: ReleaseCoordinate,
}

impl TargetArtifact {
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub fn target_kind(&self) -> &StableId { &self.target_kind }
    #[must_use]
    pub fn bytes(&self) -> &[u8] { &self.bytes }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetCompilation {
    pub(crate) target: TargetDescriptor,
    pub(crate) artifact: TargetArtifact,
    pub(crate) preservation_proof: StageProof,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetCompilationProof {
    pub(crate) stage: StageProof,
    pub(crate) all_nodes_supported: bool,
    pub(crate) portfolio_complete: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct TargetCompilationSet {
    pub(crate) csag: Csag,
    pub(crate) compilations: Vec<TargetCompilation>,
    pub(crate) portfolio: BTreeSet<StableId>,
    pub(crate) proof: TargetCompilationProof,
}

impl TargetCompilationSet {
    #[must_use]
    pub fn csag(&self) -> &Csag { &self.csag }
    #[must_use]
    pub fn compilations(&self) -> &[TargetCompilation] { &self.compilations }
    #[must_use]
    pub fn portfolio(&self) -> &BTreeSet<StableId> { &self.portfolio }
    #[must_use]
    pub fn proof(&self) -> &TargetCompilationProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum TargetCompilationRefusal {
    InvalidIdentity(IdentityRefusal),
    NoTargetRequested,
    UnsupportedTarget { target: StableId },
    TargetDescriptorNotSelected { target: StableId },
    TargetDescriptorDigestDrift { target: StableId },
    UnsupportedNodeKind { target: StableId, kind: CsagNodeKind },
    TargetPortfolioIncomplete,
    PreservationProofFailed { target: StableId },
    PackageLockMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeCapabilityDescriptorCarrier {
    pub release_identity: String,
    pub descriptor_artifact: ArtifactRefCarrier,
    pub capabilities: Vec<String>,
    pub claimed_digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeCapabilityDescriptor {
    pub(crate) release: ReleaseCoordinate,
    pub(crate) descriptor_artifact: ArtifactRef,
    pub(crate) capabilities: BTreeSet<StableId>,
    pub(crate) digest: [u8; 32],
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProviderBindingRequirement {
    pub(crate) identity: StableId,
    pub(crate) capability: StableId,
    pub(crate) cardinality: Cardinality,
    pub(crate) absence: AbsenceSemantics,
    pub(crate) runtime_release: ReleaseCoordinate,
    pub(crate) source_requirement: StableId,
}

impl ProviderBindingRequirement {
    #[must_use]
    pub fn identity(&self) -> &StableId { &self.identity }
    #[must_use]
    pub fn capability(&self) -> &StableId { &self.capability }
    #[must_use]
    pub const fn cardinality(&self) -> Cardinality { self.cardinality }
    #[must_use]
    pub const fn absence(&self) -> AbsenceSemantics { self.absence }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeRequirementClosureProof {
    pub(crate) stage: StageProof,
    pub(crate) every_requirement_supported: bool,
    pub(crate) portable_only: bool,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct RuntimeRequirementClosure {
    pub(crate) targets: TargetCompilationSet,
    pub(crate) requirements: Vec<ProviderBindingRequirement>,
    pub(crate) runtime_descriptors: Vec<RuntimeCapabilityDescriptor>,
    pub(crate) proof: RuntimeRequirementClosureProof,
}

impl RuntimeRequirementClosure {
    #[must_use]
    pub fn targets(&self) -> &TargetCompilationSet { &self.targets }
    #[must_use]
    pub fn requirements(&self) -> &[ProviderBindingRequirement] { &self.requirements }
    #[must_use]
    pub fn descriptors(&self) -> &[RuntimeCapabilityDescriptor] {
        &self.runtime_descriptors
    }
    #[must_use]
    pub fn proof(&self) -> &RuntimeRequirementClosureProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum RuntimeRequirementClosureRefusal {
    InvalidIdentity(IdentityRefusal),
    NoRuntimeRequirement,
    RuntimeDescriptorNotSelected { release: StableId },
    RuntimeDescriptorDigestDrift { release: StableId },
    UnsupportedRuntimeCapability { capability: StableId },
    AmbiguousRuntimeCapability { capability: StableId, releases: Vec<StableId> },
    ProviderSpecificValueLeaked { value: String },
    PackageLockMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationClosureSeal {
    pub(crate) subject: SubjectKey,
    pub(crate) canonical_domain: SeparationDomain,
    pub(crate) digest_domain: SeparationDomain,
    pub(crate) digest: [u8; 32],
    pub(crate) proof: StageProof,
}

impl ApplicationClosureSeal {
    #[must_use]
    pub fn subject(&self) -> &SubjectKey { &self.subject }
    #[must_use]
    pub fn canonical_domain(&self) -> &SeparationDomain { &self.canonical_domain }
    #[must_use]
    pub fn digest_domain(&self) -> &SeparationDomain { &self.digest_domain }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ApplicationClosure {
    pub(crate) stage0: Stage0PackageAuthority,
    pub(crate) constitution: AdmittedConstitution,
    pub(crate) source: AdmittedApplicationSource,
    pub(crate) family_plans: FamilyPlanSet,
    pub(crate) binding: ApplicationBinding,
    pub(crate) obligations: ObligationClosure,
    pub(crate) csag: Csag,
    pub(crate) targets: TargetCompilationSet,
    pub(crate) runtime: RuntimeRequirementClosure,
    pub(crate) upstream_proof_ledger: ProofLedger,
    pub(crate) proof_ledger: ProofLedger,
    pub(crate) seal: ApplicationClosureSeal,
}

impl ApplicationClosure {
    #[must_use]
    pub fn stage0(&self) -> &Stage0PackageAuthority { &self.stage0 }
    #[must_use]
    pub fn constitution(&self) -> &AdmittedConstitution { &self.constitution }
    #[must_use]
    pub fn source(&self) -> &AdmittedApplicationSource { &self.source }
    #[must_use]
    pub fn family_plans(&self) -> &FamilyPlanSet { &self.family_plans }
    #[must_use]
    pub fn binding(&self) -> &ApplicationBinding { &self.binding }
    #[must_use]
    pub fn obligations(&self) -> &ObligationClosure { &self.obligations }
    #[must_use]
    pub fn csag(&self) -> &Csag { &self.csag }
    #[must_use]
    pub fn targets(&self) -> &TargetCompilationSet { &self.targets }
    #[must_use]
    pub fn runtime(&self) -> &RuntimeRequirementClosure { &self.runtime }
    #[must_use]
    pub fn proof_ledger(&self) -> &ProofLedger { &self.proof_ledger }
    #[must_use]
    pub fn seal(&self) -> &ApplicationClosureSeal { &self.seal }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationClosureRefusal {
    ArtifactThreadMismatch { stage: StageId },
    PackageLockMismatch,
    UnclosedGap { subject: StableId },
    InvalidCsag,
    EmptyTargetPortfolio,
    RuntimeRequirementsNotClosed,
    UpstreamProofMissing { stage: StageId },
    ProofLedgerInconsistent,
    SealSubjectMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ReleaseManifest {
    pub(crate) application: StableId,
    pub(crate) package_lock: PackageLockRef,
    pub(crate) application_closure_digest: [u8; 32],
    pub(crate) target_artifacts: BTreeMap<StableId, [u8; 32]>,
    pub(crate) provider_requirements: Vec<StableId>,
    pub(crate) format_edition: Edition,
}

impl ReleaseManifest {
    #[must_use]
    pub fn application(&self) -> &StableId { &self.application }
    #[must_use]
    pub fn target_artifacts(&self) -> &BTreeMap<StableId, [u8; 32]> {
        &self.target_artifacts
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AppReleaseSeal {
    pub(crate) subject: SubjectKey,
    pub(crate) separation_domain: SeparationDomain,
    pub(crate) digest: [u8; 32],
    pub(crate) proof: StageProof,
}

impl AppReleaseSeal {
    #[must_use]
    pub fn subject(&self) -> &SubjectKey { &self.subject }
    #[must_use]
    pub fn separation_domain(&self) -> &SeparationDomain { &self.separation_domain }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AppRelease {
    pub(crate) application_closure: ApplicationClosure,
    pub(crate) manifest: ReleaseManifest,
    pub(crate) target_artifacts: Vec<TargetArtifact>,
    pub(crate) unbound_provider_requirements: Vec<ProviderBindingRequirement>,
    pub(crate) proof_ledger: ProofLedger,
    pub(crate) seal: AppReleaseSeal,
}

impl AppRelease {
    #[must_use]
    pub fn application_closure(&self) -> &ApplicationClosure { &self.application_closure }
    #[must_use]
    pub fn manifest(&self) -> &ReleaseManifest { &self.manifest }
    #[must_use]
    pub fn target_artifacts(&self) -> &[TargetArtifact] { &self.target_artifacts }
    #[must_use]
    pub fn provider_requirements(&self) -> &[ProviderBindingRequirement] {
        &self.unbound_provider_requirements
    }
    #[must_use]
    pub fn proof_ledger(&self) -> &ProofLedger { &self.proof_ledger }
    #[must_use]
    pub fn seal(&self) -> &AppReleaseSeal { &self.seal }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum AppReleaseAssemblyRefusal {
    ApplicationClosureUnsealed,
    TargetPortfolioIncomplete,
    TargetArtifactDigestMismatch { artifact: StableId },
    ProviderLeakageIntoPortableRelease { value: String },
    OfflineProofInventoryIncomplete { stage: StageId },
    ManifestMismatch,
    ReleaseSealVerificationFailed,
    PackageLockMismatch,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProviderOfferCarrier {
    pub provider: String,
    pub capability: String,
    pub endpoint: String,
    pub evidence: ArtifactRefCarrier,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProviderBinding {
    pub(crate) requirement: ProviderBindingRequirement,
    pub(crate) provider: StableId,
    pub(crate) endpoint: String,
    pub(crate) evidence: ArtifactRef,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeploymentPlanSeal {
    pub(crate) separation_domain: SeparationDomain,
    pub(crate) digest: [u8; 32],
    pub(crate) proof: StageProof,
}

impl DeploymentPlanSeal {
    #[must_use]
    pub fn separation_domain(&self) -> &SeparationDomain { &self.separation_domain }
    #[must_use]
    pub const fn digest(&self) -> &[u8; 32] { &self.digest }
    #[must_use]
    pub fn proof(&self) -> &StageProof { &self.proof }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct DeploymentPlan {
    pub(crate) app_release: AppRelease,
    pub(crate) provider_bindings: Vec<ProviderBinding>,
    pub(crate) seal: DeploymentPlanSeal,
}

impl DeploymentPlan {
    #[must_use]
    pub fn provider_bindings(&self) -> &[ProviderBinding] { &self.provider_bindings }
    #[must_use]
    pub fn app_release(&self) -> &AppRelease { &self.app_release }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DeploymentPlanningRefusal {
    InvalidIdentity(IdentityRefusal),
    MissingProvider { capability: StableId },
    AmbiguousProvider { capability: StableId, providers: Vec<StableId> },
    ProviderEvidenceInvalid { provider: StableId },
    CardinalityUnsatisfied { requirement: StableId },
    PortableReleaseContainsProviderBinding,
    ChargeOverflow,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BootInput {
    pub(crate) deployment: DeploymentPlan,
    pub(crate) release_digest: [u8; 32],
    pub(crate) deployment_digest: [u8; 32],
    pub(crate) startup_contract: BTreeMap<StableId, StableId>,
}

impl BootInput {
    #[must_use]
    pub fn deployment(&self) -> &DeploymentPlan { &self.deployment }
    #[must_use]
    pub const fn release_digest(&self) -> &[u8; 32] { &self.release_digest }
    #[must_use]
    pub const fn deployment_digest(&self) -> &[u8; 32] { &self.deployment_digest }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct OfflineVerificationReport {
    pub(crate) package_lock: PackageLockRef,
    pub(crate) checked_stages: BTreeSet<StageId>,
    pub(crate) proof_count: u64,
    pub(crate) application_closure_digest: [u8; 32],
    pub(crate) app_release_digest: [u8; 32],
    pub(crate) deployment_digest: [u8; 32],
}

impl OfflineVerificationReport {
    #[must_use]
    pub fn checked_stages(&self) -> &BTreeSet<StageId> { &self.checked_stages }
    #[must_use]
    pub const fn proof_count(&self) -> u64 { self.proof_count }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum OfflineVerificationRefusal {
    Stage0(crate::stage0::Stage0PackageAuthorityRefusal),
    PackageLockMismatch,
    ProofDigestMismatch { stage: StageId },
    ProofWitnessMismatch { stage: StageId },
    MissingProof { stage: StageId },
    DuplicateProof { stage: StageId },
    ProofLedgerCommitmentMismatch,
    ApplicationClosureDigestMismatch,
    AppReleaseDigestMismatch,
    DeploymentDigestMismatch,
    BootInputMismatch,
    ChargeOverflow,
}

pub type ExecutableSourceAdmissionOutcome = TotalOutcome<AdmittedApplicationSource, ApplicationSourceParsingRefusal>;
pub type ExecutableConstitutionAdmissionOutcome = TotalOutcome<AdmittedConstitution, DeclarationAdmissionRefusal>;
pub type ExecutableParseOutcome = TotalOutcome<ParsedSourceSet, ApplicationSourceParsingRefusal>;
pub type ExecutableDeclarationAdmissionOutcome = TotalOutcome<AdmittedDeclarationSet, DeclarationAdmissionRefusal>;
pub type ExecutableNameBindingOutcome = TotalOutcome<BoundDeclarationGraph, NameBindingRefusal>;
pub type ExecutableFamilyDescriptorOutcome = TotalOutcome<FamilyDescriptorSet, FamilyCompilationRefusal>;
pub type ExecutablePackExpansionOutcome = TotalOutcome<ExpandedContributionSet, PackExpansionRefusal>;
pub type ExecutableDecisionResolutionOutcome = TotalOutcome<ResolvedDecisionSet, DecisionResolutionRefusal>;
pub type ExecutableFamilyPlanOutcome = TotalOutcome<FamilyPlanSet, FamilyCompilationRefusal>;
pub type ExecutableApplicationBindingOutcome = TotalOutcome<ApplicationBinding, ApplicationBindingRefusal>;
pub type ExecutableObligationClosureOutcome = TotalOutcome<ObligationClosure, ObligationClosureRefusal>;
pub type ExecutableCsagOutcome = TotalOutcome<Csag, CsagRefusal>;
pub type ExecutableTargetCompilationOutcome = TotalOutcome<TargetCompilationSet, TargetCompilationRefusal>;
pub type ExecutableRuntimeRequirementClosureOutcome = TotalOutcome<RuntimeRequirementClosure, RuntimeRequirementClosureRefusal>;
pub type ExecutableApplicationClosureOutcome = TotalOutcome<ApplicationClosure, ApplicationClosureRefusal>;
pub type ExecutableAppReleaseOutcome = TotalOutcome<AppRelease, AppReleaseAssemblyRefusal>;
pub type ExecutableDeploymentPlanOutcome = TotalOutcome<DeploymentPlan, DeploymentPlanningRefusal>;
pub type ExecutableBootInputOutcome = TotalOutcome<BootInput, DeploymentPlanningRefusal>;
pub type ExecutableOfflineVerificationOutcome = TotalOutcome<OfflineVerificationReport, OfflineVerificationRefusal>;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ExecutableArtifactThread {
    pub stage0: &'static str,
    pub source_admission: &'static str,
    pub parsing: &'static str,
    pub name_binding: &'static str,
    pub family_plans: &'static str,
    pub application_binding: &'static str,
    pub obligation_closure: &'static str,
    pub csag: &'static str,
    pub targets: &'static str,
    pub runtime: &'static str,
    pub application_closure: &'static str,
    pub app_release: &'static str,
    pub deployment: &'static str,
    pub boot: &'static str,
    pub offline_reverification: &'static str,
}

pub const EXECUTABLE_ARTIFACT_THREAD: ExecutableArtifactThread = ExecutableArtifactThread {
    stage0: "Stage0PackageAuthority",
    source_admission: "AdmittedApplicationSource + AdmittedConstitution",
    parsing: "ParsedSourceSet + AdmittedDeclarationSet",
    name_binding: "BoundDeclarationGraph",
    family_plans: "FamilyPlanSet",
    application_binding: "ApplicationBinding",
    obligation_closure: "ObligationClosure + GapDispositionSet",
    csag: "Csag",
    targets: "TargetCompilationSet",
    runtime: "RuntimeRequirementClosure",
    application_closure: "ApplicationClosure",
    app_release: "AppRelease",
    deployment: "DeploymentPlan",
    boot: "BootInput",
    offline_reverification: "OfflineVerificationReport",
};

pub(crate) fn needs_input(
    stage: &str,
    kind: crate::waist::MissingInputKind,
    subjects: Vec<StableId>,
) -> CompilerNeedsInput {
    CompilerNeedsInput {
        stage: StageId::admit(stage).expect("static stage identity"),
        kind,
        subjects,
    }
}

pub(crate) fn outcome_exhausted<T, R>(exhaustion: Exhaustion) -> TotalOutcome<T, R> {
    TotalOutcome::Exhausted(exhaustion)
}

pub(crate) fn finite_budget() -> WorkBudget { WorkBudget::fixture() }
