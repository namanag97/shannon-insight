#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, re, subprocess, sys
from collections import defaultdict, deque
from pathlib import Path
try:
    import jsonschema
except Exception as e:
    print("FAIL jsonschema unavailable",e); raise SystemExit(1)

ID_RE=re.compile(r"^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)*$")
SUFFIX_RE=re.compile(r"(?:/v\d+|@v\d+|[-_]v\d+)$",re.I)
REQUIRED_ROOT=["CODEX-START-HERE.md","CATALOG.json","OWNERSHIP-MATRIX.json","EXISTING-SEM-CROSSWALK.json","BOUNDARY-ADJUDICATION.json","HARD-DEPENDENCY-DAG.json","SEMANTIC-SEAM-GRAPH.json","IMPLEMENTATION-ORDER.json","FIRST-BATCH-SELECTION.json","OPEN-QUESTIONS.json","GAP-LEDGER.json","RESEARCH-LEDGER.json","SSPEC-COMPLIANCE-MATRIX.json","CONFORMANCE-COVERAGE.json","MANIFEST.json","PACKAGE-VERIFY.json","README.md"]
REQUIRED_SPEC=["SPEC.json","SPEC.schema.json","CONTEXT-SPEC.json","CONTEXT-SPEC.schema.json","DOMAIN-MODEL.json","ONTOLOGY.json","VOCABULARY.json","TYPES.json","STATES.json","TRANSITIONS.json","OPERATIONS.json","RUST-API.json","DECISIONS.json","CONTRACTS.json","LAWS.json","REFUSALS.json","BUDGETS.json","CAPABILITIES.json","EVOLUTION.json","COMPILER-QUERIES.json","IR.json","VALIDATION.json","LOWERING.json","RUNTIME-OBLIGATIONS.json","DIAGNOSTICS.json","DEPENDENCY-DAG.json","PROOF-OBLIGATIONS.json","GAPS.json","CONFORMANCE-MATRIX.json","RESEARCH-SOURCES.json","SOURCE-GRAPH.json","IMPLEMENTATION-PACKET.json","STATUS.json","MANIFEST.json","README.md","VERIFY/verify.py"]

def load(p): return json.loads(p.read_text(encoding="utf-8"))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
class V:
    def __init__(self): self.errors=[]; self.checks=0
    def check(self,c,m): self.checks+=1; (None if c else self.errors.append(m))

def acyclic(nodes,edges):
    indeg={n:0 for n in nodes}; nxt=defaultdict(list)
    for e in edges:
        if e["from"] not in indeg or e["to"] not in indeg: return False
        indeg[e["to"]]+=1; nxt[e["from"]].append(e["to"])
    q=deque(sorted(n for n,d in indeg.items() if d==0)); seen=[]
    while q:
        n=q.popleft(); seen.append(n)
        for m in nxt[n]:
            indeg[m]-=1
            if indeg[m]==0:q.append(m)
    return len(seen)==len(nodes)

def detect_fixture(root, fixture):
    import copy
    mut=fixture["mutation"]; kind=mut["kind"]
    cat=copy.deepcopy(load(root/"CATALOG.json")); dag=copy.deepcopy(load(root/"HARD-DEPENDENCY-DAG.json"))
    if kind=="CATALOG_DUPLICATE":
        row=next(x for x in cat["libraries"] if x["identity"]==mut["identity"]); cat["libraries"].append(copy.deepcopy(row))
        ids=[x["identity"] for x in cat["libraries"]]; return "DUPLICATE_IDENTITY" if len(ids)!=len(set(ids)) else None
    if kind=="CATALOG_ADD":
        cat["libraries"].append({"identity":mut["identity"]}); return "EDITION_SUFFIX" if SUFFIX_RE.search(mut["identity"]) else None
    if kind=="DAG_EDGE":
        dag["edges"].append({"from":mut["from"],"to":mut["to"],"kind":"FIXTURE"})
        if mut["from"] not in dag["nodes"] or mut["to"] not in dag["nodes"]: return "UNKNOWN_DEPENDENCY"
        if not acyclic(dag["nodes"],dag["edges"]): return "HARD_DEPENDENCY_CYCLE"
        seams=load(root/"SEMANTIC-SEAM-GRAPH.json")["seams"]
        if any({x["consumer"],x["provider"]}=={mut["from"],mut["to"]} for x in seams): return "SEAM_HARD_EDGE_COLLISION"
        return None
    lib=root/"LIBRARIES"/mut.get("library","DAT-COLLECTION")
    if kind=="REMOVE_STATE_CELL":
        st=load(lib/"STATES.json")["state_machine"]; cells=copy.deepcopy(load(lib/"TRANSITIONS.json")["matrix"]); cells.pop()
        return "STATE_MATRIX_INCOMPLETE" if len(cells)!=len(st["states"])*len(st["commands"]) else None
    if kind=="OPERATION_ADD_UNKNOWN_LAW":
        ops=copy.deepcopy(load(lib/"OPERATIONS.json")["operations"]); ops[0]["law_coverage"].append("LAW-NOT-THERE")
        known={x["identity"] for x in load(lib/"LAWS.json")["laws"]}; return "UNKNOWN_LAW" if not set(ops[0]["law_coverage"])<=known else None
    if kind=="REMOVE_DECISION_ABSENCE":
        dec=copy.deepcopy(load(lib/"DECISIONS.json")["decisions"]); dec[0]["absence_semantics"]=""
        return "DECISION_ABSENCE_MISSING" if not dec[0].get("absence_semantics") else None
    if kind=="ZERO_BUDGET":
        b=copy.deepcopy(load(lib/"BUDGETS.json")["budgets"]); b[0]["max_input_bytes"]=0
        return "UNBOUNDED_BUDGET" if b[0]["max_input_bytes"]<=0 else None
    if kind=="ADMITTED_DESERIALIZABLE":
        types=copy.deepcopy(load(lib/"RUST-API.json")["types"]); t=next(x for x in types if x["kind"] in {"ADMITTED_VALUE","ADMITTED_ENTITY","PROOF","AUTHORITY"}); t["deserialize_constructor"]=True
        return "FORGEABLE_ADMITTED_TYPE" if t["deserialize_constructor"] or not t["fields_private"] else None
    if kind=="LOCAL_PROVIDER_OFFER":
        c=copy.deepcopy(load(lib/"CONTRACTS.json")); c["offers"]={"provider":"FORGED"}
        return "PROVIDER_OFFER_LEAK" if c["offers"].get("disposition")!="INAPPLICABLE" else None
    if kind=="SET_LOWERING_VERIFIED":
        low=copy.deepcopy(load(lib/"LOWERING.json")); low["lowering_verified"]=True
        return "LOWERING_OVERCLAIM" if low["lowering_verified"] else None
    if kind=="ADD_UNKNOWN_SOURCE":
        known={x["identity"] for x in load(root/"RESEARCH-LEDGER.json")["sources"]}; sources=copy.deepcopy(load(lib/"RESEARCH-SOURCES.json")["sources"]); sources.append({"identity":"SRC-NOT-THERE"})
        return "UNKNOWN_RESEARCH_SOURCE" if any(x["identity"] not in known for x in sources) else None
    if kind=="CERTIFY":
        st=copy.deepcopy(load(lib/"STATUS.json")); st["certified"]=True; st["certification"]="PRODUCTION"
        return "CERTIFICATION_OVERCLAIM" if st["certified"] or st["certification"]!="NONE" else None
    if kind=="DIRECT_MUTATION":
        rt=copy.deepcopy(load(lib/"RUNTIME-OBLIGATIONS.json")); rt["mutation_path"]="DIRECT_DATABASE_WRITE"
        return "MUTATION_PATH_BYPASS" if "Host Role Composition → Mutation Kernel" not in rt["mutation_path"] else None
    return None

def verify(root):
    v=V()
    for rel in REQUIRED_ROOT: v.check((root/rel).exists(),f"missing root {rel}")
    cat=load(root/"CATALOG.json"); libs=cat["libraries"]; ids=[x["identity"] for x in libs]
    v.check(len(ids)==len(set(ids)),"duplicate catalog identity")
    for x in libs:
        v.check(bool(ID_RE.fullmatch(x["identity"])),f"invalid identity {x['identity']}")
        v.check(not SUFFIX_RE.search(x["identity"]),f"edition suffix {x['identity']}")
    batch=cat["first_batch"]; v.check(len(batch)==8,"first batch must be exactly eight")
    dag=load(root/"HARD-DEPENDENCY-DAG.json")
    v.check(set(dag["nodes"])==set(ids),"DAG/catalog node drift")
    v.check(acyclic(dag["nodes"],dag["edges"]),"hard dependency cycle")
    hard_pairs={(e["from"],e["to"]) for e in dag["edges"]}|{(e["to"],e["from"]) for e in dag["edges"]}
    seams=load(root/"SEMANTIC-SEAM-GRAPH.json")["seams"]
    for s in seams:
        if s["consumer"] in ids and s["provider"] in ids:
            v.check((s["consumer"],s["provider"]) not in hard_pairs,"semantic seam duplicated as hard edge")
    source_ids={x["identity"] for x in load(root/"RESEARCH-LEDGER.json")["sources"]}
    global_ops=set(); global_laws=set(); global_refs=set()
    for lib_id in batch:
        d=root/"LIBRARIES"/lib_id
        for rel in REQUIRED_SPEC: v.check((d/rel).exists(),f"{lib_id} missing {rel}")
        spec=load(d/"SPEC.json"); context=load(d/"CONTEXT-SPEC.json")
        jsonschema.Draft202012Validator(load(d/"SPEC.schema.json")).validate(spec)
        jsonschema.Draft202012Validator(load(d/"CONTEXT-SPEC.schema.json")).validate(context)
        v.check(spec["identity"]==lib_id,"directory/spec identity drift")
        v.check(spec["edition"]>=1 and spec["status"]=="REVIEW_CANDIDATE" and spec["certification"]=="NONE","status overclaim")
        ops=load(d/"OPERATIONS.json")["operations"]; rust=load(d/"RUST-API.json")
        laws=load(d/"LAWS.json")["laws"]; refs=load(d/"REFUSALS.json")["variants"]; decs=load(d/"DECISIONS.json")["decisions"]
        opids={x["identity"] for x in ops}; lawids={x["identity"] for x in laws}; refids={x["identity"] for x in refs}; decids={x["identity"] for x in decs}
        v.check(len(opids)==len(ops) and len(lawids)==len(laws) and len(refids)==len(refs),f"{lib_id} duplicate local IDs")
        v.check({x["identity"] for x in rust["operations"]}==opids,f"{lib_id} operation/Rust API drift")
        for op in ops:
            v.check(op["candidate_signature"].startswith("pub fn ") and "Result<" in op["candidate_signature"],f"{op['identity']} placeholder signature")
            v.check(set(op["law_coverage"])<=lawids,f"{op['identity']} unknown law")
            v.check(set(op["decision_dependencies"])<=decids,f"{op['identity']} unknown decision")
            v.check(op["side_effect_posture"]=="PURE_NO_IO",f"{op['identity']} provider/I/O leakage")
            v.check(op["budget"],f"{op['identity']} budget missing")
        for law in laws:
            v.check(set(law["operations_affected"])<=opids,f"{law['identity']} unknown operation")
            v.check(set(law["refusal_on_violation"])<=refids,f"{law['identity']} unknown refusal")
        for dec in decs: v.check(bool(dec.get("absence_semantics")),f"{dec['identity']} missing absence")
        for t in rust["types"]:
            if t["kind"] in {"ADMITTED_VALUE","ADMITTED_ENTITY","PROOF","AUTHORITY"}:
                v.check(t["fields_private"] and not t["deserialize_constructor"],f"{lib_id} forgeable {t['candidate_rust_name']}")
        st=load(d/"STATES.json")["state_machine"]; matrix=load(d/"TRANSITIONS.json")["matrix"]
        v.check(len(matrix)==len(st["states"])*len(st["commands"]),f"{lib_id} state matrix incomplete")
        v.check(len({(x["state"],x["command"]) for x in matrix})==len(matrix),f"{lib_id} state matrix duplicate")
        for cell in matrix:
            v.check((cell["outcome"]=="TRANSITION" and cell["event"] and not cell["refusal"]) or (cell["outcome"]=="REFUSAL" and cell["refusal"] in refids),f"{lib_id} transition/refusal drift")
        for b in load(d/"BUDGETS.json")["budgets"]:
            for key in ["max_input_bytes","max_items","max_depth","max_output_bytes","max_iterations"]: v.check(isinstance(b[key],int) and b[key]>0,f"{lib_id} unbounded {key}")
            v.check("allocate" in b["precharge_order"] and b["precharge_order"].index("allocate") > b["precharge_order"].index("charge allocation") and b["overflow_behavior"].startswith("REFUSE_"),f"{lib_id} unsafe budget")
        conf=load(d/"CONFORMANCE-MATRIX.json")["cases"]
        for law_id in lawids:
            kinds={x["kind"] for x in conf if x["law"]==law_id}
            v.check({"POSITIVE","NEGATIVE_TWIN","BOUNDARY_MAX","BOUNDARY_MAX_PLUS_ONE","MUTATION","EXHAUSTION","REPLAY"}<=kinds,f"{law_id} conformance incomplete")
        rsrc=load(d/"RESEARCH-SOURCES.json")["sources"]
        for s in rsrc: v.check(s["identity"] in source_ids,f"{lib_id} source not in root ledger {s['identity']}")
        sgraph=load(d/"SOURCE-GRAPH.json")
        local_paths={x["path"] for x in load(root/"SOURCE-LOCK.json")["sources"]}
        for sid in sgraph["sources"]:
            v.check(sid in source_ids or sid in local_paths,f"{lib_id} source graph unresolved {sid}")
        status=load(d/"STATUS.json")
        for key in ["semantic_execution_verified","implementation_verified","compiler_integration_verified","lowering_verified","runtime_vertical_verified","provider_conformance_verified","independently_verified","ratified","certified"]: v.check(status[key] is False,f"{lib_id} overclaims {key}")
        v.check("Host Role Composition → Mutation Kernel" in load(d/"RUNTIME-OBLIGATIONS.json")["mutation_path"],f"{lib_id} mutation bypass")
        manifest=load(d/"MANIFEST.json")
        for row in manifest["files"]: v.check((d/row["path"]).exists() and digest(d/row["path"])==row["sha256"],f"{lib_id} manifest mismatch {row['path']}")
        global_ops|=opids; global_laws|=lawids; global_refs|=refids
    manifest=load(root/"MANIFEST.json")
    for row in manifest["files"]: v.check((root/row["path"]).exists() and digest(root/row["path"])==row["sha256"],f"root manifest mismatch {row['path']}")
    fixture_rows=[]
    for entry in load(root/"VERIFY/FIXTURE-INDEX.json")["fixtures"]:
        fixture=load(root/"VERIFY"/entry["path"]); actual=detect_fixture(root,fixture)
        row={"path":entry["path"],"expected":fixture["expected_code"],"actual":actual,"result":"PASS" if actual==fixture["expected_code"] else "FAIL"}
        fixture_rows.append(row); v.check(row["result"]=="PASS",f"negative fixture failed {entry['path']}: {actual}")
    v.fixture_rows=fixture_rows
    return v

def main():
    root=Path(sys.argv[1] if len(sys.argv)>1 else ".").resolve(); v=verify(root)
    result={"result":"PASS" if not v.errors else "FAIL","checks":v.checks,"errors":v.errors,"negative_fixtures":getattr(v,"fixture_rows",[])}
    print(json.dumps(result,indent=2,sort_keys=True)); raise SystemExit(0 if not v.errors else 1)
if __name__=="__main__": main()
