# Generated Corpus Navigation

JSON/JSONL is the source of truth. This file only helps humans find it, apparently still a necessary accommodation.

- Total primary records: 3190
- First-class typed relations: 460
- Context-map relationships: 107
- Candidate bounded contexts: 23
- Boundary hypotheses evaluated: 57

## Canonical collections

- `corpus/artifacts.jsonl` — 88 records
- `corpus/capabilities.jsonl` — 61 records
- `corpus/claims.jsonl` — 91 records
- `corpus/commands.jsonl` — 84 records
- `corpus/compositions.jsonl` — 12 records
- `corpus/concepts.jsonl` — 499 records
- `corpus/context_relationships.jsonl` — 107 records
- `corpus/contexts.jsonl` — 57 records
- `corpus/contextual_meanings.jsonl` — 82 records
- `corpus/coverage_areas.jsonl` — 47 records
- `corpus/entities.jsonl` — 34 records
- `corpus/events.jsonl` — 95 records
- `corpus/evidence_sources.jsonl` — 50 records
- `corpus/laws.jsonl` — 123 records
- `corpus/mappings.jsonl` — 67 records
- `corpus/policies.jsonl` — 37 records
- `corpus/profiles.jsonl` — 14 records
- `corpus/queries.jsonl` — 66 records
- `corpus/refusals.jsonl` — 101 records
- `corpus/relations.jsonl` — 460 records
- `corpus/states.jsonl` — 231 records
- `corpus/value_objects.jsonl` — 62 records
- `issues/conflicts.jsonl` — 6 records
- `issues/gaps.jsonl` — 10 records
- `issues/unresolved_boundaries.jsonl` — 25 records
- `issues/unresolved_references.jsonl` — 10 records
- `registry_intake/candidate_units.jsonl` — 83 records
- `registry_intake/disposition_ledger.jsonl` — 83 records
- `registry_intake/existing_record_crosswalk.jsonl` — 83 records
- `registry_intake/merge_split_proposals.jsonl` — 13 records
- `registry_intake/registry_change_requests.jsonl` — 11 records
- `scenarios/boundary_examples.jsonl` — 171 records
- `scenarios/competency_questions.jsonl` — 42 records
- `scenarios/cross_domain_examples.jsonl` — 57 records
- `scenarios/negative_examples.jsonl` — 57 records
- `scenarios/positive_examples.jsonl` — 57 records
- `scenarios/scenarios.jsonl` — 14 records

## Context dispositions

- `ASSURANCE_EVIDENCE` — 1
- `CANDIDATE_BOUNDED_CONTEXT` — 23
- `COMPILER_STAGE` — 7
- `COMPOSITION` — 1
- `FOUNDATION_ALGEBRA_CANDIDATE` — 2
- `OWNER_LOCAL_MODULE` — 2
- `PORTABLE_IR_DIALECT` — 1
- `PROFILE` — 1
- `PROOF_VERTICAL` — 1
- `PROVIDER_IMPLEMENTATION` — 2
- `RESOURCE_CONTRACT` — 2
- `RUNTIME_MECHANISM` — 4
- `SEMANTIC_FAMILY_CANDIDATE` — 4
- `SPLIT_REQUIRED` — 6

See `generated/index.json` for ID-level navigation.
