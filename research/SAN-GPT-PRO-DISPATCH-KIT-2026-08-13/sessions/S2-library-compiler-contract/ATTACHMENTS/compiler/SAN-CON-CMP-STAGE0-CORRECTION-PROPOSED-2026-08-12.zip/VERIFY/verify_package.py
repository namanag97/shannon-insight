#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from collections import defaultdict, deque
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

EXPECTED_TOP_LEVEL = {
    'EXECUTIVE-FINDINGS.md',
    'CURRENT-EXECUTION-DAG.json',
    'CORRECTED-EXECUTION-DAG.json',
    'AUTHORITY-ISSUANCE-MATRIX.json',
    'VALUE-AND-PROOF-OWNERSHIP.json',
    'CON-CMP-COVERAGE-MATRIX.json',
    'UNREACHABLE-PATHS.json',
    'SPEC-CODE-DELTAS.json',
    'DELETION-AND-TOMBSTONE-PLAN.json',
    'RUST-API-CORRECTIONS.json',
    'INTEGRATION-TEST-VECTORS.json',
    'IMPLEMENTATION-ORDER.json',
    'OPEN-DECISIONS.json',
    'ARTIFACT-LADDER-RULING.json',
    'MANIFEST.json',
    'VERIFY',
}
REQUIRED_DIMENSIONS = {
    'source_present', 'symbol_present', 'reachable', 'behavior_tested',
    'integrated', 'independently_verified', 'certification'
}
REQUIRED_TEST_CATEGORIES = {
    'positive', 'negative_twin', 'substitution', 'replay',
    'budget_boundary', 'absence', 'offline_reverification'
}
SOURCE_REF_KEYS = {
    'source_set', 'path', 'start_line', 'end_line',
    'file_sha256', 'span_sha256', 'supports'
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding='utf-8'))


def walk(value: Any):
    yield value
    if isinstance(value, dict):
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def cycle_check(nodes: list[str], edges: list[tuple[str, str]]) -> tuple[bool, list[str]]:
    adj: dict[str, list[str]] = defaultdict(list)
    indeg = {n: 0 for n in nodes}
    for a, b in edges:
        adj[a].append(b)
        indeg.setdefault(a, 0)
        indeg[b] = indeg.get(b, 0) + 1
    q = deque(sorted(n for n, d in indeg.items() if d == 0))
    order: list[str] = []
    while q:
        n = q.popleft()
        order.append(n)
        for m in sorted(adj[n]):
            indeg[m] -= 1
            if indeg[m] == 0:
                q.append(m)
    return len(order) == len(indeg), order


def add_check(checks: list[dict[str, Any]], errors: list[str], name: str, passed: bool, detail: str) -> None:
    checks.append({'name': name, 'passed': passed, 'detail': detail})
    if not passed:
        errors.append(f'{name}: {detail}')


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--package-root', required=True)
    parser.add_argument('--snapshot-root', required=True)
    parser.add_argument('--handoff-root', required=True)
    parser.add_argument('--proposal-root', required=True)
    parser.add_argument('--report-out', required=True)
    args = parser.parse_args()

    root = Path(args.package_root).resolve()
    source_roots = {
        'SNAPSHOT': Path(args.snapshot_root).resolve(),
        'HANDOFF': Path(args.handoff_root).resolve(),
        'PROPOSAL': Path(args.proposal_root).resolve(),
    }
    report_out = Path(args.report_out).resolve()
    checks: list[dict[str, Any]] = []
    errors: list[str] = []
    counts = {
        'json_artifacts_validated': 0,
        'schemas_meta_validated': 0,
        'source_references_verified': 0,
        'record_identities': 0,
        'record_references': 0,
        'integration_test_vectors': 0,
    }

    actual_top = {p.name for p in root.iterdir()}
    add_check(checks, errors, 'exact_top_level', actual_top == EXPECTED_TOP_LEVEL,
              f'expected={sorted(EXPECTED_TOP_LEVEL)} actual={sorted(actual_top)}')

    schema_dir = root / 'VERIFY' / 'schemas'
    schema_paths = sorted(schema_dir.glob('*.schema.json'))
    schema_errors: list[str] = []
    closed_errors: list[str] = []
    for path in schema_paths:
        try:
            schema = load_json(path)
            Draft202012Validator.check_schema(schema)
            counts['schemas_meta_validated'] += 1
            for node in walk(schema):
                if isinstance(node, dict) and node.get('type') == 'object':
                    if node.get('additionalProperties') is not False:
                        closed_errors.append(f'{path.relative_to(root)} object schema is not closed')
        except Exception as exc:
            schema_errors.append(f'{path.relative_to(root)}: {exc}')
    add_check(checks, errors, 'schemas_meta_validate', not schema_errors,
              'all schemas valid' if not schema_errors else '; '.join(schema_errors))
    add_check(checks, errors, 'all_object_schemas_closed', not closed_errors,
              'all object schemas use additionalProperties=false' if not closed_errors else '; '.join(closed_errors))

    data_json_paths = []
    for path in sorted(root.rglob('*.json')):
        rel = path.relative_to(root).as_posix()
        if rel.startswith('VERIFY/schemas/'):
            continue
        if rel == 'VERIFY/PACKAGE-VERIFICATION.json' and not path.exists():
            continue
        data_json_paths.append(path)

    loaded: dict[str, Any] = {}
    validation_errors: list[str] = []
    for path in data_json_paths:
        rel = path.relative_to(root).as_posix()
        try:
            value = load_json(path)
            loaded[rel] = value
            schema_ref = value.get('$schema') if isinstance(value, dict) else None
            if not isinstance(schema_ref, str):
                validation_errors.append(f'{rel}: missing $schema')
                continue
            schema_path = root / schema_ref
            if not schema_path.is_file():
                validation_errors.append(f'{rel}: schema not found: {schema_ref}')
                continue
            Draft202012Validator(load_json(schema_path)).validate(value)
            counts['json_artifacts_validated'] += 1
        except Exception as exc:
            validation_errors.append(f'{rel}: {exc}')
    add_check(checks, errors, 'all_json_validate_against_closed_schemas', not validation_errors,
              'all data JSON valid' if not validation_errors else '; '.join(validation_errors))

    source_errors: list[str] = []
    for rel, value in loaded.items():
        for node in walk(value):
            if isinstance(node, dict) and SOURCE_REF_KEYS.issubset(node.keys()):
                source_set = node['source_set']
                if source_set not in source_roots:
                    source_errors.append(f'{rel}: unknown source set {source_set}')
                    continue
                path = source_roots[source_set] / node['path']
                if not path.is_file():
                    source_errors.append(f'{rel}: missing source {source_set}/{node["path"]}')
                    continue
                actual_file = sha256_file(path)
                if actual_file != node['file_sha256']:
                    source_errors.append(f'{rel}: file hash mismatch {source_set}/{node["path"]}')
                    continue
                lines = path.read_text(encoding='utf-8', errors='replace').splitlines(keepends=True)
                a, b = node['start_line'], node['end_line']
                if not isinstance(a, int) or not isinstance(b, int) or a < 1 or b < a or b > len(lines):
                    source_errors.append(f'{rel}: invalid span {source_set}/{node["path"]}:{a}-{b}')
                    continue
                span = ''.join(lines[a-1:b]).encode('utf-8')
                if sha256_bytes(span) != node['span_sha256']:
                    source_errors.append(f'{rel}: span hash mismatch {source_set}/{node["path"]}:{a}-{b}')
                    continue
                counts['source_references_verified'] += 1
    add_check(checks, errors, 'source_paths_line_spans_and_hashes', not source_errors,
              f'verified={counts["source_references_verified"]}' if not source_errors else '; '.join(source_errors))

    ids: set[str] = set()
    duplicates: set[str] = set()
    refs: list[str] = []
    bad_ids: list[str] = []
    edition_pattern = re.compile(r'(?i)(?:^|[-_])edition(?:[-_]|$)|@v\d|/v\d|[-_]v\d')
    for rel, value in loaded.items():
        for node in walk(value):
            if not isinstance(node, dict):
                continue
            rid = node.get('record_id')
            if rid is not None:
                if not isinstance(rid, str):
                    bad_ids.append(f'{rel}: non-string record_id')
                else:
                    if rid in ids:
                        duplicates.add(rid)
                    ids.add(rid)
                    if edition_pattern.search(rid):
                        bad_ids.append(f'{rel}: embedded edition in record_id {rid}')
            rr = node.get('record_refs')
            if rr is not None:
                if not isinstance(rr, list) or not all(isinstance(x, str) for x in rr):
                    bad_ids.append(f'{rel}: invalid record_refs')
                else:
                    refs.extend(rr)
    missing_refs = sorted(set(refs) - ids)
    counts['record_identities'] = len(ids)
    counts['record_references'] = len(refs)
    add_check(checks, errors, 'record_identities_unique_and_edition_free', not duplicates and not bad_ids,
              f'ids={len(ids)}' if not duplicates and not bad_ids else f'duplicates={sorted(duplicates)} errors={bad_ids}')
    add_check(checks, errors, 'cross_file_record_references_resolve', not missing_refs,
              f'references={len(refs)}' if not missing_refs else f'missing={missing_refs}')

    coverage = loaded.get('CON-CMP-COVERAGE-MATRIX.json', {})
    con_rows = coverage.get('constitution_coordinates', [])
    cmp_rows = coverage.get('compiler_coordinates', [])
    coverage_errors: list[str] = []
    if {r.get('coordinate') for r in con_rows} != {f'CON-{i:03d}' for i in range(1, 14)}:
        coverage_errors.append('CON coordinate set is not exactly CON-001..CON-013')
    if {r.get('coordinate') for r in cmp_rows} != {f'CMP-{i:03d}' for i in range(1, 13)}:
        coverage_errors.append('CMP coordinate set is not exactly CMP-001..CMP-012')
    for row in con_rows + cmp_rows:
        missing = REQUIRED_DIMENSIONS - set(row.keys())
        if missing:
            coverage_errors.append(f'{row.get("coordinate")}: missing dimensions {sorted(missing)}')
        for dim in REQUIRED_DIMENSIONS - {'certification'}:
            value = row.get(dim)
            if not isinstance(value, dict) or set(value.keys()) != {'state', 'note', 'evidence'}:
                coverage_errors.append(f'{row.get("coordinate")}: malformed {dim}')
        if row.get('certification') != 'NONE':
            coverage_errors.append(f'{row.get("coordinate")}: certification is not NONE')
    add_check(checks, errors, 'con_cmp_coverage_dimensions_exact', not coverage_errors,
              '13 CON + 12 CMP rows with separate dimensions' if not coverage_errors else '; '.join(coverage_errors))

    vectors_doc = loaded.get('INTEGRATION-TEST-VECTORS.json', {})
    vectors = vectors_doc.get('vectors', [])
    counts['integration_test_vectors'] = len(vectors)
    by_transition: dict[str, set[str]] = defaultdict(set)
    for vector in vectors:
        by_transition[vector.get('transition_id')].add(vector.get('category'))
    vector_errors = []
    expected_transitions = {f'T{i:02d}' for i in range(11)}
    if set(by_transition) != expected_transitions:
        vector_errors.append(f'transitions={sorted(by_transition)} expected={sorted(expected_transitions)}')
    for tid in expected_transitions:
        if by_transition.get(tid, set()) != REQUIRED_TEST_CATEGORIES:
            vector_errors.append(f'{tid}: categories={sorted(by_transition.get(tid, set()))}')
    if len(vectors) != 77:
        vector_errors.append(f'vector count={len(vectors)} expected=77')
    add_check(checks, errors, 'integration_vector_matrix_complete', not vector_errors,
              '11 transitions × 7 categories = 77 vectors' if not vector_errors else '; '.join(vector_errors))

    dag_errors: list[str] = []
    for rel in ('CURRENT-EXECUTION-DAG.json', 'CORRECTED-EXECUTION-DAG.json'):
        doc = loaded.get(rel, {})
        for graph_name in ('rust_dependency_dag', 'artifact_production_dag', 'proof_reference_graph'):
            graph = doc.get(graph_name, {})
            ca = graph.get('cycle_analysis', {})
            if ca.get('acyclic') is not True:
                dag_errors.append(f'{rel}:{graph_name} not marked acyclic')
            nodes = graph.get('nodes', [])
            edges = graph.get('edges', [])
            if graph_name == 'rust_dependency_dag':
                node_values = [n.get('crate') for n in nodes]
                edge_values = [(e.get('from_crate'), e.get('to_crate')) for e in edges]
            elif graph_name == 'artifact_production_dag':
                node_values = [n.get('artifact') for n in nodes]
                edge_values = [(e.get('from_artifact'), e.get('to_artifact')) for e in edges]
            else:
                node_values = [n.get('proof') for n in nodes]
                edge_values = [(e.get('from_proof'), e.get('to_proof')) for e in edges]
            if any(v is None for v in node_values) or any(a is None or b is None for a, b in edge_values):
                dag_errors.append(f'{rel}:{graph_name} malformed node/edge fields')
                continue
            acyclic, _ = cycle_check(node_values, edge_values)
            if not acyclic:
                dag_errors.append(f'{rel}:{graph_name} independently detected cycle')
    add_check(checks, errors, 'rust_artifact_and_proof_dags_acyclic', not dag_errors,
              'all six checked DAGs acyclic' if not dag_errors else '; '.join(dag_errors))

    manifest = loaded.get('MANIFEST.json')
    manifest_errors: list[str] = []
    payload_root = ''
    manifest_sha = sha256_file(root / 'MANIFEST.json') if (root / 'MANIFEST.json').is_file() else ''
    if not isinstance(manifest, dict):
        manifest_errors.append('MANIFEST.json missing/unreadable')
    else:
        excluded = set(manifest.get('excluded_control_paths', []))
        expected_files = {x.get('path') for x in manifest.get('payload_files', [])}
        actual_files = {
            p.relative_to(root).as_posix()
            for p in root.rglob('*')
            if p.is_file() and p.relative_to(root).as_posix() not in excluded
        }
        if expected_files != actual_files:
            manifest_errors.append(f'payload set mismatch missing={sorted(expected_files-actual_files)} extra={sorted(actual_files-expected_files)}')
        rows = []
        for entry in manifest.get('payload_files', []):
            rel = entry.get('path')
            path = root / rel
            if not path.is_file():
                manifest_errors.append(f'missing payload {rel}')
                continue
            actual_hash = sha256_file(path)
            actual_size = path.stat().st_size
            if actual_hash != entry.get('sha256') or actual_size != entry.get('size_bytes'):
                manifest_errors.append(f'payload mismatch {rel}')
            rows.append(f'{rel}\0{actual_hash}\0{actual_size}\n')
        payload_root = sha256_bytes(''.join(sorted(rows)).encode('utf-8'))
        if payload_root != manifest.get('payload_root_sha256'):
            manifest_errors.append('payload root mismatch')
    add_check(checks, errors, 'manifest_file_set_hashes_and_root', not manifest_errors,
              f'payload_root={payload_root}' if not manifest_errors else '; '.join(manifest_errors))

    exact_artifact_set = {
        'CURRENT-EXECUTION-DAG.json', 'CORRECTED-EXECUTION-DAG.json',
        'AUTHORITY-ISSUANCE-MATRIX.json', 'VALUE-AND-PROOF-OWNERSHIP.json',
        'CON-CMP-COVERAGE-MATRIX.json', 'UNREACHABLE-PATHS.json',
        'SPEC-CODE-DELTAS.json', 'DELETION-AND-TOMBSTONE-PLAN.json',
        'RUST-API-CORRECTIONS.json', 'INTEGRATION-TEST-VECTORS.json',
        'IMPLEMENTATION-ORDER.json', 'OPEN-DECISIONS.json',
        'ARTIFACT-LADDER-RULING.json', 'MANIFEST.json',
        'VERIFY/SOURCE-VERIFICATION.json'
    }
    missing_data = sorted(exact_artifact_set - set(loaded))
    add_check(checks, errors, 'required_machine_artifacts_present', not missing_data,
              'all required machine artifacts present' if not missing_data else f'missing={missing_data}')

    passed = not errors
    report = {
        '$schema': 'VERIFY/schemas/PACKAGE-VERIFICATION.schema.json',
        'package_id': 'SAN-CON-CMP-STAGE0-CORRECTION-PACKAGE',
        'status': 'PROPOSED',
        'certification': 'NONE',
        'passed': passed,
        'errors': errors,
        'checks': checks,
        'counts': counts,
        'manifest_sha256': manifest_sha,
        'payload_root_sha256': payload_root,
        'source_roots_used': {k: str(v) for k, v in source_roots.items()},
        'limitations': [
            'This verifier validates package structure, citations, hashes, cross-references and declared DAG/test coverage.',
            'It does not compile Rust because cargo is unavailable in the audit execution environment.',
            'It does not certify semantics or production eligibility.',
        ],
    }
    report_out.parent.mkdir(parents=True, exist_ok=True)
    report_out.write_text(json.dumps(report, sort_keys=True, indent=2) + '\n', encoding='utf-8')

    report_schema = load_json(root / 'VERIFY/schemas/PACKAGE-VERIFICATION.schema.json')
    try:
        Draft202012Validator(report_schema).validate(report)
    except Exception as exc:
        print(f'package verification report schema failure: {exc}', file=sys.stderr)
        return 2

    print(json.dumps({'passed': passed, 'errors': errors, 'checks': len(checks), 'counts': counts}, sort_keys=True))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
