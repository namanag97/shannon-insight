# SAN Digital Systems Domain Atlas

Navigation for the machine-readable candidate corpus. JSON and JSONL are authoritative; Markdown is not.

## Start here

- `manifest.json` — package identity, scope, counts, and file inventory.
- `VALIDATION.json` — mechanical validation results and unresolved duplicate warnings.
- `coverage/coverage_matrix.json` — populated coverage and declared limits.
- `coverage/boundary_evaluation.json` — all candidate boundary tests and dispositions.
- `generated/index.json` — record ID to JSONL path and line.
- `registry_intake/` — non-ratified crosswalks and intake proposals; the supplied registry is not mutated.
- `issues/` — conflicts, gaps, unresolved compiler boundaries, and unresolved external seams.
- `schemas/` and `vocabularies/` — Draft 2020-12 record schemas and closed corpus vocabularies.

## Canonical handling

Each JSONL line is one independently addressable record. Validate it against the schema selected by its `kind` in `generated/index.json`. References use identifiers, not display names. `CHECKSUMS.txt` covers every package file except itself.

## Corpus posture

This is a research corpus and boundary hypothesis package, not registry ratification, software, a compiler, a runtime, or a deployment.
