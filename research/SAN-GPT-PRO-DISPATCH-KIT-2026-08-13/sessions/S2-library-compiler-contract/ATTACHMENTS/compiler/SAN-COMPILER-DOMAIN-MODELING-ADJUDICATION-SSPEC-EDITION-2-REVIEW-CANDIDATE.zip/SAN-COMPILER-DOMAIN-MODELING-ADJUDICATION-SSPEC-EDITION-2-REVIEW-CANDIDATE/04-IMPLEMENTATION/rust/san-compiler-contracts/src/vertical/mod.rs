//! Executable constitutional application-compilation reference vertical.
//!
//! CMP-006 emits `ApplicationBinding`; CMP-007 emits `ObligationClosure`;
//! CMP-008 emits the already-verified-and-sealed `Csag`; CMP-009 emits target
//! compilations; RUN supplies portable runtime requirement closure; CMP-013
//! alone emits final `ApplicationClosure`; CMP-010 emits provider-neutral
//! `AppRelease`. Concrete provider binding occurs only in deployment planning.

mod model;
mod pipeline;

pub use model::*;
pub use pipeline::*;

#[cfg(any(test, feature = "fixture"))]
pub mod fixture;
